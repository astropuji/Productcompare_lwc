require('./server').start();
