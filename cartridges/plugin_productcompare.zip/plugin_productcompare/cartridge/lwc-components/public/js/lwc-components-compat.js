(function () {
  'use strict';

  var __concat = Proxy.concat;

  var __callKey2 = Proxy.callKey2;

  var __setKey = Proxy.setKey;

  var __inKey = Proxy.inKey;

  var __setKey$1 = Proxy.setKey;

  function _defineProperty(obj, key, value) {
    if (__inKey(obj, key)) {
      Object.compatDefineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      __setKey$1(obj, key, value);
    }

    return obj;
  }

  var defineProperty = _defineProperty;

  var __callKey1 = Proxy.callKey1;

  function _instanceof(left, right) {
    if (right != null && typeof Symbol !== "undefined" && (right._ES5ProxyType ? right.get(Symbol.hasInstance) : right[Symbol.hasInstance])) {
      return !!__callKey1(right, Symbol.hasInstance, left);
    } else {
      return _instanceof_1(left, right);
    }
  }

  var _instanceof_1 = _instanceof;

  function _classCallCheck(instance, Constructor) {
    if (!_instanceof_1(instance, Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var classCallCheck = _classCallCheck;

  var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

  function commonjsRequire () {
  	throw new Error('Dynamic requires are not currently supported by rollup-plugin-commonjs');
  }

  function unwrapExports (x) {
  	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
  }

  function createCommonjsModule(fn, module) {
  	return module = { exports: {} }, fn(module, module.exports), module.exports;
  }

  function getCjsExportFromNamespace (n) {
  	return n && n['default'] || n;
  }

  var commonjsHelpers = /*#__PURE__*/Object.freeze({
    __proto__: null,
    commonjsGlobal: commonjsGlobal,
    commonjsRequire: commonjsRequire,
    unwrapExports: unwrapExports,
    createCommonjsModule: createCommonjsModule,
    getCjsExportFromNamespace: getCjsExportFromNamespace
  });

  var _typeof_1 = __callKey1(commonjsHelpers, "createCommonjsModule", function (module) {
    function _typeof(obj) {
      "@babel/helpers - typeof";

      if (typeof Symbol === "function" && _typeof_1(Symbol.iterator) === "symbol") {
        __setKey$1(module, "exports", _typeof = function _typeof(obj) {
          return _typeof_1(obj);
        });
      } else {
        __setKey$1(module, "exports", _typeof = function _typeof(obj) {
          return obj && typeof Symbol === "function" && (obj._ES5ProxyType ? obj.get("constructor") : obj.constructor) === Symbol && obj !== Symbol.prototype ? "symbol" : _typeof_1(obj);
        });
      }

      return _typeof(obj);
    }

    __setKey$1(module, "exports", _typeof);
  });

  var _create, _create2;

  /* proxy-compat-disable */
  function invariant(value, msg) {
    if (!value) {
      throw new Error("Invariant Violation: ".concat(msg));
    }
  }

  function isTrue(value, msg) {
    if (!value) {
      throw new Error("Assert Violation: ".concat(msg));
    }
  }

  function isFalse(value, msg) {
    if (value) {
      throw new Error("Assert Violation: ".concat(msg));
    }
  }

  function fail(msg) {
    throw new Error(msg);
  }

  var assert = Object.freeze({
    invariant: invariant,
    isTrue: isTrue,
    isFalse: isFalse,
    fail: fail
  });
  var assign = Object.assign,
      create = Object.create,
      defineProperties = Object.defineProperties,
      defineProperty$1 = Object.defineProperty,
      getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor,
      getPrototypeOf = Object.getPrototypeOf,
      hasOwnProperty = Object.hasOwnProperty,
      setPrototypeOf = Object.setPrototypeOf;
  var isArray = Array.isArray;
  var _Array$prototype = Array.prototype,
      ArrayConstructor = _Array$prototype.constructor,
      ArrayFilter = _Array$prototype.filter,
      ArrayFind = _Array$prototype.find,
      forEach = _Array$prototype.forEach,
      ArrayIndexOf = _Array$prototype.indexOf,
      ArrayJoin = _Array$prototype.join,
      ArrayMap = _Array$prototype.map,
      ArrayPush = _Array$prototype.push,
      ArrayReduce = _Array$prototype.reduce,
      ArrayReverse = _Array$prototype.reverse,
      ArraySlice = _Array$prototype.slice,
      ArraySplice = _Array$prototype.splice,
      ArrayUnshift = _Array$prototype.unshift;
  var _String$prototype = String.prototype,
      StringCharCodeAt = _String$prototype.charCodeAt;

  function isUndefined(obj) {
    return obj === undefined;
  }

  function isNull(obj) {
    return obj === null;
  }

  function isTrue$1(obj) {
    return obj === true;
  }

  function isFalse$1(obj) {
    return obj === false;
  }

  function isFunction(obj) {
    return typeof obj === 'function';
  }

  var OtS = {}.toString;

  function toString(obj) {
    if (obj && obj.toString) {
      if (isArray(obj)) {
        return ArrayJoin.call(ArrayMap.call(obj, toString), ',');
      }

      return obj.toString();
    } else if (_typeof_1(obj) === 'object') {
      return OtS.call(obj);
    } else {
      return obj + emptyString;
    }
  }

  function getPropertyDescriptor(o, p) {
    do {
      var d = getOwnPropertyDescriptor(o, p);

      if (!isUndefined(d)) {
        return d;
      }

      o = getPrototypeOf(o);
    } while (o !== null);
  }

  var emptyString = '';
  var hasNativeSymbolsSupport = Symbol('x').toString() === 'Symbol(x)';

  function createFieldName(key, namespace) {
    return hasNativeSymbolsSupport ? Symbol(key) : "$$lwc-".concat(namespace, "-").concat(key, "$$");
  }

  var hiddenFieldsMap = new WeakMap();

  function setHiddenField(o, fieldName, value) {
    var valuesByField = hiddenFieldsMap.get(o);

    if (isUndefined(valuesByField)) {
      valuesByField = create(null);
      hiddenFieldsMap.set(o, valuesByField);
    }

    valuesByField[fieldName] = value;
  }

  function getHiddenField(o, fieldName) {
    var valuesByField = hiddenFieldsMap.get(o);

    if (!isUndefined(valuesByField)) {
      return valuesByField[fieldName];
    }
  }

  var fields = Object.freeze({
    createFieldName: createFieldName,
    setHiddenField: setHiddenField,
    getHiddenField: getHiddenField
  });
  var _Node = Node,
      DOCUMENT_POSITION_CONTAINED_BY = _Node.DOCUMENT_POSITION_CONTAINED_BY,
      DOCUMENT_POSITION_CONTAINS = _Node.DOCUMENT_POSITION_CONTAINS,
      DOCUMENT_POSITION_PRECEDING = _Node.DOCUMENT_POSITION_PRECEDING,
      DOCUMENT_POSITION_FOLLOWING = _Node.DOCUMENT_POSITION_FOLLOWING,
      ELEMENT_NODE = _Node.ELEMENT_NODE,
      TEXT_NODE = _Node.TEXT_NODE,
      CDATA_SECTION_NODE = _Node.CDATA_SECTION_NODE,
      PROCESSING_INSTRUCTION_NODE = _Node.PROCESSING_INSTRUCTION_NODE,
      COMMENT_NODE = _Node.COMMENT_NODE;
  var _Node$prototype = Node.prototype,
      appendChild = _Node$prototype.appendChild,
      cloneNode = _Node$prototype.cloneNode,
      compareDocumentPosition = _Node$prototype.compareDocumentPosition,
      insertBefore = _Node$prototype.insertBefore,
      removeChild = _Node$prototype.removeChild,
      replaceChild = _Node$prototype.replaceChild,
      hasChildNodes = _Node$prototype.hasChildNodes,
      contains = _Node$prototype.contains;
  var firstChildGetter = getOwnPropertyDescriptor(Node.prototype, 'firstChild').get;
  var lastChildGetter = getOwnPropertyDescriptor(Node.prototype, 'lastChild').get;
  var textContentGetter = getOwnPropertyDescriptor(Node.prototype, 'textContent').get;
  var parentNodeGetter = getOwnPropertyDescriptor(Node.prototype, 'parentNode').get;
  var ownerDocumentGetter = getOwnPropertyDescriptor(Node.prototype, 'ownerDocument').get;
  var parentElementGetter = hasOwnProperty.call(Node.prototype, 'parentElement') ? getOwnPropertyDescriptor(Node.prototype, 'parentElement').get : getOwnPropertyDescriptor(HTMLElement.prototype, 'parentElement').get;
  var textContextSetter = getOwnPropertyDescriptor(Node.prototype, 'textContent').set;
  var childNodesGetter = hasOwnProperty.call(Node.prototype, 'childNodes') ? getOwnPropertyDescriptor(Node.prototype, 'childNodes').get : getOwnPropertyDescriptor(HTMLElement.prototype, 'childNodes').get;
  var isConnected = hasOwnProperty.call(Node.prototype, 'isConnected') ? getOwnPropertyDescriptor(Node.prototype, 'isConnected').get : function () {
    var doc = ownerDocumentGetter.call(this);
    return doc === null || (compareDocumentPosition.call(doc, this) & DOCUMENT_POSITION_CONTAINED_BY) !== 0;
  };
  var _Element$prototype = Element.prototype,
      hasAttribute = _Element$prototype.hasAttribute,
      getAttribute = _Element$prototype.getAttribute,
      setAttribute = _Element$prototype.setAttribute,
      removeAttribute = _Element$prototype.removeAttribute,
      querySelectorAll = _Element$prototype.querySelectorAll,
      getBoundingClientRect = _Element$prototype.getBoundingClientRect,
      getElementsByTagName = _Element$prototype.getElementsByTagName,
      getElementsByTagNameNS = _Element$prototype.getElementsByTagNameNS;
  var _Element$prototype2 = Element.prototype,
      addEventListener = _Element$prototype2.addEventListener,
      removeEventListener = _Element$prototype2.removeEventListener;
  var childElementCountGetter = getOwnPropertyDescriptor(Element.prototype, 'childElementCount').get;
  var firstElementChildGetter = getOwnPropertyDescriptor(Element.prototype, 'firstElementChild').get;
  var lastElementChildGetter = getOwnPropertyDescriptor(Element.prototype, 'lastElementChild').get;
  var innerHTMLDescriptor = hasOwnProperty.call(Element.prototype, 'innerHTML') ? getOwnPropertyDescriptor(Element.prototype, 'innerHTML') : getOwnPropertyDescriptor(HTMLElement.prototype, 'innerHTML');
  var innerHTMLGetter = innerHTMLDescriptor.get;
  var innerHTMLSetter = innerHTMLDescriptor.set;
  var outerHTMLDescriptor = hasOwnProperty.call(Element.prototype, 'outerHTML') ? getOwnPropertyDescriptor(Element.prototype, 'outerHTML') : getOwnPropertyDescriptor(HTMLElement.prototype, 'outerHTML');
  var outerHTMLGetter = outerHTMLDescriptor.get;
  var outerHTMLSetter = outerHTMLDescriptor.set;
  var tagNameGetter = getOwnPropertyDescriptor(Element.prototype, 'tagName').get;
  var tabIndexDescriptor = getOwnPropertyDescriptor(HTMLElement.prototype, 'tabIndex');
  var tabIndexGetter = tabIndexDescriptor.get;
  var tabIndexSetter = tabIndexDescriptor.set;
  var matches = hasOwnProperty.call(Element.prototype, 'matches') ? Element.prototype.matches : Element.prototype.msMatchesSelector;
  var childrenGetter = hasOwnProperty.call(Element.prototype, 'children') ? getOwnPropertyDescriptor(Element.prototype, 'children').get : getOwnPropertyDescriptor(HTMLElement.prototype, 'children').get;
  var getElementsByClassName = HTMLElement.prototype.getElementsByClassName;
  var dispatchEvent = 'EventTarget' in window ? EventTarget.prototype.dispatchEvent : Node.prototype.dispatchEvent;
  var eventTargetGetter = getOwnPropertyDescriptor(Event.prototype, 'target').get;
  var eventCurrentTargetGetter = getOwnPropertyDescriptor(Event.prototype, 'currentTarget').get;
  var focusEventRelatedTargetGetter = getOwnPropertyDescriptor(FocusEvent.prototype, 'relatedTarget').get;
  var DocumentPrototypeActiveElement = getOwnPropertyDescriptor(Document.prototype, 'activeElement').get;
  var elementFromPoint = hasOwnProperty.call(Document.prototype, 'elementFromPoint') ? Document.prototype.elementFromPoint : Document.prototype.msElementFromPoint;
  var defaultViewGetter = getOwnPropertyDescriptor(Document.prototype, 'defaultView').get;
  var _Document$prototype = Document.prototype,
      createComment = _Document$prototype.createComment,
      querySelectorAll$1 = _Document$prototype.querySelectorAll,
      getElementById = _Document$prototype.getElementById,
      getElementsByClassName$1 = _Document$prototype.getElementsByClassName,
      getElementsByTagName$1 = _Document$prototype.getElementsByTagName,
      getElementsByTagNameNS$1 = _Document$prototype.getElementsByTagNameNS;
  var getElementsByName = HTMLDocument.prototype.getElementsByName;
  var _window = window,
      windowAddEventListener = _window.addEventListener,
      windowRemoveEventListener = _window.removeEventListener;
  var MO = MutationObserver;
  var MutationObserverObserve = MO.prototype.observe;

  function detect() {
    return typeof HTMLSlotElement === 'undefined';
  }

  var _document = document,
      createElement = _document.createElement;
  var CHAR_S = 115;
  var CHAR_L = 108;
  var CHAR_O = 111;
  var CHAR_T = 116;

  function apply() {
    var HTMLSlotElement = function HTMLSlotElement() {
      classCallCheck(this, HTMLSlotElement);
    };

    setPrototypeOf(HTMLSlotElement, HTMLElement.constructor);
    setPrototypeOf(HTMLSlotElement.prototype, HTMLElement.prototype);
    Window.prototype.HTMLSlotElement = HTMLSlotElement;

    document.createElement = function (name) {
      var elm = createElement.apply(this, ArraySlice.call(arguments));

      if (name.length === 4 && StringCharCodeAt.call(name, 0) === CHAR_S && StringCharCodeAt.call(name, 1) === CHAR_L && StringCharCodeAt.call(name, 2) === CHAR_O && StringCharCodeAt.call(name, 3) === CHAR_T) {
        setPrototypeOf(elm, HTMLSlotElement.prototype);
      }

      return elm;
    };
  }

  if (detect()) {
    apply();
  }

  function getOwnerDocument(node) {
    var doc = ownerDocumentGetter.call(node);
    return doc === null ? node : doc;
  }

  function getOwnerWindow(node) {
    var doc = getOwnerDocument(node);
    var win = defaultViewGetter.call(doc);

    if (win === null) {
      throw new TypeError();
    }

    return win;
  }

  var skipGlobalPatching;

  function isGlobalPatchingSkipped(node) {
    if (isUndefined(skipGlobalPatching)) {
      var ownerDocument = getOwnerDocument(node);
      skipGlobalPatching = ownerDocument.body && getAttribute.call(ownerDocument.body, 'data-global-patching-bypass') === 'temporary-bypass';
    }

    return isTrue$1(skipGlobalPatching);
  }

  function arrayFromCollection(collection) {
    var size = collection.length;
    var cloned = new ArrayConstructor(size);

    if (size > 0) {
      for (var i = 0; i < size; i++) {
        cloned[i] = collection[i];
      }
    }

    return cloned;
  }

  function pathComposer(startNode, composed) {
    var composedPath = [];
    var current = startNode;
    var startRoot = _instanceof_1(startNode, Window) ? startNode : startNode.getRootNode();

    while (!isNull(current)) {
      composedPath.push(current);
      var assignedSlot = null;

      if (_instanceof_1(current, Element)) {
        assignedSlot = current.assignedSlot;
      }

      if (!isNull(assignedSlot)) {
        current = assignedSlot;
      } else if (_instanceof_1(current, ShadowRoot) && (composed || current !== startRoot)) {
        current = current.host;
      } else {
        current = current.parentNode;
      }
    }

    var doc;

    if (_instanceof_1(startNode, Window)) {
      doc = startNode.document;
    } else {
      doc = getOwnerDocument(startNode);
    }

    if (composedPath[composedPath.length - 1] === doc) {
      composedPath.push(window);
    }

    return composedPath;
  }

  function retarget(refNode, path) {
    if (isNull(refNode)) {
      return null;
    }

    var refNodePath = pathComposer(refNode, true);
    var p$ = path;

    for (var i = 0, ancestor, lastRoot, root, rootIdx; i < p$.length; i++) {
      ancestor = p$[i];
      root = _instanceof_1(ancestor, Window) ? ancestor : ancestor.getRootNode();

      if (root !== lastRoot) {
        rootIdx = refNodePath.indexOf(root);
        lastRoot = root;
      }

      if (!_instanceof_1(root, SyntheticShadowRoot) || rootIdx > -1) {
        return ancestor;
      }
    }

    return null;
  }

  var EventListenerContext;

  (function (EventListenerContext) {
    EventListenerContext[EventListenerContext["CUSTOM_ELEMENT_LISTENER"] = 1] = "CUSTOM_ELEMENT_LISTENER";
    EventListenerContext[EventListenerContext["SHADOW_ROOT_LISTENER"] = 2] = "SHADOW_ROOT_LISTENER";
  })(EventListenerContext || (EventListenerContext = {}));

  var eventToContextMap = new WeakMap();

  function isChildNode(root, node) {
    return !!(compareDocumentPosition.call(root, node) & DOCUMENT_POSITION_CONTAINED_BY);
  }

  var GET_ROOT_NODE_CONFIG_FALSE = {
    composed: false
  };

  function getRootNodeHost(node, options) {
    var rootNode = node.getRootNode(options);

    if ('mode' in rootNode && 'delegatesFocus' in rootNode) {
      rootNode = getHost(rootNode);
    }

    return rootNode;
  }

  function targetGetter() {
    var originalCurrentTarget = eventCurrentTargetGetter.call(this);
    var originalTarget = eventTargetGetter.call(this);
    var composedPath = pathComposer(originalTarget, this.composed);
    var doc = getOwnerDocument(originalTarget);

    if (!_instanceof_1(originalCurrentTarget, Node)) {
      if (isNull(originalCurrentTarget) && isUndefined(getNodeOwnerKey(originalTarget))) {
        return originalTarget;
      }

      return retarget(doc, composedPath);
    } else if (originalCurrentTarget === doc || originalCurrentTarget === doc.body) {
      if (isUndefined(getNodeOwnerKey(originalTarget))) {
        return originalTarget;
      }

      return retarget(doc, composedPath);
    }

    var eventContext = eventToContextMap.get(this);
    var currentTarget = eventContext === EventListenerContext.SHADOW_ROOT_LISTENER ? getShadowRoot(originalCurrentTarget) : originalCurrentTarget;
    return retarget(currentTarget, composedPath);
  }

  function composedPathValue() {
    var originalTarget = eventTargetGetter.call(this);
    var originalCurrentTarget = eventCurrentTargetGetter.call(this);
    return isNull(originalCurrentTarget) ? [] : pathComposer(originalTarget, this.composed);
  }

  function patchEvent(event) {
    if (eventToContextMap.has(event)) {
      return;
    }

    defineProperties(event, {
      target: {
        get: targetGetter,
        enumerable: true,
        configurable: true
      },
      composedPath: {
        value: composedPathValue,
        writable: true,
        enumerable: true,
        configurable: true
      },
      srcElement: {
        get: targetGetter,
        enumerable: true,
        configurable: true
      },
      path: {
        get: composedPathValue,
        enumerable: true,
        configurable: true
      }
    });
    var originalRelatedTargetDescriptor = getPropertyDescriptor(event, 'relatedTarget');

    if (!isUndefined(originalRelatedTargetDescriptor)) {
      var relatedTargetGetter = originalRelatedTargetDescriptor.get;
      defineProperty$1(event, 'relatedTarget', {
        get: function get() {
          var eventContext = eventToContextMap.get(this);
          var originalCurrentTarget = eventCurrentTargetGetter.call(this);
          var relatedTarget = relatedTargetGetter.call(this);

          if (isNull(relatedTarget)) {
            return null;
          }

          var currentTarget = eventContext === EventListenerContext.SHADOW_ROOT_LISTENER ? getShadowRoot(originalCurrentTarget) : originalCurrentTarget;
          return retarget(currentTarget, pathComposer(relatedTarget, true));
        },
        enumerable: true,
        configurable: true
      });
    }

    eventToContextMap.set(event, 0);
  }

  var customElementToWrappedListeners = new WeakMap();

  function getEventMap(elm) {
    var listenerInfo = customElementToWrappedListeners.get(elm);

    if (isUndefined(listenerInfo)) {
      listenerInfo = create(null);
      customElementToWrappedListeners.set(elm, listenerInfo);
    }

    return listenerInfo;
  }

  var shadowRootEventListenerMap = new WeakMap();

  function getWrappedShadowRootListener(sr, listener) {
    if (!isFunction(listener)) {
      throw new TypeError();
    }

    var shadowRootWrappedListener = shadowRootEventListenerMap.get(listener);

    if (isUndefined(shadowRootWrappedListener)) {
      shadowRootWrappedListener = function shadowRootWrappedListener(event) {
        var composed = event.composed;
        var target = eventTargetGetter.call(event);
        var currentTarget = eventCurrentTargetGetter.call(event);

        if (target !== currentTarget) {
          var rootNode = getRootNodeHost(target, {
            composed: composed
          });

          if (isChildNode(rootNode, currentTarget) || composed === false && rootNode === currentTarget) {
            listener.call(sr, event);
          }
        }
      };

      shadowRootWrappedListener.placement = EventListenerContext.SHADOW_ROOT_LISTENER;

      {
        shadowRootWrappedListener.original = listener;
      }

      shadowRootEventListenerMap.set(listener, shadowRootWrappedListener);
    }

    return shadowRootWrappedListener;
  }

  var customElementEventListenerMap = new WeakMap();

  function getWrappedCustomElementListener(elm, listener) {
    if (!isFunction(listener)) {
      throw new TypeError();
    }

    var customElementWrappedListener = customElementEventListenerMap.get(listener);

    if (isUndefined(customElementWrappedListener)) {
      customElementWrappedListener = function customElementWrappedListener(event) {
        if (isValidEventForCustomElement(event)) {
          listener.call(elm, event);
        }
      };

      customElementWrappedListener.placement = EventListenerContext.CUSTOM_ELEMENT_LISTENER;

      {
        customElementWrappedListener.original = listener;
      }

      customElementEventListenerMap.set(listener, customElementWrappedListener);
    }

    return customElementWrappedListener;
  }

  function domListener(evt) {
    patchEvent(evt);
    var immediatePropagationStopped = false;
    var propagationStopped = false;
    var type = evt.type,
        stopImmediatePropagation = evt.stopImmediatePropagation,
        stopPropagation = evt.stopPropagation;
    var currentTarget = eventCurrentTargetGetter.call(evt);
    var listenerMap = getEventMap(currentTarget);
    var listeners = listenerMap[type];
    defineProperty$1(evt, 'stopImmediatePropagation', {
      value: function value() {
        immediatePropagationStopped = true;
        stopImmediatePropagation.call(evt);
      },
      writable: true,
      enumerable: true,
      configurable: true
    });
    defineProperty$1(evt, 'stopPropagation', {
      value: function value() {
        propagationStopped = true;
        stopPropagation.call(evt);
      },
      writable: true,
      enumerable: true,
      configurable: true
    });
    var bookkeeping = ArraySlice.call(listeners);

    function invokeListenersByPlacement(placement) {
      forEach.call(bookkeeping, function (listener) {
        if (isFalse$1(immediatePropagationStopped) && listener.placement === placement) {
          if (ArrayIndexOf.call(listeners, listener) !== -1) {
            listener.call(undefined, evt);
          }
        }
      });
    }

    eventToContextMap.set(evt, EventListenerContext.SHADOW_ROOT_LISTENER);
    invokeListenersByPlacement(EventListenerContext.SHADOW_ROOT_LISTENER);

    if (isFalse$1(immediatePropagationStopped) && isFalse$1(propagationStopped)) {
      eventToContextMap.set(evt, EventListenerContext.CUSTOM_ELEMENT_LISTENER);
      invokeListenersByPlacement(EventListenerContext.CUSTOM_ELEMENT_LISTENER);
    }

    eventToContextMap.set(evt, 0);
  }

  function attachDOMListener(elm, type, wrappedListener) {
    var listenerMap = getEventMap(elm);
    var cmpEventHandlers = listenerMap[type];

    if (isUndefined(cmpEventHandlers)) {
      cmpEventHandlers = listenerMap[type] = [];
    }

    if (cmpEventHandlers.length === 0) {
      addEventListener.call(elm, type, domListener);
    }

    ArrayPush.call(cmpEventHandlers, wrappedListener);
  }

  function detachDOMListener(elm, type, wrappedListener) {
    var listenerMap = getEventMap(elm);
    var p;
    var listeners;

    if (!isUndefined(listeners = listenerMap[type]) && (p = ArrayIndexOf.call(listeners, wrappedListener)) !== -1) {
      ArraySplice.call(listeners, p, 1);

      if (listeners.length === 0) {
        removeEventListener.call(elm, type, domListener);
      }
    }
  }

  function isValidEventForCustomElement(event) {
    var target = eventTargetGetter.call(event);
    var currentTarget = eventCurrentTargetGetter.call(event);
    var composed = event.composed;
    return composed === true || target === currentTarget || isChildNode(getRootNodeHost(target, GET_ROOT_NODE_CONFIG_FALSE), currentTarget);
  }

  function addCustomElementEventListener(elm, type, listener, _options) {
    {
      if (!isFunction(listener)) {
        throw new TypeError("Invalid second argument for Element.addEventListener() in ".concat(toString(elm), " for event \"").concat(type, "\". Expected an EventListener but received ").concat(listener, "."));
      }
    }

    var wrappedListener = getWrappedCustomElementListener(elm, listener);
    attachDOMListener(elm, type, wrappedListener);
  }

  function removeCustomElementEventListener(elm, type, listener, _options) {
    var wrappedListener = getWrappedCustomElementListener(elm, listener);
    detachDOMListener(elm, type, wrappedListener);
  }

  function addShadowRootEventListener(sr, type, listener, _options) {
    {
      if (!isFunction(listener)) {
        throw new TypeError("Invalid second argument for ShadowRoot.addEventListener() in ".concat(toString(sr), " for event \"").concat(type, "\". Expected an EventListener but received ").concat(listener, "."));
      }
    }

    var elm = getHost(sr);
    var wrappedListener = getWrappedShadowRootListener(sr, listener);
    attachDOMListener(elm, type, wrappedListener);
  }

  function removeShadowRootEventListener(sr, type, listener, _options) {
    var elm = getHost(sr);
    var wrappedListener = getWrappedShadowRootListener(sr, listener);
    detachDOMListener(elm, type, wrappedListener);
  }

  function getTextContent(node) {
    switch (node.nodeType) {
      case ELEMENT_NODE:
        {
          var childNodes = getFilteredChildNodes(node);
          var content = '';

          for (var i = 0, len = childNodes.length; i < len; i += 1) {
            var currentNode = childNodes[i];

            if (currentNode.nodeType !== COMMENT_NODE) {
              content += getTextContent(currentNode);
            }
          }

          return content;
        }

      default:
        return node.nodeValue;
    }
  }

  var createFieldName$1 = fields.createFieldName,
      getHiddenField$1 = fields.getHiddenField,
      setHiddenField$1 = fields.setHiddenField;
  var Items = createFieldName$1('items', 'synthetic-shadow');

  function StaticNodeList() {
    throw new TypeError('Illegal constructor');
  }

  StaticNodeList.prototype = create(NodeList.prototype, (_create = {
    constructor: {
      writable: true,
      configurable: true,
      value: StaticNodeList
    },
    item: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(index) {
        return this[index];
      }
    },
    length: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return getHiddenField$1(this, Items).length;
      }
    },
    forEach: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(cb, thisArg) {
        forEach.call(getHiddenField$1(this, Items), cb, thisArg);
      }
    },
    entries: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        return ArrayMap.call(getHiddenField$1(this, Items), function (v, i) {
          return [i, v];
        });
      }
    },
    keys: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        return ArrayMap.call(getHiddenField$1(this, Items), function (v, i) {
          return i;
        });
      }
    },
    values: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        return getHiddenField$1(this, Items);
      }
    }
  }, defineProperty(_create, Symbol.iterator, {
    writable: true,
    configurable: true,
    value: function value() {
      var _this = this;

      var nextIndex = 0;
      return {
        next: function next() {
          var items = getHiddenField$1(_this, Items);
          return nextIndex < items.length ? {
            value: items[nextIndex++],
            done: false
          } : {
            done: true
          };
        }
      };
    }
  }), defineProperty(_create, Symbol.toStringTag, {
    configurable: true,
    get: function get() {
      return 'NodeList';
    }
  }), defineProperty(_create, "toString", {
    writable: true,
    configurable: true,
    value: function value() {
      return '[object NodeList]';
    }
  }), _create));
  setPrototypeOf(StaticNodeList, NodeList);

  function createStaticNodeList(items) {
    var nodeList = create(StaticNodeList.prototype);
    setHiddenField$1(nodeList, Items, items);
    forEach.call(items, function (item, index) {
      defineProperty$1(nodeList, index, {
        value: item,
        enumerable: true,
        configurable: true
      });
    });
    return nodeList;
  }

  var createFieldName$2 = fields.createFieldName,
      getHiddenField$2 = fields.getHiddenField,
      setHiddenField$2 = fields.setHiddenField;
  var Items$1 = createFieldName$2('items');

  function isValidHTMLCollectionName(name) {
    return name !== 'length' && isNaN(name);
  }

  function getNodeHTMLCollectionName(node) {
    return node.getAttribute('id') || node.getAttribute('name');
  }

  function StaticHTMLCollection() {
    throw new TypeError('Illegal constructor');
  }

  StaticHTMLCollection.prototype = create(HTMLCollection.prototype, (_create2 = {
    constructor: {
      writable: true,
      configurable: true,
      value: StaticHTMLCollection
    },
    item: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(index) {
        return this[index];
      }
    },
    length: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return getHiddenField$2(this, Items$1).length;
      }
    },
    namedItem: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(name) {
        if (isValidHTMLCollectionName(name) && this[name]) {
          return this[name];
        }

        var items = getHiddenField$2(this, Items$1);

        for (var len = items.length - 1; len >= 0; len -= 1) {
          var item = items[len];
          var nodeName = getNodeHTMLCollectionName(item);

          if (nodeName === name) {
            return item;
          }
        }

        return null;
      }
    },
    forEach: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(cb, thisArg) {
        forEach.call(getHiddenField$2(this, Items$1), cb, thisArg);
      }
    },
    entries: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        return ArrayMap.call(getHiddenField$2(this, Items$1), function (v, i) {
          return [i, v];
        });
      }
    },
    keys: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        return ArrayMap.call(getHiddenField$2(this, Items$1), function (v, i) {
          return i;
        });
      }
    },
    values: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        return getHiddenField$2(this, Items$1);
      }
    }
  }, defineProperty(_create2, Symbol.iterator, {
    writable: true,
    configurable: true,
    value: function value() {
      var _this2 = this;

      var nextIndex = 0;
      return {
        next: function next() {
          var items = getHiddenField$2(_this2, Items$1);
          return nextIndex < items.length ? {
            value: items[nextIndex++],
            done: false
          } : {
            done: true
          };
        }
      };
    }
  }), defineProperty(_create2, Symbol.toStringTag, {
    configurable: true,
    get: function get() {
      return 'HTMLCollection';
    }
  }), defineProperty(_create2, "toString", {
    writable: true,
    configurable: true,
    value: function value() {
      return '[object HTMLCollection]';
    }
  }), _create2));
  setPrototypeOf(StaticHTMLCollection, HTMLCollection);

  function createStaticHTMLCollection(items) {
    var collection = create(StaticHTMLCollection.prototype);
    setHiddenField$2(collection, Items$1, items);
    forEach.call(items, function (item, index) {
      defineProperty$1(collection, index, {
        value: item,
        enumerable: true,
        configurable: true
      });
    });
    return collection;
  }

  function getInnerHTML(node) {
    var s = '';
    var childNodes = getFilteredChildNodes(node);

    for (var i = 0, len = childNodes.length; i < len; i += 1) {
      s += getOuterHTML(childNodes[i]);
    }

    return s;
  }

  var escapeAttrRegExp = /[&\u00A0"]/g;
  var escapeDataRegExp = /[&\u00A0<>]/g;
  var _String$prototype2 = String.prototype,
      replace = _String$prototype2.replace,
      toLowerCase = _String$prototype2.toLowerCase;

  function escapeReplace(c) {
    switch (c) {
      case '&':
        return '&amp;';

      case '<':
        return '&lt;';

      case '>':
        return '&gt;';

      case '"':
        return '&quot;';

      case "\xA0":
        return '&nbsp;';

      default:
        return '';
    }
  }

  function escapeAttr(s) {
    return replace.call(s, escapeAttrRegExp, escapeReplace);
  }

  function escapeData(s) {
    return replace.call(s, escapeDataRegExp, escapeReplace);
  }

  var voidElements = new Set(['AREA', 'BASE', 'BR', 'COL', 'COMMAND', 'EMBED', 'HR', 'IMG', 'INPUT', 'KEYGEN', 'LINK', 'META', 'PARAM', 'SOURCE', 'TRACK', 'WBR']);
  var plaintextParents = new Set(['STYLE', 'SCRIPT', 'XMP', 'IFRAME', 'NOEMBED', 'NOFRAMES', 'PLAINTEXT', 'NOSCRIPT']);

  function getOuterHTML(node) {
    switch (node.nodeType) {
      case ELEMENT_NODE:
        {
          var attrs = node.attributes;
          var tagName = tagNameGetter.call(node);
          var s = '<' + toLowerCase.call(tagName);

          for (var i = 0, attr; attr = attrs[i]; i++) {
            s += ' ' + attr.name + '="' + escapeAttr(attr.value) + '"';
          }

          s += '>';

          if (voidElements.has(tagName)) {
            return s;
          }

          return s + getInnerHTML(node) + '</' + toLowerCase.call(tagName) + '>';
        }

      case TEXT_NODE:
        {
          var data = node.data,
              parentNode = node.parentNode;

          if (_instanceof_1(parentNode, Element) && plaintextParents.has(tagNameGetter.call(parentNode))) {
            return data;
          }

          return escapeData(data);
        }

      case CDATA_SECTION_NODE:
        {
          return "<!CDATA[[".concat(node.data, "]]>");
        }

      case PROCESSING_INSTRUCTION_NODE:
        {
          return "<?".concat(node.target, " ").concat(node.data, "?>");
        }

      case COMMENT_NODE:
        {
          return "<!--".concat(node.data, "-->");
        }

      default:
        {
          return '';
        }
    }
  }

  var getHiddenField$3 = fields.getHiddenField,
      setHiddenField$3 = fields.setHiddenField,
      createFieldName$3 = fields.createFieldName;
  var ShadowRootResolverKey = '$shadowResolver$';
  var InternalSlot = createFieldName$3('shadowRecord', 'synthetic-shadow');
  var _document2 = document,
      createDocumentFragment = _document2.createDocumentFragment;

  function getInternalSlot(root) {
    var record = getHiddenField$3(root, InternalSlot);

    if (isUndefined(record)) {
      throw new TypeError();
    }

    return record;
  }

  var ShadowResolverPrivateKey = '$$ShadowResolverKey$$';
  defineProperty$1(Node.prototype, ShadowRootResolverKey, {
    set: function set(fn) {
      this[ShadowResolverPrivateKey] = fn;
      setNodeOwnerKey(this, fn.nodeKey);
    },
    get: function get() {
      return this[ShadowResolverPrivateKey];
    },
    configurable: true,
    enumerable: true
  });

  function getShadowRootResolver(node) {
    return node[ShadowRootResolverKey];
  }

  function setShadowRootResolver(node, fn) {
    node[ShadowRootResolverKey] = fn;
  }

  function isDelegatingFocus(host) {
    return getInternalSlot(host).delegatesFocus;
  }

  function getHost(root) {
    return getInternalSlot(root).host;
  }

  function getShadowRoot(elm) {
    return getInternalSlot(elm).shadowRoot;
  }

  function isHostElement(elm) {
    return !isUndefined(getHiddenField$3(elm, InternalSlot));
  }

  var uid = 0;

  function attachShadow(elm, options) {
    if (!isUndefined(getHiddenField$3(elm, InternalSlot))) {
      throw new Error("Failed to execute 'attachShadow' on 'Element': Shadow root cannot be created on a host which already hosts a shadow tree.");
    }

    var mode = options.mode,
        delegatesFocus = options.delegatesFocus;
    var doc = getOwnerDocument(elm);
    var sr = createDocumentFragment.call(doc);
    var record = {
      mode: mode,
      delegatesFocus: !!delegatesFocus,
      host: elm,
      shadowRoot: sr
    };
    setHiddenField$3(sr, InternalSlot, record);
    setHiddenField$3(elm, InternalSlot, record);

    var shadowResolver = function shadowResolver() {
      return sr;
    };

    var x = shadowResolver.nodeKey = uid++;
    setNodeKey(elm, x);
    setShadowRootResolver(sr, shadowResolver);
    setPrototypeOf(sr, SyntheticShadowRoot.prototype);
    return sr;
  }

  var SyntheticShadowRootDescriptors = {
    constructor: {
      writable: true,
      configurable: true,
      value: SyntheticShadowRoot
    },
    toString: {
      writable: true,
      configurable: true,
      value: function value() {
        return "[object ShadowRoot]";
      }
    }
  };
  var ShadowRootDescriptors = {
    activeElement: {
      enumerable: true,
      configurable: true,
      get: function get() {
        var host = getHost(this);
        var doc = getOwnerDocument(host);
        var activeElement = DocumentPrototypeActiveElement.call(doc);

        if (isNull(activeElement)) {
          return activeElement;
        }

        if ((compareDocumentPosition.call(host, activeElement) & DOCUMENT_POSITION_CONTAINED_BY) === 0) {
          return null;
        }

        var node = activeElement;

        while (!isNodeOwnedBy(host, node)) {
          node = parentElementGetter.call(node);
        }

        if (isSlotElement(node)) {
          return null;
        }

        return node;
      }
    },
    delegatesFocus: {
      configurable: true,
      get: function get() {
        return getInternalSlot(this).delegatesFocus;
      }
    },
    elementFromPoint: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(left, top) {
        var host = getHost(this);
        var doc = getOwnerDocument(host);
        var element = elementFromPoint.call(doc, left, top);

        if (isNull(element)) {
          return element;
        }

        return retarget(this, pathComposer(element, true));
      }
    },
    elementsFromPoint: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(_left, _top) {
        throw new Error();
      }
    },
    getSelection: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        throw new Error();
      }
    },
    host: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return getHost(this);
      }
    },
    mode: {
      configurable: true,
      get: function get() {
        return getInternalSlot(this).mode;
      }
    },
    styleSheets: {
      enumerable: true,
      configurable: true,
      get: function get() {
        throw new Error();
      }
    }
  };
  var NodePatchDescriptors = {
    insertBefore: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(newChild, refChild) {
        insertBefore.call(getHost(this), newChild, refChild);
        return newChild;
      }
    },
    removeChild: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(oldChild) {
        removeChild.call(getHost(this), oldChild);
        return oldChild;
      }
    },
    appendChild: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(newChild) {
        appendChild.call(getHost(this), newChild);
        return newChild;
      }
    },
    replaceChild: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(newChild, oldChild) {
        replaceChild.call(getHost(this), newChild, oldChild);
        return oldChild;
      }
    },
    addEventListener: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(type, listener, options) {
        addShadowRootEventListener(this, type, listener);
      }
    },
    removeEventListener: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(type, listener, options) {
        removeShadowRootEventListener(this, type, listener);
      }
    },
    baseURI: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return getHost(this).baseURI;
      }
    },
    childNodes: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return createStaticNodeList(shadowRootChildNodes(this));
      }
    },
    compareDocumentPosition: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(otherNode) {
        var host = getHost(this);

        if (this === otherNode) {
          return 0;
        } else if (this.contains(otherNode)) {
          return 20;
        } else if (compareDocumentPosition.call(host, otherNode) & DOCUMENT_POSITION_CONTAINED_BY) {
          return 37;
        } else {
          return 35;
        }
      }
    },
    contains: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(otherNode) {
        if (this === otherNode) {
          return true;
        }

        var host = getHost(this);
        return (compareDocumentPosition.call(host, otherNode) & DOCUMENT_POSITION_CONTAINED_BY) !== 0 && isNodeOwnedBy(host, otherNode);
      }
    },
    firstChild: {
      enumerable: true,
      configurable: true,
      get: function get() {
        var childNodes = getInternalChildNodes(this);
        return childNodes[0] || null;
      }
    },
    lastChild: {
      enumerable: true,
      configurable: true,
      get: function get() {
        var childNodes = getInternalChildNodes(this);
        return childNodes[childNodes.length - 1] || null;
      }
    },
    hasChildNodes: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value() {
        var childNodes = getInternalChildNodes(this);
        return childNodes.length > 0;
      }
    },
    isConnected: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return isConnected.call(getHost(this));
      }
    },
    nextSibling: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return null;
      }
    },
    previousSibling: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return null;
      }
    },
    nodeName: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return '#document-fragment';
      }
    },
    nodeType: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return 11;
      }
    },
    nodeValue: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return null;
      }
    },
    ownerDocument: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return getHost(this).ownerDocument;
      }
    },
    parentElement: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return null;
      }
    },
    parentNode: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return null;
      }
    },
    textContent: {
      enumerable: true,
      configurable: true,
      get: function get() {
        var childNodes = getInternalChildNodes(this);
        var textContent = '';

        for (var i = 0, len = childNodes.length; i < len; i += 1) {
          var currentNode = childNodes[i];

          if (currentNode.nodeType !== COMMENT_NODE) {
            textContent += getTextContent(currentNode);
          }
        }

        return textContent;
      },
      set: function set(v) {
        var host = getHost(this);
        textContextSetter.call(host, v);
      }
    },
    getRootNode: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(options) {
        return !isUndefined(options) && isTrue$1(options.composed) ? getHost(this).getRootNode(options) : this;
      }
    }
  };
  var ElementPatchDescriptors = {
    innerHTML: {
      enumerable: true,
      configurable: true,
      get: function get() {
        var childNodes = getInternalChildNodes(this);
        var innerHTML = '';

        for (var i = 0, len = childNodes.length; i < len; i += 1) {
          innerHTML += getOuterHTML(childNodes[i]);
        }

        return innerHTML;
      },
      set: function set(v) {
        var host = getHost(this);
        innerHTMLSetter.call(host, v);
      }
    }
  };
  var ParentNodePatchDescriptors = {
    childElementCount: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return this.children.length;
      }
    },
    children: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return createStaticHTMLCollection(ArrayFilter.call(shadowRootChildNodes(this), function (elm) {
          return _instanceof_1(elm, Element);
        }));
      }
    },
    firstElementChild: {
      enumerable: true,
      configurable: true,
      get: function get() {
        return this.children[0] || null;
      }
    },
    lastElementChild: {
      enumerable: true,
      configurable: true,
      get: function get() {
        var children = this.children;
        return children.item(children.length - 1) || null;
      }
    },
    querySelector: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(selectors) {
        return shadowRootQuerySelector(this, selectors);
      }
    },
    querySelectorAll: {
      writable: true,
      enumerable: true,
      configurable: true,
      value: function value(selectors) {
        return createStaticNodeList(shadowRootQuerySelectorAll(this, selectors));
      }
    }
  };
  assign(SyntheticShadowRootDescriptors, NodePatchDescriptors, ParentNodePatchDescriptors, ElementPatchDescriptors, ShadowRootDescriptors);

  function SyntheticShadowRoot() {
    throw new TypeError('Illegal constructor');
  }

  SyntheticShadowRoot.prototype = create(DocumentFragment.prototype, SyntheticShadowRootDescriptors);

  function getIE11FakeShadowRootPlaceholder(host) {
    var shadowRoot = getShadowRoot(host);
    var c = shadowRoot.$$placeholder$$;

    if (!isUndefined(c)) {
      return c;
    }

    var doc = getOwnerDocument(host);
    c = shadowRoot.$$placeholder$$ = createComment.call(doc, '');
    defineProperties(c, {
      childNodes: {
        get: function get() {
          return shadowRoot.childNodes;
        },
        enumerable: true,
        configurable: true
      },
      tagName: {
        get: function get() {
          return "#shadow-root (".concat(shadowRoot.mode, ")");
        },
        enumerable: true,
        configurable: true
      }
    });
    return c;
  }

  function getNodeOwner(node) {
    if (!_instanceof_1(node, Node)) {
      return null;
    }

    var ownerKey = getNodeNearestOwnerKey(node);

    if (isUndefined(ownerKey)) {
      return null;
    }

    var nodeOwner = node;

    while (!isNull(nodeOwner) && getNodeKey(nodeOwner) !== ownerKey) {
      nodeOwner = parentNodeGetter.call(nodeOwner);
    }

    if (isNull(nodeOwner)) {
      return null;
    }

    return nodeOwner;
  }

  function isSlotElement(node) {
    return _instanceof_1(node, HTMLSlotElement);
  }

  function isNodeOwnedBy(owner, node) {
    {
      assert.invariant(_instanceof_1(owner, HTMLElement), "isNodeOwnedBy() should be called with an element as the first argument instead of ".concat(owner));
      assert.invariant(_instanceof_1(node, Node), "isNodeOwnedBy() should be called with a node as the second argument instead of ".concat(node));
      assert.invariant(compareDocumentPosition.call(node, owner) & DOCUMENT_POSITION_CONTAINS, "isNodeOwnedBy() should never be called with a node that is not a child node of ".concat(owner));
    }

    var ownerKey = getNodeNearestOwnerKey(node);
    return isUndefined(ownerKey) || getNodeKey(owner) === ownerKey;
  }

  function shadowRootChildNodes(root) {
    var elm = getHost(root);
    return getAllMatches(elm, arrayFromCollection(childNodesGetter.call(elm)));
  }

  function getAllMatches(owner, nodeList) {
    var filteredAndPatched = [];

    for (var i = 0, len = nodeList.length; i < len; i += 1) {
      var node = nodeList[i];
      var isOwned = isNodeOwnedBy(owner, node);

      if (isOwned) {
        ArrayPush.call(filteredAndPatched, node);
      }
    }

    return filteredAndPatched;
  }

  function getFirstMatch(owner, nodeList) {
    for (var i = 0, len = nodeList.length; i < len; i += 1) {
      if (isNodeOwnedBy(owner, nodeList[i])) {
        return nodeList[i];
      }
    }

    return null;
  }

  function shadowRootQuerySelector(root, selector) {
    var elm = getHost(root);
    var nodeList = arrayFromCollection(querySelectorAll.call(elm, selector));
    return getFirstMatch(elm, nodeList);
  }

  function shadowRootQuerySelectorAll(root, selector) {
    var elm = getHost(root);
    var nodeList = querySelectorAll.call(elm, selector);
    return getAllMatches(elm, arrayFromCollection(nodeList));
  }

  function getFilteredChildNodes(node) {
    var children;

    if (!isHostElement(node) && !isSlotElement(node)) {
      children = childNodesGetter.call(node);
      return arrayFromCollection(children);
    }

    if (isHostElement(node)) {
      var slots = arrayFromCollection(querySelectorAll.call(node, 'slot'));
      var resolver = getShadowRootResolver(getShadowRoot(node));
      return ArrayReduce.call(slots, function (seed, slot) {
        if (resolver === getShadowRootResolver(slot)) {
          ArrayPush.apply(seed, getFilteredSlotAssignedNodes(slot));
        }

        return seed;
      }, []);
    } else {
      children = arrayFromCollection(childNodesGetter.call(node));

      var _resolver = getShadowRootResolver(node);

      return ArrayReduce.call(children, function (seed, child) {
        if (_resolver === getShadowRootResolver(child)) {
          ArrayPush.call(seed, child);
        }

        return seed;
      }, []);
    }
  }

  function getFilteredSlotAssignedNodes(slot) {
    var owner = getNodeOwner(slot);

    if (isNull(owner)) {
      return [];
    }

    var childNodes = arrayFromCollection(childNodesGetter.call(slot));
    return ArrayReduce.call(childNodes, function (seed, child) {
      if (!isNodeOwnedBy(owner, child)) {
        ArrayPush.call(seed, child);
      }

      return seed;
    }, []);
  }

  var OwnerKey = '$$OwnerKey$$';
  var OwnKey = '$$OwnKey$$';
  var hasNativeSymbolsSupport$1 = Symbol('x').toString() === 'Symbol(x)';

  function getNodeOwnerKey(node) {
    return node[OwnerKey];
  }

  function setNodeOwnerKey(node, value) {
    {
      defineProperty$1(node, OwnerKey, {
        value: value,
        configurable: true
      });
    }
  }

  function setNodeKey(node, value) {
    {
      defineProperty$1(node, OwnKey, {
        value: value
      });
    }
  }

  function getNodeNearestOwnerKey(node) {
    var ownerNode = node;
    var ownerKey;

    while (!isNull(ownerNode)) {
      ownerKey = ownerNode[OwnerKey];

      if (!isUndefined(ownerKey)) {
        return ownerKey;
      }

      ownerNode = parentNodeGetter.call(ownerNode);
    }
  }

  function getNodeKey(node) {
    return node[OwnKey];
  }

  function isNodeShadowed(node) {
    return !isUndefined(getNodeNearestOwnerKey(node));
  }

  function hasMountedChildren(node) {
    return isSlotElement(node) || isHostElement(node);
  }

  function getShadowParent(node, value) {
    var owner = getNodeOwner(node);

    if (value === owner) {
      return getShadowRoot(owner);
    } else if (_instanceof_1(value, Element)) {
      if (getNodeNearestOwnerKey(node) === getNodeNearestOwnerKey(value)) {
        return value;
      } else if (!isNull(owner) && isSlotElement(value)) {
        var slotOwner = getNodeOwner(value);

        if (!isNull(slotOwner) && isNodeOwnedBy(owner, slotOwner)) {
          return slotOwner;
        }
      }
    }

    return null;
  }

  function hasChildNodesPatched() {
    return getInternalChildNodes(this).length > 0;
  }

  function firstChildGetterPatched() {
    var childNodes = getInternalChildNodes(this);
    return childNodes[0] || null;
  }

  function lastChildGetterPatched() {
    var childNodes = getInternalChildNodes(this);
    return childNodes[childNodes.length - 1] || null;
  }

  function textContentGetterPatched() {
    return getTextContent(this);
  }

  function textContentSetterPatched(value) {
    textContextSetter.call(this, value);
  }

  function parentNodeGetterPatched() {
    var value = parentNodeGetter.call(this);

    if (isNull(value)) {
      return value;
    }

    return getShadowParent(this, value);
  }

  function parentElementGetterPatched() {
    var value = parentNodeGetter.call(this);

    if (isNull(value)) {
      return null;
    }

    var parentNode = getShadowParent(this, value);
    return _instanceof_1(parentNode, Element) ? parentNode : null;
  }

  function compareDocumentPositionPatched(otherNode) {
    if (this.getRootNode() === otherNode) {
      return 10;
    } else if (getNodeOwnerKey(this) !== getNodeOwnerKey(otherNode)) {
      return 35;
    }

    return compareDocumentPosition.call(this, otherNode);
  }

  function containsPatched(otherNode) {
    if (otherNode == null || getNodeOwnerKey(this) !== getNodeOwnerKey(otherNode)) {
      return false;
    }

    return (compareDocumentPosition.call(this, otherNode) & DOCUMENT_POSITION_CONTAINED_BY) !== 0;
  }

  function cloneNodePatched(deep) {
    var clone = cloneNode.call(this, false);

    if (!deep) {
      return clone;
    }

    var childNodes = getInternalChildNodes(this);

    for (var i = 0, len = childNodes.length; i < len; i += 1) {
      clone.appendChild(childNodes[i].cloneNode(true));
    }

    return clone;
  }

  function childNodesGetterPatched() {
    if (_instanceof_1(this, Element) && isHostElement(this)) {
      var owner = getNodeOwner(this);
      var childNodes = isNull(owner) ? [] : getAllMatches(owner, getFilteredChildNodes(this));

      if ( isFalse$1(hasNativeSymbolsSupport$1) && isExternalChildNodeAccessorFlagOn()) {
        ArrayUnshift.call(childNodes, getIE11FakeShadowRootPlaceholder(this));
      }

      return createStaticNodeList(childNodes);
    }

    return childNodesGetter.call(this);
  }

  var nativeGetRootNode = Node.prototype.getRootNode;
  var getDocumentOrRootNode = !isUndefined(nativeGetRootNode) ? nativeGetRootNode : function () {
    var node = this;
    var nodeParent;

    while (!isNull(nodeParent = parentNodeGetter.call(node))) {
      node = nodeParent;
    }

    return node;
  };

  function getNearestRoot(node) {
    var ownerNode = getNodeOwner(node);

    if (isNull(ownerNode)) {
      return getDocumentOrRootNode.call(node);
    }

    return getShadowRoot(ownerNode);
  }

  function getRootNodePatched(options) {
    var composed = isUndefined(options) ? false : !!options.composed;
    return isTrue$1(composed) ? getDocumentOrRootNode.call(this, options) : getNearestRoot(this);
  }

  defineProperties(Node.prototype, {
    firstChild: {
      get: function get() {
        if (hasMountedChildren(this)) {
          return firstChildGetterPatched.call(this);
        }

        return firstChildGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    lastChild: {
      get: function get() {
        if (hasMountedChildren(this)) {
          return lastChildGetterPatched.call(this);
        }

        return lastChildGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    textContent: {
      get: function get() {
        if (isNodeShadowed(this) || isHostElement(this)) {
          return textContentGetterPatched.call(this);
        }

        if (isGlobalPatchingSkipped(this)) {
          return textContentGetter.call(this);
        }

        return textContentGetterPatched.call(this);
      },
      set: textContentSetterPatched,
      enumerable: true,
      configurable: true
    },
    parentNode: {
      get: function get() {
        if (isNodeShadowed(this)) {
          return parentNodeGetterPatched.call(this);
        }

        return parentNodeGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    parentElement: {
      get: function get() {
        if (isNodeShadowed(this)) {
          return parentElementGetterPatched.call(this);
        }

        return parentElementGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    childNodes: {
      get: function get() {
        if (hasMountedChildren(this)) {
          return childNodesGetterPatched.call(this);
        }

        return childNodesGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    hasChildNodes: {
      value: function value() {
        if (hasMountedChildren(this)) {
          return hasChildNodesPatched.call(this);
        }

        return hasChildNodes.call(this);
      },
      enumerable: true,
      writable: true,
      configurable: true
    },
    compareDocumentPosition: {
      value: function value(otherNode) {
        if (isGlobalPatchingSkipped(this)) {
          return compareDocumentPosition.call(this, otherNode);
        }

        return compareDocumentPositionPatched.call(this, otherNode);
      },
      enumerable: true,
      writable: true,
      configurable: true
    },
    contains: {
      value: function value(otherNode) {
        if (isGlobalPatchingSkipped(this)) {
          contains.call(otherNode, otherNode);
        }

        return containsPatched.call(this, otherNode);
      },
      enumerable: true,
      writable: true,
      configurable: true
    },
    cloneNode: {
      value: function value(deep) {
        if (isNodeShadowed(this) || isHostElement(this)) {
          return cloneNodePatched.call(this, deep);
        }

        if (isGlobalPatchingSkipped(this)) {
          return cloneNode.call(this, deep);
        }

        return cloneNodePatched.call(this, deep);
      },
      enumerable: true,
      writable: true,
      configurable: true
    },
    getRootNode: {
      value: getRootNodePatched,
      enumerable: true,
      configurable: true,
      writable: true
    }
  });
  var internalChildNodeAccessorFlag = false;

  function isExternalChildNodeAccessorFlagOn() {
    return !internalChildNodeAccessorFlag;
  }

  var getInternalChildNodes =  isFalse$1(hasNativeSymbolsSupport$1) ? function (node) {
    internalChildNodeAccessorFlag = true;
    var childNodes;
    var error = null;

    try {
      childNodes = node.childNodes;
    } catch (e) {
      error = e;
    } finally {
      internalChildNodeAccessorFlag = false;

      if (!isNull(error)) {
        throw error;
      }
    }

    return childNodes;
  } : function (node) {
    return node.childNodes;
  };

  if (hasOwnProperty.call(HTMLElement.prototype, 'contains')) {
    defineProperty$1(HTMLElement.prototype, 'contains', getOwnPropertyDescriptor(Node.prototype, 'contains'));
  }

  if (hasOwnProperty.call(HTMLElement.prototype, 'parentElement')) {
    defineProperty$1(HTMLElement.prototype, 'parentElement', getOwnPropertyDescriptor(Node.prototype, 'parentElement'));
  }

  function elemFromPoint(left, top) {
    var element = elementFromPoint.call(this, left, top);

    if (isNull(element)) {
      return element;
    }

    return retarget(this, pathComposer(element, true));
  }

  Document.prototype.elementFromPoint = elemFromPoint;
  defineProperty$1(Document.prototype, 'activeElement', {
    get: function get() {
      var node = DocumentPrototypeActiveElement.call(this);

      if (isNull(node)) {
        return node;
      }

      while (!isUndefined(getNodeOwnerKey(node))) {
        node = parentElementGetter.call(node);

        if (isNull(node)) {
          return null;
        }
      }

      if (node.tagName === 'HTML') {
        node = this.body;
      }

      return node;
    },
    enumerable: true,
    configurable: true
  });
  defineProperty$1(Document.prototype, 'getElementById', {
    value: function value() {
      var elm = getElementById.apply(this, ArraySlice.call(arguments));

      if (isNull(elm)) {
        return null;
      }

      return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(elm) ? elm : null;
    },
    writable: true,
    enumerable: true,
    configurable: true
  });
  defineProperty$1(Document.prototype, 'querySelector', {
    value: function value() {
      var elements = arrayFromCollection(querySelectorAll$1.apply(this, ArraySlice.call(arguments)));
      var filtered = ArrayFind.call(elements, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(elm);
      });
      return !isUndefined(filtered) ? filtered : null;
    },
    writable: true,
    enumerable: true,
    configurable: true
  });
  defineProperty$1(Document.prototype, 'querySelectorAll', {
    value: function value() {
      var elements = arrayFromCollection(querySelectorAll$1.apply(this, ArraySlice.call(arguments)));
      var filtered = ArrayFilter.call(elements, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(elm);
      });
      return createStaticNodeList(filtered);
    },
    writable: true,
    enumerable: true,
    configurable: true
  });
  defineProperty$1(Document.prototype, 'getElementsByClassName', {
    value: function value() {
      var elements = arrayFromCollection(getElementsByClassName$1.apply(this, ArraySlice.call(arguments)));
      var filtered = ArrayFilter.call(elements, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(elm);
      });
      return createStaticHTMLCollection(filtered);
    },
    writable: true,
    enumerable: true,
    configurable: true
  });
  defineProperty$1(Document.prototype, 'getElementsByTagName', {
    value: function value() {
      var elements = arrayFromCollection(getElementsByTagName$1.apply(this, ArraySlice.call(arguments)));
      var filtered = ArrayFilter.call(elements, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(elm);
      });
      return createStaticHTMLCollection(filtered);
    },
    writable: true,
    enumerable: true,
    configurable: true
  });
  defineProperty$1(Document.prototype, 'getElementsByTagNameNS', {
    value: function value() {
      var elements = arrayFromCollection(getElementsByTagNameNS$1.apply(this, ArraySlice.call(arguments)));
      var filtered = ArrayFilter.call(elements, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(elm);
      });
      return createStaticHTMLCollection(filtered);
    },
    writable: true,
    enumerable: true,
    configurable: true
  });
  defineProperty$1(getOwnPropertyDescriptor(HTMLDocument.prototype, 'getElementsByName') ? HTMLDocument.prototype : Document.prototype, 'getElementsByName', {
    value: function value() {
      var elements = arrayFromCollection(getElementsByName.apply(this, ArraySlice.call(arguments)));
      var filtered = ArrayFilter.call(elements, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(elm);
      });
      return createStaticNodeList(filtered);
    },
    writable: true,
    enumerable: true,
    configurable: true
  });
  Object.defineProperty(window, 'ShadowRoot', {
    value: SyntheticShadowRoot,
    configurable: true,
    writable: true
  });

  function doesEventNeedsPatch(e) {
    var originalTarget = eventTargetGetter.call(e);
    return _instanceof_1(originalTarget, Node) && isNodeShadowed(originalTarget);
  }

  function getEventListenerWrapper(fnOrObj) {
    var wrapperFn = null;

    try {
      wrapperFn = fnOrObj.$$lwcEventWrapper$$;

      if (!wrapperFn) {
        var isHandlerFunction = typeof fnOrObj === 'function';

        wrapperFn = fnOrObj.$$lwcEventWrapper$$ = function (e) {
          if (doesEventNeedsPatch(e)) {
            patchEvent(e);
          }

          return isHandlerFunction ? fnOrObj.call(this, e) : fnOrObj.handleEvent && fnOrObj.handleEvent(e);
        };
      }
    } catch (e) {}

    return wrapperFn;
  }

  function windowAddEventListener$1(type, fnOrObj, optionsOrCapture) {
    var handlerType = _typeof_1(fnOrObj);

    if (handlerType !== 'function' && handlerType !== 'object') {
      return;
    }

    if (handlerType === 'object' && (!fnOrObj.handleEvent || typeof fnOrObj.handleEvent !== 'function')) {
      return;
    }

    var wrapperFn = getEventListenerWrapper(fnOrObj);
    windowAddEventListener.call(this, type, wrapperFn, optionsOrCapture);
  }

  function windowRemoveEventListener$1(type, fnOrObj, optionsOrCapture) {
    var wrapperFn = getEventListenerWrapper(fnOrObj);
    windowRemoveEventListener.call(this, type, wrapperFn || fnOrObj, optionsOrCapture);
  }

  function addEventListener$1(type, fnOrObj, optionsOrCapture) {
    var handlerType = _typeof_1(fnOrObj);

    if (handlerType !== 'function' && handlerType !== 'object') {
      return;
    }

    if (handlerType === 'object' && (!fnOrObj.handleEvent || typeof fnOrObj.handleEvent !== 'function')) {
      return;
    }

    var wrapperFn = getEventListenerWrapper(fnOrObj);
    addEventListener.call(this, type, wrapperFn, optionsOrCapture);
  }

  function removeEventListener$1(type, fnOrObj, optionsOrCapture) {
    var wrapperFn = getEventListenerWrapper(fnOrObj);
    removeEventListener.call(this, type, wrapperFn || fnOrObj, optionsOrCapture);
  }

  window.addEventListener = windowAddEventListener$1;
  window.removeEventListener = windowRemoveEventListener$1;
  Node.prototype.addEventListener = addEventListener$1;
  Node.prototype.removeEventListener = removeEventListener$1;
  var composedDescriptor = Object.getOwnPropertyDescriptor(Event.prototype, 'composed');

  function detect$1() {
    if (!composedDescriptor) {
      return false;
    }

    var clickEvent = new Event('click');
    var button = document.createElement('button');
    button.addEventListener('click', function (event) {
      return clickEvent = event;
    });
    button.click();
    return !composedDescriptor.get.call(clickEvent);
  }

  var originalClickDescriptor = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'click');

  function handleClick(event) {
    Object.defineProperty(event, 'composed', {
      configurable: true,
      enumerable: true,
      get: function get() {
        return true;
      }
    });
  }

  function apply$1() {
    HTMLElement.prototype.click = function () {
      addEventListener.call(this, 'click', handleClick);

      try {
        originalClickDescriptor.value.call(this);
      } finally {
        removeEventListener.call(this, 'click', handleClick);
      }
    };
  }

  if (detect$1()) {
    apply$1();
  }

  function detect$2() {
    return Object.getOwnPropertyDescriptor(Event.prototype, 'composed') === undefined;
  }

  function apply$2() {
    var composedEvents = assign(create(null), {
      blur: 1,
      focus: 1,
      focusin: 1,
      focusout: 1,
      click: 1,
      dblclick: 1,
      mousedown: 1,
      mouseenter: 1,
      mouseleave: 1,
      mousemove: 1,
      mouseout: 1,
      mouseover: 1,
      mouseup: 1,
      wheel: 1,
      beforeinput: 1,
      input: 1,
      keydown: 1,
      keyup: 1,
      compositionstart: 1,
      compositionupdate: 1,
      compositionend: 1,
      touchstart: 1,
      touchend: 1,
      touchmove: 1,
      touchcancel: 1,
      pointerover: 1,
      pointerenter: 1,
      pointerdown: 1,
      pointermove: 1,
      pointerup: 1,
      pointercancel: 1,
      pointerout: 1,
      pointerleave: 1,
      gotpointercapture: 1,
      lostpointercapture: 1,
      dragstart: 1,
      drag: 1,
      dragenter: 1,
      dragleave: 1,
      dragover: 1,
      drop: 1,
      dragend: 1,
      DOMActivate: 1,
      DOMFocusIn: 1,
      DOMFocusOut: 1,
      keypress: 1
    });
    Object.defineProperties(Event.prototype, {
      composed: {
        get: function get() {
          var type = this.type;
          return composedEvents[type] === 1;
        },
        configurable: true,
        enumerable: true
      }
    });
  }

  if (detect$2()) {
    apply$2();
  }

  var OriginalCustomEvent = CustomEvent;

  function PatchedCustomEvent(type, eventInitDict) {
    var event = new OriginalCustomEvent(type, eventInitDict);
    Object.defineProperties(event, {
      composed: {
        get: function get() {
          return !!(eventInitDict && eventInitDict.composed);
        },
        configurable: true,
        enumerable: true
      }
    });
    return event;
  }

  PatchedCustomEvent.prototype = OriginalCustomEvent.prototype;
  window.CustomEvent = PatchedCustomEvent;
  var originalComposedGetter = Object.getOwnPropertyDescriptor(Event.prototype, 'composed').get;
  Object.defineProperties(FocusEvent.prototype, {
    composed: {
      get: function get() {
        var isTrusted = this.isTrusted;
        var composed = originalComposedGetter.call(this);

        if (isTrusted && composed === false) {
          return true;
        }

        return composed;
      },
      enumerable: true,
      configurable: true
    }
  });

  function detect$3() {
    return typeof HTMLIFrameElement !== 'undefined';
  }

  function apply$3() {
    var desc = getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow');
    var originalGetter = desc.get;

    desc.get = function () {
      var original = originalGetter.call(this);

      if (isNull(original) || isUndefined(getNodeOwnerKey(this))) {
        return original;
      }

      return wrapIframeWindow(original);
    };

    defineProperty$1(HTMLIFrameElement.prototype, 'contentWindow', desc);
  }

  function wrapIframeWindow(win) {
    return {
      addEventListener: function addEventListener() {
        return win.addEventListener.apply(win, arguments);
      },
      blur: function blur() {
        return win.blur.apply(win, arguments);
      },
      close: function close() {
        return win.close.apply(win, arguments);
      },
      focus: function focus() {
        return win.focus.apply(win, arguments);
      },
      postMessage: function postMessage() {
        return win.postMessage.apply(win, arguments);
      },
      removeEventListener: function removeEventListener() {
        return win.removeEventListener.apply(win, arguments);
      },

      get closed() {
        return win.closed;
      },

      get frames() {
        return win.frames;
      },

      get length() {
        return win.length;
      },

      get location() {
        return win.location;
      },

      set location(value) {
        win.location = value;
      },

      get opener() {
        return win.opener;
      },

      get parent() {
        return win.parent;
      },

      get self() {
        return win.self;
      },

      get top() {
        return win.top;
      },

      get window() {
        return win.window;
      }

    };
  }

  if (detect$3()) {
    apply$3();
  }

  var OriginalMutationObserver = MutationObserver;
  var _OriginalMutationObse = OriginalMutationObserver.prototype,
      originalDisconnect = _OriginalMutationObse.disconnect,
      originalObserve = _OriginalMutationObse.observe,
      originalTakeRecords = _OriginalMutationObse.takeRecords;
  var wrapperLookupField = '$$lwcObserverCallbackWrapper$$';
  var observerLookupField = '$$lwcNodeObservers$$';
  var observerToNodesMap = new WeakMap();

  function retargetMutationRecord(originalRecord) {
    var addedNodes = originalRecord.addedNodes,
        removedNodes = originalRecord.removedNodes,
        target = originalRecord.target,
        type = originalRecord.type;
    var retargetedRecord = create(MutationRecord.prototype);
    defineProperties(retargetedRecord, {
      addedNodes: {
        get: function get() {
          return addedNodes;
        },
        enumerable: true,
        configurable: true
      },
      removedNodes: {
        get: function get() {
          return removedNodes;
        },
        enumerable: true,
        configurable: true
      },
      type: {
        get: function get() {
          return type;
        },
        enumerable: true,
        configurable: true
      },
      target: {
        get: function get() {
          return target.shadowRoot;
        },
        enumerable: true,
        configurable: true
      }
    });
    return retargetedRecord;
  }

  function isQualifiedObserver(observer, target) {
    var parentNode = target;

    while (!isNull(parentNode)) {
      var parentNodeObservers = parentNode[observerLookupField];

      if (!isUndefined(parentNodeObservers) && (parentNodeObservers[0] === observer || ArrayIndexOf.call(parentNodeObservers, observer) !== -1)) {
        return true;
      }

      parentNode = parentNode.parentNode;
    }

    return false;
  }

  function filterMutationRecords(mutations, observer) {
    return ArrayReduce.call(mutations, function (filteredSet, record) {
      var target = record.target,
          addedNodes = record.addedNodes,
          removedNodes = record.removedNodes,
          type = record.type;

      if (type === 'childList' && !isUndefined(getNodeKey(target))) {
        if (addedNodes.length > 0) {
          var sampleNode = addedNodes[0];

          if (isQualifiedObserver(observer, sampleNode)) {
            if (target[observerLookupField] && (target[observerLookupField][0] === observer || ArrayIndexOf.call(target[observerLookupField], observer) !== -1)) {
              ArrayPush.call(filteredSet, record);
            } else {
              ArrayPush.call(filteredSet, retargetMutationRecord(record));
            }
          }
        } else {
          var shadowRoot = target.shadowRoot;
          var _sampleNode = removedNodes[0];

          if (getNodeNearestOwnerKey(target) === getNodeNearestOwnerKey(_sampleNode) && isQualifiedObserver(observer, target)) {
            ArrayPush.call(filteredSet, record);
          } else if (shadowRoot && shadowRoot[observerLookupField] && (shadowRoot[observerLookupField][0] === observer || ArrayIndexOf.call(shadowRoot[observerLookupField], observer) !== -1)) {
            ArrayPush.call(filteredSet, retargetMutationRecord(record));
          }
        }
      } else {
        if (isQualifiedObserver(observer, target)) {
          ArrayPush.call(filteredSet, record);
        }
      }

      return filteredSet;
    }, []);
  }

  function getWrappedCallback(callback) {
    var wrappedCallback = callback[wrapperLookupField];

    if (isUndefined(wrappedCallback)) {
      wrappedCallback = callback[wrapperLookupField] = function (mutations, observer) {
        var filteredRecords = filterMutationRecords(mutations, observer);

        if (filteredRecords.length === 0) {
          return;
        }

        callback.call(observer, filteredRecords, observer);
      };
    }

    return wrappedCallback;
  }

  function PatchedMutationObserver(callback) {
    var wrappedCallback = getWrappedCallback(callback);
    var observer = new OriginalMutationObserver(wrappedCallback);
    return observer;
  }

  function patchedDisconnect() {
    var _this3 = this;

    originalDisconnect.call(this);
    var observedNodes = observerToNodesMap.get(this);

    if (!isUndefined(observedNodes)) {
      forEach.call(observedNodes, function (observedNode) {
        var observers = observedNode[observerLookupField];

        if (!isUndefined(observers)) {
          var index = ArrayIndexOf.call(observers, _this3);

          if (index !== -1) {
            ArraySplice.call(observers, index, 1);
          }
        }
      });
      observedNodes.length = 0;
    }
  }

  function patchedObserve(target, options) {
    if (isUndefined(target[observerLookupField])) {
      defineProperty$1(target, observerLookupField, {
        value: []
      });
    }

    if (ArrayIndexOf.call(target[observerLookupField], this) === -1) {
      ArrayPush.call(target[observerLookupField], this);
    }

    if (_instanceof_1(target, SyntheticShadowRoot)) {
      target = target.host;
    }

    if (observerToNodesMap.has(this)) {
      var observedNodes = observerToNodesMap.get(this);

      if (ArrayIndexOf.call(observedNodes, target) === -1) {
        ArrayPush.call(observedNodes, target);
      }
    } else {
      observerToNodesMap.set(this, [target]);
    }

    return originalObserve.call(this, target, options);
  }

  function patchedTakeRecords() {
    return filterMutationRecords(originalTakeRecords.call(this), this);
  }

  PatchedMutationObserver.prototype = OriginalMutationObserver.prototype;
  PatchedMutationObserver.prototype.disconnect = patchedDisconnect;
  PatchedMutationObserver.prototype.observe = patchedObserve;
  PatchedMutationObserver.prototype.takeRecords = patchedTakeRecords;
  defineProperty$1(window, 'MutationObserver', {
    value: PatchedMutationObserver,
    configurable: true,
    writable: true
  });
  var observer;
  var createFieldName$4 = fields.createFieldName,
      getHiddenField$4 = fields.getHiddenField,
      setHiddenField$4 = fields.setHiddenField;
  var observerConfig = {
    childList: true
  };
  var SlotChangeKey = createFieldName$4('slotchange', 'synthetic-shadow');

  function initSlotObserver() {
    return new MO(function (mutations) {
      var slots = [];
      forEach.call(mutations, function (mutation) {
        {
          assert.invariant(mutation.type === 'childList', "Invalid mutation type: ".concat(mutation.type, ". This mutation handler for slots should only handle \"childList\" mutations."));
        }

        var slot = mutation.target;

        if (ArrayIndexOf.call(slots, slot) === -1) {
          ArrayPush.call(slots, slot);
          dispatchEvent.call(slot, new CustomEvent('slotchange'));
        }
      });
    });
  }

  function getFilteredSlotFlattenNodes(slot) {
    var childNodes = arrayFromCollection(childNodesGetter.call(slot));
    return ArrayReduce.call(childNodes, function (seed, child) {
      if (_instanceof_1(child, Element) && isSlotElement(child)) {
        ArrayPush.apply(seed, getFilteredSlotFlattenNodes(child));
      } else {
        ArrayPush.call(seed, child);
      }

      return seed;
    }, []);
  }

  function assignedSlotGetterPatched() {
    var parentNode = parentNodeGetter.call(this);

    if (isNull(parentNode) || !isSlotElement(parentNode) || getNodeNearestOwnerKey(parentNode) === getNodeNearestOwnerKey(this)) {
      return null;
    }

    return parentNode;
  }

  defineProperties(HTMLSlotElement.prototype, {
    addEventListener: {
      value: function value(type, listener, options) {
        HTMLElement.prototype.addEventListener.call(this, type, listener, options);

        if (isNodeShadowed(this) && type === 'slotchange' && !getHiddenField$4(this, SlotChangeKey)) {
          setHiddenField$4(this, SlotChangeKey, true);

          if (!observer) {
            observer = initSlotObserver();
          }

          MutationObserverObserve.call(observer, this, observerConfig);
        }
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    assignedElements: {
      value: function value(options) {
        var flatten = !isUndefined(options) && isTrue$1(options.flatten);
        var nodes = flatten ? getFilteredSlotFlattenNodes(this) : getFilteredSlotAssignedNodes(this);
        return ArrayFilter.call(nodes, function (node) {
          return _instanceof_1(node, Element);
        });
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    assignedNodes: {
      value: function value(options) {
        var flatten = !isUndefined(options) && isTrue$1(options.flatten);
        return flatten ? getFilteredSlotFlattenNodes(this) : getFilteredSlotAssignedNodes(this);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    name: {
      get: function get() {
        var name = getAttribute.call(this, 'name');
        return isNull(name) ? '' : name;
      },
      set: function set(value) {
        setAttribute.call(this, 'name', value);
      },
      enumerable: true,
      configurable: true
    },
    childNodes: {
      get: function get() {
        if (isNodeShadowed(this)) {
          var owner = getNodeOwner(this);
          var childNodes = isNull(owner) ? [] : getAllMatches(owner, getFilteredChildNodes(this));
          return createStaticNodeList(childNodes);
        }

        return childNodesGetter.call(this);
      },
      enumerable: true,
      configurable: true
    }
  });
  defineProperties(Text.prototype, {
    assignedSlot: {
      get: assignedSlotGetterPatched,
      enumerable: true,
      configurable: true
    }
  });

  function foldSlotElement(slot) {
    var parent = parentElementGetter.call(slot);

    while (!isNull(parent) && isSlotElement(parent)) {
      slot = parent;
      parent = parentElementGetter.call(slot);
    }

    return slot;
  }

  function isNodeSlotted(host, node) {
    {
      assert.invariant(_instanceof_1(host, HTMLElement), "isNodeSlotted() should be called with a host as the first argument instead of ".concat(host));
      assert.invariant(_instanceof_1(node, Node), "isNodeSlotted() should be called with a node as the second argument instead of ".concat(node));
      assert.invariant(compareDocumentPosition.call(node, host) & DOCUMENT_POSITION_CONTAINS, "isNodeSlotted() should never be called with a node that is not a child node of ".concat(host));
    }

    var hostKey = getNodeKey(host);
    var currentElement = _instanceof_1(node, Element) ? node : parentElementGetter.call(node);

    while (!isNull(currentElement) && currentElement !== host) {
      var elmOwnerKey = getNodeNearestOwnerKey(currentElement);
      var parent = parentElementGetter.call(currentElement);

      if (elmOwnerKey === hostKey) {
        return isSlotElement(currentElement);
      } else if (parent === host) {
        return false;
      } else if (!isNull(parent) && getNodeNearestOwnerKey(parent) !== elmOwnerKey) {
        if (isSlotElement(parent)) {
          currentElement = getNodeOwner(foldSlotElement(parent));

          if (!isNull(currentElement)) {
            if (currentElement === host) {
              return true;
            } else if (getNodeNearestOwnerKey(currentElement) === hostKey) {
              return true;
            }
          }
        } else {
          return false;
        }
      } else {
        currentElement = parent;
      }
    }

    return false;
  }

  function getAllSlottedMatches(host, nodeList) {
    var filteredAndPatched = [];

    for (var i = 0, len = nodeList.length; i < len; i += 1) {
      var node = nodeList[i];

      if (!isNodeOwnedBy(host, node) && isNodeSlotted(host, node)) {
        ArrayPush.call(filteredAndPatched, node);
      }
    }

    return filteredAndPatched;
  }

  function getFirstSlottedMatch(host, nodeList) {
    for (var i = 0, len = nodeList.length; i < len; i += 1) {
      var node = nodeList[i];

      if (!isNodeOwnedBy(host, node) && isNodeSlotted(host, node)) {
        return node;
      }
    }

    return null;
  }

  function innerHTMLGetterPatched() {
    var childNodes = getInternalChildNodes(this);
    var innerHTML = '';

    for (var i = 0, len = childNodes.length; i < len; i += 1) {
      innerHTML += getOuterHTML(childNodes[i]);
    }

    return innerHTML;
  }

  function outerHTMLGetterPatched() {
    return getOuterHTML(this);
  }

  function attachShadowPatched(options) {
    return attachShadow(this, options);
  }

  function shadowRootGetterPatched() {
    if (isHostElement(this)) {
      var shadow = getShadowRoot(this);

      if (shadow.mode === 'open') {
        return shadow;
      }
    }

    return null;
  }

  function childrenGetterPatched() {
    var owner = getNodeOwner(this);
    var childNodes = isNull(owner) ? [] : getAllMatches(owner, getFilteredChildNodes(this));
    return createStaticHTMLCollection(ArrayFilter.call(childNodes, function (node) {
      return _instanceof_1(node, Element);
    }));
  }

  function childElementCountGetterPatched() {
    return this.children.length;
  }

  function firstElementChildGetterPatched() {
    return this.children[0] || null;
  }

  function lastElementChildGetterPatched() {
    var children = this.children;
    return children.item(children.length - 1) || null;
  }

  defineProperties(Element.prototype, {
    innerHTML: {
      get: function get() {
        if (isNodeShadowed(this) || isHostElement(this)) {
          return innerHTMLGetterPatched.call(this);
        }

        if (isGlobalPatchingSkipped(this)) {
          return innerHTMLGetter.call(this);
        }

        return innerHTMLGetterPatched.call(this);
      },
      set: function set(v) {
        innerHTMLSetter.call(this, v);
      },
      enumerable: true,
      configurable: true
    },
    outerHTML: {
      get: function get() {
        if (isNodeShadowed(this) || isHostElement(this)) {
          return outerHTMLGetterPatched.call(this);
        }

        if (isGlobalPatchingSkipped(this)) {
          return outerHTMLGetter.call(this);
        }

        return outerHTMLGetterPatched.call(this);
      },
      set: function set(v) {
        outerHTMLSetter.call(this, v);
      },
      enumerable: true,
      configurable: true
    },
    attachShadow: {
      value: attachShadowPatched,
      enumerable: true,
      writable: true,
      configurable: true
    },
    shadowRoot: {
      get: shadowRootGetterPatched,
      enumerable: true,
      configurable: true
    },
    children: {
      get: function get() {
        if (hasMountedChildren(this)) {
          return childrenGetterPatched.call(this);
        }

        return childrenGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    childElementCount: {
      get: function get() {
        if (hasMountedChildren(this)) {
          return childElementCountGetterPatched.call(this);
        }

        return childElementCountGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    firstElementChild: {
      get: function get() {
        if (hasMountedChildren(this)) {
          return firstElementChildGetterPatched.call(this);
        }

        return firstElementChildGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    lastElementChild: {
      get: function get() {
        if (hasMountedChildren(this)) {
          return lastElementChildGetterPatched.call(this);
        }

        return lastElementChildGetter.call(this);
      },
      enumerable: true,
      configurable: true
    },
    assignedSlot: {
      get: assignedSlotGetterPatched,
      enumerable: true,
      configurable: true
    }
  });

  if (hasOwnProperty.call(HTMLElement.prototype, 'innerHTML')) {
    defineProperty$1(HTMLElement.prototype, 'innerHTML', getOwnPropertyDescriptor(Element.prototype, 'innerHTML'));
  }

  if (hasOwnProperty.call(HTMLElement.prototype, 'outerHTML')) {
    defineProperty$1(HTMLElement.prototype, 'outerHTML', getOwnPropertyDescriptor(Element.prototype, 'outerHTML'));
  }

  if (hasOwnProperty.call(HTMLElement.prototype, 'children')) {
    defineProperty$1(HTMLElement.prototype, 'children', getOwnPropertyDescriptor(Element.prototype, 'children'));
  }

  function querySelectorPatched() {
    var _this4 = this;

    var nodeList = arrayFromCollection(querySelectorAll.apply(this, ArraySlice.call(arguments)));

    if (isHostElement(this)) {
      var owner = getNodeOwner(this);

      if (isNull(owner)) {
        return null;
      } else if (getNodeKey(this)) {
        return getFirstSlottedMatch(this, nodeList);
      } else {
        return getFirstMatch(owner, nodeList);
      }
    } else if (isNodeShadowed(this)) {
      var ownerKey = getNodeOwnerKey(this);
      var elm = ArrayFind.call(nodeList, function (elm) {
        return getNodeOwnerKey(elm) === ownerKey;
      });
      return isUndefined(elm) ? null : elm;
    } else {
      var _elm = ArrayFind.call(nodeList, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(_this4);
      });

      return isUndefined(_elm) ? null : _elm;
    }
  }

  function querySelectorAllPatched() {
    var _this5 = this;

    var nodeList = arrayFromCollection(querySelectorAll.apply(this, ArraySlice.call(arguments)));
    var filtered;

    if (isHostElement(this)) {
      var owner = getNodeOwner(this);

      if (isNull(owner)) {
        filtered = [];
      } else if (getNodeKey(this)) {
        filtered = getAllSlottedMatches(this, nodeList);
      } else {
        filtered = getAllMatches(owner, nodeList);
      }
    } else if (isNodeShadowed(this)) {
      var ownerKey = getNodeOwnerKey(this);
      filtered = ArrayFilter.call(nodeList, function (elm) {
        return getNodeOwnerKey(elm) === ownerKey;
      });
    } else {
      filtered = ArrayFilter.call(nodeList, function (elm) {
        return isUndefined(getNodeOwnerKey(elm)) || isGlobalPatchingSkipped(_this5);
      });
    }

    return createStaticNodeList(filtered);
  }

  defineProperties(Element.prototype, {
    querySelector: {
      value: querySelectorPatched,
      writable: true,
      enumerable: true,
      configurable: true
    },
    querySelectorAll: {
      value: querySelectorAllPatched,
      writable: true,
      enumerable: true,
      configurable: true
    },
    getElementsByClassName: {
      value: function value() {
        var _this6 = this;

        var elements = arrayFromCollection(getElementsByClassName.apply(this, ArraySlice.call(arguments)));
        var ownerKey = getNodeOwnerKey(this);
        var filtered = ArrayFilter.call(elements, function (elm) {
          return getNodeOwnerKey(elm) === ownerKey || isGlobalPatchingSkipped(_this6);
        });
        return createStaticHTMLCollection(filtered);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getElementsByTagName: {
      value: function value() {
        var _this7 = this;

        var elements = arrayFromCollection(getElementsByTagName.apply(this, ArraySlice.call(arguments)));
        var ownerKey = getNodeOwnerKey(this);
        var filtered = ArrayFilter.call(elements, function (elm) {
          return getNodeOwnerKey(elm) === ownerKey || isGlobalPatchingSkipped(_this7);
        });
        return createStaticHTMLCollection(filtered);
      },
      writable: true,
      enumerable: true,
      configurable: true
    },
    getElementsByTagNameNS: {
      value: function value() {
        var _this8 = this;

        var elements = arrayFromCollection(getElementsByTagNameNS.apply(this, ArraySlice.call(arguments)));
        var ownerKey = getNodeOwnerKey(this);
        var filtered = ArrayFilter.call(elements, function (elm) {
          return getNodeOwnerKey(elm) === ownerKey || isGlobalPatchingSkipped(_this8);
        });
        return createStaticHTMLCollection(filtered);
      },
      writable: true,
      enumerable: true,
      configurable: true
    }
  });

  if (hasOwnProperty.call(HTMLElement.prototype, 'getElementsByClassName')) {
    defineProperty$1(HTMLElement.prototype, 'getElementsByClassName', getOwnPropertyDescriptor(Element.prototype, 'getElementsByClassName'));
  }

  var createFieldName$5 = fields.createFieldName,
      getHiddenField$5 = fields.getHiddenField,
      setHiddenField$5 = fields.setHiddenField;
  var TabbableElementsQuery = "\n    button:not([tabindex=\"-1\"]):not([disabled]),\n    [contenteditable]:not([tabindex=\"-1\"]),\n    video[controls]:not([tabindex=\"-1\"]),\n    audio[controls]:not([tabindex=\"-1\"]),\n    [href]:not([tabindex=\"-1\"]),\n    input:not([tabindex=\"-1\"]):not([disabled]),\n    select:not([tabindex=\"-1\"]):not([disabled]),\n    textarea:not([tabindex=\"-1\"]):not([disabled]),\n    [tabindex=\"0\"]\n";
  var DidAddMouseDownListener = createFieldName$5('DidAddMouseDownListener', 'synthetic-shadow');

  function isVisible(element) {
    var _getBoundingClientRec = getBoundingClientRect.call(element),
        width = _getBoundingClientRec.width,
        height = _getBoundingClientRec.height;

    var noZeroSize = width > 0 || height > 0;
    return noZeroSize && getComputedStyle(element).visibility !== 'hidden';
  }

  function isTabbable(element) {
    return matches.call(element, TabbableElementsQuery) && isVisible(element);
  }

  function getTabbableSegments(host) {
    var doc = getOwnerDocument(host);
    var all = arrayFromCollection(querySelectorAll$1.call(doc, TabbableElementsQuery));
    var inner = arrayFromCollection(querySelectorAll.call(host, TabbableElementsQuery));

    {
      assert.invariant(getAttribute.call(host, 'tabindex') === '-1' || isDelegatingFocus(host), "The focusin event is only relevant when the tabIndex property is -1 on the host.");
    }

    var firstChild = inner[0];
    var lastChild = inner[inner.length - 1];
    var hostIndex = ArrayIndexOf.call(all, host);
    var firstChildIndex = hostIndex > -1 ? hostIndex : ArrayIndexOf.call(all, firstChild);
    var lastChildIndex = inner.length === 0 ? firstChildIndex + 1 : ArrayIndexOf.call(all, lastChild) + 1;
    var prev = ArraySlice.call(all, 0, firstChildIndex);
    var next = ArraySlice.call(all, lastChildIndex);
    return {
      prev: prev,
      inner: inner,
      next: next
    };
  }

  function getActiveElement(host) {
    var doc = getOwnerDocument(host);
    var activeElement = DocumentPrototypeActiveElement.call(doc);

    if (isNull(activeElement)) {
      return activeElement;
    }

    return (compareDocumentPosition.call(host, activeElement) & DOCUMENT_POSITION_CONTAINED_BY) !== 0 ? activeElement : null;
  }

  function relatedTargetPosition(host, relatedTarget) {
    var pos = compareDocumentPosition.call(host, relatedTarget);

    if (pos & DOCUMENT_POSITION_CONTAINED_BY) {
      return 0;
    } else if (pos & DOCUMENT_POSITION_PRECEDING) {
      return 1;
    } else if (pos & DOCUMENT_POSITION_FOLLOWING) {
      return 2;
    }

    return -1;
  }

  function muteEvent(event) {
    event.preventDefault();
    event.stopPropagation();
  }

  function muteFocusEventsDuringExecution(win, func) {
    windowAddEventListener.call(win, 'focusin', muteEvent, true);
    windowAddEventListener.call(win, 'focusout', muteEvent, true);
    func();
    windowRemoveEventListener.call(win, 'focusin', muteEvent, true);
    windowRemoveEventListener.call(win, 'focusout', muteEvent, true);
  }

  function focusOnNextOrBlur(segment, target, relatedTarget) {
    var win = getOwnerWindow(relatedTarget);
    var next = getNextTabbable(segment, relatedTarget);

    if (isNull(next)) {
      muteFocusEventsDuringExecution(win, function () {
        target.blur();
      });
    } else {
      muteFocusEventsDuringExecution(win, function () {
        next.focus();
      });
    }
  }

  var letBrowserHandleFocus = false;

  function disableKeyboardFocusNavigationRoutines() {
    letBrowserHandleFocus = true;
  }

  function enableKeyboardFocusNavigationRoutines() {
    letBrowserHandleFocus = false;
  }

  function skipHostHandler(event) {
    if (letBrowserHandleFocus) {
      enableKeyboardFocusNavigationRoutines();
      return;
    }

    var host = eventCurrentTargetGetter.call(event);
    var target = eventTargetGetter.call(event);

    if (host !== target) {
      return;
    }

    var relatedTarget = focusEventRelatedTargetGetter.call(event);

    if (isNull(relatedTarget)) {
      return;
    }

    var segments = getTabbableSegments(host);
    var position = relatedTargetPosition(host, relatedTarget);

    if (position === 1) {
      var findTabbableElms = isTabbableFrom.bind(null, host.getRootNode());
      var first = ArrayFind.call(segments.inner, findTabbableElms);

      if (!isUndefined(first)) {
        var win = getOwnerWindow(first);
        muteFocusEventsDuringExecution(win, function () {
          first.focus();
        });
      } else {
        focusOnNextOrBlur(segments.next, target, relatedTarget);
      }
    } else if (host === target) {
      focusOnNextOrBlur(ArrayReverse.call(segments.prev), target, relatedTarget);
    }
  }

  function skipShadowHandler(event) {
    if (letBrowserHandleFocus) {
      enableKeyboardFocusNavigationRoutines();
      return;
    }

    var relatedTarget = focusEventRelatedTargetGetter.call(event);

    if (isNull(relatedTarget)) {
      return;
    }

    var host = eventCurrentTargetGetter.call(event);
    var segments = getTabbableSegments(host);

    if (ArrayIndexOf.call(segments.inner, relatedTarget) !== -1) {
      return;
    }

    var target = eventTargetGetter.call(event);
    var position = relatedTargetPosition(host, relatedTarget);

    if (position === 1) {
      focusOnNextOrBlur(segments.next, target, relatedTarget);
    }

    if (position === 2) {
      focusOnNextOrBlur(ArrayReverse.call(segments.prev), target, relatedTarget);
    }
  }

  function isTabbableFrom(fromRoot, toElm) {
    if (!isTabbable(toElm)) {
      return false;
    }

    var ownerDocument = getOwnerDocument(toElm);
    var root = toElm.getRootNode();

    while (root !== ownerDocument && root !== fromRoot) {
      var sr = root;
      var host = sr.host;

      if (getAttribute.call(host, 'tabindex') === '-1') {
        return false;
      }

      root = host && host.getRootNode();
    }

    return true;
  }

  function getNextTabbable(tabbables, relatedTarget) {
    var len = tabbables.length;

    if (len > 0) {
      for (var i = 0; i < len; i += 1) {
        var next = tabbables[i];

        if (isTabbableFrom(relatedTarget.getRootNode(), next)) {
          return next;
        }
      }
    }

    return null;
  }

  function handleFocus(elm) {
    {
      assert.invariant(isDelegatingFocus(elm), "Invalid attempt to handle focus event for ".concat(toString(elm), ". ").concat(toString(elm), " should have delegates focus true, but is not delegating focus"));
    }

    bindDocumentMousedownMouseupHandlers(elm);
    ignoreFocusIn(elm);
    addEventListener.call(elm, 'focusin', skipHostHandler, true);
  }

  function ignoreFocus(elm) {
    removeEventListener.call(elm, 'focusin', skipHostHandler, true);
  }

  function bindDocumentMousedownMouseupHandlers(elm) {
    var ownerDocument = getOwnerDocument(elm);

    if (!getHiddenField$5(ownerDocument, DidAddMouseDownListener)) {
      setHiddenField$5(ownerDocument, DidAddMouseDownListener, true);
      addEventListener.call(ownerDocument, 'mousedown', disableKeyboardFocusNavigationRoutines, true);
      addEventListener.call(ownerDocument, 'mouseup', function () {
        setTimeout(enableKeyboardFocusNavigationRoutines);
      }, true);
    }
  }

  function handleFocusIn(elm) {
    {
      assert.invariant(tabIndexGetter.call(elm) === -1, "Invalid attempt to handle focus in  ".concat(toString(elm), ". ").concat(toString(elm), " should have tabIndex -1, but has tabIndex ").concat(tabIndexGetter.call(elm)));
    }

    bindDocumentMousedownMouseupHandlers(elm);
    ignoreFocus(elm);
    addEventListener.call(elm, 'focusin', skipShadowHandler, true);
  }

  function ignoreFocusIn(elm) {
    removeEventListener.call(elm, 'focusin', skipShadowHandler, true);
  }

  var _HTMLElement$prototyp = HTMLElement.prototype,
      blur = _HTMLElement$prototyp.blur,
      focus = _HTMLElement$prototyp.focus;

  function tabIndexGetterPatched() {
    if (isDelegatingFocus(this) && isFalse$1(hasAttribute.call(this, 'tabindex'))) {
      return 0;
    }

    return tabIndexGetter.call(this);
  }

  function tabIndexSetterPatched(value) {
    var delegatesFocus = isDelegatingFocus(this);
    var prevValue = tabIndexGetter.call(this);
    var prevHasAttr = hasAttribute.call(this, 'tabindex');
    tabIndexSetter.call(this, value);
    var currValue = tabIndexGetter.call(this);
    var currHasAttr = hasAttribute.call(this, 'tabindex');
    var didValueChange = prevValue !== currValue;

    if (prevHasAttr && (didValueChange || isFalse$1(currHasAttr))) {
      if (prevValue === -1) {
        ignoreFocusIn(this);
      }

      if (prevValue === 0 && delegatesFocus) {
        ignoreFocus(this);
      }
    }

    if (isFalse$1(currHasAttr)) {
      return;
    }

    if (prevHasAttr && currHasAttr && isFalse$1(didValueChange)) {
      return;
    }

    if (currValue === -1) {
      handleFocusIn(this);
    }

    if (currValue === 0 && delegatesFocus) {
      handleFocus(this);
    }
  }

  function blurPatched() {
    if (isDelegatingFocus(this)) {
      var currentActiveElement = getActiveElement(this);

      if (!isNull(currentActiveElement)) {
        currentActiveElement.blur();
        return;
      }
    }

    return blur.call(this);
  }

  function focusPatched() {
    disableKeyboardFocusNavigationRoutines();
    focus.call(this);
    enableKeyboardFocusNavigationRoutines();
  }

  defineProperties(HTMLElement.prototype, {
    tabIndex: {
      get: function get() {
        if (isHostElement(this)) {
          return tabIndexGetterPatched.call(this);
        }

        return tabIndexGetter.call(this);
      },
      set: function set(v) {
        if (isHostElement(this)) {
          return tabIndexSetterPatched.call(this, v);
        }

        return tabIndexSetter.call(this, v);
      },
      enumerable: true,
      configurable: true
    },
    blur: {
      value: function value() {
        if (isHostElement(this)) {
          return blurPatched.call(this);
        }

        blur.call(this);
      },
      enumerable: true,
      writable: true,
      configurable: true
    },
    focus: {
      value: function value() {
        focusPatched.call(this);
      },
      enumerable: true,
      writable: true,
      configurable: true
    }
  });
  var eventTargetGetter$1 = getOwnPropertyDescriptor(Event.prototype, 'target').get;
  var eventCurrentTargetGetter$1 = getOwnPropertyDescriptor(Event.prototype, 'currentTarget').get;
  var _Node$prototype2 = Node.prototype,
      superAddEventListener = _Node$prototype2.addEventListener,
      superRemoveEventListener = _Node$prototype2.removeEventListener;

  function addEventListenerPatched(type, listener, options) {
    if (isHostElement(this)) {
      addCustomElementEventListener(this, type, listener);
    } else {
      superAddEventListener.call(this, type, listener, options);
    }
  }

  function removeEventListenerPatched(type, listener, options) {
    if (isHostElement(this)) {
      removeCustomElementEventListener(this, type, listener);
    } else {
      superRemoveEventListener.call(this, type, listener, options);
    }
  }

  if (typeof EventTarget !== 'undefined') {
    defineProperties(EventTarget.prototype, {
      addEventListener: {
        value: addEventListenerPatched,
        enumerable: true,
        writable: true,
        configurable: true
      },
      removeEventListener: {
        value: removeEventListenerPatched,
        enumerable: true,
        writable: true,
        configurable: true
      }
    });
  } else {
    defineProperties(Node.prototype, {
      addEventListener: {
        value: addEventListenerPatched,
        enumerable: true,
        writable: true,
        configurable: true
      },
      removeEventListener: {
        value: removeEventListenerPatched,
        enumerable: true,
        writable: true,
        configurable: true
      }
    });
  }

  var ShadowTokenPrivateKey = '$$ShadowTokenKey$$';

  function getShadowToken(node) {
    return node.$shadowToken$;
  }

  function setShadowToken(node, shadowToken) {
    node.$shadowToken$ = shadowToken;
  }

  defineProperty$1(Element.prototype, '$shadowToken$', {
    set: function set(shadowToken) {
      var oldShadowToken = this[ShadowTokenPrivateKey];

      if (!isUndefined(oldShadowToken) && oldShadowToken !== shadowToken) {
        removeAttribute.call(this, oldShadowToken);
      }

      if (!isUndefined(shadowToken)) {
        setAttribute.call(this, shadowToken, '');
      }

      this[ShadowTokenPrivateKey] = shadowToken;
    },
    get: function get() {
      return this[ShadowTokenPrivateKey];
    },
    configurable: true
  });
  var MO$1 = MutationObserver;
  var MutationObserverObserve$1 = MO$1.prototype.observe;
  var DomManualPrivateKey = '$$DomManualKey$$';
  var portalObserver;
  var portalObserverConfig = {
    childList: true,
    subtree: true
  };

  function adoptChildNode(node, fn, shadowToken) {
    if (getShadowRootResolver(node) === fn) {
      return;
    }

    setShadowRootResolver(node, fn);

    if (_instanceof_1(node, Element)) {
      setShadowToken(node, shadowToken);
      var childNodes = getInternalChildNodes(node);

      for (var i = 0, len = childNodes.length; i < len; i += 1) {
        var child = childNodes[i];
        adoptChildNode(child, fn, shadowToken);
      }
    }
  }

  function initPortalObserver() {
    return new MO$1(function (mutations) {
      forEach.call(mutations, function (mutation) {
        var elm = mutation.target,
            addedNodes = mutation.addedNodes;
        var fn = getShadowRootResolver(elm);
        var shadowToken = getShadowToken(elm);

        for (var i = 0, len = addedNodes.length; i < len; i += 1) {
          var node = addedNodes[i];
          adoptChildNode(node, fn, shadowToken);
        }
      });
    });
  }

  function markElementAsPortal(elm) {
    if (isUndefined(portalObserver)) {
      portalObserver = initPortalObserver();
    }

    if (isUndefined(getShadowRootResolver(elm))) {
      throw new Error("Invalid Element");
    }

    MutationObserverObserve$1.call(portalObserver, elm, portalObserverConfig);
  }

  defineProperty$1(Element.prototype, '$domManual$', {
    set: function set(v) {
      this[DomManualPrivateKey] = v;

      if (isTrue$1(v)) {
        markElementAsPortal(this);
      }
    },
    get: function get() {
      return this[DomManualPrivateKey];
    },
    configurable: true
  });
  /** version: 1.0.2 */

  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  var assertThisInitialized = _assertThisInitialized;

  function _possibleConstructorReturn(self, call) {
    if (call && (_typeof_1(call) === "object" || typeof call === "function")) {
      return call;
    }

    return assertThisInitialized(self);
  }

  var possibleConstructorReturn = _possibleConstructorReturn;

  var getPrototypeOf$1 = __callKey1(commonjsHelpers, "createCommonjsModule", function (module) {
    function _getPrototypeOf(o) {
      __setKey$1(module, "exports", _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
        return (o._ES5ProxyType ? o.get("__proto__") : o.__proto__) || Object.getPrototypeOf(o);
      });

      return _getPrototypeOf(o);
    }

    __setKey$1(module, "exports", _getPrototypeOf);
  });

  var __callKey2$1 = Proxy.callKey2;

  function _superPropBase(object, property) {
    while (!__callKey2$1(Object.prototype._ES5ProxyType ? Object.prototype.get("compatHasOwnProperty") : Object.prototype.compatHasOwnProperty, "call", object, property)) {
      object = getPrototypeOf$1(object);
      if (object === null) break;
    }

    return object;
  }

  var superPropBase = _superPropBase;

  var get = __callKey1(commonjsHelpers, "createCommonjsModule", function (module) {
    function _get(target, property, receiver) {
      if (typeof Reflect !== "undefined" && (Reflect._ES5ProxyType ? Reflect.get("get") : Reflect.get)) {
        __setKey$1(module, "exports", _get = Reflect._ES5ProxyType ? Reflect.get("get") : Reflect.get);
      } else {
        __setKey$1(module, "exports", _get = function _get(target, property, receiver) {
          var base = superPropBase(target, property);
          if (!base) return;
          var desc = Object.compatGetOwnPropertyDescriptor(base, property);

          if (desc._ES5ProxyType ? desc.get("get") : desc.get) {
            return __callKey1(desc._ES5ProxyType ? desc.get("get") : desc.get, "call", receiver);
          }

          return desc._ES5ProxyType ? desc.get("value") : desc.value;
        });
      }

      return _get(target, property, receiver || target);
    }

    __setKey$1(module, "exports", _get);
  });

  var setPrototypeOf$1 = __callKey1(commonjsHelpers, "createCommonjsModule", function (module) {
    function _setPrototypeOf(o, p) {
      __setKey$1(module, "exports", _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
        __setKey$1(o, "__proto__", p);

        return o;
      });

      return _setPrototypeOf(o, p);
    }

    __setKey$1(module, "exports", _setPrototypeOf);
  });

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    __setKey$1(subClass, "prototype", Object.create(superClass && (superClass._ES5ProxyType ? superClass.get("prototype") : superClass.prototype), {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    }));

    if (superClass) setPrototypeOf$1(subClass, superClass);
  }

  var inherits = _inherits;

  function _defineProperties(target, props) {
    for (var i = 0; i < (props._ES5ProxyType ? props.get("length") : props.length); i++) {
      var descriptor = props._ES5ProxyType ? props.get(i) : props[i];

      __setKey$1(descriptor, "enumerable", (descriptor._ES5ProxyType ? descriptor.get("enumerable") : descriptor.enumerable) || false);

      __setKey$1(descriptor, "configurable", true);

      if (__inKey(descriptor, "value")) __setKey$1(descriptor, "writable", true);
      Object.compatDefineProperty(target, descriptor._ES5ProxyType ? descriptor.get("key") : descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor._ES5ProxyType ? Constructor.get("prototype") : Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  var createClass = _createClass;

  /* proxy-compat-disable */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  function detect$4() {
    // Don't apply polyfill when ProxyCompat is enabled.
    if ('getKey' in Proxy) {
      return false;
    }

    var proxy = new Proxy([3, 4], {});
    var res = [1, 2].concat(proxy);
    return res.length !== 4;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var isConcatSpreadable = Symbol.isConcatSpreadable;
  var isArray$1 = Array.isArray;
  var _Array$prototype$1 = Array.prototype,
      ArraySlice$1 = _Array$prototype$1.slice,
      ArrayUnshift$1 = _Array$prototype$1.unshift,
      ArrayShift = _Array$prototype$1.shift;

  function isObject(O) {
    return _typeof_1(O) === 'object' ? O !== null : typeof O === 'function';
  } // https://www.ecma-international.org/ecma-262/6.0/#sec-isconcatspreadable


  function isSpreadable(O) {
    if (!isObject(O)) {
      return false;
    }

    var spreadable = O[isConcatSpreadable];
    return spreadable !== undefined ? Boolean(spreadable) : isArray$1(O);
  } // https://www.ecma-international.org/ecma-262/6.0/#sec-array.prototype.concat


  function ArrayConcatPolyfill() {
    for (var _len = arguments.length, _args = new Array(_len), _key2 = 0; _key2 < _len; _key2++) {
      _args[_key2] = arguments[_key2];
    }

    var O = Object(this);
    var A = [];
    var N = 0;
    var items = ArraySlice$1.call(arguments);
    ArrayUnshift$1.call(items, O);

    while (items.length) {
      var E = ArrayShift.call(items);

      if (isSpreadable(E)) {
        var _k = 0;
        var length = E.length;

        for (_k; _k < length; _k += 1, N += 1) {
          if (_k in E) {
            var subElement = E[_k];
            A[N] = subElement;
          }
        }
      } else {
        A[N] = E;
        N += 1;
      }
    }

    return A;
  }

  function apply$4() {
    Array.prototype.concat = ArrayConcatPolyfill;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  if (detect$4()) {
    apply$4();
  }
  /**
   * Copyright (C) 2018 salesforce.com, inc.
   */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function invariant$1(value, msg) {
    if (!value) {
      throw new Error("Invariant Violation: ".concat(msg));
    }
  }

  function isTrue$2(value, msg) {
    if (!value) {
      throw new Error("Assert Violation: ".concat(msg));
    }
  }

  function isFalse$2(value, msg) {
    if (value) {
      throw new Error("Assert Violation: ".concat(msg));
    }
  }

  function fail$1(msg) {
    throw new Error(msg);
  }

  var assert$1 =
  /*#__PURE__*/
  Object.freeze({
    __proto__: null,
    invariant: invariant$1,
    isTrue: isTrue$2,
    isFalse: isFalse$2,
    fail: fail$1
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  var assign$1 = Object.assign,
      create$1 = Object.create,
      defineProperties$1 = Object.defineProperties,
      defineProperty$2 = Object.defineProperty,
      freeze = Object.freeze,
      getOwnPropertyDescriptor$1 = Object.getOwnPropertyDescriptor,
      getOwnPropertyNames = Object.getOwnPropertyNames,
      getPrototypeOf$2 = Object.getPrototypeOf,
      hasOwnProperty$1 = Object.hasOwnProperty,
      keys = Object.keys,
      seal = Object.seal,
      setPrototypeOf$2 = Object.setPrototypeOf;
  var isArray$1$1 = Array.isArray;
  var _Array$prototype2 = Array.prototype,
      ArrayIndexOf$1 = _Array$prototype2.indexOf,
      ArrayJoin$1 = _Array$prototype2.join,
      ArrayMap$1 = _Array$prototype2.map,
      ArrayPush$1 = _Array$prototype2.push,
      ArraySlice$1$1 = _Array$prototype2.slice,
      ArrayUnshift$1$1 = _Array$prototype2.unshift,
      forEach$1 = _Array$prototype2.forEach;
  var _String$prototype$1 = String.prototype,
      StringCharCodeAt$1 = _String$prototype$1.charCodeAt,
      StringReplace = _String$prototype$1.replace,
      StringSlice = _String$prototype$1.slice,
      StringToLowerCase = _String$prototype$1.toLowerCase;

  function isUndefined$1(obj) {
    return obj === undefined;
  }

  function isNull$1(obj) {
    return obj === null;
  }

  function isTrue$1$1(obj) {
    return obj === true;
  }

  function isFalse$1$1(obj) {
    return obj === false;
  }

  function isFunction$1(obj) {
    return typeof obj === 'function';
  }

  function isObject$1(obj) {
    return _typeof_1(obj) === 'object';
  }

  function isString(obj) {
    return typeof obj === 'string';
  }

  function isNumber(obj) {
    return typeof obj === 'number';
  }

  var OtS$1 = {}.toString;

  function toString$1(obj) {
    if (obj && obj.toString) {
      // Arrays might hold objects with "null" prototype So using
      // Array.prototype.toString directly will cause an error Iterate through
      // all the items and handle individually.
      if (isArray$1$1(obj)) {
        return ArrayJoin$1.call(ArrayMap$1.call(obj, toString$1), ',');
      }

      return obj.toString();
    } else if (_typeof_1(obj) === 'object') {
      return OtS$1.call(obj);
    } else {
      return obj + emptyString$1;
    }
  }

  function getPropertyDescriptor$1(o, p) {
    do {
      var _d = getOwnPropertyDescriptor$1(o, p);

      if (!isUndefined$1(_d)) {
        return _d;
      }

      o = getPrototypeOf$2(o);
    } while (o !== null);
  }

  var emptyString$1 = '';
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * According to the following list, there are 48 aria attributes of which two (ariaDropEffect and
   * ariaGrabbed) are deprecated:
   * https://www.w3.org/TR/wai-aria-1.1/#x6-6-definitions-of-states-and-properties-all-aria-attributes
   *
   * The above list of 46 aria attributes is consistent with the following resources:
   * https://github.com/w3c/aria/pull/708/files#diff-eacf331f0ffc35d4b482f1d15a887d3bR11060
   * https://wicg.github.io/aom/spec/aria-reflection.html
   */

  var AriaPropertyNames = ['ariaActiveDescendant', 'ariaAtomic', 'ariaAutoComplete', 'ariaBusy', 'ariaChecked', 'ariaColCount', 'ariaColIndex', 'ariaColSpan', 'ariaControls', 'ariaCurrent', 'ariaDescribedBy', 'ariaDetails', 'ariaDisabled', 'ariaErrorMessage', 'ariaExpanded', 'ariaFlowTo', 'ariaHasPopup', 'ariaHidden', 'ariaInvalid', 'ariaKeyShortcuts', 'ariaLabel', 'ariaLabelledBy', 'ariaLevel', 'ariaLive', 'ariaModal', 'ariaMultiLine', 'ariaMultiSelectable', 'ariaOrientation', 'ariaOwns', 'ariaPlaceholder', 'ariaPosInSet', 'ariaPressed', 'ariaReadOnly', 'ariaRelevant', 'ariaRequired', 'ariaRoleDescription', 'ariaRowCount', 'ariaRowIndex', 'ariaRowSpan', 'ariaSelected', 'ariaSetSize', 'ariaSort', 'ariaValueMax', 'ariaValueMin', 'ariaValueNow', 'ariaValueText', 'role'];
  var AttrNameToPropNameMap = create$1(null);
  var PropNameToAttrNameMap = create$1(null); // Synthetic creation of all AOM property descriptors for Custom Elements

  forEach$1.call(AriaPropertyNames, function (propName) {
    // Typescript infers the wrong function type for this particular overloaded method:
    // https://github.com/Microsoft/TypeScript/issues/27972
    // @ts-ignore type-mismatch
    var attrName = StringToLowerCase.call(StringReplace.call(propName, /^aria/, 'aria-'));
    AttrNameToPropNameMap[attrName] = propName;
    PropNameToAttrNameMap[propName] = attrName;
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /*
   * In IE11, symbols are expensive.
   * Due to the nature of the symbol polyfill. This method abstract the
   * creation of symbols, so we can fallback to string when native symbols
   * are not supported. Note that we can't use typeof since it will fail when transpiling.
   */

  var hasNativeSymbolsSupport$2 = Symbol('x').toString() === 'Symbol(x)';

  function createHiddenField(key, namespace) {
    return hasNativeSymbolsSupport$2 ? Symbol(key) : "$$lwc-".concat(namespace, "-").concat(key, "$$");
  }

  var hiddenFieldsMap$1 = new WeakMap();

  function setHiddenField$6(o, field, value) {
    var valuesByField = hiddenFieldsMap$1.get(o);

    if (isUndefined$1(valuesByField)) {
      valuesByField = create$1(null);
      hiddenFieldsMap$1.set(o, valuesByField);
    }

    valuesByField[field] = value;
  }

  function getHiddenField$6(o, field) {
    var valuesByField = hiddenFieldsMap$1.get(o);

    if (!isUndefined$1(valuesByField)) {
      return valuesByField[field];
    }
  }
  /** version: 1.7.1 */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function detect$1$1(propName) {
    return Object.getOwnPropertyDescriptor(Element.prototype, propName) === undefined;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var _Element$prototype$1 = Element.prototype,
      getAttribute$1 = _Element$prototype$1.getAttribute,
      hasAttribute$1 = _Element$prototype$1.hasAttribute,
      removeAttribute$1 = _Element$prototype$1.removeAttribute,
      setAttribute$1 = _Element$prototype$1.setAttribute;
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  var nodeToAriaPropertyValuesMap = new WeakMap();

  function getAriaPropertyMap(elm) {
    var map = nodeToAriaPropertyValuesMap.get(elm);

    if (map === undefined) {
      map = {};
      nodeToAriaPropertyValuesMap.set(elm, map);
    }

    return map;
  }

  function getNormalizedAriaPropertyValue(value) {
    return value == null ? null : String(value);
  }

  function createAriaPropertyPropertyDescriptor(propName, attrName) {
    return {
      get: function get() {
        var map = getAriaPropertyMap(this);

        if (hasOwnProperty$1.call(map, propName)) {
          return map[propName];
        } // otherwise just reflect what's in the attribute


        return hasAttribute$1.call(this, attrName) ? getAttribute$1.call(this, attrName) : null;
      },
      set: function set(newValue) {
        var normalizedValue = getNormalizedAriaPropertyValue(newValue);
        var map = getAriaPropertyMap(this);
        map[propName] = normalizedValue; // reflect into the corresponding attribute

        if (newValue === null) {
          removeAttribute$1.call(this, attrName);
        } else {
          setAttribute$1.call(this, attrName, newValue);
        }
      },
      configurable: true,
      enumerable: true
    };
  }

  function patch(propName) {
    // Typescript is inferring the wrong function type for this particular
    // overloaded method: https://github.com/Microsoft/TypeScript/issues/27972
    // @ts-ignore type-mismatch
    var attrName = PropNameToAttrNameMap[propName];
    var descriptor = createAriaPropertyPropertyDescriptor(propName, attrName);
    Object.defineProperty(Element.prototype, propName, descriptor);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var ElementPrototypeAriaPropertyNames = keys(PropNameToAttrNameMap);

  for (var _i = 0, len = ElementPrototypeAriaPropertyNames.length; _i < len; _i += 1) {
    var propName = ElementPrototypeAriaPropertyNames[_i];

    if (detect$1$1(propName)) {
      patch(propName);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var nextTickCallbackQueue = [];
  var SPACE_CHAR = 32;
  var EmptyObject = seal(create$1(null));
  var EmptyArray = seal([]);

  function flushCallbackQueue() {
    {
      if (nextTickCallbackQueue.length === 0) {
        throw new Error("Internal Error: If callbackQueue is scheduled, it is because there must be at least one callback on this pending queue.");
      }
    }

    var callbacks = nextTickCallbackQueue;
    nextTickCallbackQueue = []; // reset to a new queue

    for (var _i2 = 0, _len2 = callbacks.length; _i2 < _len2; _i2 += 1) {
      callbacks[_i2]();
    }
  }

  function addCallbackToNextTick(callback) {
    {
      if (!isFunction$1(callback)) {
        throw new Error("Internal Error: addCallbackToNextTick() can only accept a function callback");
      }
    }

    if (nextTickCallbackQueue.length === 0) {
      Promise.resolve().then(flushCallbackQueue);
    }

    ArrayPush$1.call(nextTickCallbackQueue, callback);
  }
  /*
   * Copyright (c) 2019, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var create$1$1 = Object.create;
  var _Array$prototype3 = Array.prototype,
      ArraySplice$1 = _Array$prototype3.splice,
      ArrayIndexOf$1$1 = _Array$prototype3.indexOf,
      ArrayPush$1$1 = _Array$prototype3.push;
  var TargetToReactiveRecordMap = new WeakMap();

  function isUndefined$1$1(obj) {
    return obj === undefined;
  }

  function getReactiveRecord(target) {
    var reactiveRecord = TargetToReactiveRecordMap.get(target);

    if (isUndefined$1$1(reactiveRecord)) {
      var newRecord = create$1$1(null);
      reactiveRecord = newRecord;
      TargetToReactiveRecordMap.set(target, newRecord);
    }

    return reactiveRecord;
  }

  var currentReactiveObserver = null;

  function valueMutated(target, key) {
    var reactiveRecord = TargetToReactiveRecordMap.get(target);

    if (!isUndefined$1$1(reactiveRecord)) {
      var reactiveObservers = reactiveRecord[key];

      if (!isUndefined$1$1(reactiveObservers)) {
        for (var _i3 = 0, _len3 = reactiveObservers.length; _i3 < _len3; _i3 += 1) {
          var ro = reactiveObservers[_i3];
          ro.notify();
        }
      }
    }
  }

  function valueObserved(target, key) {
    // We should determine if an active Observing Record is present to track mutations.
    if (currentReactiveObserver === null) {
      return;
    }

    var ro = currentReactiveObserver;
    var reactiveRecord = getReactiveRecord(target);
    var reactiveObservers = reactiveRecord[key];

    if (isUndefined$1$1(reactiveObservers)) {
      reactiveObservers = [];
      reactiveRecord[key] = reactiveObservers;
    } else if (reactiveObservers[0] === ro) {
      return; // perf optimization considering that most subscriptions will come from the same record
    }

    if (ArrayIndexOf$1$1.call(reactiveObservers, ro) === -1) {
      ro.link(reactiveObservers);
    }
  }

  var ReactiveObserver =
  /*#__PURE__*/
  function () {
    function ReactiveObserver(callback) {
      classCallCheck(this, ReactiveObserver);

      this.listeners = [];
      this.callback = callback;
    }

    createClass(ReactiveObserver, [{
      key: "observe",
      value: function observe(job) {
        var inceptionReactiveRecord = currentReactiveObserver;
        currentReactiveObserver = this;
        var error;

        try {
          job();
        } catch (e) {
          error = Object(e);
        } finally {
          currentReactiveObserver = inceptionReactiveRecord;

          if (error !== undefined) {
            throw error; // eslint-disable-line no-unsafe-finally
          }
        }
      }
      /**
       * This method is responsible for disconnecting the Reactive Observer
       * from any Reactive Record that has a reference to it, to prevent future
       * notifications about previously recorded access.
       */

    }, {
      key: "reset",
      value: function reset() {
        var listeners = this.listeners;
        var len = listeners.length;

        if (len > 0) {
          for (var _i4 = 0; _i4 < len; _i4 += 1) {
            var set = listeners[_i4];
            var pos = ArrayIndexOf$1$1.call(listeners[_i4], this);
            ArraySplice$1.call(set, pos, 1);
          }

          listeners.length = 0;
        }
      } // friend methods

    }, {
      key: "notify",
      value: function notify() {
        this.callback.call(undefined, this);
      }
    }, {
      key: "link",
      value: function link(reactiveObservers) {
        ArrayPush$1$1.call(reactiveObservers, this); // we keep track of observing records where the observing record was added to so we can do some clean up later on

        ArrayPush$1$1.call(this.listeners, reactiveObservers);
      }
    }]);

    return ReactiveObserver;
  }();
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function componentValueMutated(vm, key) {
    valueMutated(vm.component, key);
  }

  function componentValueObserved(vm, key) {
    valueObserved(vm.component, key);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function getComponentTag(vm) {
    return "<".concat(StringToLowerCase.call(vm.tagName), ">");
  } // TODO [#1695]: Unify getComponentStack and getErrorComponentStack


  function getComponentStack(vm) {
    var stack = [];
    var prefix = '';

    while (!isNull$1(vm.owner)) {
      ArrayPush$1.call(stack, prefix + getComponentTag(vm));
      vm = vm.owner;
      prefix += '\t';
    }

    return ArrayJoin$1.call(stack, '\n');
  }

  function getErrorComponentStack(vm) {
    var wcStack = [];
    var currentVm = vm;

    while (!isNull$1(currentVm)) {
      ArrayPush$1.call(wcStack, getComponentTag(currentVm));
      currentVm = currentVm.owner;
    }

    return wcStack.reverse().join('\n\t');
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function logError(message, vm) {
    var msg = "[LWC error]: ".concat(message);

    if (!isUndefined$1(vm)) {
      msg = "".concat(msg, "\n").concat(getComponentStack(vm));
    }

    try {
      throw new Error(msg);
    } catch (e) {
      /* eslint-disable-next-line no-console */
      console.error(e);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function handleEvent(event, vnode) {
    var type = event.type;
    var on = vnode.data.on;
    var handler = on && on[type]; // call event handler if exists

    if (handler) {
      handler.call(undefined, event);
    }
  }

  function createListener() {
    return function handler(event) {
      handleEvent(event, handler.vnode);
    };
  }

  function updateAllEventListeners(oldVnode, vnode) {
    if (isUndefined$1(oldVnode.listener)) {
      createAllEventListeners(vnode);
    } else {
      vnode.listener = oldVnode.listener;
      vnode.listener.vnode = vnode;
    }
  }

  function createAllEventListeners(vnode) {
    var on = vnode.data.on;

    if (isUndefined$1(on)) {
      return;
    }

    var elm = vnode.elm;
    var listener = vnode.listener = createListener();
    listener.vnode = vnode;
    var name;

    for (name in on) {
      elm.addEventListener(name, listener);
    }
  }

  var modEvents = {
    update: updateAllEventListeners,
    create: createAllEventListeners
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  var defaultDefHTMLPropertyNames = ['accessKey', 'dir', 'draggable', 'hidden', 'id', 'lang', 'spellcheck', 'tabIndex', 'title']; // Few more exceptions that are using the attribute name to match the property in lowercase.
  // this list was compiled from https://msdn.microsoft.com/en-us/library/ms533062(v=vs.85).aspx
  // and https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes
  // Note: this list most be in sync with the compiler as well.

  var HTMLPropertyNamesWithLowercasedReflectiveAttributes = ['accessKey', 'readOnly', 'tabIndex', 'bgColor', 'colSpan', 'rowSpan', 'contentEditable', 'dateTime', 'formAction', 'isMap', 'maxLength', 'useMap'];

  function offsetPropertyErrorMessage(name) {
    return "Using the `".concat(name, "` property is an anti-pattern because it rounds the value to an integer. Instead, use the `getBoundingClientRect` method to obtain fractional values for the size of an element and its position relative to the viewport.");
  } // Global HTML Attributes & Properties
  // https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes
  // https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement


  var globalHTMLProperties = assign$1(create$1(null), {
    accessKey: {
      attribute: 'accesskey'
    },
    accessKeyLabel: {
      readOnly: true
    },
    className: {
      attribute: 'class',
      error: 'Using the `className` property is an anti-pattern because of slow runtime behavior and potential conflicts with classes provided by the owner element. Use the `classList` API instead.'
    },
    contentEditable: {
      attribute: 'contenteditable'
    },
    dataset: {
      readOnly: true,
      error: "Using the `dataset` property is an anti-pattern because it can't be statically analyzed. Expose each property individually using the `@api` decorator instead."
    },
    dir: {
      attribute: 'dir'
    },
    draggable: {
      attribute: 'draggable'
    },
    dropzone: {
      attribute: 'dropzone',
      readOnly: true
    },
    hidden: {
      attribute: 'hidden'
    },
    id: {
      attribute: 'id'
    },
    inputMode: {
      attribute: 'inputmode'
    },
    lang: {
      attribute: 'lang'
    },
    slot: {
      attribute: 'slot',
      error: 'Using the `slot` property is an anti-pattern.'
    },
    spellcheck: {
      attribute: 'spellcheck'
    },
    style: {
      attribute: 'style'
    },
    tabIndex: {
      attribute: 'tabindex'
    },
    title: {
      attribute: 'title'
    },
    translate: {
      attribute: 'translate'
    },
    // additional "global attributes" that are not present in the link above.
    isContentEditable: {
      readOnly: true
    },
    offsetHeight: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetHeight')
    },
    offsetLeft: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetLeft')
    },
    offsetParent: {
      readOnly: true
    },
    offsetTop: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetTop')
    },
    offsetWidth: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetWidth')
    },
    role: {
      attribute: 'role'
    }
  });
  var AttrNameToPropNameMap$1 = assign$1(create$1(null), AttrNameToPropNameMap);
  var PropNameToAttrNameMap$1 = assign$1(create$1(null), PropNameToAttrNameMap);
  forEach$1.call(defaultDefHTMLPropertyNames, function (propName) {
    var attrName = StringToLowerCase.call(propName);
    AttrNameToPropNameMap$1[attrName] = propName;
    PropNameToAttrNameMap$1[propName] = attrName;
  });
  forEach$1.call(HTMLPropertyNamesWithLowercasedReflectiveAttributes, function (propName) {
    var attrName = StringToLowerCase.call(propName);
    AttrNameToPropNameMap$1[attrName] = propName;
    PropNameToAttrNameMap$1[propName] = attrName;
  });
  var CAPS_REGEX = /[A-Z]/g;
  /**
   * This method maps between property names
   * and the corresponding attribute name.
   */

  function getAttrNameFromPropName(propName) {
    if (isUndefined$1(PropNameToAttrNameMap$1[propName])) {
      PropNameToAttrNameMap$1[propName] = StringReplace.call(propName, CAPS_REGEX, function (match) {
        return '-' + match.toLowerCase();
      });
    }

    return PropNameToAttrNameMap$1[propName];
  }

  var controlledElement = null;
  var controlledAttributeName;

  function isAttributeLocked(elm, attrName) {
    return elm !== controlledElement || attrName !== controlledAttributeName;
  }

  function lockAttribute(_elm, _key) {
    controlledElement = null;
    controlledAttributeName = undefined;
  }

  function unlockAttribute(elm, key) {
    controlledElement = elm;
    controlledAttributeName = key;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var xlinkNS = 'http://www.w3.org/1999/xlink';
  var xmlNS = 'http://www.w3.org/XML/1998/namespace';
  var ColonCharCode = 58;

  function updateAttrs(oldVnode, vnode) {
    var attrs = vnode.data.attrs;

    if (isUndefined$1(attrs)) {
      return;
    }

    var oldAttrs = oldVnode.data.attrs;

    if (oldAttrs === attrs) {
      return;
    }

    {
      assert$1.invariant(isUndefined$1(oldAttrs) || keys(oldAttrs).join(',') === keys(attrs).join(','), "vnode.data.attrs cannot change shape.");
    }

    var elm = vnode.elm;
    var key;
    oldAttrs = isUndefined$1(oldAttrs) ? EmptyObject : oldAttrs; // update modified attributes, add new attributes
    // this routine is only useful for data-* attributes in all kind of elements
    // and aria-* in standard elements (custom elements will use props for these)

    for (key in attrs) {
      var cur = attrs[key];
      var old = oldAttrs[key];

      if (old !== cur) {
        unlockAttribute(elm, key);

        if (StringCharCodeAt$1.call(key, 3) === ColonCharCode) {
          // Assume xml namespace
          elm.setAttributeNS(xmlNS, key, cur);
        } else if (StringCharCodeAt$1.call(key, 5) === ColonCharCode) {
          // Assume xlink namespace
          elm.setAttributeNS(xlinkNS, key, cur);
        } else if (isNull$1(cur)) {
          elm.removeAttribute(key);
        } else {
          elm.setAttribute(key, cur);
        }

        lockAttribute();
      }
    }
  }

  var emptyVNode = {
    data: {}
  };
  var modAttrs = {
    create: function create(vnode) {
      return updateAttrs(emptyVNode, vnode);
    },
    update: updateAttrs
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  function isLiveBindingProp(sel, key) {
    // For properties with live bindings, we read values from the DOM element
    // instead of relying on internally tracked values.
    return sel === 'input' && (key === 'value' || key === 'checked');
  }

  function update(oldVnode, vnode) {
    var props = vnode.data.props;

    if (isUndefined$1(props)) {
      return;
    }

    var oldProps = oldVnode.data.props;

    if (oldProps === props) {
      return;
    }

    {
      assert$1.invariant(isUndefined$1(oldProps) || keys(oldProps).join(',') === keys(props).join(','), 'vnode.data.props cannot change shape.');
    }

    var elm = vnode.elm;
    var isFirstPatch = isUndefined$1(oldProps);
    var sel = vnode.sel;

    for (var key in props) {
      var cur = props[key];

      {
        if (!(key in elm)) {
          // TODO [#1297]: Move this validation to the compiler
          assert$1.fail("Unknown public property \"".concat(key, "\" of element <").concat(sel, ">. This is likely a typo on the corresponding attribute \"").concat(getAttrNameFromPropName(key), "\"."));
        }
      } // if it is the first time this element is patched, or the current value is different to the previous value...


      if (isFirstPatch || cur !== (isLiveBindingProp(sel, key) ? elm[key] : oldProps[key])) {
        elm[key] = cur;
      }
    }
  }

  var emptyVNode$1 = {
    data: {}
  };
  var modProps = {
    create: function create(vnode) {
      return update(emptyVNode$1, vnode);
    },
    update: update
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  var classNameToClassMap = create$1(null);

  function getMapFromClassName(className) {
    // Intentionally using == to match undefined and null values from computed style attribute
    if (className == null) {
      return EmptyObject;
    } // computed class names must be string


    className = isString(className) ? className : className + '';
    var map = classNameToClassMap[className];

    if (map) {
      return map;
    }

    map = create$1(null);
    var start = 0;
    var o;
    var len = className.length;

    for (o = 0; o < len; o++) {
      if (StringCharCodeAt$1.call(className, o) === SPACE_CHAR) {
        if (o > start) {
          map[StringSlice.call(className, start, o)] = true;
        }

        start = o + 1;
      }
    }

    if (o > start) {
      map[StringSlice.call(className, start, o)] = true;
    }

    classNameToClassMap[className] = map;

    {
      // just to make sure that this object never changes as part of the diffing algo
      freeze(map);
    }

    return map;
  }

  function updateClassAttribute(oldVnode, vnode) {
    var elm = vnode.elm,
        newClass = vnode.data.className;
    var oldClass = oldVnode.data.className;

    if (oldClass === newClass) {
      return;
    }

    var classList = elm.classList;
    var newClassMap = getMapFromClassName(newClass);
    var oldClassMap = getMapFromClassName(oldClass);
    var name;

    for (name in oldClassMap) {
      // remove only if it is not in the new class collection and it is not set from within the instance
      if (isUndefined$1(newClassMap[name])) {
        classList.remove(name);
      }
    }

    for (name in newClassMap) {
      if (isUndefined$1(oldClassMap[name])) {
        classList.add(name);
      }
    }
  }

  var emptyVNode$2 = {
    data: {}
  };
  var modComputedClassName = {
    create: function create(vnode) {
      return updateClassAttribute(emptyVNode$2, vnode);
    },
    update: updateClassAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  function updateStyleAttribute(oldVnode, vnode) {
    var newStyle = vnode.data.style;

    if (oldVnode.data.style === newStyle) {
      return;
    }

    var elm = vnode.elm;
    var style = elm.style;

    if (!isString(newStyle) || newStyle === '') {
      removeAttribute$1.call(elm, 'style');
    } else {
      style.cssText = newStyle;
    }
  }

  var emptyVNode$3 = {
    data: {}
  };
  var modComputedStyle = {
    create: function create(vnode) {
      return updateStyleAttribute(emptyVNode$3, vnode);
    },
    update: updateStyleAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // The compiler takes care of transforming the inline classnames into an object. It's faster to set the
  // different classnames properties individually instead of via a string.

  function createClassAttribute(vnode) {
    var elm = vnode.elm,
        classMap = vnode.data.classMap;

    if (isUndefined$1(classMap)) {
      return;
    }

    var classList = elm.classList;

    for (var name in classMap) {
      classList.add(name);
    }
  }

  var modStaticClassName = {
    create: createClassAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // The compiler takes care of transforming the inline style into an object. It's faster to set the
  // different style properties individually instead of via a string.

  function createStyleAttribute(vnode) {
    var elm = vnode.elm,
        styleMap = vnode.data.styleMap;

    if (isUndefined$1(styleMap)) {
      return;
    }

    var style = elm.style;

    for (var name in styleMap) {
      style[name] = styleMap[name];
    }
  }

  var modStaticStyle = {
    create: createStyleAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
  @license
  Copyright (c) 2015 Simon Friis Vindum.
  This code may only be used under the MIT License found at
  https://github.com/snabbdom/snabbdom/blob/master/LICENSE
  Code distributed by Snabbdom as part of the Snabbdom project at
  https://github.com/snabbdom/snabbdom/
  */

  function isUndef(s) {
    return s === undefined;
  }

  function sameVnode(vnode1, vnode2) {
    return vnode1.key === vnode2.key && vnode1.sel === vnode2.sel;
  }

  function isVNode(vnode) {
    return vnode != null;
  }

  function createKeyToOldIdx(children, beginIdx, endIdx) {
    var map = {};
    var j, key, ch; // TODO [#1637]: simplify this by assuming that all vnodes has keys

    for (j = beginIdx; j <= endIdx; ++j) {
      ch = children[j];

      if (isVNode(ch)) {
        key = ch.key;

        if (key !== undefined) {
          map[key] = j;
        }
      }
    }

    return map;
  }

  function addVnodes(parentElm, before, vnodes, startIdx, endIdx) {
    for (; startIdx <= endIdx; ++startIdx) {
      var ch = vnodes[startIdx];

      if (isVNode(ch)) {
        ch.hook.create(ch);
        ch.hook.insert(ch, parentElm, before);
      }
    }
  }

  function removeVnodes(parentElm, vnodes, startIdx, endIdx) {
    for (; startIdx <= endIdx; ++startIdx) {
      var ch = vnodes[startIdx]; // text nodes do not have logic associated to them

      if (isVNode(ch)) {
        ch.hook.remove(ch, parentElm);
      }
    }
  }

  function updateDynamicChildren(parentElm, oldCh, newCh) {
    var oldStartIdx = 0;
    var newStartIdx = 0;
    var oldEndIdx = oldCh.length - 1;
    var oldStartVnode = oldCh[0];
    var oldEndVnode = oldCh[oldEndIdx];
    var newEndIdx = newCh.length - 1;
    var newStartVnode = newCh[0];
    var newEndVnode = newCh[newEndIdx];
    var oldKeyToIdx;
    var idxInOld;
    var elmToMove;
    var before;

    while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
      if (!isVNode(oldStartVnode)) {
        oldStartVnode = oldCh[++oldStartIdx]; // Vnode might have been moved left
      } else if (!isVNode(oldEndVnode)) {
        oldEndVnode = oldCh[--oldEndIdx];
      } else if (!isVNode(newStartVnode)) {
        newStartVnode = newCh[++newStartIdx];
      } else if (!isVNode(newEndVnode)) {
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldStartVnode, newStartVnode)) {
        patchVnode(oldStartVnode, newStartVnode);
        oldStartVnode = oldCh[++oldStartIdx];
        newStartVnode = newCh[++newStartIdx];
      } else if (sameVnode(oldEndVnode, newEndVnode)) {
        patchVnode(oldEndVnode, newEndVnode);
        oldEndVnode = oldCh[--oldEndIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldStartVnode, newEndVnode)) {
        // Vnode moved right
        patchVnode(oldStartVnode, newEndVnode);
        newEndVnode.hook.move(oldStartVnode, parentElm, oldEndVnode.elm.nextSibling);
        oldStartVnode = oldCh[++oldStartIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldEndVnode, newStartVnode)) {
        // Vnode moved left
        patchVnode(oldEndVnode, newStartVnode);
        newStartVnode.hook.move(oldEndVnode, parentElm, oldStartVnode.elm);
        oldEndVnode = oldCh[--oldEndIdx];
        newStartVnode = newCh[++newStartIdx];
      } else {
        if (oldKeyToIdx === undefined) {
          oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx);
        }

        idxInOld = oldKeyToIdx[newStartVnode.key];

        if (isUndef(idxInOld)) {
          // New element
          newStartVnode.hook.create(newStartVnode);
          newStartVnode.hook.insert(newStartVnode, parentElm, oldStartVnode.elm);
          newStartVnode = newCh[++newStartIdx];
        } else {
          elmToMove = oldCh[idxInOld];

          if (isVNode(elmToMove)) {
            if (elmToMove.sel !== newStartVnode.sel) {
              // New element
              newStartVnode.hook.create(newStartVnode);
              newStartVnode.hook.insert(newStartVnode, parentElm, oldStartVnode.elm);
            } else {
              patchVnode(elmToMove, newStartVnode);
              oldCh[idxInOld] = undefined;
              newStartVnode.hook.move(elmToMove, parentElm, oldStartVnode.elm);
            }
          }

          newStartVnode = newCh[++newStartIdx];
        }
      }
    }

    if (oldStartIdx <= oldEndIdx || newStartIdx <= newEndIdx) {
      if (oldStartIdx > oldEndIdx) {
        var n = newCh[newEndIdx + 1];
        before = isVNode(n) ? n.elm : null;
        addVnodes(parentElm, before, newCh, newStartIdx, newEndIdx);
      } else {
        removeVnodes(parentElm, oldCh, oldStartIdx, oldEndIdx);
      }
    }
  }

  function updateStaticChildren(parentElm, oldCh, newCh) {
    var length = newCh.length;

    if (oldCh.length === 0) {
      // the old list is empty, we can directly insert anything new
      addVnodes(parentElm, null, newCh, 0, length);
      return;
    } // if the old list is not empty, the new list MUST have the same
    // amount of nodes, that's why we call this static children


    var referenceElm = null;

    for (var _i5 = length - 1; _i5 >= 0; _i5 -= 1) {
      var vnode = newCh[_i5];
      var oldVNode = oldCh[_i5];

      if (vnode !== oldVNode) {
        if (isVNode(oldVNode)) {
          if (isVNode(vnode)) {
            // both vnodes must be equivalent, and se just need to patch them
            patchVnode(oldVNode, vnode);
            referenceElm = vnode.elm;
          } else {
            // removing the old vnode since the new one is null
            oldVNode.hook.remove(oldVNode, parentElm);
          }
        } else if (isVNode(vnode)) {
          // this condition is unnecessary
          vnode.hook.create(vnode); // insert the new node one since the old one is null

          vnode.hook.insert(vnode, parentElm, referenceElm);
          referenceElm = vnode.elm;
        }
      }
    }
  }

  function patchVnode(oldVnode, vnode) {
    if (oldVnode !== vnode) {
      vnode.elm = oldVnode.elm;
      vnode.hook.update(oldVnode, vnode);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function generateDataDescriptor(options) {
    return assign$1({
      configurable: true,
      enumerable: true,
      writable: true
    }, options);
  }

  function generateAccessorDescriptor(options) {
    return assign$1({
      configurable: true,
      enumerable: true
    }, options);
  }

  var isDomMutationAllowed = false;

  function unlockDomMutation() {

    isDomMutationAllowed = true;
  }

  function lockDomMutation() {

    isDomMutationAllowed = false;
  }

  function portalRestrictionErrorMessage(name, type) {
    return "The `".concat(name, "` ").concat(type, " is available only on elements that use the `lwc:dom=\"manual\"` directive.");
  }

  function getNodeRestrictionsDescriptors(node) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var originalTextContentDescriptor = getPropertyDescriptor$1(node, 'textContent');
    var originalNodeValueDescriptor = getPropertyDescriptor$1(node, 'nodeValue');
    var appendChild = node.appendChild,
        insertBefore = node.insertBefore,
        removeChild = node.removeChild,
        replaceChild = node.replaceChild;
    return {
      appendChild: generateDataDescriptor({
        value: function value(aChild) {
          if (_instanceof_1(this, Element) && isFalse$1$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('appendChild', 'method'));
          }

          return appendChild.call(this, aChild);
        }
      }),
      insertBefore: generateDataDescriptor({
        value: function value(newNode, referenceNode) {
          if (!isDomMutationAllowed && _instanceof_1(this, Element) && isFalse$1$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('insertBefore', 'method'));
          }

          return insertBefore.call(this, newNode, referenceNode);
        }
      }),
      removeChild: generateDataDescriptor({
        value: function value(aChild) {
          if (!isDomMutationAllowed && _instanceof_1(this, Element) && isFalse$1$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('removeChild', 'method'));
          }

          return removeChild.call(this, aChild);
        }
      }),
      replaceChild: generateDataDescriptor({
        value: function value(newChild, oldChild) {
          if (_instanceof_1(this, Element) && isFalse$1$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('replaceChild', 'method'));
          }

          return replaceChild.call(this, newChild, oldChild);
        }
      }),
      nodeValue: generateAccessorDescriptor({
        get: function get() {
          return originalNodeValueDescriptor.get.call(this);
        },
        set: function set(value) {
          if (!isDomMutationAllowed && _instanceof_1(this, Element) && isFalse$1$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('nodeValue', 'property'));
          }

          originalNodeValueDescriptor.set.call(this, value);
        }
      }),
      textContent: generateAccessorDescriptor({
        get: function get() {
          return originalTextContentDescriptor.get.call(this);
        },
        set: function set(value) {
          if (_instanceof_1(this, Element) && isFalse$1$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('textContent', 'property'));
          }

          originalTextContentDescriptor.set.call(this, value);
        }
      })
    };
  }

  function getElementRestrictionsDescriptors(elm, options) {

    var descriptors = getNodeRestrictionsDescriptors(elm, options);
    var originalInnerHTMLDescriptor = getPropertyDescriptor$1(elm, 'innerHTML');
    var originalOuterHTMLDescriptor = getPropertyDescriptor$1(elm, 'outerHTML');
    assign$1(descriptors, {
      innerHTML: generateAccessorDescriptor({
        get: function get() {
          return originalInnerHTMLDescriptor.get.call(this);
        },
        set: function set(value) {
          if (isFalse$1$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('innerHTML', 'property'), getAssociatedVMIfPresent(this));
          }

          return originalInnerHTMLDescriptor.set.call(this, value);
        }
      }),
      outerHTML: generateAccessorDescriptor({
        get: function get() {
          return originalOuterHTMLDescriptor.get.call(this);
        },
        set: function set(_value) {
          throw new TypeError("Invalid attempt to set outerHTML on Element.");
        }
      })
    });
    return descriptors;
  }

  var BLOCKED_SHADOW_ROOT_METHODS = ['cloneNode', 'getElementById', 'getSelection', 'elementsFromPoint', 'dispatchEvent'];

  function getShadowRootRestrictionsDescriptors(sr) {
    // thing when using the real shadow root, because if that's the case,
    // the component will not work when running with synthetic shadow.


    var originalAddEventListener = sr.addEventListener;
    var descriptors = getNodeRestrictionsDescriptors(sr);
    var originalInnerHTMLDescriptor = getPropertyDescriptor$1(sr, 'innerHTML');
    var originalTextContentDescriptor = getPropertyDescriptor$1(sr, 'textContent');
    assign$1(descriptors, {
      innerHTML: generateAccessorDescriptor({
        get: function get() {
          return originalInnerHTMLDescriptor.get.call(this);
        },
        set: function set(_value) {
          throw new TypeError("Invalid attempt to set innerHTML on ShadowRoot.");
        }
      }),
      textContent: generateAccessorDescriptor({
        get: function get() {
          return originalTextContentDescriptor.get.call(this);
        },
        set: function set(_value) {
          throw new TypeError("Invalid attempt to set textContent on ShadowRoot.");
        }
      }),
      addEventListener: generateDataDescriptor({
        value: function value(type, listener, options) {
          // TODO [#420]: this is triggered when the component author attempts to add a listener
          // programmatically into its Component's shadow root
          if (!isUndefined$1(options)) {
            logError('The `addEventListener` method in `LightningElement` does not support any options.', getAssociatedVMIfPresent(this));
          } // Typescript does not like it when you treat the `arguments` object as an array
          // @ts-ignore type-mismatch


          return originalAddEventListener.apply(this, arguments);
        }
      })
    });
    forEach$1.call(BLOCKED_SHADOW_ROOT_METHODS, function (methodName) {
      descriptors[methodName] = generateAccessorDescriptor({
        get: function get() {
          throw new Error("Disallowed method \"".concat(methodName, "\" in ShadowRoot."));
        }
      });
    });
    return descriptors;
  } // Custom Elements Restrictions:
  // -----------------------------


  function getCustomElementRestrictionsDescriptors(elm) {

    var descriptors = getNodeRestrictionsDescriptors(elm);
    var originalAddEventListener = elm.addEventListener;
    var originalInnerHTMLDescriptor = getPropertyDescriptor$1(elm, 'innerHTML');
    var originalOuterHTMLDescriptor = getPropertyDescriptor$1(elm, 'outerHTML');
    var originalTextContentDescriptor = getPropertyDescriptor$1(elm, 'textContent');
    return assign$1(descriptors, {
      innerHTML: generateAccessorDescriptor({
        get: function get() {
          return originalInnerHTMLDescriptor.get.call(this);
        },
        set: function set(_value) {
          throw new TypeError("Invalid attempt to set innerHTML on HTMLElement.");
        }
      }),
      outerHTML: generateAccessorDescriptor({
        get: function get() {
          return originalOuterHTMLDescriptor.get.call(this);
        },
        set: function set(_value) {
          throw new TypeError("Invalid attempt to set outerHTML on HTMLElement.");
        }
      }),
      textContent: generateAccessorDescriptor({
        get: function get() {
          return originalTextContentDescriptor.get.call(this);
        },
        set: function set(_value) {
          throw new TypeError("Invalid attempt to set textContent on HTMLElement.");
        }
      }),
      addEventListener: generateDataDescriptor({
        value: function value(type, listener, options) {
          // TODO [#420]: this is triggered when the component author attempts to add a listener
          // programmatically into a lighting element node
          if (!isUndefined$1(options)) {
            logError('The `addEventListener` method in `LightningElement` does not support any options.', getAssociatedVMIfPresent(this));
          } // Typescript does not like it when you treat the `arguments` object as an array
          // @ts-ignore type-mismatch


          return originalAddEventListener.apply(this, arguments);
        }
      })
    });
  }

  function getComponentRestrictionsDescriptors() {

    return {
      tagName: generateAccessorDescriptor({
        get: function get() {
          throw new Error("Usage of property `tagName` is disallowed because the component itself does" + " not know which tagName will be used to create the element, therefore writing" + " code that check for that value is error prone.");
        },
        configurable: true,
        enumerable: false
      })
    };
  }

  function getLightningElementPrototypeRestrictionsDescriptors(proto) {

    var originalDispatchEvent = proto.dispatchEvent;
    var descriptors = {
      dispatchEvent: generateDataDescriptor({
        value: function value(event) {
          var vm = getAssociatedVM(this);

          if (!isNull$1(event) && isObject$1(event)) {
            var type = event.type;

            if (!/^[a-z][a-z0-9_]*$/.test(type)) {
              logError("Invalid event type \"".concat(type, "\" dispatched in element ").concat(getComponentTag(vm), ".") + " Event name must start with a lowercase letter and followed only lowercase" + " letters, numbers, and underscores", vm);
            }
          } // Typescript does not like it when you treat the `arguments` object as an array
          // @ts-ignore type-mismatch


          return originalDispatchEvent.apply(this, arguments);
        }
      })
    };
    forEach$1.call(getOwnPropertyNames(globalHTMLProperties), function (propName) {
      if (propName in proto) {
        return; // no need to redefine something that we are already exposing
      }

      descriptors[propName] = generateAccessorDescriptor({
        get: function get() {
          var _globalHTMLProperties = globalHTMLProperties[propName],
              error = _globalHTMLProperties.error,
              attribute = _globalHTMLProperties.attribute;
          var msg = [];
          msg.push("Accessing the global HTML property \"".concat(propName, "\" is disabled."));

          if (error) {
            msg.push(error);
          } else if (attribute) {
            msg.push("Instead access it via `this.getAttribute(\"".concat(attribute, "\")`."));
          }

          logError(msg.join('\n'), getAssociatedVM(this));
        },
        set: function set() {
          var readOnly = globalHTMLProperties[propName].readOnly;

          if (readOnly) {
            logError("The global HTML property `".concat(propName, "` is read-only."), getAssociatedVM(this));
          }
        }
      });
    });
    return descriptors;
  }

  function patchElementWithRestrictions(elm, options) {
    defineProperties$1(elm, getElementRestrictionsDescriptors(elm, options));
  } // This routine will prevent access to certain properties on a shadow root instance to guarantee
  // that all components will work fine in IE11 and other browsers without shadow dom support.


  function patchShadowRootWithRestrictions(sr) {
    defineProperties$1(sr, getShadowRootRestrictionsDescriptors(sr));
  }

  function patchCustomElementWithRestrictions(elm) {
    var restrictionsDescriptors = getCustomElementRestrictionsDescriptors(elm);
    var elmProto = getPrototypeOf$2(elm);
    setPrototypeOf$2(elm, create$1(elmProto, restrictionsDescriptors));
  }

  function patchComponentWithRestrictions(cmp) {
    defineProperties$1(cmp, getComponentRestrictionsDescriptors());
  }

  function patchLightningElementPrototypeWithRestrictions(proto) {
    defineProperties$1(proto, getLightningElementPrototypeRestrictionsDescriptors(proto));
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * This is a descriptor map that contains
   * all standard properties that a Custom Element can support (including AOM properties), which
   * determines what kind of capabilities the Base HTML Element and
   * Base Lightning Element should support.
   */


  var HTMLElementOriginalDescriptors = create$1(null);
  forEach$1.call(keys(PropNameToAttrNameMap), function (propName) {
    // Note: intentionally using our in-house getPropertyDescriptor instead of getOwnPropertyDescriptor here because
    // in IE11, some properties are on Element.prototype instead of HTMLElement, just to be sure.
    var descriptor = getPropertyDescriptor$1(HTMLElement.prototype, propName);

    if (!isUndefined$1(descriptor)) {
      HTMLElementOriginalDescriptors[propName] = descriptor;
    }
  });
  forEach$1.call(defaultDefHTMLPropertyNames, function (propName) {
    // Note: intentionally using our in-house getPropertyDescriptor instead of getOwnPropertyDescriptor here because
    // in IE11, id property is on Element.prototype instead of HTMLElement, and we suspect that more will fall into
    // this category, so, better to be sure.
    var descriptor = getPropertyDescriptor$1(HTMLElement.prototype, propName);

    if (!isUndefined$1(descriptor)) {
      HTMLElementOriginalDescriptors[propName] = descriptor;
    }
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * This operation is called with a descriptor of an standard html property
   * that a Custom Element can support (including AOM properties), which
   * determines what kind of capabilities the Base Lightning Element should support. When producing the new descriptors
   * for the Base Lightning Element, it also include the reactivity bit, so the standard property is reactive.
   */

  function createBridgeToElementDescriptor(propName, descriptor) {
    var _get = descriptor.get,
        _set = descriptor.set,
        enumerable = descriptor.enumerable,
        configurable = descriptor.configurable;

    if (!isFunction$1(_get)) {
      {
        assert$1.fail("Detected invalid public property descriptor for HTMLElement.prototype.".concat(propName, " definition. Missing the standard getter."));
      }

      throw new TypeError();
    }

    if (!isFunction$1(_set)) {
      {
        assert$1.fail("Detected invalid public property descriptor for HTMLElement.prototype.".concat(propName, " definition. Missing the standard setter."));
      }

      throw new TypeError();
    }

    return {
      enumerable: enumerable,
      configurable: configurable,
      get: function get() {
        var vm = getAssociatedVM(this);

        if (isBeingConstructed(vm)) {
          {
            var name = vm.elm.constructor.name;
            logError("`".concat(name, "` constructor can't read the value of property `").concat(propName, "` because the owner component hasn't set the value yet. Instead, use the `").concat(name, "` constructor to set a default value for the property."), vm);
          }

          return;
        }

        componentValueObserved(vm, propName);
        return _get.call(vm.elm);
      },
      set: function set(newValue) {
        var vm = getAssociatedVM(this);

        {
          var _vmBeingRendered = getVMBeingRendered();

          assert$1.invariant(!isInvokingRender, "".concat(_vmBeingRendered, ".render() method has side effects on the state of ").concat(vm, ".").concat(propName));
          assert$1.invariant(!isUpdatingTemplate, "When updating the template of ".concat(_vmBeingRendered, ", one of the accessors used by the template has side effects on the state of ").concat(vm, ".").concat(propName));
          assert$1.isFalse(isBeingConstructed(vm), "Failed to construct '".concat(getComponentTag(vm), "': The result must not have attributes."));
          assert$1.invariant(!isObject$1(newValue) || isNull$1(newValue), "Invalid value \"".concat(newValue, "\" for \"").concat(propName, "\" of ").concat(vm, ". Value cannot be an object, must be a primitive value."));
        }

        if (newValue !== vm.cmpProps[propName]) {
          vm.cmpProps[propName] = newValue;
          componentValueMutated(vm, propName);
        }

        return _set.call(vm.elm, newValue);
      }
    };
  }

  function getLinkedElement(cmp) {
    return getAssociatedVM(cmp).elm;
  }
  /**
   * This class is the base class for any LWC element.
   * Some elements directly extends this class, others implement it via inheritance.
   **/


  function BaseLightningElementConstructor() {
    // This should be as performant as possible, while any initialization should be done lazily
    if (isNull$1(vmBeingConstructed)) {
      throw new ReferenceError('Illegal constructor');
    }

    {
      assert$1.invariant(_instanceof_1(vmBeingConstructed.elm, HTMLElement), "Component creation requires a DOM element to be associated to ".concat(vmBeingConstructed, "."));
    }

    var vm = vmBeingConstructed;
    var elm = vm.elm,
        mode = vm.mode,
        ctor = vm.def.ctor;
    var component = this;
    var cmpRoot = elm.attachShadow({
      mode: mode,
      delegatesFocus: !!ctor.delegatesFocus,
      '$$lwc-synthetic-mode$$': true
    });
    vm.component = this;
    vm.cmpRoot = cmpRoot; // Locker hooks assignment. When the LWC engine run with Locker, Locker intercepts all the new
    // component creation and passes hooks to instrument all the component interactions with the
    // engine. We are intentionally hiding this argument from the formal API of LightningElement
    // because we don't want folks to know about it just yet.

    if (arguments.length === 1) {
      var _arguments$ = arguments[0],
          _callHook = _arguments$.callHook,
          _setHook = _arguments$.setHook,
          _getHook = _arguments$.getHook;
      vm.callHook = _callHook;
      vm.setHook = _setHook;
      vm.getHook = _getHook;
    } // Linking elm, shadow root and component with the VM.


    associateVM(component, vm);
    associateVM(cmpRoot, vm);
    associateVM(elm, vm); // Adding extra guard rails in DEV mode.

    {
      patchCustomElementWithRestrictions(elm);
      patchComponentWithRestrictions(component);
      patchShadowRootWithRestrictions(cmpRoot);
    }

    return this;
  }

  BaseLightningElementConstructor.prototype = {
    constructor: BaseLightningElementConstructor,
    dispatchEvent: function dispatchEvent() {
      var elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch;

      return elm.dispatchEvent.apply(elm, arguments);
    },
    addEventListener: function addEventListener(type, listener, options) {
      var vm = getAssociatedVM(this);

      {
        var _vmBeingRendered2 = getVMBeingRendered();

        assert$1.invariant(!isInvokingRender, "".concat(_vmBeingRendered2, ".render() method has side effects on the state of ").concat(vm, " by adding an event listener for \"").concat(type, "\"."));
        assert$1.invariant(!isUpdatingTemplate, "Updating the template of ".concat(_vmBeingRendered2, " has side effects on the state of ").concat(vm, " by adding an event listener for \"").concat(type, "\"."));
        assert$1.invariant(isFunction$1(listener), "Invalid second argument for this.addEventListener() in ".concat(vm, " for event \"").concat(type, "\". Expected an EventListener but received ").concat(listener, "."));
      }

      var wrappedListener = getWrappedComponentsListener(vm, listener);
      vm.elm.addEventListener(type, wrappedListener, options);
    },
    removeEventListener: function removeEventListener(type, listener, options) {
      var vm = getAssociatedVM(this);
      var wrappedListener = getWrappedComponentsListener(vm, listener);
      vm.elm.removeEventListener(type, wrappedListener, options);
    },
    hasAttribute: function hasAttribute() {
      var elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.hasAttribute.apply(elm, arguments);
    },
    hasAttributeNS: function hasAttributeNS() {
      var elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.hasAttributeNS.apply(elm, arguments);
    },
    removeAttribute: function removeAttribute(attrName) {
      var elm = getLinkedElement(this);
      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.removeAttribute.apply(elm, arguments);
      lockAttribute();
    },
    removeAttributeNS: function removeAttributeNS(_namespace, attrName) {
      var elm = getLinkedElement(this);
      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.removeAttributeNS.apply(elm, arguments);
      lockAttribute();
    },
    getAttribute: function getAttribute() {
      var elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.getAttribute.apply(elm, arguments);
    },
    getAttributeNS: function getAttributeNS() {
      var elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.getAttributeNS.apply(elm, arguments);
    },
    setAttribute: function setAttribute(attrName) {
      var elm = getLinkedElement(this);

      {
        var vm = getAssociatedVM(this);
        assert$1.isFalse(isBeingConstructed(vm), "Failed to construct '".concat(getComponentTag(vm), "': The result must not have attributes."));
      }

      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.setAttribute.apply(elm, arguments);
      lockAttribute();
    },
    setAttributeNS: function setAttributeNS(_namespace, attrName) {
      var elm = getLinkedElement(this);

      {
        var vm = getAssociatedVM(this);
        assert$1.isFalse(isBeingConstructed(vm), "Failed to construct '".concat(getComponentTag(vm), "': The result must not have attributes."));
      }

      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.setAttributeNS.apply(elm, arguments);
      lockAttribute();
    },
    getBoundingClientRect: function getBoundingClientRect() {
      var elm = getLinkedElement(this);

      {
        var vm = getAssociatedVM(this);
        assert$1.isFalse(isBeingConstructed(vm), "this.getBoundingClientRect() should not be called during the construction of the custom element for ".concat(getComponentTag(vm), " because the element is not yet in the DOM, instead, you can use it in one of the available life-cycle hooks."));
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.getBoundingClientRect.apply(elm, arguments);
    },

    /**
     * Returns the first element that is a descendant of node that
     * matches selectors.
     */
    // querySelector<K extends keyof HTMLElementTagNameMap>(selectors: K): HTMLElementTagNameMap[K] | null;
    // querySelector<K extends keyof SVGElementTagNameMap>(selectors: K): SVGElementTagNameMap[K] | null;
    querySelector: function querySelector() {
      var elm = getLinkedElement(this);

      {
        var vm = getAssociatedVM(this);
        assert$1.isFalse(isBeingConstructed(vm), "this.querySelector() cannot be called during the construction of the custom element for ".concat(getComponentTag(vm), " because no children has been added to this element yet."));
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.querySelector.apply(elm, arguments);
    },

    /**
     * Returns all element descendants of node that
     * match selectors.
     */
    // querySelectorAll<K extends keyof HTMLElementTagNameMap>(selectors: K): NodeListOf<HTMLElementTagNameMap[K]>,
    // querySelectorAll<K extends keyof SVGElementTagNameMap>(selectors: K): NodeListOf<SVGElementTagNameMap[K]>,
    querySelectorAll: function querySelectorAll() {
      var elm = getLinkedElement(this);

      {
        var vm = getAssociatedVM(this);
        assert$1.isFalse(isBeingConstructed(vm), "this.querySelectorAll() cannot be called during the construction of the custom element for ".concat(getComponentTag(vm), " because no children has been added to this element yet."));
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.querySelectorAll.apply(elm, arguments);
    },

    /**
     * Returns all element descendants of node that
     * match the provided tagName.
     */
    getElementsByTagName: function getElementsByTagName() {
      var elm = getLinkedElement(this);

      {
        var vm = getAssociatedVM(this);
        assert$1.isFalse(isBeingConstructed(vm), "this.getElementsByTagName() cannot be called during the construction of the custom element for ".concat(getComponentTag(vm), " because no children has been added to this element yet."));
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.getElementsByTagName.apply(elm, arguments);
    },

    /**
     * Returns all element descendants of node that
     * match the provide classnames.
     */
    getElementsByClassName: function getElementsByClassName() {
      var elm = getLinkedElement(this);

      {
        var vm = getAssociatedVM(this);
        assert$1.isFalse(isBeingConstructed(vm), "this.getElementsByClassName() cannot be called during the construction of the custom element for ".concat(getComponentTag(vm), " because no children has been added to this element yet."));
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.getElementsByClassName.apply(elm, arguments);
    },

    get isConnected() {
      return getLinkedElement(this).isConnected;
    },

    get classList() {
      {
        var vm = getAssociatedVM(this); // TODO [#1290]: this still fails in dev but works in production, eventually, we should just throw in all modes

        assert$1.isFalse(isBeingConstructed(vm), "Failed to construct ".concat(vm, ": The result must not have attributes. Adding or tampering with classname in constructor is not allowed in a web component, use connectedCallback() instead."));
      }

      return getLinkedElement(this).classList;
    },

    get template() {
      var vm = getAssociatedVM(this);
      return vm.cmpRoot;
    },

    get shadowRoot() {
      // From within the component instance, the shadowRoot is always
      // reported as "closed". Authors should rely on this.template instead.
      return null;
    },

    render: function render() {
      var vm = getAssociatedVM(this);
      return vm.def.template;
    },
    toString: function toString() {
      var vm = getAssociatedVM(this);
      return "[object ".concat(vm.def.name, "]");
    }
  };
  var lightningBasedDescriptors = create$1(null);

  for (var _propName in HTMLElementOriginalDescriptors) {
    lightningBasedDescriptors[_propName] = createBridgeToElementDescriptor(_propName, HTMLElementOriginalDescriptors[_propName]);
  }

  defineProperties$1(BaseLightningElementConstructor.prototype, lightningBasedDescriptors);
  defineProperty$2(BaseLightningElementConstructor, 'CustomElementConstructor', {
    get: function get() {
      // If required, a runtime-specific implementation must be defined.
      throw new ReferenceError('The current runtime does not support CustomElementConstructor.');
    },
    configurable: true
  });

  {
    patchLightningElementPrototypeWithRestrictions(BaseLightningElementConstructor.prototype);
  } // @ts-ignore


  var BaseLightningElement = BaseLightningElementConstructor;

  function internalWireFieldDecorator(key) {
    return {
      get: function get() {
        var vm = getAssociatedVM(this);
        componentValueObserved(vm, key);
        return vm.cmpFields[key];
      },
      set: function set(value) {
        var vm = getAssociatedVM(this);
        /**
         * Reactivity for wired fields is provided in wiring.
         * We intentionally add reactivity here since this is just
         * letting the author to do the wrong thing, but it will keep our
         * system to be backward compatible.
         */

        if (value !== vm.cmpFields[key]) {
          vm.cmpFields[key] = value;
          componentValueMutated(vm, key);
        }
      },
      enumerable: true,
      configurable: true
    };
  }
  /**
   * Copyright (C) 2017 salesforce.com, inc.
   */


  var isArray$2 = Array.isArray;
  var getPrototypeOf$1$1 = Object.getPrototypeOf,
      ObjectCreate = Object.create,
      ObjectDefineProperty = Object.defineProperty,
      _isExtensible = Object.isExtensible,
      getOwnPropertyDescriptor$1$1 = Object.getOwnPropertyDescriptor,
      getOwnPropertyNames$1 = Object.getOwnPropertyNames,
      getOwnPropertySymbols = Object.getOwnPropertySymbols,
      _preventExtensions = Object.preventExtensions,
      hasOwnProperty$1$1 = Object.hasOwnProperty;
  var _Array$prototype4 = Array.prototype,
      ArrayPush$2 = _Array$prototype4.push,
      ArrayConcat = _Array$prototype4.concat;
  var OtS$1$1 = {}.toString;

  function toString$1$1(obj) {
    if (obj && obj.toString) {
      return obj.toString();
    } else if (_typeof_1(obj) === 'object') {
      return OtS$1$1.call(obj);
    } else {
      return obj + '';
    }
  }

  function isUndefined$2(obj) {
    return obj === undefined;
  }

  function isFunction$1$1(obj) {
    return typeof obj === 'function';
  }

  function isObject$2(obj) {
    return _typeof_1(obj) === 'object';
  }

  var proxyToValueMap = new WeakMap();

  function registerProxy(proxy, value) {
    proxyToValueMap.set(proxy, value);
  }

  var unwrap = function unwrap(replicaOrAny) {
    return proxyToValueMap.get(replicaOrAny) || replicaOrAny;
  };

  function wrapValue(membrane, value) {
    return membrane.valueIsObservable(value) ? membrane.getProxy(value) : value;
  }
  /**
   * Unwrap property descriptors will set value on original descriptor
   * We only need to unwrap if value is specified
   * @param descriptor external descrpitor provided to define new property on original value
   */


  function unwrapDescriptor(descriptor) {
    if (hasOwnProperty$1$1.call(descriptor, 'value')) {
      descriptor.value = unwrap(descriptor.value);
    }

    return descriptor;
  }

  function lockShadowTarget(membrane, shadowTarget, originalTarget) {
    var targetKeys = ArrayConcat.call(getOwnPropertyNames$1(originalTarget), getOwnPropertySymbols(originalTarget));
    targetKeys.forEach(function (key) {
      var descriptor = getOwnPropertyDescriptor$1$1(originalTarget, key); // We do not need to wrap the descriptor if configurable
      // Because we can deal with wrapping it when user goes through
      // Get own property descriptor. There is also a chance that this descriptor
      // could change sometime in the future, so we can defer wrapping
      // until we need to

      if (!descriptor.configurable) {
        descriptor = wrapDescriptor(membrane, descriptor, wrapValue);
      }

      ObjectDefineProperty(shadowTarget, key, descriptor);
    });

    _preventExtensions(shadowTarget);
  }

  var ReactiveProxyHandler =
  /*#__PURE__*/
  function () {
    function ReactiveProxyHandler(membrane, value) {
      classCallCheck(this, ReactiveProxyHandler);

      this.originalTarget = value;
      this.membrane = membrane;
    }

    createClass(ReactiveProxyHandler, [{
      key: "get",
      value: function get(shadowTarget, key) {
        var originalTarget = this.originalTarget,
            membrane = this.membrane;
        var value = originalTarget[key];
        var valueObserved = membrane.valueObserved;
        valueObserved(originalTarget, key);
        return membrane.getProxy(value);
      }
    }, {
      key: "set",
      value: function set(shadowTarget, key, value) {
        var originalTarget = this.originalTarget,
            valueMutated = this.membrane.valueMutated;
        var oldValue = originalTarget[key];

        if (oldValue !== value) {
          originalTarget[key] = value;
          valueMutated(originalTarget, key);
        } else if (key === 'length' && isArray$2(originalTarget)) {
          // fix for issue #236: push will add the new index, and by the time length
          // is updated, the internal length is already equal to the new length value
          // therefore, the oldValue is equal to the value. This is the forking logic
          // to support this use case.
          valueMutated(originalTarget, key);
        }

        return true;
      }
    }, {
      key: "deleteProperty",
      value: function deleteProperty(shadowTarget, key) {
        var originalTarget = this.originalTarget,
            valueMutated = this.membrane.valueMutated;
        delete originalTarget[key];
        valueMutated(originalTarget, key);
        return true;
      }
    }, {
      key: "apply",
      value: function apply(shadowTarget, thisArg, argArray) {
        /* No op */
      }
    }, {
      key: "construct",
      value: function construct(target, argArray, newTarget) {
        /* No op */
      }
    }, {
      key: "has",
      value: function has(shadowTarget, key) {
        var originalTarget = this.originalTarget,
            valueObserved = this.membrane.valueObserved;
        valueObserved(originalTarget, key);
        return key in originalTarget;
      }
    }, {
      key: "ownKeys",
      value: function ownKeys(shadowTarget) {
        var originalTarget = this.originalTarget;
        return ArrayConcat.call(getOwnPropertyNames$1(originalTarget), getOwnPropertySymbols(originalTarget));
      }
    }, {
      key: "isExtensible",
      value: function isExtensible(shadowTarget) {
        var shadowIsExtensible = _isExtensible(shadowTarget);

        if (!shadowIsExtensible) {
          return shadowIsExtensible;
        }

        var originalTarget = this.originalTarget,
            membrane = this.membrane;

        var targetIsExtensible = _isExtensible(originalTarget);

        if (!targetIsExtensible) {
          lockShadowTarget(membrane, shadowTarget, originalTarget);
        }

        return targetIsExtensible;
      }
    }, {
      key: "setPrototypeOf",
      value: function setPrototypeOf(shadowTarget, prototype) {
        {
          throw new Error("Invalid setPrototypeOf invocation for reactive proxy ".concat(toString$1$1(this.originalTarget), ". Prototype of reactive objects cannot be changed."));
        }
      }
    }, {
      key: "getPrototypeOf",
      value: function getPrototypeOf(shadowTarget) {
        var originalTarget = this.originalTarget;
        return getPrototypeOf$1$1(originalTarget);
      }
    }, {
      key: "getOwnPropertyDescriptor",
      value: function getOwnPropertyDescriptor(shadowTarget, key) {
        var originalTarget = this.originalTarget,
            membrane = this.membrane;
        var valueObserved = this.membrane.valueObserved; // keys looked up via hasOwnProperty need to be reactive

        valueObserved(originalTarget, key);
        var desc = getOwnPropertyDescriptor$1$1(originalTarget, key);

        if (isUndefined$2(desc)) {
          return desc;
        }

        var shadowDescriptor = getOwnPropertyDescriptor$1$1(shadowTarget, key);

        if (!isUndefined$2(shadowDescriptor)) {
          return shadowDescriptor;
        } // Note: by accessing the descriptor, the key is marked as observed
        // but access to the value, setter or getter (if available) cannot observe
        // mutations, just like regular methods, in which case we just do nothing.


        desc = wrapDescriptor(membrane, desc, wrapValue);

        if (!desc.configurable) {
          // If descriptor from original target is not configurable,
          // We must copy the wrapped descriptor over to the shadow target.
          // Otherwise, proxy will throw an invariant error.
          // This is our last chance to lock the value.
          // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy/handler/getOwnPropertyDescriptor#Invariants
          ObjectDefineProperty(shadowTarget, key, desc);
        }

        return desc;
      }
    }, {
      key: "preventExtensions",
      value: function preventExtensions(shadowTarget) {
        var originalTarget = this.originalTarget,
            membrane = this.membrane;
        lockShadowTarget(membrane, shadowTarget, originalTarget);

        _preventExtensions(originalTarget);

        return true;
      }
    }, {
      key: "defineProperty",
      value: function defineProperty(shadowTarget, key, descriptor) {
        var originalTarget = this.originalTarget,
            membrane = this.membrane;
        var valueMutated = membrane.valueMutated;
        var configurable = descriptor.configurable; // We have to check for value in descriptor
        // because Object.freeze(proxy) calls this method
        // with only { configurable: false, writeable: false }
        // Additionally, method will only be called with writeable:false
        // if the descriptor has a value, as opposed to getter/setter
        // So we can just check if writable is present and then see if
        // value is present. This eliminates getter and setter descriptors

        if (hasOwnProperty$1$1.call(descriptor, 'writable') && !hasOwnProperty$1$1.call(descriptor, 'value')) {
          var originalDescriptor = getOwnPropertyDescriptor$1$1(originalTarget, key);
          descriptor.value = originalDescriptor.value;
        }

        ObjectDefineProperty(originalTarget, key, unwrapDescriptor(descriptor));

        if (configurable === false) {
          ObjectDefineProperty(shadowTarget, key, wrapDescriptor(membrane, descriptor, wrapValue));
        }

        valueMutated(originalTarget, key);
        return true;
      }
    }]);

    return ReactiveProxyHandler;
  }();

  function wrapReadOnlyValue(membrane, value) {
    return membrane.valueIsObservable(value) ? membrane.getReadOnlyProxy(value) : value;
  }

  var ReadOnlyHandler =
  /*#__PURE__*/
  function () {
    function ReadOnlyHandler(membrane, value) {
      classCallCheck(this, ReadOnlyHandler);

      this.originalTarget = value;
      this.membrane = membrane;
    }

    createClass(ReadOnlyHandler, [{
      key: "get",
      value: function get(shadowTarget, key) {
        var membrane = this.membrane,
            originalTarget = this.originalTarget;
        var value = originalTarget[key];
        var valueObserved = membrane.valueObserved;
        valueObserved(originalTarget, key);
        return membrane.getReadOnlyProxy(value);
      }
    }, {
      key: "set",
      value: function set(shadowTarget, key, value) {
        {
          var originalTarget = this.originalTarget;
          throw new Error("Invalid mutation: Cannot set \"".concat(key.toString(), "\" on \"").concat(originalTarget, "\". \"").concat(originalTarget, "\" is read-only."));
        }
      }
    }, {
      key: "deleteProperty",
      value: function deleteProperty(shadowTarget, key) {
        {
          var originalTarget = this.originalTarget;
          throw new Error("Invalid mutation: Cannot delete \"".concat(key.toString(), "\" on \"").concat(originalTarget, "\". \"").concat(originalTarget, "\" is read-only."));
        }
      }
    }, {
      key: "apply",
      value: function apply(shadowTarget, thisArg, argArray) {
        /* No op */
      }
    }, {
      key: "construct",
      value: function construct(target, argArray, newTarget) {
        /* No op */
      }
    }, {
      key: "has",
      value: function has(shadowTarget, key) {
        var originalTarget = this.originalTarget,
            valueObserved = this.membrane.valueObserved;
        valueObserved(originalTarget, key);
        return key in originalTarget;
      }
    }, {
      key: "ownKeys",
      value: function ownKeys(shadowTarget) {
        var originalTarget = this.originalTarget;
        return ArrayConcat.call(getOwnPropertyNames$1(originalTarget), getOwnPropertySymbols(originalTarget));
      }
    }, {
      key: "setPrototypeOf",
      value: function setPrototypeOf(shadowTarget, prototype) {
        {
          var originalTarget = this.originalTarget;
          throw new Error("Invalid prototype mutation: Cannot set prototype on \"".concat(originalTarget, "\". \"").concat(originalTarget, "\" prototype is read-only."));
        }
      }
    }, {
      key: "getOwnPropertyDescriptor",
      value: function getOwnPropertyDescriptor(shadowTarget, key) {
        var originalTarget = this.originalTarget,
            membrane = this.membrane;
        var valueObserved = membrane.valueObserved; // keys looked up via hasOwnProperty need to be reactive

        valueObserved(originalTarget, key);
        var desc = getOwnPropertyDescriptor$1$1(originalTarget, key);

        if (isUndefined$2(desc)) {
          return desc;
        }

        var shadowDescriptor = getOwnPropertyDescriptor$1$1(shadowTarget, key);

        if (!isUndefined$2(shadowDescriptor)) {
          return shadowDescriptor;
        } // Note: by accessing the descriptor, the key is marked as observed
        // but access to the value or getter (if available) cannot be observed,
        // just like regular methods, in which case we just do nothing.


        desc = wrapDescriptor(membrane, desc, wrapReadOnlyValue);

        if (hasOwnProperty$1$1.call(desc, 'set')) {
          desc.set = undefined; // readOnly membrane does not allow setters
        }

        if (!desc.configurable) {
          // If descriptor from original target is not configurable,
          // We must copy the wrapped descriptor over to the shadow target.
          // Otherwise, proxy will throw an invariant error.
          // This is our last chance to lock the value.
          // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy/handler/getOwnPropertyDescriptor#Invariants
          ObjectDefineProperty(shadowTarget, key, desc);
        }

        return desc;
      }
    }, {
      key: "preventExtensions",
      value: function preventExtensions(shadowTarget) {
        {
          var originalTarget = this.originalTarget;
          throw new Error("Invalid mutation: Cannot preventExtensions on ".concat(originalTarget, "\". \"").concat(originalTarget, " is read-only."));
        }
      }
    }, {
      key: "defineProperty",
      value: function defineProperty(shadowTarget, key, descriptor) {
        {
          var originalTarget = this.originalTarget;
          throw new Error("Invalid mutation: Cannot defineProperty \"".concat(key.toString(), "\" on \"").concat(originalTarget, "\". \"").concat(originalTarget, "\" is read-only."));
        }
      }
    }]);

    return ReadOnlyHandler;
  }();

  function extract(objectOrArray) {
    if (isArray$2(objectOrArray)) {
      return objectOrArray.map(function (item) {
        var original = unwrap(item);

        if (original !== item) {
          return extract(original);
        }

        return item;
      });
    }

    var obj = ObjectCreate(getPrototypeOf$1$1(objectOrArray));
    var names = getOwnPropertyNames$1(objectOrArray);
    return ArrayConcat.call(names, getOwnPropertySymbols(objectOrArray)).reduce(function (seed, key) {
      var item = objectOrArray[key];
      var original = unwrap(item);

      if (original !== item) {
        seed[key] = extract(original);
      } else {
        seed[key] = item;
      }

      return seed;
    }, obj);
  }

  var formatter = {
    header: function header(plainOrProxy) {
      var originalTarget = unwrap(plainOrProxy); // if originalTarget is falsy or not unwrappable, exit

      if (!originalTarget || originalTarget === plainOrProxy) {
        return null;
      }

      var obj = extract(plainOrProxy);
      return ['object', {
        object: obj
      }];
    },
    hasBody: function hasBody() {
      return false;
    },
    body: function body() {
      return null;
    }
  }; // Inspired from paulmillr/es6-shim
  // https://github.com/paulmillr/es6-shim/blob/master/es6-shim.js#L176-L185

  function getGlobal() {
    // the only reliable means to get the global object is `Function('return this')()`
    // However, this causes CSP violations in Chrome apps.
    if (typeof globalThis !== 'undefined') {
      return globalThis;
    }

    if (typeof self !== 'undefined') {
      return self;
    }

    if (typeof window !== 'undefined') {
      return window;
    }

    if (typeof global !== 'undefined') {
      return global;
    } // Gracefully degrade if not able to locate the global object


    return {};
  }

  function init() {

    var global = getGlobal(); // Custom Formatter for Dev Tools. To enable this, open Chrome Dev Tools
    //  - Go to Settings,
    //  - Under console, select "Enable custom formatters"
    // For more information, https://docs.google.com/document/d/1FTascZXT9cxfetuPRT2eXPQKXui4nWFivUnS_335T3U/preview

    var devtoolsFormatters = global.devtoolsFormatters || [];
    ArrayPush$2.call(devtoolsFormatters, formatter);
    global.devtoolsFormatters = devtoolsFormatters;
  }

  {
    init();
  }

  function createShadowTarget(value) {
    var shadowTarget = undefined;

    if (isArray$2(value)) {
      shadowTarget = [];
    } else if (isObject$2(value)) {
      shadowTarget = {};
    }

    return shadowTarget;
  }

  var ObjectDotPrototype = Object.prototype;

  function defaultValueIsObservable(value) {
    // intentionally checking for null
    if (value === null) {
      return false;
    } // treat all non-object types, including undefined, as non-observable values


    if (_typeof_1(value) !== 'object') {
      return false;
    }

    if (isArray$2(value)) {
      return true;
    }

    var proto = getPrototypeOf$1$1(value);
    return proto === ObjectDotPrototype || proto === null || getPrototypeOf$1$1(proto) === null;
  }

  var defaultValueObserved = function defaultValueObserved(obj, key) {
    /* do nothing */
  };

  var defaultValueMutated = function defaultValueMutated(obj, key) {
    /* do nothing */
  };

  var defaultValueDistortion = function defaultValueDistortion(value) {
    return value;
  };

  function wrapDescriptor(membrane, descriptor, getValue) {
    var set = descriptor.set,
        get = descriptor.get;

    if (hasOwnProperty$1$1.call(descriptor, 'value')) {
      descriptor.value = getValue(membrane, descriptor.value);
    } else {
      if (!isUndefined$2(get)) {
        descriptor.get = function () {
          // invoking the original getter with the original target
          return getValue(membrane, get.call(unwrap(this)));
        };
      }

      if (!isUndefined$2(set)) {
        descriptor.set = function (value) {
          // At this point we don't have a clear indication of whether
          // or not a valid mutation will occur, we don't have the key,
          // and we are not sure why and how they are invoking this setter.
          // Nevertheless we preserve the original semantics by invoking the
          // original setter with the original target and the unwrapped value
          set.call(unwrap(this), membrane.unwrapProxy(value));
        };
      }
    }

    return descriptor;
  }

  var ReactiveMembrane =
  /*#__PURE__*/
  function () {
    function ReactiveMembrane(options) {
      classCallCheck(this, ReactiveMembrane);

      this.valueDistortion = defaultValueDistortion;
      this.valueMutated = defaultValueMutated;
      this.valueObserved = defaultValueObserved;
      this.valueIsObservable = defaultValueIsObservable;
      this.objectGraph = new WeakMap();

      if (!isUndefined$2(options)) {
        var _valueDistortion = options.valueDistortion,
            _valueMutated = options.valueMutated,
            _valueObserved = options.valueObserved,
            valueIsObservable = options.valueIsObservable;
        this.valueDistortion = isFunction$1$1(_valueDistortion) ? _valueDistortion : defaultValueDistortion;
        this.valueMutated = isFunction$1$1(_valueMutated) ? _valueMutated : defaultValueMutated;
        this.valueObserved = isFunction$1$1(_valueObserved) ? _valueObserved : defaultValueObserved;
        this.valueIsObservable = isFunction$1$1(valueIsObservable) ? valueIsObservable : defaultValueIsObservable;
      }
    }

    createClass(ReactiveMembrane, [{
      key: "getProxy",
      value: function getProxy(value) {
        var unwrappedValue = unwrap(value);
        var distorted = this.valueDistortion(unwrappedValue);

        if (this.valueIsObservable(distorted)) {
          var o = this.getReactiveState(unwrappedValue, distorted); // when trying to extract the writable version of a readonly
          // we return the readonly.

          return o.readOnly === value ? value : o.reactive;
        }

        return distorted;
      }
    }, {
      key: "getReadOnlyProxy",
      value: function getReadOnlyProxy(value) {
        value = unwrap(value);
        var distorted = this.valueDistortion(value);

        if (this.valueIsObservable(distorted)) {
          return this.getReactiveState(value, distorted).readOnly;
        }

        return distorted;
      }
    }, {
      key: "unwrapProxy",
      value: function unwrapProxy(p) {
        return unwrap(p);
      }
    }, {
      key: "getReactiveState",
      value: function getReactiveState(value, distortedValue) {
        var objectGraph = this.objectGraph;
        var reactiveState = objectGraph.get(distortedValue);

        if (reactiveState) {
          return reactiveState;
        }

        var membrane = this;
        reactiveState = {
          get reactive() {
            var reactiveHandler = new ReactiveProxyHandler(membrane, distortedValue); // caching the reactive proxy after the first time it is accessed

            var proxy = new Proxy(createShadowTarget(distortedValue), reactiveHandler);
            registerProxy(proxy, value);
            ObjectDefineProperty(this, 'reactive', {
              value: proxy
            });
            return proxy;
          },

          get readOnly() {
            var readOnlyHandler = new ReadOnlyHandler(membrane, distortedValue); // caching the readOnly proxy after the first time it is accessed

            var proxy = new Proxy(createShadowTarget(distortedValue), readOnlyHandler);
            registerProxy(proxy, value);
            ObjectDefineProperty(this, 'readOnly', {
              value: proxy
            });
            return proxy;
          }

        };
        objectGraph.set(distortedValue, reactiveState);
        return reactiveState;
      }
    }]);

    return ReactiveMembrane;
  }();
  /** version: 0.26.0 */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function valueDistortion(value) {
    return value;
  }

  var reactiveMembrane = new ReactiveMembrane({
    valueObserved: valueObserved,
    valueMutated: valueMutated,
    valueDistortion: valueDistortion
  });

  function internalTrackDecorator(key) {
    return {
      get: function get() {
        var vm = getAssociatedVM(this);
        componentValueObserved(vm, key);
        return vm.cmpFields[key];
      },
      set: function set(newValue) {
        var vm = getAssociatedVM(this);

        {
          var _vmBeingRendered3 = getVMBeingRendered();

          assert$1.invariant(!isInvokingRender, "".concat(_vmBeingRendered3, ".render() method has side effects on the state of ").concat(vm, ".").concat(toString$1(key)));
          assert$1.invariant(!isUpdatingTemplate, "Updating the template of ".concat(_vmBeingRendered3, " has side effects on the state of ").concat(vm, ".").concat(toString$1(key)));
        }

        var reactiveOrAnyValue = reactiveMembrane.getProxy(newValue);

        if (reactiveOrAnyValue !== vm.cmpFields[key]) {
          vm.cmpFields[key] = reactiveOrAnyValue;
          componentValueMutated(vm, key);
        }
      },
      enumerable: true,
      configurable: true
    };
  }
  /**
   * Copyright (C) 2018 salesforce.com, inc.
   */

  /**
   * Copyright (C) 2018 salesforce.com, inc.
   */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var create$2 = Object.create;
  var _Array$prototype5 = Array.prototype,
      forEach$1$1 = _Array$prototype5.forEach;
  var _String$prototype2$1 = String.prototype,
      StringReplace$1 = _String$prototype2$1.replace,
      StringToLowerCase$1 = _String$prototype2$1.toLowerCase;
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * According to the following list, there are 48 aria attributes of which two (ariaDropEffect and
   * ariaGrabbed) are deprecated:
   * https://www.w3.org/TR/wai-aria-1.1/#x6-6-definitions-of-states-and-properties-all-aria-attributes
   *
   * The above list of 46 aria attributes is consistent with the following resources:
   * https://github.com/w3c/aria/pull/708/files#diff-eacf331f0ffc35d4b482f1d15a887d3bR11060
   * https://wicg.github.io/aom/spec/aria-reflection.html
   */


  var AriaPropertyNames$1 = ['ariaActiveDescendant', 'ariaAtomic', 'ariaAutoComplete', 'ariaBusy', 'ariaChecked', 'ariaColCount', 'ariaColIndex', 'ariaColSpan', 'ariaControls', 'ariaCurrent', 'ariaDescribedBy', 'ariaDetails', 'ariaDisabled', 'ariaErrorMessage', 'ariaExpanded', 'ariaFlowTo', 'ariaHasPopup', 'ariaHidden', 'ariaInvalid', 'ariaKeyShortcuts', 'ariaLabel', 'ariaLabelledBy', 'ariaLevel', 'ariaLive', 'ariaModal', 'ariaMultiLine', 'ariaMultiSelectable', 'ariaOrientation', 'ariaOwns', 'ariaPlaceholder', 'ariaPosInSet', 'ariaPressed', 'ariaReadOnly', 'ariaRelevant', 'ariaRequired', 'ariaRoleDescription', 'ariaRowCount', 'ariaRowIndex', 'ariaRowSpan', 'ariaSelected', 'ariaSetSize', 'ariaSort', 'ariaValueMax', 'ariaValueMin', 'ariaValueNow', 'ariaValueText', 'role'];
  var AttrNameToPropNameMap$2 = create$2(null);
  var PropNameToAttrNameMap$2 = create$2(null); // Synthetic creation of all AOM property descriptors for Custom Elements

  forEach$1$1.call(AriaPropertyNames$1, function (propName) {
    // Typescript infers the wrong function type for this particular overloaded method:
    // https://github.com/Microsoft/TypeScript/issues/27972
    // @ts-ignore type-mismatch
    var attrName = StringToLowerCase$1.call(StringReplace$1.call(propName, /^aria/, 'aria-'));
    AttrNameToPropNameMap$2[attrName] = propName;
    PropNameToAttrNameMap$2[propName] = attrName;
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /*
   * In IE11, symbols are expensive.
   * Due to the nature of the symbol polyfill. This method abstract the
   * creation of symbols, so we can fallback to string when native symbols
   * are not supported. Note that we can't use typeof since it will fail when transpiling.
   */

  var hasNativeSymbolsSupport$1$1 = Symbol('x').toString() === 'Symbol(x)';
  /** version: 1.7.1 */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // Cached reference to globalThis

  var _globalThis;

  if ((typeof globalThis === "undefined" ? "undefined" : _typeof_1(globalThis)) === 'object') {
    _globalThis = globalThis;
  }

  function getGlobalThis() {
    if (_typeof_1(_globalThis) === 'object') {
      return _globalThis;
    }

    try {
      // eslint-disable-next-line no-extend-native
      Object.defineProperty(Object.prototype, '__magic__', {
        get: function get() {
          return this;
        },
        configurable: true
      }); // @ts-ignore
      // __magic__ is undefined in Safari 10 and IE10 and older.
      // eslint-disable-next-line no-undef

      _globalThis = __magic__; // @ts-ignore

      delete Object.prototype.__magic__;
    } catch (ex) {// In IE8, Object.defineProperty only works on DOM objects.
    } finally {
      // If the magic above fails for some reason we assume that we are in a
      // legacy browser. Assume `window` exists in this case.
      if (typeof _globalThis === 'undefined') {
        _globalThis = window;
      }
    }

    return _globalThis;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var _globalThis$1 = getGlobalThis();

  if (!_globalThis$1.lwcRuntimeFlags) {
    Object.defineProperty(_globalThis$1, 'lwcRuntimeFlags', {
      value: create$2(null)
    });
  }

  var runtimeFlags = _globalThis$1.lwcRuntimeFlags; // This function is not supported for use within components and is meant for

  function createPublicPropertyDescriptor(key) {
    return {
      get: function get() {
        var vm = getAssociatedVM(this);

        if (isBeingConstructed(vm)) {
          {
            var name = vm.elm.constructor.name;
            logError("`".concat(name, "` constructor can\u2019t read the value of property `").concat(toString$1(key), "` because the owner component hasn\u2019t set the value yet. Instead, use the `").concat(name, "` constructor to set a default value for the property."), vm);
          }

          return;
        }

        componentValueObserved(vm, key);
        return vm.cmpProps[key];
      },
      set: function set(newValue) {
        var vm = getAssociatedVM(this);

        {
          var _vmBeingRendered4 = getVMBeingRendered();

          assert$1.invariant(!isInvokingRender, "".concat(_vmBeingRendered4, ".render() method has side effects on the state of ").concat(vm, ".").concat(toString$1(key)));
          assert$1.invariant(!isUpdatingTemplate, "Updating the template of ".concat(_vmBeingRendered4, " has side effects on the state of ").concat(vm, ".").concat(toString$1(key)));
        }

        vm.cmpProps[key] = newValue;
        componentValueMutated(vm, key);
      },
      enumerable: true,
      configurable: true
    };
  }

  var AccessorReactiveObserver =
  /*#__PURE__*/
  function (_ReactiveObserver) {
    inherits(AccessorReactiveObserver, _ReactiveObserver);

    function AccessorReactiveObserver(vm, set) {
      var _this;

      classCallCheck(this, AccessorReactiveObserver);

      _this = possibleConstructorReturn(this, getPrototypeOf$1(AccessorReactiveObserver).call(this, function () {
        if (isFalse$1$1(_this.debouncing)) {
          _this.debouncing = true;
          addCallbackToNextTick(function () {
            if (isTrue$1$1(_this.debouncing)) {
              var _assertThisInitialize = assertThisInitialized(assertThisInitialized(_this)),
                  value = _assertThisInitialize.value;

              var dirtyStateBeforeSetterCall = vm.isDirty,
                  component = vm.component,
                  _idx = vm.idx;
              set.call(component, value); // de-bouncing after the call to the original setter to prevent
              // infinity loop if the setter itself is mutating things that
              // were accessed during the previous invocation.

              _this.debouncing = false;

              if (isTrue$1$1(vm.isDirty) && isFalse$1$1(dirtyStateBeforeSetterCall) && _idx > 0) {
                // immediate rehydration due to a setter driven mutation, otherwise
                // the component will get rendered on the second tick, which it is not
                // desirable.
                rerenderVM(vm);
              }
            }
          });
        }
      }));
      _this.debouncing = false;
      return _this;
    }

    createClass(AccessorReactiveObserver, [{
      key: "reset",
      value: function reset(value) {
        get(getPrototypeOf$1(AccessorReactiveObserver.prototype), "reset", this).call(this);

        this.debouncing = false;

        if (arguments.length > 0) {
          this.value = value;
        }
      }
    }]);

    return AccessorReactiveObserver;
  }(ReactiveObserver);

  function createPublicAccessorDescriptor(key, descriptor) {
    var _get3 = descriptor.get,
        _set2 = descriptor.set,
        enumerable = descriptor.enumerable,
        configurable = descriptor.configurable;

    if (!isFunction$1(_get3)) {
      {
        assert$1.invariant(isFunction$1(_get3), "Invalid compiler output for public accessor ".concat(toString$1(key), " decorated with @api"));
      }

      throw new Error();
    }

    return {
      get: function get() {
        {
          // Assert that the this value is an actual Component with an associated VM.
          getAssociatedVM(this);
        }

        return _get3.call(this);
      },
      set: function set(newValue) {
        var _this2 = this;

        var vm = getAssociatedVM(this);

        {
          var _vmBeingRendered5 = getVMBeingRendered();

          assert$1.invariant(!isInvokingRender, "".concat(_vmBeingRendered5, ".render() method has side effects on the state of ").concat(vm, ".").concat(toString$1(key)));
          assert$1.invariant(!isUpdatingTemplate, "Updating the template of ".concat(_vmBeingRendered5, " has side effects on the state of ").concat(vm, ".").concat(toString$1(key)));
        }

        if (_set2) {
          if (runtimeFlags.ENABLE_REACTIVE_SETTER) {
            var ro = vm.oar[key];

            if (isUndefined$1(ro)) {
              ro = vm.oar[key] = new AccessorReactiveObserver(vm, _set2);
            } // every time we invoke this setter from outside (through this wrapper setter)
            // we should reset the value and then debounce just in case there is a pending
            // invocation the next tick that is not longer relevant since the value is changing
            // from outside.


            ro.reset(newValue);
            ro.observe(function () {
              _set2.call(_this2, newValue);
            });
          } else {
            _set2.call(this, newValue);
          }
        } else {
          assert$1.fail("Invalid attempt to set a new value for property ".concat(toString$1(key), " of ").concat(vm, " that does not has a setter decorated with @api."));
        }
      },
      enumerable: enumerable,
      configurable: configurable
    };
  }

  function createObservedFieldPropertyDescriptor(key) {
    return {
      get: function get() {
        var vm = getAssociatedVM(this);
        componentValueObserved(vm, key);
        return vm.cmpFields[key];
      },
      set: function set(newValue) {
        var vm = getAssociatedVM(this);

        if (newValue !== vm.cmpFields[key]) {
          vm.cmpFields[key] = newValue;
          componentValueMutated(vm, key);
        }
      },
      enumerable: true,
      configurable: true
    };
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var PropType;

  (function (PropType) {
    PropType[PropType["Field"] = 0] = "Field";
    PropType[PropType["Set"] = 1] = "Set";
    PropType[PropType["Get"] = 2] = "Get";
    PropType[PropType["GetSet"] = 3] = "GetSet";
  })(PropType || (PropType = {}));

  function validateObservedField(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined$1(descriptor)) {
        assert$1.fail("Compiler Error: Invalid field ".concat(fieldName, " declaration."));
      }
    }
  }

  function validateFieldDecoratedWithTrack(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined$1(descriptor)) {
        assert$1.fail("Compiler Error: Invalid @track ".concat(fieldName, " declaration."));
      }
    }
  }

  function validateFieldDecoratedWithWire(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined$1(descriptor)) {
        assert$1.fail("Compiler Error: Invalid @wire(...) ".concat(fieldName, " field declaration."));
      }
    }
  }

  function validateMethodDecoratedWithWire(Ctor, methodName, descriptor) {
    {
      if (isUndefined$1(descriptor) || !isFunction$1(descriptor.value) || isFalse$1$1(descriptor.writable)) {
        assert$1.fail("Compiler Error: Invalid @wire(...) ".concat(methodName, " method declaration."));
      }
    }
  }

  function validateFieldDecoratedWithApi(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined$1(descriptor)) {
        assert$1.fail("Compiler Error: Invalid @api ".concat(fieldName, " field declaration."));
      }
    }
  }

  function validateAccessorDecoratedWithApi(Ctor, fieldName, descriptor) {
    {
      if (isUndefined$1(descriptor)) {
        assert$1.fail("Compiler Error: Invalid @api get ".concat(fieldName, " accessor declaration."));
      } else if (isFunction$1(descriptor.set)) {
        assert$1.isTrue(isFunction$1(descriptor.get), "Compiler Error: Missing getter for property ".concat(toString$1(fieldName), " decorated with @api in ").concat(Ctor, ". You cannot have a setter without the corresponding getter."));
      } else if (!isFunction$1(descriptor.get)) {
        assert$1.fail("Compiler Error: Missing @api get ".concat(fieldName, " accessor declaration."));
      }
    }
  }

  function validateMethodDecoratedWithApi(Ctor, methodName, descriptor) {
    {
      if (isUndefined$1(descriptor) || !isFunction$1(descriptor.value) || isFalse$1$1(descriptor.writable)) {
        assert$1.fail("Compiler Error: Invalid @api ".concat(methodName, " method declaration."));
      }
    }
  }
  /**
   * INTERNAL: This function can only be invoked by compiled code. The compiler
   * will prevent this function from being imported by user-land code.
   */


  function registerDecorators(Ctor, meta) {
    var proto = Ctor.prototype;
    var publicProps = meta.publicProps,
        publicMethods = meta.publicMethods,
        wire = meta.wire,
        track = meta.track,
        fields = meta.fields;
    var apiMethods = create$1(null);
    var apiFields = create$1(null);
    var wiredMethods = create$1(null);
    var wiredFields = create$1(null);
    var observedFields = create$1(null);
    var apiFieldsConfig = create$1(null);
    var descriptor;

    if (!isUndefined$1(publicProps)) {
      for (var fieldName in publicProps) {
        var propConfig = publicProps[fieldName];
        apiFieldsConfig[fieldName] = propConfig.config;
        descriptor = getOwnPropertyDescriptor$1(proto, fieldName);

        if (propConfig.config > 0) {
          // accessor declaration
          {
            validateAccessorDecoratedWithApi(Ctor, fieldName, descriptor);
          }

          if (isUndefined$1(descriptor)) {
            throw new Error();
          }

          descriptor = createPublicAccessorDescriptor(fieldName, descriptor);
        } else {
          // field declaration
          {
            validateFieldDecoratedWithApi(Ctor, fieldName, descriptor);
          }

          descriptor = createPublicPropertyDescriptor(fieldName);
        }

        apiFields[fieldName] = descriptor;
        defineProperty$2(proto, fieldName, descriptor);
      }
    }

    if (!isUndefined$1(publicMethods)) {
      forEach$1.call(publicMethods, function (methodName) {
        descriptor = getOwnPropertyDescriptor$1(proto, methodName);

        {
          validateMethodDecoratedWithApi(Ctor, methodName, descriptor);
        }

        if (isUndefined$1(descriptor)) {
          throw new Error();
        }

        apiMethods[methodName] = descriptor;
      });
    }

    if (!isUndefined$1(wire)) {
      for (var fieldOrMethodName in wire) {
        var _wire$fieldOrMethodNa = wire[fieldOrMethodName],
            adapter = _wire$fieldOrMethodNa.adapter,
            method = _wire$fieldOrMethodNa.method,
            configCallback = _wire$fieldOrMethodNa.config,
            _wire$fieldOrMethodNa2 = _wire$fieldOrMethodNa.dynamic,
            dynamic = _wire$fieldOrMethodNa2 === void 0 ? [] : _wire$fieldOrMethodNa2;
        descriptor = getOwnPropertyDescriptor$1(proto, fieldOrMethodName);

        if (method === 1) {
          {
            assert$1.isTrue(adapter, "@wire on method \"".concat(fieldOrMethodName, "\": adapter id must be truthy."));
            validateMethodDecoratedWithWire(Ctor, fieldOrMethodName, descriptor);
          }

          if (isUndefined$1(descriptor)) {
            throw new Error();
          }

          wiredMethods[fieldOrMethodName] = descriptor;
          storeWiredMethodMeta(descriptor, adapter, configCallback, dynamic);
        } else {
          {
            assert$1.isTrue(adapter, "@wire on field \"".concat(fieldOrMethodName, "\": adapter id must be truthy."));
            validateFieldDecoratedWithWire(Ctor, fieldOrMethodName, descriptor);
          }

          descriptor = internalWireFieldDecorator(fieldOrMethodName);
          wiredFields[fieldOrMethodName] = descriptor;
          storeWiredFieldMeta(descriptor, adapter, configCallback, dynamic);
          defineProperty$2(proto, fieldOrMethodName, descriptor);
        }
      }
    }

    if (!isUndefined$1(track)) {
      for (var _fieldName in track) {
        descriptor = getOwnPropertyDescriptor$1(proto, _fieldName);

        {
          validateFieldDecoratedWithTrack(Ctor, _fieldName, descriptor);
        }

        descriptor = internalTrackDecorator(_fieldName);
        defineProperty$2(proto, _fieldName, descriptor);
      }
    }

    if (!isUndefined$1(fields)) {
      for (var _i6 = 0, n = fields.length; _i6 < n; _i6++) {
        var _fieldName2 = fields[_i6];
        descriptor = getOwnPropertyDescriptor$1(proto, _fieldName2);

        {
          validateObservedField(Ctor, _fieldName2, descriptor);
        }

        observedFields[_fieldName2] = createObservedFieldPropertyDescriptor(_fieldName2);
      }
    }

    setDecoratorsMeta(Ctor, {
      apiMethods: apiMethods,
      apiFields: apiFields,
      apiFieldsConfig: apiFieldsConfig,
      wiredMethods: wiredMethods,
      wiredFields: wiredFields,
      observedFields: observedFields
    });
    return Ctor;
  }

  var signedDecoratorToMetaMap = new Map();

  function setDecoratorsMeta(Ctor, meta) {
    signedDecoratorToMetaMap.set(Ctor, meta);
  }

  var defaultMeta = {
    apiMethods: EmptyObject,
    apiFields: EmptyObject,
    apiFieldsConfig: EmptyObject,
    wiredMethods: EmptyObject,
    wiredFields: EmptyObject,
    observedFields: EmptyObject
  };

  function getDecoratorsMeta(Ctor) {
    var meta = signedDecoratorToMetaMap.get(Ctor);
    return isUndefined$1(meta) ? defaultMeta : meta;
  }

  var signedTemplateSet = new Set();

  function defaultEmptyTemplate() {
    return [];
  }

  signedTemplateSet.add(defaultEmptyTemplate);

  function isTemplateRegistered(tpl) {
    return signedTemplateSet.has(tpl);
  }
  /**
   * INTERNAL: This function can only be invoked by compiled code. The compiler
   * will prevent this function from being imported by userland code.
   */


  function registerTemplate(tpl) {
    signedTemplateSet.add(tpl); // chaining this method as a way to wrap existing
    // assignment of templates easily, without too much transformation

    return tpl;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // from the element instance, and get the value or set a new value on the component.
  // This means that across different elements, similar names can get the exact same
  // descriptor, so we can cache them:


  var cachedGetterByKey = create$1(null);
  var cachedSetterByKey = create$1(null);

  function createGetter(key) {
    var fn = cachedGetterByKey[key];

    if (isUndefined$1(fn)) {
      fn = cachedGetterByKey[key] = function () {
        var vm = getAssociatedVM(this);
        var getHook = vm.getHook;
        return getHook(vm.component, key);
      };
    }

    return fn;
  }

  function createSetter(key) {
    var fn = cachedSetterByKey[key];

    if (isUndefined$1(fn)) {
      fn = cachedSetterByKey[key] = function (newValue) {
        var vm = getAssociatedVM(this);
        var setHook = vm.setHook;
        newValue = reactiveMembrane.getReadOnlyProxy(newValue);
        setHook(vm.component, key, newValue);
      };
    }

    return fn;
  }

  function createMethodCaller(methodName) {
    return function () {
      var vm = getAssociatedVM(this);
      var callHook = vm.callHook,
          component = vm.component;
      var fn = component[methodName];
      return callHook(vm.component, fn, ArraySlice$1$1.call(arguments));
    };
  }

  function HTMLBridgeElementFactory(SuperClass, props, methods) {
    var HTMLBridgeElement;
    /**
     * Modern browsers will have all Native Constructors as regular Classes
     * and must be instantiated with the new keyword. In older browsers,
     * specifically IE11, those are objects with a prototype property defined,
     * since they are not supposed to be extended or instantiated with the
     * new keyword. This forking logic supports both cases, specifically because
     * wc.ts relies on the construction path of the bridges to create new
     * fully qualifying web components.
     */

    if (isFunction$1(SuperClass)) {
      HTMLBridgeElement =
      /*#__PURE__*/
      function (_SuperClass) {
        inherits(HTMLBridgeElement, _SuperClass);

        function HTMLBridgeElement() {
          classCallCheck(this, HTMLBridgeElement);

          return possibleConstructorReturn(this, getPrototypeOf$1(HTMLBridgeElement).apply(this, arguments));
        }

        return HTMLBridgeElement;
      }(SuperClass);
    } else {
      HTMLBridgeElement = function HTMLBridgeElement() {
        // Bridge classes are not supposed to be instantiated directly in
        // browsers that do not support web components.
        throw new TypeError('Illegal constructor');
      }; // prototype inheritance dance


      setPrototypeOf$2(HTMLBridgeElement, SuperClass);
      setPrototypeOf$2(HTMLBridgeElement.prototype, SuperClass.prototype);
      defineProperty$2(HTMLBridgeElement.prototype, 'constructor', {
        writable: true,
        configurable: true,
        value: HTMLBridgeElement
      });
    }

    var descriptors = create$1(null); // expose getters and setters for each public props on the new Element Bridge

    for (var _i7 = 0, _len4 = props.length; _i7 < _len4; _i7 += 1) {
      var _propName2 = props[_i7];
      descriptors[_propName2] = {
        get: createGetter(_propName2),
        set: createSetter(_propName2),
        enumerable: true,
        configurable: true
      };
    } // expose public methods as props on the new Element Bridge


    for (var _i8 = 0, _len5 = methods.length; _i8 < _len5; _i8 += 1) {
      var methodName = methods[_i8];
      descriptors[methodName] = {
        value: createMethodCaller(methodName),
        writable: true,
        configurable: true
      };
    }

    defineProperties$1(HTMLBridgeElement.prototype, descriptors);
    return HTMLBridgeElement;
  }

  var BaseBridgeElement = HTMLBridgeElementFactory(HTMLElement, getOwnPropertyNames(HTMLElementOriginalDescriptors), []);
  freeze(BaseBridgeElement);
  seal(BaseBridgeElement.prototype);
  /*
   * Copyright (c) 2020, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  function resolveCircularModuleDependency(fn) {
    return fn();
  }

  function isCircularModuleDependency(obj) {
    return isFunction$1(obj) && hasOwnProperty$1.call(obj, '__circular__');
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var CtorToDefMap = new WeakMap();

  function getCtorProto(Ctor, subclassComponentName) {
    var proto = getPrototypeOf$2(Ctor);

    if (isNull$1(proto)) {
      throw new ReferenceError("Invalid prototype chain for ".concat(subclassComponentName, ", you must extend LightningElement."));
    } // covering the cases where the ref is circular in AMD


    if (isCircularModuleDependency(proto)) {
      var p = resolveCircularModuleDependency(proto);

      {
        if (isNull$1(p)) {
          throw new ReferenceError("Circular module dependency for ".concat(subclassComponentName, ", must resolve to a constructor that extends LightningElement."));
        }
      } // escape hatch for Locker and other abstractions to provide their own base class instead
      // of our Base class without having to leak it to user-land. If the circular function returns
      // itself, that's the signal that we have hit the end of the proto chain, which must always
      // be base.


      proto = p === proto ? BaseLightningElement : p;
    }

    return proto;
  }

  function createComponentDef(Ctor, meta, subclassComponentName) {
    {
      // local to dev block
      var ctorName = Ctor.name; // Removing the following assert until https://bugs.webkit.org/show_bug.cgi?id=190140 is fixed.
      // assert.isTrue(ctorName && isString(ctorName), `${toString(Ctor)} should have a "name" property with string value, but found ${ctorName}.`);

      assert$1.isTrue(Ctor.constructor, "Missing ".concat(ctorName, ".constructor, ").concat(ctorName, " should have a \"constructor\" property."));
    }

    var name = meta.name;
    var template = meta.template;
    var decoratorsMeta = getDecoratorsMeta(Ctor);
    var apiFields = decoratorsMeta.apiFields,
        apiFieldsConfig = decoratorsMeta.apiFieldsConfig,
        apiMethods = decoratorsMeta.apiMethods,
        wiredFields = decoratorsMeta.wiredFields,
        wiredMethods = decoratorsMeta.wiredMethods,
        observedFields = decoratorsMeta.observedFields;
    var proto = Ctor.prototype;
    var connectedCallback = proto.connectedCallback,
        disconnectedCallback = proto.disconnectedCallback,
        renderedCallback = proto.renderedCallback,
        errorCallback = proto.errorCallback,
        render = proto.render;
    var superProto = getCtorProto(Ctor, subclassComponentName);
    var superDef = superProto !== BaseLightningElement ? getComponentInternalDef(superProto, subclassComponentName) : lightingElementDef;
    var SuperBridge = isNull$1(superDef) ? BaseBridgeElement : superDef.bridge;
    var bridge = HTMLBridgeElementFactory(SuperBridge, keys(apiFields), keys(apiMethods));
    var props = assign$1(create$1(null), superDef.props, apiFields);
    var propsConfig = assign$1(create$1(null), superDef.propsConfig, apiFieldsConfig);
    var methods = assign$1(create$1(null), superDef.methods, apiMethods);
    var wire = assign$1(create$1(null), superDef.wire, wiredFields, wiredMethods);
    connectedCallback = connectedCallback || superDef.connectedCallback;
    disconnectedCallback = disconnectedCallback || superDef.disconnectedCallback;
    renderedCallback = renderedCallback || superDef.renderedCallback;
    errorCallback = errorCallback || superDef.errorCallback;
    render = render || superDef.render;
    template = template || superDef.template; // installing observed fields into the prototype.

    defineProperties$1(proto, observedFields);
    var def = {
      ctor: Ctor,
      name: name,
      wire: wire,
      props: props,
      propsConfig: propsConfig,
      methods: methods,
      bridge: bridge,
      template: template,
      connectedCallback: connectedCallback,
      disconnectedCallback: disconnectedCallback,
      renderedCallback: renderedCallback,
      errorCallback: errorCallback,
      render: render
    };

    {
      freeze(Ctor.prototype);
    }

    return def;
  }
  /**
   * EXPERIMENTAL: This function allows for the identification of LWC constructors. This API is
   * subject to change or being removed.
   */


  function isComponentConstructor(ctor) {
    if (!isFunction$1(ctor)) {
      return false;
    } // Fast path: LightningElement is part of the prototype chain of the constructor.


    if (_instanceof_1(ctor.prototype, BaseLightningElement)) {
      return true;
    } // Slow path: LightningElement is not part of the prototype chain of the constructor, we need
    // climb up the constructor prototype chain to check in case there are circular dependencies
    // to resolve.


    var current = ctor;

    do {
      if (isCircularModuleDependency(current)) {
        var circularResolved = resolveCircularModuleDependency(current); // If the circular function returns itself, that's the signal that we have hit the end
        // of the proto chain, which must always be a valid base constructor.

        if (circularResolved === current) {
          return true;
        }

        current = circularResolved;
      }

      if (current === BaseLightningElement) {
        return true;
      }
    } while (!isNull$1(current) && (current = getPrototypeOf$2(current))); // Finally return false if the LightningElement is not part of the prototype chain.


    return false;
  }

  function getComponentInternalDef(Ctor, name) {
    var def = CtorToDefMap.get(Ctor);

    if (isUndefined$1(def)) {
      if (isCircularModuleDependency(Ctor)) {
        var resolvedCtor = resolveCircularModuleDependency(Ctor);
        def = getComponentInternalDef(resolvedCtor); // Cache the unresolved component ctor too. The next time if the same unresolved ctor is used,
        // look up the definition in cache instead of re-resolving and recreating the def.

        CtorToDefMap.set(Ctor, def);
        return def;
      }

      if (!isComponentConstructor(Ctor)) {
        throw new TypeError("".concat(Ctor, " is not a valid component, or does not extends LightningElement from \"lwc\". You probably forgot to add the extend clause on the class declaration."));
      }

      var meta = getComponentRegisteredMeta(Ctor);

      if (isUndefined$1(meta)) {
        // TODO [#1295]: remove this workaround after refactoring tests
        meta = {
          template: undefined,
          name: Ctor.name
        };
      }

      def = createComponentDef(Ctor, meta, name || Ctor.name);
      CtorToDefMap.set(Ctor, def);
    }

    return def;
  } // Only set prototype for public methods and properties
  // No DOM Patching occurs here


  function setElementProto(elm, def) {
    setPrototypeOf$2(elm, def.bridge.prototype);
  }

  var lightingElementDef = {
    ctor: BaseLightningElement,
    name: BaseLightningElement.name,
    props: lightningBasedDescriptors,
    propsConfig: EmptyObject,
    methods: EmptyObject,
    wire: EmptyObject,
    bridge: BaseBridgeElement,
    template: defaultEmptyTemplate,
    render: BaseLightningElement.prototype.render
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var useSyntheticShadow = hasOwnProperty$1.call(Element.prototype, '$shadowToken$');
  var dispatchEvent$1 = 'EventTarget' in window ? EventTarget.prototype.dispatchEvent : Node.prototype.dispatchEvent; // IE11

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  var noop = function noop() {
    return void 0;
  };

  function observeElementChildNodes(elm) {
    elm.$domManual$ = true;
  }

  function setElementShadowToken(elm, token) {
    elm.$shadowToken$ = token;
  }

  function updateNodeHook(oldVnode, vnode) {
    var text = vnode.text;

    if (oldVnode.text !== text) {
      {
        unlockDomMutation();
      }
      /**
       * Compiler will never produce a text property that is not string
       */


      vnode.elm.nodeValue = text;

      {
        lockDomMutation();
      }
    }
  }

  function insertNodeHook(vnode, parentNode, referenceNode) {
    {
      unlockDomMutation();
    }

    parentNode.insertBefore(vnode.elm, referenceNode);

    {
      lockDomMutation();
    }
  }

  function removeNodeHook(vnode, parentNode) {
    {
      unlockDomMutation();
    }

    parentNode.removeChild(vnode.elm);

    {
      lockDomMutation();
    }
  }

  function createElmHook(vnode) {
    modEvents.create(vnode); // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.

    modAttrs.create(vnode);
    modProps.create(vnode);
    modStaticClassName.create(vnode);
    modStaticStyle.create(vnode);
    modComputedClassName.create(vnode);
    modComputedStyle.create(vnode);
  }

  var LWCDOMMode;

  (function (LWCDOMMode) {
    LWCDOMMode["manual"] = "manual";
  })(LWCDOMMode || (LWCDOMMode = {}));

  function fallbackElmHook(elm, vnode) {
    var owner = vnode.owner;

    if (isTrue$1$1(useSyntheticShadow)) {
      var context = vnode.data.context;
      var shadowAttribute = owner.context.shadowAttribute;

      if (!isUndefined$1(context) && !isUndefined$1(context.lwc) && context.lwc.dom === LWCDOMMode.manual) {
        // this element will now accept any manual content inserted into it
        observeElementChildNodes(elm);
      } // when running in synthetic shadow mode, we need to set the shadowToken value
      // into each element from the template, so they can be styled accordingly.


      setElementShadowToken(elm, shadowAttribute);
    }

    {
      var _context = vnode.data.context;
      var isPortal = !isUndefined$1(_context) && !isUndefined$1(_context.lwc) && _context.lwc.dom === LWCDOMMode.manual;
      patchElementWithRestrictions(elm, {
        isPortal: isPortal
      });
    }
  }

  function updateElmHook(oldVnode, vnode) {
    // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.
    modAttrs.update(oldVnode, vnode);
    modProps.update(oldVnode, vnode);
    modComputedClassName.update(oldVnode, vnode);
    modComputedStyle.update(oldVnode, vnode);
  }

  function insertCustomElmHook(vnode) {
    var vm = getAssociatedVM(vnode.elm);
    appendVM(vm);
  }

  function updateChildrenHook(oldVnode, vnode) {
    var children = vnode.children,
        owner = vnode.owner;
    var fn = hasDynamicChildren(children) ? updateDynamicChildren : updateStaticChildren;
    runWithBoundaryProtection(owner, owner.owner, noop, function () {
      fn(vnode.elm, oldVnode.children, children);
    }, noop);
  }

  function allocateChildrenHook(vnode) {
    var vm = getAssociatedVM(vnode.elm); // A component with slots will re-render because:
    // 1- There is a change of the internal state.
    // 2- There is a change on the external api (ex: slots)
    //
    // In case #1, the vnodes in the cmpSlots will be reused since they didn't changed. This routine emptied the
    // slotted children when those VCustomElement were rendered and therefore in subsequent calls to allocate children
    // in a reused VCustomElement, there won't be any slotted children.
    // For those cases, we will use the reference for allocated children stored when rendering the fresh VCustomElement.
    //
    // In case #2, we will always get a fresh VCustomElement.

    var children = vnode.aChildren || vnode.children;
    vm.aChildren = children;

    if (isTrue$1$1(useSyntheticShadow)) {
      // slow path
      allocateInSlot(vm, children); // save the allocated children in case this vnode is reused.

      vnode.aChildren = children; // every child vnode is now allocated, and the host should receive none directly, it receives them via the shadow!

      vnode.children = EmptyArray;
    }
  }

  function createViewModelHook(elm, vnode) {
    if (!isUndefined$1(getAssociatedVMIfPresent(elm))) {
      // There is a possibility that a custom element is registered under tagName,
      // in which case, the initialization is already carry on, and there is nothing else
      // to do here since this hook is called right after invoking `document.createElement`.
      return;
    }

    var sel = vnode.sel,
        mode = vnode.mode,
        ctor = vnode.ctor,
        owner = vnode.owner;
    var def = getComponentInternalDef(ctor);
    setElementProto(elm, def);

    if (isTrue$1$1(useSyntheticShadow)) {
      var shadowAttribute = owner.context.shadowAttribute; // when running in synthetic shadow mode, we need to set the shadowToken value
      // into each element from the template, so they can be styled accordingly.

      setElementShadowToken(elm, shadowAttribute);
    }

    createVM(elm, def, {
      mode: mode,
      owner: owner,
      tagName: sel
    });

    {
      assert$1.isTrue(isArray$1$1(vnode.children), "Invalid vnode for a custom element, it must have children defined.");
    }
  }

  function createCustomElmHook(vnode) {
    modEvents.create(vnode); // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.

    modAttrs.create(vnode);
    modProps.create(vnode);
    modStaticClassName.create(vnode);
    modStaticStyle.create(vnode);
    modComputedClassName.create(vnode);
    modComputedStyle.create(vnode);
  }

  function createChildrenHook(vnode) {
    var elm = vnode.elm,
        children = vnode.children;

    for (var j = 0; j < children.length; ++j) {
      var ch = children[j];

      if (ch != null) {
        ch.hook.create(ch);
        ch.hook.insert(ch, elm, null);
      }
    }
  }

  function rerenderCustomElmHook(vnode) {
    var vm = getAssociatedVM(vnode.elm);

    {
      assert$1.isTrue(isArray$1$1(vnode.children), "Invalid vnode for a custom element, it must have children defined.");
    }

    rerenderVM(vm);
  }

  function updateCustomElmHook(oldVnode, vnode) {
    // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.
    modAttrs.update(oldVnode, vnode);
    modProps.update(oldVnode, vnode);
    modComputedClassName.update(oldVnode, vnode);
    modComputedStyle.update(oldVnode, vnode);
  }

  function removeElmHook(vnode) {
    // this method only needs to search on child vnodes from template
    // to trigger the remove hook just in case some of those children
    // are custom elements.
    var children = vnode.children,
        elm = vnode.elm;

    for (var j = 0, _len6 = children.length; j < _len6; ++j) {
      var ch = children[j];

      if (!isNull$1(ch)) {
        ch.hook.remove(ch, elm);
      }
    }
  }

  function removeCustomElmHook(vnode) {
    // for custom elements we don't have to go recursively because the removeVM routine
    // will take care of disconnecting any child VM attached to its shadow as well.
    removeVM(getAssociatedVM(vnode.elm));
  } // Using a WeakMap instead of a WeakSet because this one works in IE11 :(


  var FromIteration = new WeakMap(); // dynamic children means it was generated by an iteration
  // in a template, and will require a more complex diffing algo.

  function markAsDynamicChildren(children) {
    FromIteration.set(children, 1);
  }

  function hasDynamicChildren(children) {
    return FromIteration.has(children);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var CHAR_S$1 = 115;
  var CHAR_V = 118;
  var CHAR_G = 103;
  var NamespaceAttributeForSVG = 'http://www.w3.org/2000/svg';
  var SymbolIterator = Symbol.iterator;
  var TextHook = {
    create: function create(vnode) {
      var elm = document.createTextNode(vnode.text);
      linkNodeToShadow(elm, vnode);
      vnode.elm = elm;
    },
    update: updateNodeHook,
    insert: insertNodeHook,
    move: insertNodeHook,
    remove: removeNodeHook
  }; // insert is called after update, which is used somewhere else (via a module)
  // to mark the vm as inserted, that means we cannot use update as the main channel
  // to rehydrate when dirty, because sometimes the element is not inserted just yet,
  // which breaks some invariants. For that reason, we have the following for any
  // Custom Element that is inserted via a template.

  var ElementHook = {
    create: function create(vnode) {
      var data = vnode.data,
          sel = vnode.sel,
          clonedElement = vnode.clonedElement;
      var ns = data.ns; // TODO [#1364]: supporting the ability to inject a cloned StyleElement via a vnode this is
      // used for style tags for native shadow

      var elm;

      if (isUndefined$1(clonedElement)) {
        elm = isUndefined$1(ns) ? document.createElement(sel) : document.createElementNS(ns, sel);
      } else {
        elm = clonedElement;
      }

      linkNodeToShadow(elm, vnode);
      fallbackElmHook(elm, vnode);
      vnode.elm = elm;
      createElmHook(vnode);
    },
    update: function update(oldVnode, vnode) {
      updateElmHook(oldVnode, vnode);
      updateChildrenHook(oldVnode, vnode);
    },
    insert: function insert(vnode, parentNode, referenceNode) {
      insertNodeHook(vnode, parentNode, referenceNode);
      createChildrenHook(vnode);
    },
    move: function move(vnode, parentNode, referenceNode) {
      insertNodeHook(vnode, parentNode, referenceNode);
    },
    remove: function remove(vnode, parentNode) {
      removeNodeHook(vnode, parentNode);
      removeElmHook(vnode);
    }
  };
  var CustomElementHook = {
    create: function create(vnode) {
      var sel = vnode.sel;
      var elm = document.createElement(sel);
      linkNodeToShadow(elm, vnode);
      createViewModelHook(elm, vnode);
      vnode.elm = elm;
      allocateChildrenHook(vnode);
      createCustomElmHook(vnode);
    },
    update: function update(oldVnode, vnode) {
      updateCustomElmHook(oldVnode, vnode); // in fallback mode, the allocation will always set children to
      // empty and delegate the real allocation to the slot elements

      allocateChildrenHook(vnode); // in fallback mode, the children will be always empty, so, nothing
      // will happen, but in native, it does allocate the light dom

      updateChildrenHook(oldVnode, vnode); // this will update the shadowRoot

      rerenderCustomElmHook(vnode);
    },
    insert: function insert(vnode, parentNode, referenceNode) {
      insertNodeHook(vnode, parentNode, referenceNode);
      var vm = getAssociatedVM(vnode.elm);

      {
        assert$1.isTrue(vm.state === VMState.created, "".concat(vm, " cannot be recycled."));
      }

      runConnectedCallback(vm);
      createChildrenHook(vnode);
      insertCustomElmHook(vnode);
    },
    move: function move(vnode, parentNode, referenceNode) {
      insertNodeHook(vnode, parentNode, referenceNode);
    },
    remove: function remove(vnode, parentNode) {
      removeNodeHook(vnode, parentNode);
      removeCustomElmHook(vnode);
    }
  };

  function linkNodeToShadow(elm, vnode) {
    // TODO [#1164]: this should eventually be done by the polyfill directly
    elm.$shadowResolver$ = vnode.owner.cmpRoot.$shadowResolver$;
  } // TODO [#1136]: this should be done by the compiler, adding ns to every sub-element


  function addNS(vnode) {
    var data = vnode.data,
        children = vnode.children,
        sel = vnode.sel;
    data.ns = NamespaceAttributeForSVG; // TODO [#1275]: review why `sel` equal `foreignObject` should get this `ns`

    if (isArray$1$1(children) && sel !== 'foreignObject') {
      for (var j = 0, n = children.length; j < n; ++j) {
        var childNode = children[j];

        if (childNode != null && childNode.hook === ElementHook) {
          addNS(childNode);
        }
      }
    }
  }

  function addVNodeToChildLWC(vnode) {
    ArrayPush$1.call(getVMBeingRendered().velements, vnode);
  } // [h]tml node


  function h(sel, data, children) {
    var vmBeingRendered = getVMBeingRendered();

    {
      assert$1.isTrue(isString(sel), "h() 1st argument sel must be a string.");
      assert$1.isTrue(isObject$1(data), "h() 2nd argument data must be an object.");
      assert$1.isTrue(isArray$1$1(children), "h() 3rd argument children must be an array.");
      assert$1.isTrue('key' in data, " <".concat(sel, "> \"key\" attribute is invalid or missing for ").concat(vmBeingRendered, ". Key inside iterator is either undefined or null.")); // checking reserved internal data properties

      assert$1.isFalse(data.className && data.classMap, "vnode.data.className and vnode.data.classMap ambiguous declaration.");
      assert$1.isFalse(data.styleMap && data.style, "vnode.data.styleMap and vnode.data.style ambiguous declaration.");

      if (data.style && !isString(data.style)) {
        logError("Invalid 'style' attribute passed to <".concat(sel, "> is ignored. This attribute must be a string value."), vmBeingRendered);
      }

      forEach$1.call(children, function (childVnode) {
        if (childVnode != null) {
          assert$1.isTrue(childVnode && 'sel' in childVnode && 'data' in childVnode && 'children' in childVnode && 'text' in childVnode && 'elm' in childVnode && 'key' in childVnode, "".concat(childVnode, " is not a vnode."));
        }
      });
    }

    var key = data.key;
    var text, elm;
    var vnode = {
      sel: sel,
      data: data,
      children: children,
      text: text,
      elm: elm,
      key: key,
      hook: ElementHook,
      owner: vmBeingRendered
    };

    if (sel.length === 3 && StringCharCodeAt$1.call(sel, 0) === CHAR_S$1 && StringCharCodeAt$1.call(sel, 1) === CHAR_V && StringCharCodeAt$1.call(sel, 2) === CHAR_G) {
      addNS(vnode);
    }

    return vnode;
  } // [t]ab[i]ndex function


  function ti(value) {
    // if value is greater than 0, we normalize to 0
    // If value is an invalid tabIndex value (null, undefined, string, etc), we let that value pass through
    // If value is less than -1, we don't care
    var shouldNormalize = value > 0 && !(isTrue$1$1(value) || isFalse$1$1(value));

    {
      var _vmBeingRendered6 = getVMBeingRendered();

      if (shouldNormalize) {
        logError("Invalid tabindex value `".concat(toString$1(value), "` in template for ").concat(_vmBeingRendered6, ". This attribute must be set to 0 or -1."), _vmBeingRendered6);
      }
    }

    return shouldNormalize ? 0 : value;
  } // [s]lot element node


  function s(slotName, data, children, slotset) {
    {
      assert$1.isTrue(isString(slotName), "s() 1st argument slotName must be a string.");
      assert$1.isTrue(isObject$1(data), "s() 2nd argument data must be an object.");
      assert$1.isTrue(isArray$1$1(children), "h() 3rd argument children must be an array.");
    }

    if (!isUndefined$1(slotset) && !isUndefined$1(slotset[slotName]) && slotset[slotName].length !== 0) {
      children = slotset[slotName];
    }

    var vnode = h('slot', data, children);

    if (useSyntheticShadow) {
      // TODO [#1276]: compiler should give us some sort of indicator when a vnodes collection is dynamic
      sc(children);
    }

    return vnode;
  } // [c]ustom element node


  function c(sel, Ctor, data) {
    var children = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : EmptyArray;
    var vmBeingRendered = getVMBeingRendered();

    {
      assert$1.isTrue(isString(sel), "c() 1st argument sel must be a string.");
      assert$1.isTrue(isFunction$1(Ctor), "c() 2nd argument Ctor must be a function.");
      assert$1.isTrue(isObject$1(data), "c() 3nd argument data must be an object.");
      assert$1.isTrue(arguments.length === 3 || isArray$1$1(children), "c() 4nd argument data must be an array."); // checking reserved internal data properties

      assert$1.isFalse(data.className && data.classMap, "vnode.data.className and vnode.data.classMap ambiguous declaration.");
      assert$1.isFalse(data.styleMap && data.style, "vnode.data.styleMap and vnode.data.style ambiguous declaration.");

      if (data.style && !isString(data.style)) {
        logError("Invalid 'style' attribute passed to <".concat(sel, "> is ignored. This attribute must be a string value."), vmBeingRendered);
      }

      if (arguments.length === 4) {
        forEach$1.call(children, function (childVnode) {
          if (childVnode != null) {
            assert$1.isTrue(childVnode && 'sel' in childVnode && 'data' in childVnode && 'children' in childVnode && 'text' in childVnode && 'elm' in childVnode && 'key' in childVnode, "".concat(childVnode, " is not a vnode."));
          }
        });
      }
    }

    var key = data.key;
    var text, elm;
    var vnode = {
      sel: sel,
      data: data,
      children: children,
      text: text,
      elm: elm,
      key: key,
      hook: CustomElementHook,
      ctor: Ctor,
      owner: vmBeingRendered,
      mode: 'open'
    };
    addVNodeToChildLWC(vnode);
    return vnode;
  } // [i]terable node


  function i(iterable, factory) {
    var list = []; // TODO [#1276]: compiler should give us some sort of indicator when a vnodes collection is dynamic

    sc(list);
    var vmBeingRendered = getVMBeingRendered();

    if (isUndefined$1(iterable) || iterable === null) {
      {
        logError("Invalid template iteration for value \"".concat(toString$1(iterable), "\" in ").concat(vmBeingRendered, ". It must be an Array or an iterable Object."), vmBeingRendered);
      }

      return list;
    }

    {
      assert$1.isFalse(isUndefined$1(iterable[SymbolIterator]), "Invalid template iteration for value `".concat(toString$1(iterable), "` in ").concat(vmBeingRendered, ". It must be an array-like object and not `null` nor `undefined`."));
    }

    var iterator = iterable[SymbolIterator]();

    {
      assert$1.isTrue(iterator && isFunction$1(iterator.next), "Invalid iterator function for \"".concat(toString$1(iterable), "\" in ").concat(vmBeingRendered, "."));
    }

    var next = iterator.next();
    var j = 0;
    var _next = next,
        value = _next.value,
        last = _next.done;
    var keyMap;
    var iterationError;

    {
      keyMap = create$1(null);
    }

    while (last === false) {
      // implementing a look-back-approach because we need to know if the element is the last
      next = iterator.next();
      last = next.done; // template factory logic based on the previous collected value

      var vnode = factory(value, j, j === 0, last);

      if (isArray$1$1(vnode)) {
        ArrayPush$1.apply(list, vnode);
      } else {
        ArrayPush$1.call(list, vnode);
      }

      {
        var vnodes = isArray$1$1(vnode) ? vnode : [vnode];
        forEach$1.call(vnodes, function (childVnode) {
          if (!isNull$1(childVnode) && isObject$1(childVnode) && !isUndefined$1(childVnode.sel)) {
            var key = childVnode.key;

            if (isString(key) || isNumber(key)) {
              if (keyMap[key] === 1 && isUndefined$1(iterationError)) {
                iterationError = "Duplicated \"key\" attribute value for \"<".concat(childVnode.sel, ">\" in ").concat(vmBeingRendered, " for item number ").concat(j, ". A key with value \"").concat(childVnode.key, "\" appears more than once in the iteration. Key values must be unique numbers or strings.");
              }

              keyMap[key] = 1;
            } else if (isUndefined$1(iterationError)) {
              iterationError = "Invalid \"key\" attribute value in \"<".concat(childVnode.sel, ">\" in ").concat(vmBeingRendered, " for item number ").concat(j, ". Set a unique \"key\" value on all iterated child elements.");
            }
          }
        });
      } // preparing next value


      j += 1;
      value = next.value;
    }

    {
      if (!isUndefined$1(iterationError)) {
        logError(iterationError, vmBeingRendered);
      }
    }

    return list;
  }
  /**
   * [f]lattening
   */


  function f(items) {
    {
      assert$1.isTrue(isArray$1$1(items), 'flattening api can only work with arrays.');
    }

    var len = items.length;
    var flattened = []; // TODO [#1276]: compiler should give us some sort of indicator when a vnodes collection is dynamic

    sc(flattened);

    for (var j = 0; j < len; j += 1) {
      var item = items[j];

      if (isArray$1$1(item)) {
        ArrayPush$1.apply(flattened, item);
      } else {
        ArrayPush$1.call(flattened, item);
      }
    }

    return flattened;
  } // [t]ext node


  function t(text) {
    var data = EmptyObject;
    var sel, children, key, elm;
    return {
      sel: sel,
      data: data,
      children: children,
      text: text,
      elm: elm,
      key: key,
      hook: TextHook,
      owner: getVMBeingRendered()
    };
  } // [d]ynamic value to produce a text vnode


  function d(value) {
    if (value == null) {
      return null;
    }

    return t(value);
  } // [b]ind function


  function b(fn) {
    var vmBeingRendered = getVMBeingRendered();

    if (isNull$1(vmBeingRendered)) {
      throw new Error();
    }

    var vm = vmBeingRendered;
    return function (event) {
      invokeEventListener(vm, fn, vm.component, event);
    };
  } // [k]ey function


  function k(compilerKey, obj) {
    switch (_typeof_1(obj)) {
      case 'number':
      case 'string':
        return compilerKey + ':' + obj;

      case 'object':
        {
          assert$1.fail("Invalid key value \"".concat(obj, "\" in ").concat(getVMBeingRendered(), ". Key must be a string or number."));
        }

    }
  } // [g]lobal [id] function


  function gid(id) {
    var vmBeingRendered = getVMBeingRendered();

    if (isUndefined$1(id) || id === '') {
      {
        logError("Invalid id value \"".concat(id, "\". The id attribute must contain a non-empty string."), vmBeingRendered);
      }

      return id;
    } // We remove attributes when they are assigned a value of null


    if (isNull$1(id)) {
      return null;
    }

    return "".concat(id, "-").concat(vmBeingRendered.idx);
  } // [f]ragment [id] function


  function fid(url) {
    var vmBeingRendered = getVMBeingRendered();

    if (isUndefined$1(url) || url === '') {
      {
        if (isUndefined$1(url)) {
          logError("Undefined url value for \"href\" or \"xlink:href\" attribute. Expected a non-empty string.", vmBeingRendered);
        }
      }

      return url;
    } // We remove attributes when they are assigned a value of null


    if (isNull$1(url)) {
      return null;
    } // Apply transformation only for fragment-only-urls


    if (/^#/.test(url)) {
      return "".concat(url, "-").concat(vmBeingRendered.idx);
    }

    return url;
  }
  /**
   * Map to store an index value assigned to any dynamic component reference ingested
   * by dc() api. This allows us to generate a unique unique per template per dynamic
   * component reference to avoid diffing algo mismatches.
   */


  var DynamicImportedComponentMap = new Map();
  var dynamicImportedComponentCounter = 0;
  /**
   * create a dynamic component via `<x-foo lwc:dynamic={Ctor}>`
   */

  function dc(sel, Ctor, data, children) {
    {
      assert$1.isTrue(isString(sel), "dc() 1st argument sel must be a string.");
      assert$1.isTrue(isObject$1(data), "dc() 3nd argument data must be an object.");
      assert$1.isTrue(arguments.length === 3 || isArray$1$1(children), "dc() 4nd argument data must be an array.");
    } // null or undefined values should produce a null value in the VNodes


    if (Ctor == null) {
      return null;
    }

    if (!isComponentConstructor(Ctor)) {
      throw new Error("Invalid LWC Constructor ".concat(toString$1(Ctor), " for custom element <").concat(sel, ">."));
    }

    var idx = DynamicImportedComponentMap.get(Ctor);

    if (isUndefined$1(idx)) {
      idx = dynamicImportedComponentCounter++;
      DynamicImportedComponentMap.set(Ctor, idx);
    } // the new vnode key is a mix of idx and compiler key, this is required by the diffing algo
    // to identify different constructors as vnodes with different keys to avoid reusing the
    // element used for previous constructors.


    data.key = "dc:".concat(idx, ":").concat(data.key);
    return c(sel, Ctor, data, children);
  }
  /**
   * slow children collection marking mechanism. this API allows the compiler to signal
   * to the engine that a particular collection of children must be diffed using the slow
   * algo based on keys due to the nature of the list. E.g.:
   *
   *   - slot element's children: the content of the slot has to be dynamic when in synthetic
   *                              shadow mode because the `vnode.children` might be the slotted
   *                              content vs default content, in which case the size and the
   *                              keys are not matching.
   *   - children that contain dynamic components
   *   - children that are produced by iteration
   *
   */


  function sc(vnodes) {
    {
      assert$1.isTrue(isArray$1$1(vnodes), 'sc() api can only work with arrays.');
    } // We have to mark the vnodes collection as dynamic so we can later on
    // choose to use the snabbdom virtual dom diffing algo instead of our
    // static dummy algo.


    markAsDynamicChildren(vnodes);
    return vnodes;
  }

  var api$1 =
  /*#__PURE__*/
  Object.freeze({
    __proto__: null,
    h: h,
    ti: ti,
    s: s,
    c: c,
    i: i,
    f: f,
    t: t,
    d: d,
    b: b,
    k: k,
    gid: gid,
    fid: fid,
    dc: dc,
    sc: sc
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  var CachedStyleFragments = create$1(null);

  function createStyleElement(styleContent) {
    var elm = document.createElement('style');
    elm.type = 'text/css';
    elm.textContent = styleContent;
    return elm;
  }

  function getCachedStyleElement(styleContent) {
    var fragment = CachedStyleFragments[styleContent];

    if (isUndefined$1(fragment)) {
      fragment = document.createDocumentFragment();
      var styleElm = createStyleElement(styleContent);
      fragment.appendChild(styleElm);
      CachedStyleFragments[styleContent] = fragment;
    }

    return fragment.cloneNode(true).firstChild;
  }

  var globalStyleParent = document.head || document.body || document;
  var InsertedGlobalStyleContent = create$1(null);

  function insertGlobalStyle(styleContent) {
    // inserts the global style when needed, otherwise does nothing
    if (isUndefined$1(InsertedGlobalStyleContent[styleContent])) {
      InsertedGlobalStyleContent[styleContent] = true;
      var elm = createStyleElement(styleContent);
      globalStyleParent.appendChild(elm);
    }
  }

  function createStyleVNode(elm) {
    var vnode = h('style', {
      key: 'style'
    }, EmptyArray); // TODO [#1364]: supporting the ability to inject a cloned StyleElement
    // forcing the diffing algo to use the cloned style for native shadow

    vnode.clonedElement = elm;
    return vnode;
  }
  /**
   * Reset the styling token applied to the host element.
   */


  function resetStyleAttributes(vm) {
    var context = vm.context,
        elm = vm.elm; // Remove the style attribute currently applied to the host element.

    var oldHostAttribute = context.hostAttribute;

    if (!isUndefined$1(oldHostAttribute)) {
      removeAttribute$1.call(elm, oldHostAttribute);
    } // Reset the scoping attributes associated to the context.


    context.hostAttribute = context.shadowAttribute = undefined;
  }
  /**
   * Apply/Update the styling token applied to the host element.
   */


  function applyStyleAttributes(vm, hostAttribute, shadowAttribute) {
    var context = vm.context,
        elm = vm.elm; // Remove the style attribute currently applied to the host element.

    setAttribute$1.call(elm, hostAttribute, '');
    context.hostAttribute = hostAttribute;
    context.shadowAttribute = shadowAttribute;
  }

  function collectStylesheets(stylesheets, hostSelector, shadowSelector, isNative, aggregatorFn) {
    forEach$1.call(stylesheets, function (sheet) {
      if (isArray$1$1(sheet)) {
        collectStylesheets(sheet, hostSelector, shadowSelector, isNative, aggregatorFn);
      } else {
        aggregatorFn(sheet(hostSelector, shadowSelector, isNative));
      }
    });
  }

  function evaluateCSS(stylesheets, hostAttribute, shadowAttribute) {
    {
      assert$1.isTrue(isArray$1$1(stylesheets), "Invalid stylesheets.");
    }

    if (useSyntheticShadow) {
      var hostSelector = "[".concat(hostAttribute, "]");
      var shadowSelector = "[".concat(shadowAttribute, "]");
      collectStylesheets(stylesheets, hostSelector, shadowSelector, false, function (textContent) {
        insertGlobalStyle(textContent);
      });
      return null;
    } else {
      // Native shadow in place, we need to act accordingly by using the `:host` selector, and an
      // empty shadow selector since it is not really needed.
      var buffer = '';
      collectStylesheets(stylesheets, emptyString$1, emptyString$1, true, function (textContent) {
        buffer += textContent;
      });
      return createStyleVNode(getCachedStyleElement(buffer));
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var GlobalMeasurementPhase;

  (function (GlobalMeasurementPhase) {
    GlobalMeasurementPhase["REHYDRATE"] = "lwc-rehydrate";
    GlobalMeasurementPhase["HYDRATE"] = "lwc-hydrate";
  })(GlobalMeasurementPhase || (GlobalMeasurementPhase = {})); // Even if all the browser the engine supports implements the UserTiming API, we need to guard the measure APIs.
  // JSDom (used in Jest) for example doesn't implement the UserTiming APIs.


  var isUserTimingSupported = typeof performance !== 'undefined' && typeof performance.mark === 'function' && typeof performance.clearMarks === 'function' && typeof performance.measure === 'function' && typeof performance.clearMeasures === 'function';

  function getMarkName(phase, vm) {
    // Adding the VM idx to the mark name creates a unique mark name component instance. This is necessary to produce
    // the right measures for components that are recursive.
    return "".concat(getComponentTag(vm), " - ").concat(phase, " - ").concat(vm.idx);
  }

  function getMeasureName(phase, vm) {
    return "".concat(getComponentTag(vm), " - ").concat(phase);
  }

  function start(markName) {
    performance.mark(markName);
  }

  function end(measureName, markName) {
    performance.measure(measureName, markName); // Clear the created marks and measure to avoid filling the performance entries buffer.
    // Note: Even if the entries get deleted, existing PerformanceObservers preserve a copy of those entries.

    performance.clearMarks(markName);
    performance.clearMarks(measureName);
  }

  function noop$1() {
    /* do nothing */
  }

  var startMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    var markName = getMarkName(phase, vm);
    start(markName);
  };
  var endMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    var markName = getMarkName(phase, vm);
    var measureName = getMeasureName(phase, vm);
    end(measureName, markName);
  };
  var startGlobalMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    var markName = isUndefined$1(vm) ? phase : getMarkName(phase, vm);
    start(markName);
  };
  var endGlobalMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    var markName = isUndefined$1(vm) ? phase : getMarkName(phase, vm);
    end(phase, markName);
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  var isUpdatingTemplate = false;
  var vmBeingRendered = null;

  function getVMBeingRendered() {
    return vmBeingRendered;
  }

  function setVMBeingRendered(vm) {
    vmBeingRendered = vm;
  }

  function validateSlots(vm, html) {

    var cmpSlots = vm.cmpSlots;
    var _html$slots = html.slots,
        slots = _html$slots === void 0 ? EmptyArray : _html$slots;

    for (var slotName in cmpSlots) {
      // eslint-disable-next-line lwc-internal/no-production-assert
      assert$1.isTrue(isArray$1$1(cmpSlots[slotName]), "Slots can only be set to an array, instead received ".concat(toString$1(cmpSlots[slotName]), " for slot \"").concat(slotName, "\" in ").concat(vm, "."));

      if (slotName !== '' && ArrayIndexOf$1.call(slots, slotName) === -1) {
        // TODO [#1297]: this should never really happen because the compiler should always validate
        // eslint-disable-next-line lwc-internal/no-production-assert
        logError("Ignoring unknown provided slot name \"".concat(slotName, "\" in ").concat(vm, ". Check for a typo on the slot attribute."), vm);
      }
    }
  }

  function evaluateTemplate(vm, html) {
    {
      assert$1.isTrue(isFunction$1(html), "evaluateTemplate() second argument must be an imported template instead of ".concat(toString$1(html)));
    }

    var isUpdatingTemplateInception = isUpdatingTemplate;
    var vmOfTemplateBeingUpdatedInception = vmBeingRendered;
    var vnodes = [];
    runWithBoundaryProtection(vm, vm.owner, function () {
      // pre
      vmBeingRendered = vm;

      {
        startMeasure('render', vm);
      }
    }, function () {
      // job
      var component = vm.component,
          context = vm.context,
          cmpSlots = vm.cmpSlots,
          cmpTemplate = vm.cmpTemplate,
          tro = vm.tro;
      tro.observe(function () {
        // Reset the cache memoizer for template when needed.
        if (html !== cmpTemplate) {
          // Perf opt: do not reset the shadow root during the first rendering (there is
          // nothing to reset).
          if (!isNull$1(cmpTemplate)) {
            // It is important to reset the content to avoid reusing similar elements
            // generated from a different template, because they could have similar IDs,
            // and snabbdom just rely on the IDs.
            resetShadowRoot(vm);
          } // Check that the template was built by the compiler.


          if (!isTemplateRegistered(html)) {
            throw new TypeError("Invalid template returned by the render() method on ".concat(vm, ". It must return an imported template (e.g.: `import html from \"./").concat(vm.def.name, ".html\"`), instead, it has returned: ").concat(toString$1(html), "."));
          }

          vm.cmpTemplate = html; // Populate context with template information

          context.tplCache = create$1(null);
          resetStyleAttributes(vm);
          var stylesheets = html.stylesheets,
              stylesheetTokens = html.stylesheetTokens;

          if (isUndefined$1(stylesheets) || stylesheets.length === 0) {
            context.styleVNode = null;
          } else if (!isUndefined$1(stylesheetTokens)) {
            var hostAttribute = stylesheetTokens.hostAttribute,
                shadowAttribute = stylesheetTokens.shadowAttribute;
            applyStyleAttributes(vm, hostAttribute, shadowAttribute); // Caching style vnode so it can be reused on every render

            context.styleVNode = evaluateCSS(stylesheets, hostAttribute, shadowAttribute);
          }
        }

        if ("development" !== 'production') {
          // validating slots in every rendering since the allocated content might change over time
          validateSlots(vm, html);
        } // right before producing the vnodes, we clear up all internal references
        // to custom elements from the template.


        vm.velements = []; // Set the global flag that template is being updated

        isUpdatingTemplate = true;
        vnodes = html.call(undefined, api$1, component, cmpSlots, context.tplCache);
        var styleVNode = context.styleVNode;

        if (!isNull$1(styleVNode)) {
          ArrayUnshift$1$1.call(vnodes, styleVNode);
        }
      });
    }, function () {
      // post
      isUpdatingTemplate = isUpdatingTemplateInception;
      vmBeingRendered = vmOfTemplateBeingUpdatedInception;

      {
        endMeasure('render', vm);
      }
    });

    {
      assert$1.invariant(isArray$1$1(vnodes), "Compiler should produce html functions that always return an array.");
    }

    return vnodes;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var isInvokingRender = false;
  var vmBeingConstructed = null;

  function isBeingConstructed(vm) {
    return vmBeingConstructed === vm;
  }

  var noop$2 = function noop$2() {
    return void 0;
  };

  function invokeComponentCallback(vm, fn, args) {
    var component = vm.component,
        callHook = vm.callHook,
        owner = vm.owner;
    var result;
    runWithBoundaryProtection(vm, owner, noop$2, function () {
      // job
      result = callHook(component, fn, args);
    }, noop$2);
    return result;
  }

  function invokeComponentConstructor(vm, Ctor) {
    var vmBeingConstructedInception = vmBeingConstructed;
    var error;

    {
      startMeasure('constructor', vm);
    }

    vmBeingConstructed = vm;
    /**
     * Constructors don't need to be wrapped with a boundary because for root elements
     * it should throw, while elements from template are already wrapped by a boundary
     * associated to the diffing algo.
     */

    try {
      // job
      var result = new Ctor(); // Check indirectly if the constructor result is an instance of LightningElement. Using
      // the "instanceof" operator would not work here since Locker Service provides its own
      // implementation of LightningElement, so we indirectly check if the base constructor is
      // invoked by accessing the component on the vm.

      if (vmBeingConstructed.component !== result) {
        throw new TypeError('Invalid component constructor, the class should extend LightningElement.');
      }
    } catch (e) {
      error = Object(e);
    } finally {
      {
        endMeasure('constructor', vm);
      }

      vmBeingConstructed = vmBeingConstructedInception;

      if (!isUndefined$1(error)) {
        error.wcStack = getErrorComponentStack(vm); // re-throwing the original error annotated after restoring the context

        throw error; // eslint-disable-line no-unsafe-finally
      }
    }
  }

  function invokeComponentRenderMethod(vm) {
    var render = vm.def.render,
        callHook = vm.callHook,
        component = vm.component,
        owner = vm.owner;
    var isRenderBeingInvokedInception = isInvokingRender;
    var vmBeingRenderedInception = getVMBeingRendered();
    var html;
    var renderInvocationSuccessful = false;
    runWithBoundaryProtection(vm, owner, function () {
      // pre
      isInvokingRender = true;
      setVMBeingRendered(vm);
    }, function () {
      // job
      vm.tro.observe(function () {
        html = callHook(component, render);
        renderInvocationSuccessful = true;
      });
    }, function () {
      // post
      isInvokingRender = isRenderBeingInvokedInception;
      setVMBeingRendered(vmBeingRenderedInception);
    }); // If render() invocation failed, process errorCallback in boundary and return an empty template

    return renderInvocationSuccessful ? evaluateTemplate(vm, html) : [];
  }

  function invokeComponentRenderedCallback(vm) {
    var renderedCallback = vm.def.renderedCallback,
        component = vm.component,
        callHook = vm.callHook,
        owner = vm.owner;

    if (!isUndefined$1(renderedCallback)) {
      runWithBoundaryProtection(vm, owner, function () {
        {
          startMeasure('renderedCallback', vm);
        }
      }, function () {
        // job
        callHook(component, renderedCallback);
      }, function () {
        // post
        {
          endMeasure('renderedCallback', vm);
        }
      });
    }
  }

  function invokeEventListener(vm, fn, thisValue, event) {
    var callHook = vm.callHook,
        owner = vm.owner;
    runWithBoundaryProtection(vm, owner, noop$2, function () {
      // job
      if ("development" !== 'production') {
        assert$1.isTrue(isFunction$1(fn), "Invalid event handler for event '".concat(event.type, "' on ").concat(vm, "."));
      }

      callHook(thisValue, fn, [event]);
    }, noop$2);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var signedComponentToMetaMap = new Map();
  /**
   * INTERNAL: This function can only be invoked by compiled code. The compiler
   * will prevent this function from being imported by userland code.
   */

  function registerComponent(Ctor, _ref) {
    var name = _ref.name,
        template = _ref.tmpl;
    signedComponentToMetaMap.set(Ctor, {
      name: name,
      template: template
    }); // chaining this method as a way to wrap existing
    // assignment of component constructor easily, without too much transformation

    return Ctor;
  }

  function getComponentRegisteredMeta(Ctor) {
    return signedComponentToMetaMap.get(Ctor);
  }

  function createComponent(vm, Ctor) {
    // create the component instance
    invokeComponentConstructor(vm, Ctor);

    if (isUndefined$1(vm.component)) {
      throw new ReferenceError("Invalid construction for ".concat(Ctor, ", you must extend LightningElement."));
    }
  }

  function getTemplateReactiveObserver(vm) {
    return new ReactiveObserver(function () {
      var isDirty = vm.isDirty;

      if (isFalse$1$1(isDirty)) {
        markComponentAsDirty(vm);
        scheduleRehydration(vm);
      }
    });
  }

  function renderComponent(vm) {
    {
      assert$1.invariant(vm.isDirty, "".concat(vm, " is not dirty."));
    }

    vm.tro.reset();
    var vnodes = invokeComponentRenderMethod(vm);
    vm.isDirty = false;
    vm.isScheduled = false;

    {
      assert$1.invariant(isArray$1$1(vnodes), "".concat(vm, ".render() should always return an array of vnodes instead of ").concat(vnodes));
    }

    return vnodes;
  }

  function markComponentAsDirty(vm) {
    {
      var _vmBeingRendered7 = getVMBeingRendered();

      assert$1.isFalse(vm.isDirty, "markComponentAsDirty() for ".concat(vm, " should not be called when the component is already dirty."));
      assert$1.isFalse(isInvokingRender, "markComponentAsDirty() for ".concat(vm, " cannot be called during rendering of ").concat(_vmBeingRendered7, "."));
      assert$1.isFalse(isUpdatingTemplate, "markComponentAsDirty() for ".concat(vm, " cannot be called while updating template of ").concat(_vmBeingRendered7, "."));
    }

    vm.isDirty = true;
  }

  var cmpEventListenerMap = new WeakMap();

  function getWrappedComponentsListener(vm, listener) {
    if (!isFunction$1(listener)) {
      throw new TypeError(); // avoiding problems with non-valid listeners
    }

    var wrappedListener = cmpEventListenerMap.get(listener);

    if (isUndefined$1(wrappedListener)) {
      wrappedListener = function wrappedListener(event) {
        invokeEventListener(vm, listener, undefined, event);
      };

      cmpEventListenerMap.set(listener, wrappedListener);
    }

    return wrappedListener;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var Services = create$1(null);

  function invokeServiceHook(vm, cbs) {
    {
      assert$1.isTrue(isArray$1$1(cbs) && cbs.length > 0, "Optimize invokeServiceHook() to be invoked only when needed");
    }

    var component = vm.component,
        def = vm.def,
        context = vm.context;

    for (var _i10 = 0, _len7 = cbs.length; _i10 < _len7; ++_i10) {
      cbs[_i10].call(undefined, component, {}, def, context);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var VMState;

  (function (VMState) {
    VMState[VMState["created"] = 0] = "created";
    VMState[VMState["connected"] = 1] = "connected";
    VMState[VMState["disconnected"] = 2] = "disconnected";
  })(VMState || (VMState = {}));

  var idx = 0;
  /** The internal slot used to associate different objects the engine manipulates with the VM */

  var ViewModelReflection = createHiddenField('ViewModel', 'engine');

  function callHook(cmp, fn) {
    var args = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
    return fn.apply(cmp, args);
  }

  function setHook(cmp, prop, newValue) {
    cmp[prop] = newValue;
  }

  function getHook(cmp, prop) {
    return cmp[prop];
  }

  function rerenderVM(vm) {
    rehydrate(vm);
  }

  function connectRootElement(elm) {
    var vm = getAssociatedVM(elm);
    startGlobalMeasure(GlobalMeasurementPhase.HYDRATE, vm); // Usually means moving the element from one place to another, which is observable via
    // life-cycle hooks.

    if (vm.state === VMState.connected) {
      disconnectRootElement(elm);
    }

    runConnectedCallback(vm);
    rehydrate(vm);
    endGlobalMeasure(GlobalMeasurementPhase.HYDRATE, vm);
  }

  function disconnectRootElement(elm) {
    var vm = getAssociatedVM(elm);
    resetComponentStateWhenRemoved(vm);
  }

  function appendVM(vm) {
    rehydrate(vm);
  } // just in case the component comes back, with this we guarantee re-rendering it
  // while preventing any attempt to rehydration until after reinsertion.


  function resetComponentStateWhenRemoved(vm) {
    var state = vm.state;

    if (state !== VMState.disconnected) {
      var oar = vm.oar,
          tro = vm.tro; // Making sure that any observing record will not trigger the rehydrated on this vm

      tro.reset(); // Making sure that any observing accessor record will not trigger the setter to be reinvoked

      for (var key in oar) {
        oar[key].reset();
      }

      runDisconnectedCallback(vm); // Spec: https://dom.spec.whatwg.org/#concept-node-remove (step 14-15)

      runShadowChildNodesDisconnectedCallback(vm);
      runLightChildNodesDisconnectedCallback(vm);
    }
  } // this method is triggered by the diffing algo only when a vnode from the
  // old vnode.children is removed from the DOM.


  function removeVM(vm) {
    {
      assert$1.isTrue(vm.state === VMState.connected || vm.state === VMState.disconnected, "".concat(vm, " must have been connected."));
    }

    resetComponentStateWhenRemoved(vm);
  }

  function createVM(elm, def, options) {
    {
      assert$1.invariant(_instanceof_1(elm, HTMLElement), "VM creation requires a DOM element instead of ".concat(elm, "."));
    }

    var vm = {
      elm: elm,
      def: def,
      idx: idx++,
      state: VMState.created,
      isScheduled: false,
      isDirty: true,
      tagName: options.tagName,
      mode: options.mode,
      owner: options.owner,
      children: EmptyArray,
      aChildren: EmptyArray,
      velements: EmptyArray,
      cmpProps: create$1(null),
      cmpFields: create$1(null),
      cmpSlots: create$1(null),
      oar: create$1(null),
      cmpTemplate: null,
      context: {
        hostAttribute: undefined,
        shadowAttribute: undefined,
        styleVNode: null,
        tplCache: EmptyObject,
        wiredConnecting: EmptyArray,
        wiredDisconnecting: EmptyArray
      },
      tro: null,
      component: null,
      cmpRoot: null,
      callHook: callHook,
      setHook: setHook,
      getHook: getHook
    };
    vm.tro = getTemplateReactiveObserver(vm);

    {
      vm.toString = function () {
        return "[object:vm ".concat(def.name, " (").concat(vm.idx, ")]");
      };
    } // Create component instance associated to the vm and the element.


    createComponent(vm, def.ctor); // Initializing the wire decorator per instance only when really needed

    if (hasWireAdapters(vm)) {
      installWireAdapters(vm);
    }

    return vm;
  }

  function assertIsVM(obj) {
    if (isNull$1(obj) || !isObject$1(obj) || !('cmpRoot' in obj)) {
      throw new TypeError("".concat(obj, " is not a VM."));
    }
  }

  function associateVM(obj, vm) {
    setHiddenField$6(obj, ViewModelReflection, vm);
  }

  function getAssociatedVM(obj) {
    var vm = getHiddenField$6(obj, ViewModelReflection);

    {
      assertIsVM(vm);
    }

    return vm;
  }

  function getAssociatedVMIfPresent(obj) {
    var maybeVm = getHiddenField$6(obj, ViewModelReflection);

    {
      if (!isUndefined$1(maybeVm)) {
        assertIsVM(maybeVm);
      }
    }

    return maybeVm;
  }

  function rehydrate(vm) {
    {
      assert$1.isTrue(_instanceof_1(vm.elm, HTMLElement), "rehydration can only happen after ".concat(vm, " was patched the first time."));
    }

    if (isTrue$1$1(vm.isDirty)) {
      var children = renderComponent(vm);
      patchShadowRoot(vm, children);
    }
  }

  function patchShadowRoot(vm, newCh) {
    var cmpRoot = vm.cmpRoot,
        oldCh = vm.children;
    vm.children = newCh; // caching the new children collection

    if (newCh.length > 0 || oldCh.length > 0) {
      // patch function mutates vnodes by adding the element reference,
      // however, if patching fails it contains partial changes.
      if (oldCh !== newCh) {
        var fn = hasDynamicChildren(newCh) ? updateDynamicChildren : updateStaticChildren;
        runWithBoundaryProtection(vm, vm, function () {
          // pre
          {
            startMeasure('patch', vm);
          }
        }, function () {
          // job
          fn(cmpRoot, oldCh, newCh);
        }, function () {
          // post
          {
            endMeasure('patch', vm);
          }
        });
      }
    }

    if (vm.state === VMState.connected) {
      // If the element is connected, that means connectedCallback was already issued, and
      // any successive rendering should finish with the call to renderedCallback, otherwise
      // the connectedCallback will take care of calling it in the right order at the end of
      // the current rehydration process.
      runRenderedCallback(vm);
    }
  }

  function runRenderedCallback(vm) {
    var rendered = Services.rendered;

    if (rendered) {
      invokeServiceHook(vm, rendered);
    }

    invokeComponentRenderedCallback(vm);
  }

  var rehydrateQueue = [];

  function flushRehydrationQueue() {
    startGlobalMeasure(GlobalMeasurementPhase.REHYDRATE);

    {
      assert$1.invariant(rehydrateQueue.length, "If rehydrateQueue was scheduled, it is because there must be at least one VM on this pending queue instead of ".concat(rehydrateQueue, "."));
    }

    var vms = rehydrateQueue.sort(function (a, b) {
      return a.idx - b.idx;
    });
    rehydrateQueue = []; // reset to a new queue

    for (var _i11 = 0, _len8 = vms.length; _i11 < _len8; _i11 += 1) {
      var vm = vms[_i11];

      try {
        rehydrate(vm);
      } catch (error) {
        if (_i11 + 1 < _len8) {
          // pieces of the queue are still pending to be rehydrated, those should have priority
          if (rehydrateQueue.length === 0) {
            addCallbackToNextTick(flushRehydrationQueue);
          }

          ArrayUnshift$1$1.apply(rehydrateQueue, ArraySlice$1$1.call(vms, _i11 + 1));
        } // we need to end the measure before throwing.


        endGlobalMeasure(GlobalMeasurementPhase.REHYDRATE); // re-throwing the original error will break the current tick, but since the next tick is
        // already scheduled, it should continue patching the rest.

        throw error; // eslint-disable-line no-unsafe-finally
      }
    }

    endGlobalMeasure(GlobalMeasurementPhase.REHYDRATE);
  }

  function runConnectedCallback(vm) {
    var state = vm.state;

    if (state === VMState.connected) {
      return; // nothing to do since it was already connected
    }

    vm.state = VMState.connected; // reporting connection

    var connected = Services.connected;

    if (connected) {
      invokeServiceHook(vm, connected);
    }

    if (hasWireAdapters(vm)) {
      connectWireAdapters(vm);
    }

    var connectedCallback = vm.def.connectedCallback;

    if (!isUndefined$1(connectedCallback)) {
      {
        startMeasure('connectedCallback', vm);
      }

      invokeComponentCallback(vm, connectedCallback);

      {
        endMeasure('connectedCallback', vm);
      }
    }
  }

  function hasWireAdapters(vm) {
    return getOwnPropertyNames(vm.def.wire).length > 0;
  }

  function runDisconnectedCallback(vm) {
    {
      assert$1.isTrue(vm.state !== VMState.disconnected, "".concat(vm, " must be inserted."));
    }

    if (isFalse$1$1(vm.isDirty)) {
      // this guarantees that if the component is reused/reinserted,
      // it will be re-rendered because we are disconnecting the reactivity
      // linking, so mutations are not automatically reflected on the state
      // of disconnected components.
      vm.isDirty = true;
    }

    vm.state = VMState.disconnected; // reporting disconnection

    var disconnected = Services.disconnected;

    if (disconnected) {
      invokeServiceHook(vm, disconnected);
    }

    if (hasWireAdapters(vm)) {
      disconnectWireAdapters(vm);
    }

    var disconnectedCallback = vm.def.disconnectedCallback;

    if (!isUndefined$1(disconnectedCallback)) {
      {
        startMeasure('disconnectedCallback', vm);
      }

      invokeComponentCallback(vm, disconnectedCallback);

      {
        endMeasure('disconnectedCallback', vm);
      }
    }
  }

  function runShadowChildNodesDisconnectedCallback(vm) {
    var vCustomElementCollection = vm.velements; // Reporting disconnection for every child in inverse order since they are
    // inserted in reserved order.

    for (var _i12 = vCustomElementCollection.length - 1; _i12 >= 0; _i12 -= 1) {
      var elm = vCustomElementCollection[_i12].elm; // There are two cases where the element could be undefined:
      // * when there is an error during the construction phase, and an error
      //   boundary picks it, there is a possibility that the VCustomElement
      //   is not properly initialized, and therefore is should be ignored.
      // * when slotted custom element is not used by the element where it is
      //   slotted into it, as  a result, the custom element was never
      //   initialized.

      if (!isUndefined$1(elm)) {
        var childVM = getAssociatedVMIfPresent(elm); // The VM associated with the element might be associated undefined
        // in the case where the VM failed in the middle of its creation,
        // eg: constructor throwing before invoking super().

        if (!isUndefined$1(childVM)) {
          resetComponentStateWhenRemoved(childVM);
        }
      }
    }
  }

  function runLightChildNodesDisconnectedCallback(vm) {
    var adoptedChildren = vm.aChildren;
    recursivelyDisconnectChildren(adoptedChildren);
  }
  /**
   * The recursion doesn't need to be a complete traversal of the vnode graph,
   * instead it can be partial, when a custom element vnode is found, we don't
   * need to continue into its children because by attempting to disconnect the
   * custom element itself will trigger the removal of anything slotted or anything
   * defined on its shadow.
   */


  function recursivelyDisconnectChildren(vnodes) {
    for (var _i13 = 0, _len9 = vnodes.length; _i13 < _len9; _i13 += 1) {
      var vnode = vnodes[_i13];

      if (!isNull$1(vnode) && isArray$1$1(vnode.children) && !isUndefined$1(vnode.elm)) {
        // vnode is a VElement with children
        if (isUndefined$1(vnode.ctor)) {
          // it is a VElement, just keep looking (recursively)
          recursivelyDisconnectChildren(vnode.children);
        } else {
          // it is a VCustomElement, disconnect it and ignore its children
          resetComponentStateWhenRemoved(getAssociatedVM(vnode.elm));
        }
      }
    }
  } // This is a super optimized mechanism to remove the content of the shadowRoot without having to go
  // into snabbdom. Especially useful when the reset is a consequence of an error, in which case the
  // children VNodes might not be representing the current state of the DOM


  function resetShadowRoot(vm) {
    var children = vm.children,
        cmpRoot = vm.cmpRoot;

    for (var _i14 = 0, _len10 = children.length; _i14 < _len10; _i14++) {
      var child = children[_i14];

      if (!isNull$1(child) && !isUndefined$1(child.elm)) {
        cmpRoot.removeChild(child.elm);
      }
    }

    vm.children = EmptyArray;
    runShadowChildNodesDisconnectedCallback(vm);
    vm.velements = EmptyArray;
  }

  function scheduleRehydration(vm) {
    if (!vm.isScheduled) {
      vm.isScheduled = true;

      if (rehydrateQueue.length === 0) {
        addCallbackToNextTick(flushRehydrationQueue);
      }

      ArrayPush$1.call(rehydrateQueue, vm);
    }
  }

  function getErrorBoundaryVM(vm) {
    var currentVm = vm;

    while (!isNull$1(currentVm)) {
      if (!isUndefined$1(currentVm.def.errorCallback)) {
        return currentVm;
      }

      currentVm = currentVm.owner;
    }
  } // slow path routine
  // NOTE: we should probably more this routine to the synthetic shadow folder
  // and get the allocation to be cached by in the elm instead of in the VM


  function allocateInSlot(vm, children) {
    {
      assert$1.invariant(isObject$1(vm.cmpSlots), "When doing manual allocation, there must be a cmpSlots object available.");
    }

    var oldSlots = vm.cmpSlots;
    var cmpSlots = vm.cmpSlots = create$1(null);

    for (var _i15 = 0, _len11 = children.length; _i15 < _len11; _i15 += 1) {
      var vnode = children[_i15];

      if (isNull$1(vnode)) {
        continue;
      }

      var data = vnode.data;
      var slotName = data.attrs && data.attrs.slot || '';
      var vnodes = cmpSlots[slotName] = cmpSlots[slotName] || []; // re-keying the vnodes is necessary to avoid conflicts with default content for the slot
      // which might have similar keys. Each vnode will always have a key that
      // starts with a numeric character from compiler. In this case, we add a unique
      // notation for slotted vnodes keys, e.g.: `@foo:1:1`

      vnode.key = "@".concat(slotName, ":").concat(vnode.key);
      ArrayPush$1.call(vnodes, vnode);
    }

    if (isFalse$1$1(vm.isDirty)) {
      // We need to determine if the old allocation is really different from the new one
      // and mark the vm as dirty
      var oldKeys = keys(oldSlots);

      if (oldKeys.length !== keys(cmpSlots).length) {
        markComponentAsDirty(vm);
        return;
      }

      for (var _i16 = 0, _len12 = oldKeys.length; _i16 < _len12; _i16 += 1) {
        var key = oldKeys[_i16];

        if (isUndefined$1(cmpSlots[key]) || oldSlots[key].length !== cmpSlots[key].length) {
          markComponentAsDirty(vm);
          return;
        }

        var oldVNodes = oldSlots[key];
        var _vnodes = cmpSlots[key];

        for (var j = 0, a = cmpSlots[key].length; j < a; j += 1) {
          if (oldVNodes[j] !== _vnodes[j]) {
            markComponentAsDirty(vm);
            return;
          }
        }
      }
    }
  }

  function runWithBoundaryProtection(vm, owner, pre, job, post) {
    var error;
    pre();

    try {
      job();
    } catch (e) {
      error = Object(e);
    } finally {
      post();

      if (!isUndefined$1(error)) {
        error.wcStack = error.wcStack || getErrorComponentStack(vm);
        var errorBoundaryVm = isNull$1(owner) ? undefined : getErrorBoundaryVM(owner);

        if (isUndefined$1(errorBoundaryVm)) {
          throw error; // eslint-disable-line no-unsafe-finally
        }

        resetShadowRoot(vm); // remove offenders

        {
          startMeasure('errorCallback', errorBoundaryVm);
        } // error boundaries must have an ErrorCallback


        var errorCallback = errorBoundaryVm.def.errorCallback;
        invokeComponentCallback(errorBoundaryVm, errorCallback, [error, error.wcStack]);

        {
          endMeasure('errorCallback', errorBoundaryVm);
        }
      }
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var DeprecatedWiredElementHost = '$$DeprecatedWiredElementHostKey$$';
  var DeprecatedWiredParamsMeta = '$$DeprecatedWiredParamsMetaKey$$';
  var WireMetaMap = new Map();

  function noop$3() {}

  function createFieldDataCallback(vm, name) {
    var cmpFields = vm.cmpFields;
    return function (value) {
      if (value !== vm.cmpFields[name]) {
        // storing the value in the underlying storage
        cmpFields[name] = value;
        componentValueMutated(vm, name);
      }
    };
  }

  function createMethodDataCallback(vm, method) {
    return function (value) {
      // dispatching new value into the wired method
      invokeComponentCallback(vm, method, [value]);
    };
  }

  function createConfigWatcher(vm, wireDef, callbackWhenConfigIsReady) {
    var component = vm.component;
    var configCallback = wireDef.configCallback;
    var hasPendingConfig = false; // creating the reactive observer for reactive params when needed

    var ro = new ReactiveObserver(function () {
      if (hasPendingConfig === false) {
        hasPendingConfig = true; // collect new config in the micro-task

        Promise.resolve().then(function () {
          hasPendingConfig = false; // resetting current reactive params

          ro.reset(); // dispatching a new config due to a change in the configuration

          callback();
        });
      }
    });

    var callback = function callback() {
      var config;
      ro.observe(function () {
        return config = configCallback(component);
      }); // eslint-disable-next-line lwc-internal/no-invalid-todo
      // TODO: dev-mode validation of config based on the adapter.configSchema
      // @ts-ignore it is assigned in the observe() callback

      callbackWhenConfigIsReady(config);
    };

    return callback;
  }

  function createContextWatcher(vm, wireDef, callbackWhenContextIsReady) {
    var adapter = wireDef.adapter;
    var adapterContextToken = getAdapterToken(adapter);

    if (isUndefined$1(adapterContextToken)) {
      return; // no provider found, nothing to be done
    }

    var elm = vm.elm,
        _vm$context = vm.context,
        wiredConnecting = _vm$context.wiredConnecting,
        wiredDisconnecting = _vm$context.wiredDisconnecting; // waiting for the component to be connected to formally request the context via the token

    ArrayPush$1.call(wiredConnecting, function () {
      // This event is responsible for connecting the host element with another
      // element in the composed path that is providing contextual data. The provider
      // must be listening for a special dom event with the name corresponding to the value of
      // `adapterContextToken`, which will remain secret and internal to this file only to
      // guarantee that the linkage can be forged.
      var internalDomEvent = new CustomEvent(adapterContextToken, {
        bubbles: true,
        composed: true,
        detail: function detail(newContext, disconnectCallback) {
          // adds this callback into the disconnect bucket so it gets disconnected from parent
          // the the element hosting the wire is disconnected
          ArrayPush$1.call(wiredDisconnecting, disconnectCallback); // eslint-disable-next-line lwc-internal/no-invalid-todo
          // TODO: dev-mode validation of config based on the adapter.contextSchema

          callbackWhenContextIsReady(newContext);
        }
      });
      dispatchEvent$1.call(elm, internalDomEvent);
    });
  }

  function createConnector(vm, name, wireDef) {
    var method = wireDef.method,
        adapter = wireDef.adapter,
        configCallback = wireDef.configCallback,
        dynamic = wireDef.dynamic;
    var hasDynamicParams = dynamic.length > 0;
    var component = vm.component;
    var dataCallback = isUndefined$1(method) ? createFieldDataCallback(vm, name) : createMethodDataCallback(vm, method);
    var context;
    var connector; // Workaround to pass the component element associated to this wire adapter instance.

    defineProperty$2(dataCallback, DeprecatedWiredElementHost, {
      value: vm.elm
    });
    defineProperty$2(dataCallback, DeprecatedWiredParamsMeta, {
      value: dynamic
    });
    runWithBoundaryProtection(vm, vm, noop$3, function () {
      // job
      connector = new adapter(dataCallback);
    }, noop$3);

    var updateConnectorConfig = function updateConnectorConfig(config) {
      // every time the config is recomputed due to tracking,
      // this callback will be invoked with the new computed config
      runWithBoundaryProtection(vm, vm, noop$3, function () {
        // job
        connector.update(config, context);
      }, noop$3);
    }; // Computes the current wire config and calls the update method on the wire adapter.
    // This initial implementation may change depending on the specific wire instance, if it has params, we will need
    // to observe changes in the next tick.


    var computeConfigAndUpdate = function computeConfigAndUpdate() {
      updateConnectorConfig(configCallback(component));
    };

    if (hasDynamicParams) {
      // This wire has dynamic parameters: we wait for the component instance is created and its values set
      // in order to call the update(config) method.
      Promise.resolve().then(function () {
        computeConfigAndUpdate = createConfigWatcher(vm, wireDef, updateConnectorConfig);
        computeConfigAndUpdate();
      });
    } else {
      computeConfigAndUpdate();
    } // if the adapter needs contextualization, we need to watch for new context and push it alongside the config


    if (!isUndefined$1(adapter.contextSchema)) {
      createContextWatcher(vm, wireDef, function (newContext) {
        // every time the context is pushed into this component,
        // this callback will be invoked with the new computed context
        if (context !== newContext) {
          context = newContext; // Note: when new context arrives, the config will be recomputed and pushed along side the new
          // context, this is to preserve the identity characteristics, config should not have identity
          // (ever), while context can have identity

          computeConfigAndUpdate();
        }
      });
    } // @ts-ignore the boundary protection executes sync, connector is always defined


    return connector;
  }

  var AdapterToTokenMap = new Map();

  function getAdapterToken(adapter) {
    return AdapterToTokenMap.get(adapter);
  }

  function storeWiredMethodMeta(descriptor, adapter, configCallback, dynamic) {
    // support for callable adapters
    if (adapter.adapter) {
      adapter = adapter.adapter;
    }

    var method = descriptor.value;
    var def = {
      adapter: adapter,
      method: method,
      configCallback: configCallback,
      dynamic: dynamic
    };
    WireMetaMap.set(descriptor, def);
  }

  function storeWiredFieldMeta(descriptor, adapter, configCallback, dynamic) {
    // support for callable adapters
    if (adapter.adapter) {
      adapter = adapter.adapter;
    }

    var def = {
      adapter: adapter,
      configCallback: configCallback,
      dynamic: dynamic
    };
    WireMetaMap.set(descriptor, def);
  }

  function installWireAdapters(vm) {
    var context = vm.context,
        wire = vm.def.wire;
    var wiredConnecting = context.wiredConnecting = [];
    var wiredDisconnecting = context.wiredDisconnecting = [];

    for (var fieldNameOrMethod in wire) {
      var descriptor = wire[fieldNameOrMethod];
      var wireDef = WireMetaMap.get(descriptor);

      {
        assert$1.invariant(wireDef, "Internal Error: invalid wire definition found.");
      }

      if (!isUndefined$1(wireDef)) {
        (function () {
          var adapterInstance = createConnector(vm, fieldNameOrMethod, wireDef);
          ArrayPush$1.call(wiredConnecting, function () {
            return adapterInstance.connect();
          });
          ArrayPush$1.call(wiredDisconnecting, function () {
            return adapterInstance.disconnect();
          });
        })();
      }
    }
  }

  function connectWireAdapters(vm) {
    var wiredConnecting = vm.context.wiredConnecting;

    for (var _i17 = 0, _len13 = wiredConnecting.length; _i17 < _len13; _i17 += 1) {
      wiredConnecting[_i17]();
    }
  }

  function disconnectWireAdapters(vm) {
    var wiredDisconnecting = vm.context.wiredDisconnecting;
    runWithBoundaryProtection(vm, vm, noop$3, function () {
      // job
      for (var _i18 = 0, _len14 = wiredDisconnecting.length; _i18 < _len14; _i18 += 1) {
        wiredDisconnecting[_i18]();
      }
    }, noop$3);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * This function builds a Web Component class from a LWC constructor so it can be
   * registered as a new element via customElements.define() at any given time.
   *
   * @deprecated since version 1.3.11
   *
   * @example
   * ```
   * import { buildCustomElementConstructor } from 'lwc';
   * import Foo from 'ns/foo';
   * const WC = buildCustomElementConstructor(Foo);
   * customElements.define('x-foo', WC);
   * const elm = document.createElement('x-foo');
   * ```
   */


  function deprecatedBuildCustomElementConstructor(Ctor) {
    {
      /* eslint-disable-next-line no-console */
      console.warn('Deprecated function called: "buildCustomElementConstructor" function is deprecated and it will be removed.' + "Use \"".concat(Ctor.name, ".CustomElementConstructor\" static property of the component constructor to access the corresponding custom element constructor instead."));
    }

    return Ctor.CustomElementConstructor;
  }

  function buildCustomElementConstructor(Ctor) {
    var _a;

    var def = getComponentInternalDef(Ctor); // generating the hash table for attributes to avoid duplicate fields and facilitate validation
    // and false positives in case of inheritance.

    var attributeToPropMap = create$1(null);

    for (var _propName3 in def.props) {
      attributeToPropMap[getAttrNameFromPropName(_propName3)] = _propName3;
    }

    return _a =
    /*#__PURE__*/
    function (_def$bridge) {
      inherits(_a, _def$bridge);

      function _a() {
        var _this3;

        classCallCheck(this, _a);

        _this3 = possibleConstructorReturn(this, getPrototypeOf$1(_a).call(this));
        createVM(assertThisInitialized(assertThisInitialized(_this3)), def, {
          mode: 'open',
          owner: null,
          tagName: _this3.tagName
        });
        return _this3;
      }

      createClass(_a, [{
        key: "connectedCallback",
        value: function connectedCallback() {
          connectRootElement(this);
        }
      }, {
        key: "disconnectedCallback",
        value: function disconnectedCallback() {
          disconnectRootElement(this);
        }
      }, {
        key: "attributeChangedCallback",
        value: function attributeChangedCallback(attrName, oldValue, newValue) {
          if (oldValue === newValue) {
            // Ignore same values.
            return;
          }

          var propName = attributeToPropMap[attrName];

          if (isUndefined$1(propName)) {
            // Ignore unknown attributes.
            return;
          }

          if (!isAttributeLocked(this, attrName)) {
            // Ignore changes triggered by the engine itself during:
            // * diffing when public props are attempting to reflect to the DOM
            // * component via `this.setAttribute()`, should never update the prop
            // Both cases, the setAttribute call is always wrapped by the unlocking of the
            // attribute to be changed
            return;
          } // Reflect attribute change to the corresponding property when changed from outside.


          this[propName] = newValue;
        }
      }]);

      return _a;
    }(def.bridge), // Specify attributes for which we want to reflect changes back to their corresponding
    // properties via attributeChangedCallback.
    _a.observedAttributes = keys(attributeToPropMap), _a;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var ConnectingSlot = createHiddenField('connecting', 'engine');
  var DisconnectingSlot = createHiddenField('disconnecting', 'engine');

  function callNodeSlot(node, slot) {
    {
      assert$1.isTrue(node, "callNodeSlot() should not be called for a non-object");
    }

    var fn = getHiddenField$6(node, slot);

    if (!isUndefined$1(fn)) {
      fn(node);
    }

    return node; // for convenience
  } // Monkey patching Node methods to be able to detect the insertions and removal of root elements
  // created via createElement.


  var _Node$prototype$1 = Node.prototype,
      _appendChild = _Node$prototype$1.appendChild,
      _insertBefore = _Node$prototype$1.insertBefore,
      _removeChild = _Node$prototype$1.removeChild,
      _replaceChild = _Node$prototype$1.replaceChild;
  assign$1(Node.prototype, {
    appendChild: function appendChild(newChild) {
      var appendedNode = _appendChild.call(this, newChild);

      return callNodeSlot(appendedNode, ConnectingSlot);
    },
    insertBefore: function insertBefore(newChild, referenceNode) {
      var insertedNode = _insertBefore.call(this, newChild, referenceNode);

      return callNodeSlot(insertedNode, ConnectingSlot);
    },
    removeChild: function removeChild(oldChild) {
      var removedNode = _removeChild.call(this, oldChild);

      return callNodeSlot(removedNode, DisconnectingSlot);
    },
    replaceChild: function replaceChild(newChild, oldChild) {
      var replacedNode = _replaceChild.call(this, newChild, oldChild);

      callNodeSlot(replacedNode, DisconnectingSlot);
      callNodeSlot(newChild, ConnectingSlot);
      return replacedNode;
    }
  });
  /**
   * EXPERIMENTAL: This function is almost identical to document.createElement with the slightly
   * difference that in the options, you can pass the `is` property set to a Constructor instead of
   * just a string value. The intent is to allow the creation of an element controlled by LWC without
   * having to register the element as a custom element.
   *
   * @example
   * ```
   * const el = createElement('x-foo', { is: FooCtor });
   * ```
   */

  function createElement$1(sel, options) {
    if (!isObject$1(options) || isNull$1(options)) {
      throw new TypeError("\"createElement\" function expects an object as second parameter but received \"".concat(toString$1(options), "\"."));
    }

    var Ctor = options.is;

    if (!isFunction$1(Ctor)) {
      throw new TypeError("\"createElement\" function expects an \"is\" option with a valid component constructor.");
    }

    var element = document.createElement(sel); // There is a possibility that a custom element is registered under tagName, in which case, the
    // initialization is already carry on, and there is nothing else to do here.

    if (!isUndefined$1(getAssociatedVMIfPresent(element))) {
      return element;
    }

    var def = getComponentInternalDef(Ctor);
    setElementProto(element, def);
    createVM(element, def, {
      tagName: sel,
      mode: options.mode !== 'closed' ? 'open' : 'closed',
      owner: null
    });
    setHiddenField$6(element, ConnectingSlot, connectRootElement);
    setHiddenField$6(element, DisconnectingSlot, disconnectRootElement);
    return element;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var ComponentConstructorToCustomElementConstructorMap = new Map();

  function getCustomElementConstructor(Ctor) {
    if (Ctor === BaseLightningElement) {
      throw new TypeError("Invalid Constructor. LightningElement base class can't be claimed as a custom element.");
    }

    var ce = ComponentConstructorToCustomElementConstructorMap.get(Ctor);

    if (isUndefined$1(ce)) {
      ce = buildCustomElementConstructor(Ctor);
      ComponentConstructorToCustomElementConstructorMap.set(Ctor, ce);
    }

    return ce;
  }
  /**
   * This static getter builds a Web Component class from a LWC constructor so it can be registered
   * as a new element via customElements.define() at any given time. E.g.:
   *
   *      import Foo from 'ns/foo';
   *      customElements.define('x-foo', Foo.CustomElementConstructor);
   *      const elm = document.createElement('x-foo');
   *
   */


  defineProperty$2(BaseLightningElement, 'CustomElementConstructor', {
    get: function get() {
      return getCustomElementConstructor(this);
    }
  });
  freeze(BaseLightningElement);
  seal(BaseLightningElement.prototype);

  var __callKey1$1 = Proxy.callKey1;

  var __callKey0 = Proxy.callKey0;

  var _tmpl = void 0;

  var __iterableKey = Proxy.iterableKey;

  var __hasOwnProperty = Proxy.hasOwnProperty;

  var __callKey4 = Proxy.callKey4;

  var __setKeyPostfixIncrement = Proxy.setKeyPostfixIncrement;

  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */

  /* global Reflect, Promise */
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || _instanceof_1({
      __proto__: []
    }, Array) && function (d, b) {
      __setKey(d, "__proto__", b);
    } || function (d, b) {
      for (var p in __iterableKey(b)) {
        if (__hasOwnProperty(b, p)) __setKey(d, p, b._ES5ProxyType ? b.get(p) : b[p]);
      }
    };

    return _extendStatics(d, b);
  };

  function __extends(d, b) {
    _extendStatics(d, b);

    function __() {
      __setKey(this, "constructor", d);
    }

    __setKey(d, "prototype", b === null ? Object.create(b) : (__setKey(__, "prototype", b._ES5ProxyType ? b.get("prototype") : b.prototype), new __()));
  }

  var _assign = function __assign() {
    _assign = Object.compatAssign || function __assign(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];

        for (var p in __iterableKey(s)) {
          if (__callKey2(Object.prototype._ES5ProxyType ? Object.prototype.get("hasOwnProperty") : Object.prototype.hasOwnProperty, "call", s, p)) __setKey(t, p, s._ES5ProxyType ? s.get(p) : s[p]);
        }
      }

      return t;
    };

    return __callKey2(_assign, "apply", this, arguments);
  };
  function __rest(s, e) {
    var t = {};

    for (var p in __iterableKey(s)) {
      if (__callKey2(Object.prototype._ES5ProxyType ? Object.prototype.get("compatHasOwnProperty") : Object.prototype.compatHasOwnProperty, "call", s, p) && __callKey1$1(e, "indexOf", p) < 0) __setKey(t, p, s._ES5ProxyType ? s.get(p) : s[p]);
    }

    if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < (p._ES5ProxyType ? p.get("length") : p.length); i++) {
      var _p$i, _p$i2;

      if (__callKey1$1(e, "indexOf", p._ES5ProxyType ? p.get(i) : p[i]) < 0 && __callKey2(Object.prototype._ES5ProxyType ? Object.prototype.get("propertyIsEnumerable") : Object.prototype.propertyIsEnumerable, "call", s, p._ES5ProxyType ? p.get(i) : p[i])) __setKey(t, p._ES5ProxyType ? p.get(i) : p[i], (_p$i = p._ES5ProxyType ? p.get(i) : p[i], _p$i2 = s._ES5ProxyType ? s.get(_p$i) : s[_p$i]));
    }
    return t;
  }
  function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return _instanceof_1(value, P) ? value : new P(function (resolve) {
        resolve(value);
      });
    }

    return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) {
        try {
          step(__callKey1$1(generator, "next", value));
        } catch (e) {
          reject(e);
        }
      }

      function rejected(value) {
        try {
          step(__callKey1$1(generator, "throw", value));
        } catch (e) {
          reject(e);
        }
      }

      function step(result) {
        (result._ES5ProxyType ? result.get("done") : result.done) ? resolve(result._ES5ProxyType ? result.get("value") : result.value) : __callKey2(adopt(result._ES5ProxyType ? result.get("value") : result.value), "then", fulfilled, rejected);
      }

      step(__callKey0(generator = __callKey2(generator, "apply", thisArg, _arguments || []), "next"));
    });
  }
  function __generator(thisArg, body) {
    var _ = {
      label: 0,
      sent: function sent() {
        if ((t._ES5ProxyType ? t.get(0) : t[0]) & 1) throw t._ES5ProxyType ? t.get(1) : t[1];
        return t._ES5ProxyType ? t.get(1) : t[1];
      },
      trys: [],
      ops: []
    },
        f,
        y,
        t,
        g;
    return g = {
      next: verb(0),
      "throw": verb(1),
      "return": verb(2)
    }, typeof Symbol === "function" && __setKey(g, Symbol.iterator, function () {
      return this;
    }), g;

    function verb(n) {
      return function (v) {
        return step([n, v]);
      };
    }

    function step(op) {
      var _ref, _ref2;

      if (f) throw new TypeError("Generator is already executing.");

      while (_) {
        try {
          var _t, _done;

          if (f = 1, y && (t = (op._ES5ProxyType ? op.get(0) : op[0]) & 2 ? y._ES5ProxyType ? y.get("return") : y["return"] : (op._ES5ProxyType ? op.get(0) : op[0]) ? (y._ES5ProxyType ? y.get("throw") : y["throw"]) || ((t = y._ES5ProxyType ? y.get("return") : y["return"]) && __callKey1$1(t, "call", y), 0) : y._ES5ProxyType ? y.get("next") : y.next) && !(_t = t = __callKey2(t, "call", y, op._ES5ProxyType ? op.get(1) : op[1]), _done = _t._ES5ProxyType ? _t.get("done") : _t.done)) return t;
          if (y = 0, t) op = [(op._ES5ProxyType ? op.get(0) : op[0]) & 2, t._ES5ProxyType ? t.get("value") : t.value];

          switch (op._ES5ProxyType ? op.get(0) : op[0]) {
            case 0:
            case 1:
              t = op;
              break;

            case 4:
              __setKeyPostfixIncrement(_, "label");

              return {
                value: op._ES5ProxyType ? op.get(1) : op[1],
                done: false
              };

            case 5:
              __setKeyPostfixIncrement(_, "label");

              y = op._ES5ProxyType ? op.get(1) : op[1];
              op = [0];
              continue;

            case 7:
              op = (_._ES5ProxyType ? _.get("ops") : _.ops).pop();
              (_._ES5ProxyType ? _.get("trys") : _.trys).pop();
              continue;

            default:
              if (!(t = _._ES5ProxyType ? _.get("trys") : _.trys, t = (t._ES5ProxyType ? t.get("length") : t.length) > 0 && (_ref = (t._ES5ProxyType ? t.get("length") : t.length) - 1, _ref2 = t._ES5ProxyType ? t.get(_ref) : t[_ref])) && ((op._ES5ProxyType ? op.get(0) : op[0]) === 6 || (op._ES5ProxyType ? op.get(0) : op[0]) === 2)) {
                _ = 0;
                continue;
              }

              if ((op._ES5ProxyType ? op.get(0) : op[0]) === 3 && (!t || (op._ES5ProxyType ? op.get(1) : op[1]) > (t._ES5ProxyType ? t.get(0) : t[0]) && (op._ES5ProxyType ? op.get(1) : op[1]) < (t._ES5ProxyType ? t.get(3) : t[3]))) {
                __setKey(_, "label", op._ES5ProxyType ? op.get(1) : op[1]);

                break;
              }

              if ((op._ES5ProxyType ? op.get(0) : op[0]) === 6 && (_._ES5ProxyType ? _.get("label") : _.label) < (t._ES5ProxyType ? t.get(1) : t[1])) {
                __setKey(_, "label", t._ES5ProxyType ? t.get(1) : t[1]);

                t = op;
                break;
              }

              if (t && (_._ES5ProxyType ? _.get("label") : _.label) < (t._ES5ProxyType ? t.get(2) : t[2])) {
                __setKey(_, "label", t._ES5ProxyType ? t.get(2) : t[2]);

                (_._ES5ProxyType ? _.get("ops") : _.ops).push(op);
                break;
              }

              if (t._ES5ProxyType ? t.get(2) : t[2]) (_._ES5ProxyType ? _.get("ops") : _.ops).pop();
              (_._ES5ProxyType ? _.get("trys") : _.trys).pop();
              continue;
          }

          op = __callKey2(body, "call", thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
      }

      if ((op._ES5ProxyType ? op.get(0) : op[0]) & 5) throw op._ES5ProxyType ? op.get(1) : op[1];
      return {
        value: (op._ES5ProxyType ? op.get(0) : op[0]) ? op._ES5ProxyType ? op.get(1) : op[1] : void 0,
        done: true
      };
    }
  }
  function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
      s += arguments[i]._ES5ProxyType ? arguments[i].get("length") : arguments[i].length;
    }

    for (var r = Array(s), k = 0, i = 0; i < il; i++) {
      for (var a = arguments[i], j = 0, jl = a._ES5ProxyType ? a.get("length") : a.length; j < jl; j++, k++) {
        __setKey(r, k, a._ES5ProxyType ? a.get(j) : a[j]);
      }
    }

    return r;
  }

  var __deleteKey = Proxy.deleteKey;

  var __callKey3 = Proxy.callKey3;

  var __callKey = Proxy.callKey;

  // istanbul ignore next (See: 'https://github.com/graphql/graphql-js/issues/2317')
  var nodejsCustomInspectSymbol = typeof Symbol === 'function' && typeof Symbol.for === 'function' ? Symbol.for('nodejs.util.inspect.custom') : undefined;

  function _typeof(obj) {
    "@babel/helpers - typeof";

    if (typeof Symbol === "function" && _typeof_1(Symbol.iterator) === "symbol") {
      _typeof = function _typeof(obj) {
        return _typeof_1(obj);
      };
    } else {
      _typeof = function _typeof(obj) {
        return obj && typeof Symbol === "function" && (obj._ES5ProxyType ? obj.get("constructor") : obj.constructor) === Symbol && obj !== Symbol.prototype ? "symbol" : _typeof_1(obj);
      };
    }

    return _typeof(obj);
  }
  var MAX_ARRAY_LENGTH = 10;
  var MAX_RECURSIVE_DEPTH = 2;
  /**
   * Used to print values in error messages.
   */

  function inspect(value) {
    return formatValue(value, []);
  }

  function formatValue(value, seenValues) {
    switch (_typeof(value)) {
      case 'string':
        return JSON.stringify(value);

      case 'function':
        return (value._ES5ProxyType ? value.get("name") : value.name) ? __concat("[function ", value._ES5ProxyType ? value.get("name") : value.name, "]") : '[function]';

      case 'object':
        if (value === null) {
          return 'null';
        }

        return formatObjectValue(value, seenValues);

      default:
        return String(value);
    }
  }

  function formatObjectValue(value, previouslySeenValues) {
    if (__callKey1$1(previouslySeenValues, "indexOf", value) !== -1) {
      return '[Circular]';
    }

    var seenValues = __concat([], previouslySeenValues, [value]);

    var customInspectFn = getCustomFn(value);

    if (customInspectFn !== undefined) {
      // $FlowFixMe(>=0.90.0)
      var customValue = __callKey1$1(customInspectFn, "call", value); // check for infinite recursion


      if (customValue !== value) {
        return typeof customValue === 'string' ? customValue : formatValue(customValue, seenValues);
      }
    } else if (Array.compatIsArray(value)) {
      return formatArray(value, seenValues);
    }

    return formatObject(value, seenValues);
  }

  function formatObject(object, seenValues) {
    var keys = Object.compatKeys(object);

    if ((keys._ES5ProxyType ? keys.get("length") : keys.length) === 0) {
      return '{}';
    }

    if ((seenValues._ES5ProxyType ? seenValues.get("length") : seenValues.length) > MAX_RECURSIVE_DEPTH) {
      return '[' + getObjectTag(object) + ']';
    }

    var properties = __callKey1$1(keys, "map", function (key) {
      var value = formatValue(object._ES5ProxyType ? object.get(key) : object[key], seenValues);
      return key + ': ' + value;
    });

    return '{ ' + __callKey1$1(properties, "join", ', ') + ' }';
  }

  function formatArray(array, seenValues) {
    if ((array._ES5ProxyType ? array.get("length") : array.length) === 0) {
      return '[]';
    }

    if ((seenValues._ES5ProxyType ? seenValues.get("length") : seenValues.length) > MAX_RECURSIVE_DEPTH) {
      return '[Array]';
    }

    var len = Math.min(MAX_ARRAY_LENGTH, array._ES5ProxyType ? array.get("length") : array.length);
    var remaining = (array._ES5ProxyType ? array.get("length") : array.length) - len;
    var items = [];

    for (var i = 0; i < len; ++i) {
      items.push(formatValue(array._ES5ProxyType ? array.get(i) : array[i], seenValues));
    }

    if (remaining === 1) {
      items.push('... 1 more item');
    } else if (remaining > 1) {
      items.push(__concat("... ", remaining, " more items"));
    }

    return '[' + __callKey1$1(items, "join", ', ') + ']';
  }

  function getCustomFn(object) {
    var _String, _String2;

    var customInspectFn = (_String = String(nodejsCustomInspectSymbol), _String2 = object._ES5ProxyType ? object.get(_String) : object[_String]);

    if (typeof customInspectFn === 'function') {
      return customInspectFn;
    }

    if (typeof (object._ES5ProxyType ? object.get("inspect") : object.inspect) === 'function') {
      return object._ES5ProxyType ? object.get("inspect") : object.inspect;
    }
  }

  function getObjectTag(object) {
    var tag = __callKey2(__callKey2(__callKey1$1(Object.prototype._ES5ProxyType ? Object.prototype.get("toString") : Object.prototype.toString, "call", object), "replace", /^\[object /, ''), "replace", /]$/, '');

    if (tag === 'Object' && typeof (object._ES5ProxyType ? object.get("constructor") : object.constructor) === 'function') {
      var _constructor, _name;

      var name = (_constructor = object._ES5ProxyType ? object.get("constructor") : object.constructor, _name = _constructor._ES5ProxyType ? _constructor.get("name") : _constructor.name);

      if (typeof name === 'string' && name !== '') {
        return name;
      }
    }

    return tag;
  }

  function invariant$2(condition, message) {
    var booleanCondition = Boolean(condition); // istanbul ignore else (See transformation done in './resources/inlineInvariant.js')

    if (!booleanCondition) {
      throw new Error(message != null ? message : 'Unexpected invariant triggered.');
    }
  }

  /**
   * The `defineInspect()` function defines `inspect()` prototype method as alias of `toJSON`
   */

  function defineInspect(classObject) {
    var _prototype, _toJSON;

    var fn = (_prototype = classObject._ES5ProxyType ? classObject.get("prototype") : classObject.prototype, _toJSON = _prototype._ES5ProxyType ? _prototype.get("toJSON") : _prototype.toJSON);
    typeof fn === 'function' || invariant$2(0);

    __setKey(classObject._ES5ProxyType ? classObject.get("prototype") : classObject.prototype, "inspect", fn); // istanbul ignore else (See: 'https://github.com/graphql/graphql-js/issues/2317')


    if (nodejsCustomInspectSymbol) {
      __setKey(classObject._ES5ProxyType ? classObject.get("prototype") : classObject.prototype, nodejsCustomInspectSymbol, fn);
    }
  }

  /**
   * Contains a range of UTF-8 character offsets and token references that
   * identify the region of the source from which the AST derived.
   */

  var Location =
  /*#__PURE__*/
  function () {
    /**
     * The character offset at which this Node begins.
     */

    /**
     * The character offset at which this Node ends.
     */

    /**
     * The Token at which this Node begins.
     */

    /**
     * The Token at which this Node ends.
     */

    /**
     * The Source document the AST represents.
     */
    function Location(startToken, endToken, source) {
      __setKey(this, "start", startToken._ES5ProxyType ? startToken.get("start") : startToken.start);

      __setKey(this, "end", endToken._ES5ProxyType ? endToken.get("end") : endToken.end);

      __setKey(this, "startToken", startToken);

      __setKey(this, "endToken", endToken);

      __setKey(this, "source", source);
    }

    var _proto = Location._ES5ProxyType ? Location.get("prototype") : Location.prototype;

    __setKey(_proto, "toJSON", function toJSON() {
      return {
        start: this._ES5ProxyType ? this.get("start") : this.start,
        end: this._ES5ProxyType ? this.get("end") : this.end
      };
    });

    return Location;
  }(); // Print a simplified form when appearing in `inspect` and `util.inspect`.

  defineInspect(Location);
  /**
   * Represents a range of characters represented by a lexical token
   * within a Source.
   */

  var Token =
  /*#__PURE__*/
  function () {
    /**
     * The kind of Token.
     */

    /**
     * The character offset at which this Node begins.
     */

    /**
     * The character offset at which this Node ends.
     */

    /**
     * The 1-indexed line number on which this Token appears.
     */

    /**
     * The 1-indexed column number at which this Token begins.
     */

    /**
     * For non-punctuation tokens, represents the interpreted value of the token.
     */

    /**
     * Tokens exist as nodes in a double-linked-list amongst all tokens
     * including ignored tokens. <SOF> is always the first node and <EOF>
     * the last.
     */
    function Token(kind, start, end, line, column, prev, value) {
      __setKey(this, "kind", kind);

      __setKey(this, "start", start);

      __setKey(this, "end", end);

      __setKey(this, "line", line);

      __setKey(this, "column", column);

      __setKey(this, "value", value);

      __setKey(this, "prev", prev);

      __setKey(this, "next", null);
    }

    var _proto2 = Token._ES5ProxyType ? Token.get("prototype") : Token.prototype;

    __setKey(_proto2, "toJSON", function toJSON() {
      return {
        kind: this._ES5ProxyType ? this.get("kind") : this.kind,
        value: this._ES5ProxyType ? this.get("value") : this.value,
        line: this._ES5ProxyType ? this.get("line") : this.line,
        column: this._ES5ProxyType ? this.get("column") : this.column
      };
    });

    return Token;
  }(); // Print a simplified form when appearing in `inspect` and `util.inspect`.

  defineInspect(Token);
  /**
   * @internal
   */

  function isNode(maybeNode) {
    return maybeNode != null && typeof (maybeNode._ES5ProxyType ? maybeNode.get("kind") : maybeNode.kind) === 'string';
  }
  /**
   * The list of all possible AST node types.
   */

  /**
   * A visitor is provided to visit, it contains the collection of
   * relevant functions to be called during the visitor's traversal.
   */

  var QueryDocumentKeys = {
    Name: [],
    Document: ['definitions'],
    OperationDefinition: ['name', 'variableDefinitions', 'directives', 'selectionSet'],
    VariableDefinition: ['variable', 'type', 'defaultValue', 'directives'],
    Variable: ['name'],
    SelectionSet: ['selections'],
    Field: ['alias', 'name', 'arguments', 'directives', 'selectionSet'],
    Argument: ['name', 'value'],
    FragmentSpread: ['name', 'directives'],
    InlineFragment: ['typeCondition', 'directives', 'selectionSet'],
    FragmentDefinition: ['name', // Note: fragment variable definitions are experimental and may be changed
    // or removed in the future.
    'variableDefinitions', 'typeCondition', 'directives', 'selectionSet'],
    IntValue: [],
    FloatValue: [],
    StringValue: [],
    BooleanValue: [],
    NullValue: [],
    EnumValue: [],
    ListValue: ['values'],
    ObjectValue: ['fields'],
    ObjectField: ['name', 'value'],
    Directive: ['name', 'arguments'],
    NamedType: ['name'],
    ListType: ['type'],
    NonNullType: ['type'],
    SchemaDefinition: ['description', 'directives', 'operationTypes'],
    OperationTypeDefinition: ['type'],
    ScalarTypeDefinition: ['description', 'name', 'directives'],
    ObjectTypeDefinition: ['description', 'name', 'interfaces', 'directives', 'fields'],
    FieldDefinition: ['description', 'name', 'arguments', 'type', 'directives'],
    InputValueDefinition: ['description', 'name', 'type', 'defaultValue', 'directives'],
    InterfaceTypeDefinition: ['description', 'name', 'interfaces', 'directives', 'fields'],
    UnionTypeDefinition: ['description', 'name', 'directives', 'types'],
    EnumTypeDefinition: ['description', 'name', 'directives', 'values'],
    EnumValueDefinition: ['description', 'name', 'directives'],
    InputObjectTypeDefinition: ['description', 'name', 'directives', 'fields'],
    DirectiveDefinition: ['description', 'name', 'arguments', 'locations'],
    SchemaExtension: ['directives', 'operationTypes'],
    ScalarTypeExtension: ['name', 'directives'],
    ObjectTypeExtension: ['name', 'interfaces', 'directives', 'fields'],
    InterfaceTypeExtension: ['name', 'interfaces', 'directives', 'fields'],
    UnionTypeExtension: ['name', 'directives', 'types'],
    EnumTypeExtension: ['name', 'directives', 'values'],
    InputObjectTypeExtension: ['name', 'directives', 'fields']
  };
  var BREAK = Object.freeze({});
  /**
   * visit() will walk through an AST using a depth first traversal, calling
   * the visitor's enter function at each node in the traversal, and calling the
   * leave function after visiting that node and all of its child nodes.
   *
   * By returning different values from the enter and leave functions, the
   * behavior of the visitor can be altered, including skipping over a sub-tree of
   * the AST (by returning false), editing the AST by returning a value or null
   * to remove the value, or to stop the whole traversal by returning BREAK.
   *
   * When using visit() to edit an AST, the original AST will not be modified, and
   * a new version of the AST with the changes applied will be returned from the
   * visit function.
   *
   *     const editedAST = visit(ast, {
   *       enter(node, key, parent, path, ancestors) {
   *         // @return
   *         //   undefined: no action
   *         //   false: skip visiting this node
   *         //   visitor.BREAK: stop visiting altogether
   *         //   null: delete this node
   *         //   any value: replace this node with the returned value
   *       },
   *       leave(node, key, parent, path, ancestors) {
   *         // @return
   *         //   undefined: no action
   *         //   false: no action
   *         //   visitor.BREAK: stop visiting altogether
   *         //   null: delete this node
   *         //   any value: replace this node with the returned value
   *       }
   *     });
   *
   * Alternatively to providing enter() and leave() functions, a visitor can
   * instead provide functions named the same as the kinds of AST nodes, or
   * enter/leave visitors at a named key, leading to four permutations of
   * visitor API:
   *
   * 1) Named visitors triggered when entering a node a specific kind.
   *
   *     visit(ast, {
   *       Kind(node) {
   *         // enter the "Kind" node
   *       }
   *     })
   *
   * 2) Named visitors that trigger upon entering and leaving a node of
   *    a specific kind.
   *
   *     visit(ast, {
   *       Kind: {
   *         enter(node) {
   *           // enter the "Kind" node
   *         }
   *         leave(node) {
   *           // leave the "Kind" node
   *         }
   *       }
   *     })
   *
   * 3) Generic visitors that trigger upon entering and leaving any node.
   *
   *     visit(ast, {
   *       enter(node) {
   *         // enter any node
   *       },
   *       leave(node) {
   *         // leave any node
   *       }
   *     })
   *
   * 4) Parallel visitors for entering and leaving nodes of a specific kind.
   *
   *     visit(ast, {
   *       enter: {
   *         Kind(node) {
   *           // enter the "Kind" node
   *         }
   *       },
   *       leave: {
   *         Kind(node) {
   *           // leave the "Kind" node
   *         }
   *       }
   *     })
   */

  function visit(root, visitor) {
    var visitorKeys = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : QueryDocumentKeys;
    /* eslint-disable no-undef-init */

    var stack = undefined;
    var inArray = Array.compatIsArray(root);
    var keys = [root];
    var index = -1;
    var edits = [];
    var node = undefined;
    var key = undefined;
    var parent = undefined;
    var path = [];
    var ancestors = [];
    var newRoot = root;
    /* eslint-enable no-undef-init */

    do {
      index++;
      var isLeaving = index === (keys._ES5ProxyType ? keys.get("length") : keys.length);
      var isEdited = isLeaving && (edits._ES5ProxyType ? edits.get("length") : edits.length) !== 0;

      if (isLeaving) {
        var _ref, _ref2;

        key = (ancestors._ES5ProxyType ? ancestors.get("length") : ancestors.length) === 0 ? undefined : (_ref = (path._ES5ProxyType ? path.get("length") : path.length) - 1, _ref2 = path._ES5ProxyType ? path.get(_ref) : path[_ref]);
        node = parent;
        parent = ancestors.pop();

        if (isEdited) {
          if (inArray) {
            node = __callKey0(node, "slice");
          } else {
            var clone = {};

            for (var _i2 = 0, _Object$keys2 = Object.compatKeys(node); _i2 < (_Object$keys2._ES5ProxyType ? _Object$keys2.get("length") : _Object$keys2.length); _i2++) {
              var k = _Object$keys2._ES5ProxyType ? _Object$keys2.get(_i2) : _Object$keys2[_i2];

              __setKey(clone, k, node._ES5ProxyType ? node.get(k) : node[k]);
            }

            node = clone;
          }

          var editOffset = 0;

          for (var ii = 0; ii < (edits._ES5ProxyType ? edits.get("length") : edits.length); ii++) {
            var _ii, _, _ii2, _2;

            var editKey = (_ii = edits._ES5ProxyType ? edits.get(ii) : edits[ii], _ = _ii._ES5ProxyType ? _ii.get(0) : _ii[0]);
            var editValue = (_ii2 = edits._ES5ProxyType ? edits.get(ii) : edits[ii], _2 = _ii2._ES5ProxyType ? _ii2.get(1) : _ii2[1]);

            if (inArray) {
              editKey -= editOffset;
            }

            if (inArray && editValue === null) {
              node.splice(editKey, 1);
              editOffset++;
            } else {
              __setKey(node, editKey, editValue);
            }
          }
        }

        index = stack._ES5ProxyType ? stack.get("index") : stack.index;
        keys = stack._ES5ProxyType ? stack.get("keys") : stack.keys;
        edits = stack._ES5ProxyType ? stack.get("edits") : stack.edits;
        inArray = stack._ES5ProxyType ? stack.get("inArray") : stack.inArray;
        stack = stack._ES5ProxyType ? stack.get("prev") : stack.prev;
      } else {
        key = parent ? inArray ? index : keys._ES5ProxyType ? keys.get(index) : keys[index] : undefined;
        node = parent ? parent._ES5ProxyType ? parent.get(key) : parent[key] : newRoot;

        if (node === null || node === undefined) {
          continue;
        }

        if (parent) {
          path.push(key);
        }
      }

      var result = void 0;

      if (!Array.compatIsArray(node)) {
        if (!isNode(node)) {
          throw new Error(__concat("Invalid AST Node: ", inspect(node), "."));
        }

        var visitFn = getVisitFn(visitor, node._ES5ProxyType ? node.get("kind") : node.kind, isLeaving);

        if (visitFn) {
          result = __callKey(visitFn, "call", visitor, node, key, parent, path, ancestors);

          if (result === BREAK) {
            break;
          }

          if (result === false) {
            if (!isLeaving) {
              path.pop();
              continue;
            }
          } else if (result !== undefined) {
            edits.push([key, result]);

            if (!isLeaving) {
              if (isNode(result)) {
                node = result;
              } else {
                path.pop();
                continue;
              }
            }
          }
        }
      }

      if (result === undefined && isEdited) {
        edits.push([key, node]);
      }

      if (isLeaving) {
        path.pop();
      } else {
        var _node$kind, _node$kind2;

        var _visitorKeys$node$kin;

        stack = {
          inArray: inArray,
          index: index,
          keys: keys,
          edits: edits,
          prev: stack
        };
        inArray = Array.compatIsArray(node);
        keys = inArray ? node : (_visitorKeys$node$kin = (_node$kind = node._ES5ProxyType ? node.get("kind") : node.kind, _node$kind2 = visitorKeys._ES5ProxyType ? visitorKeys.get(_node$kind) : visitorKeys[_node$kind])) !== null && _visitorKeys$node$kin !== void 0 ? _visitorKeys$node$kin : [];
        index = -1;
        edits = [];

        if (parent) {
          ancestors.push(parent);
        }

        parent = node;
      }
    } while (stack !== undefined);

    if ((edits._ES5ProxyType ? edits.get("length") : edits.length) !== 0) {
      var _ref3, _ref4, _3;

      newRoot = (_ref3 = (edits._ES5ProxyType ? edits.get("length") : edits.length) - 1, _ref4 = edits._ES5ProxyType ? edits.get(_ref3) : edits[_ref3], _3 = _ref4._ES5ProxyType ? _ref4.get(1) : _ref4[1]);
    }

    return newRoot;
  }
  /**
   * Given a visitor instance, if it is leaving or not, and a node kind, return
   * the function the visitor runtime should call.
   */

  function getVisitFn(visitor, kind, isLeaving) {
    var kindVisitor = visitor._ES5ProxyType ? visitor.get(kind) : visitor[kind];

    if (kindVisitor) {
      if (!isLeaving && typeof kindVisitor === 'function') {
        // { Kind() {} }
        return kindVisitor;
      }

      var kindSpecificVisitor = isLeaving ? kindVisitor._ES5ProxyType ? kindVisitor.get("leave") : kindVisitor.leave : kindVisitor._ES5ProxyType ? kindVisitor.get("enter") : kindVisitor.enter;

      if (typeof kindSpecificVisitor === 'function') {
        // { Kind: { enter() {}, leave() {} } }
        return kindSpecificVisitor;
      }
    } else {
      var specificVisitor = isLeaving ? visitor._ES5ProxyType ? visitor.get("leave") : visitor.leave : visitor._ES5ProxyType ? visitor.get("enter") : visitor.enter;

      if (specificVisitor) {
        if (typeof specificVisitor === 'function') {
          // { enter() {}, leave() {} }
          return specificVisitor;
        }

        var specificKindVisitor = specificVisitor._ES5ProxyType ? specificVisitor.get(kind) : specificVisitor[kind];

        if (typeof specificKindVisitor === 'function') {
          // { enter: { Kind() {} }, leave: { Kind() {} } }
          return specificKindVisitor;
        }
      }
    }
  }

  var genericMessage = "Invariant Violation";
  var _a = Object.setPrototypeOf,
      setPrototypeOf$3 = _a === void 0 ? function (obj, proto) {
    __setKey(obj, "__proto__", proto);

    return obj;
  } : _a;

  var InvariantError =
  /** @class */
  function (_super) {
    __extends(InvariantError, _super);

    function InvariantError(message) {
      if (message === void 0) {
        message = genericMessage;
      }

      var _this = __callKey2(_super, "call", this, typeof message === "number" ? genericMessage + ": " + message + " (see https://github.com/apollographql/invariant-packages)" : message) || this;

      __setKey(_this, "framesToPop", 1);

      __setKey(_this, "name", genericMessage);

      setPrototypeOf$3(_this, InvariantError._ES5ProxyType ? InvariantError.get("prototype") : InvariantError.prototype);
      return _this;
    }

    return InvariantError;
  }(Error);

  function invariant$3(condition, message) {
    if (!condition) {
      throw new InvariantError(message);
    }
  }

  function wrapConsoleMethod(method) {
    return function () {
      return __callKey2(console._ES5ProxyType ? console.get(method) : console[method], "apply", console, arguments);
    };
  }

  (function (invariant) {
    __setKey(invariant, "warn", wrapConsoleMethod("warn"));

    __setKey(invariant, "error", wrapConsoleMethod("error"));
  })(invariant$3 || (invariant$3 = {})); // Code that uses ts-invariant with rollup-plugin-invariant may want to
  // import this process stub to avoid errors evaluating "development".
  // However, because most ESM-to-CJS compilers will rewrite the process import
  // as tsInvariant.process, which prevents proper replacement by minifiers, we
  // also attempt to define the stub globally when it is not already defined.


  var processStub = {
    env: {}
  };

  if ((typeof process === "undefined" ? "undefined" : _typeof_1(process)) === "object") {
    processStub = process;
  } else try {
    // Using Function to evaluate this assignment in global scope also escapes
    // the strict mode of the current module, thereby allowing the assignment.
    // Inspired by https://github.com/facebook/regenerator/pull/369.
    Function("stub", "process = stub")(processStub);
  } catch (atLeastWeTried) {// The assignment can fail if a Content Security Policy heavy-handedly
    // forbids Function usage. In those environments, developers should take
    // extra care to replace "development" in their production builds,
    // or define an appropriate global.process polyfill.
  }

  var invariant$1$1 = invariant$3;
  registerComponent(invariant$1$1, {
    tmpl: _tmpl
  });

  var fastJsonStableStringify = function fastJsonStableStringify(data, opts) {
    if (!opts) opts = {};
    if (typeof opts === 'function') opts = {
      cmp: opts
    };
    var cycles = typeof (opts._ES5ProxyType ? opts.get("cycles") : opts.cycles) === 'boolean' ? opts._ES5ProxyType ? opts.get("cycles") : opts.cycles : false;

    var cmp = (opts._ES5ProxyType ? opts.get("cmp") : opts.cmp) && function (f) {
      return function (node) {
        return function (a, b) {
          var aobj = {
            key: a,
            value: node._ES5ProxyType ? node.get(a) : node[a]
          };
          var bobj = {
            key: b,
            value: node._ES5ProxyType ? node.get(b) : node[b]
          };
          return f(aobj, bobj);
        };
      };
    }(opts._ES5ProxyType ? opts.get("cmp") : opts.cmp);

    var seen = [];
    return function stringify(node) {
      if (node && (node._ES5ProxyType ? node.get("toJSON") : node.toJSON) && typeof (node._ES5ProxyType ? node.get("toJSON") : node.toJSON) === 'function') {
        node = __callKey0(node, "toJSON");
      }

      if (node === undefined) return;
      if (typeof node == 'number') return isFinite(node) ? '' + node : 'null';
      if (_typeof_1(node) !== 'object') return JSON.stringify(node);
      var i, out;

      if (Array.compatIsArray(node)) {
        out = '[';

        for (i = 0; i < (node._ES5ProxyType ? node.get("length") : node.length); i++) {
          if (i) out += ',';
          out += stringify(node._ES5ProxyType ? node.get(i) : node[i]) || 'null';
        }

        return out + ']';
      }

      if (node === null) return 'null';

      if (__callKey1$1(seen, "indexOf", node) !== -1) {
        if (cycles) return JSON.stringify('__cycle__');
        throw new TypeError('Converting circular structure to JSON');
      }

      var seenIndex = seen.push(node) - 1;

      var keys = __callKey1$1(Object.compatKeys(node), "sort", cmp && cmp(node));

      out = '';

      for (i = 0; i < (keys._ES5ProxyType ? keys.get("length") : keys.length); i++) {
        var key = keys._ES5ProxyType ? keys.get(i) : keys[i];
        var value = stringify(node._ES5ProxyType ? node.get(key) : node[key]);
        if (!value) continue;
        if (out) out += ',';
        out += JSON.stringify(key) + ':' + value;
      }

      seen.splice(seenIndex, 1);
      return '{' + out + '}';
    }(data);
  };

  var _a$1 = Object.prototype,
      toString$2 = _a$1._ES5ProxyType ? _a$1.get("toString") : _a$1.toString,
      hasOwnProperty$2 = _a$1._ES5ProxyType ? _a$1.get("hasOwnProperty") : _a$1.hasOwnProperty;
  var previousComparisons = new Map();
  /**
   * Performs a deep equality check on two JavaScript values, tolerating cycles.
   */

  function equal(a, b) {
    try {
      return check(a, b);
    } finally {
      __callKey0(previousComparisons, "clear");
    }
  }

  function check(a, b) {
    // If the two values are strictly equal, our job is easy.
    if (a === b) {
      return true;
    } // Object.prototype.toString returns a representation of the runtime type of
    // the given value that is considerably more precise than typeof.


    var aTag = __callKey1$1(toString$2, "call", a);

    var bTag = __callKey1$1(toString$2, "call", b); // If the runtime types of a and b are different, they could maybe be equal
    // under some interpretation of equality, but for simplicity and performance
    // we just return false instead.


    if (aTag !== bTag) {
      return false;
    }

    switch (aTag) {
      case '[object Array]':
        // Arrays are a lot like other objects, but we can cheaply compare their
        // lengths as a short-cut before comparing their elements.
        if ((a._ES5ProxyType ? a.get("length") : a.length) !== (b._ES5ProxyType ? b.get("length") : b.length)) return false;
      // Fall through to object case...

      case '[object Object]':
        {
          if (previouslyCompared(a, b)) return true;
          var aKeys = Object.compatKeys(a);
          var bKeys = Object.compatKeys(b); // If `a` and `b` have a different number of enumerable keys, they
          // must be different.

          var keyCount = aKeys._ES5ProxyType ? aKeys.get("length") : aKeys.length;
          if (keyCount !== (bKeys._ES5ProxyType ? bKeys.get("length") : bKeys.length)) return false; // Now make sure they have the same keys.

          for (var k = 0; k < keyCount; ++k) {
            if (!__callKey2(hasOwnProperty$2, "call", b, aKeys._ES5ProxyType ? aKeys.get(k) : aKeys[k])) {
              return false;
            }
          } // Finally, check deep equality of all child properties.


          for (var k = 0; k < keyCount; ++k) {
            var key = aKeys._ES5ProxyType ? aKeys.get(k) : aKeys[k];

            if (!check(a._ES5ProxyType ? a.get(key) : a[key], b._ES5ProxyType ? b.get(key) : b[key])) {
              return false;
            }
          }

          return true;
        }

      case '[object Error]':
        return (a._ES5ProxyType ? a.get("name") : a.name) === (b._ES5ProxyType ? b.get("name") : b.name) && (a._ES5ProxyType ? a.get("message") : a.message) === (b._ES5ProxyType ? b.get("message") : b.message);

      case '[object Number]':
        // Handle NaN, which is !== itself.
        if (a !== a) return b !== b;
      // Fall through to shared +a === +b case...

      case '[object Boolean]':
      case '[object Date]':
        return +a === +b;

      case '[object RegExp]':
      case '[object String]':
        return a == "" + b;

      case '[object Map]':
      case '[object Set]':
        {
          if ((a._ES5ProxyType ? a.get("size") : a.size) !== (b._ES5ProxyType ? b.get("size") : b.size)) return false;
          if (previouslyCompared(a, b)) return true;

          var aIterator = __callKey0(a, "entries");

          var isMap = aTag === '[object Map]';

          while (true) {
            var info = __callKey0(aIterator, "next");

            if (info._ES5ProxyType ? info.get("done") : info.done) break; // If a instanceof Set, aValue === aKey.

            var _a = info._ES5ProxyType ? info.get("value") : info.value,
                aKey = _a._ES5ProxyType ? _a.get(0) : _a[0],
                aValue = _a._ES5ProxyType ? _a.get(1) : _a[1]; // So this works the same way for both Set and Map.


            if (!__callKey1$1(b, "has", aKey)) {
              return false;
            } // However, we care about deep equality of values only when dealing
            // with Map structures.


            if (isMap && !check(aValue, __callKey1$1(b, "get", aKey))) {
              return false;
            }
          }

          return true;
        }
    } // Otherwise the values are not equal.


    return false;
  }

  function previouslyCompared(a, b) {
    // Though cyclic references can make an object graph appear infinite from the
    // perspective of a depth-first traversal, the graph still contains a finite
    // number of distinct object references. We use the previousComparisons cache
    // to avoid comparing the same pair of object references more than once, which
    // guarantees termination (even if we end up comparing every object in one
    // graph to every object in the other graph, which is extremely unlikely),
    // while still allowing weird isomorphic structures (like rings with different
    // lengths) a chance to pass the equality test.
    var bSet = __callKey1$1(previousComparisons, "get", a);

    if (bSet) {
      // Return true here because we can be sure false will be returned somewhere
      // else if the objects are not equivalent.
      if (__callKey1$1(bSet, "has", b)) return true;
    } else {
      __callKey2(previousComparisons, "set", a, bSet = new Set());
    }

    __callKey1$1(bSet, "add", b);

    return false;
  }

  registerComponent(equal, {
    tmpl: _tmpl
  });

  function isStringValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'StringValue';
  }

  function isBooleanValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'BooleanValue';
  }

  function isIntValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'IntValue';
  }

  function isFloatValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'FloatValue';
  }

  function isVariable(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'Variable';
  }

  function isObjectValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'ObjectValue';
  }

  function isListValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'ListValue';
  }

  function isEnumValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'EnumValue';
  }

  function isNullValue(value) {
    return (value._ES5ProxyType ? value.get("kind") : value.kind) === 'NullValue';
  }

  function valueToObjectRepresentation(argObj, name, value, variables) {
    if (isIntValue(value) || isFloatValue(value)) {
      __setKey(argObj, name._ES5ProxyType ? name.get("value") : name.value, Number(value._ES5ProxyType ? value.get("value") : value.value));
    } else if (isBooleanValue(value) || isStringValue(value)) {
      __setKey(argObj, name._ES5ProxyType ? name.get("value") : name.value, value._ES5ProxyType ? value.get("value") : value.value);
    } else if (isObjectValue(value)) {
      var nestedArgObj_1 = {};

      __callKey1$1(value._ES5ProxyType ? value.get("fields") : value.fields, "map", function (obj) {
        return valueToObjectRepresentation(nestedArgObj_1, obj._ES5ProxyType ? obj.get("name") : obj.name, obj._ES5ProxyType ? obj.get("value") : obj.value, variables);
      });

      __setKey(argObj, name._ES5ProxyType ? name.get("value") : name.value, nestedArgObj_1);
    } else if (isVariable(value)) {
      var _ref, _value$name$value, _value$name$value2, _name, _value;

      var variableValue = (_ref = variables || {}, _value$name$value = (_name = value._ES5ProxyType ? value.get("name") : value.name, _value = _name._ES5ProxyType ? _name.get("value") : _name.value), _value$name$value2 = _ref._ES5ProxyType ? _ref.get(_value$name$value) : _ref[_value$name$value]);

      __setKey(argObj, name._ES5ProxyType ? name.get("value") : name.value, variableValue);
    } else if (isListValue(value)) {
      __setKey(argObj, name._ES5ProxyType ? name.get("value") : name.value, __callKey1$1(value._ES5ProxyType ? value.get("values") : value.values, "map", function (listValue) {
        var _name$value, _name$value2;

        var nestedArgArrayObj = {};
        valueToObjectRepresentation(nestedArgArrayObj, name, listValue, variables);
        return _name$value = name._ES5ProxyType ? name.get("value") : name.value, _name$value2 = nestedArgArrayObj._ES5ProxyType ? nestedArgArrayObj.get(_name$value) : nestedArgArrayObj[_name$value];
      }));
    } else if (isEnumValue(value)) {
      __setKey(argObj, name._ES5ProxyType ? name.get("value") : name.value, value._ES5ProxyType ? value.get("value") : value.value);
    } else if (isNullValue(value)) {
      __setKey(argObj, name._ES5ProxyType ? name.get("value") : name.value, null);
    } else {
      throw  new InvariantError("The inline argument \"" + (name._ES5ProxyType ? name.get("value") : name.value) + "\" of kind \"" + (value._ES5ProxyType ? value.get("kind") : value.kind) + "\"" + 'is not supported. Use variables instead of inline arguments to ' + 'overcome this limitation.');
    }
  }

  function storeKeyNameFromField(field, variables) {
    var _arguments, _length, _name4, _value4;

    var directivesObj = null;

    if (field._ES5ProxyType ? field.get("directives") : field.directives) {
      directivesObj = {};

      __callKey1$1(field._ES5ProxyType ? field.get("directives") : field.directives, "forEach", function (directive) {
        var _name2, _value2;

        __setKey(directivesObj, (_name2 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value2 = _name2._ES5ProxyType ? _name2.get("value") : _name2.value), {});

        if (directive._ES5ProxyType ? directive.get("arguments") : directive.arguments) {
          __callKey1$1(directive._ES5ProxyType ? directive.get("arguments") : directive.arguments, "forEach", function (_a) {
            var _directive$name$value, _directive$name$value2, _name3, _value3;

            var name = _a._ES5ProxyType ? _a.get("name") : _a.name,
                value = _a._ES5ProxyType ? _a.get("value") : _a.value;
            return valueToObjectRepresentation((_directive$name$value = (_name3 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value3 = _name3._ES5ProxyType ? _name3.get("value") : _name3.value), _directive$name$value2 = directivesObj._ES5ProxyType ? directivesObj.get(_directive$name$value) : directivesObj[_directive$name$value]), name, value, variables);
          });
        }
      });
    }

    var argObj = null;

    if ((field._ES5ProxyType ? field.get("arguments") : field.arguments) && (_arguments = field._ES5ProxyType ? field.get("arguments") : field.arguments, _length = _arguments._ES5ProxyType ? _arguments.get("length") : _arguments.length)) {
      argObj = {};

      __callKey1$1(field._ES5ProxyType ? field.get("arguments") : field.arguments, "forEach", function (_a) {
        var name = _a._ES5ProxyType ? _a.get("name") : _a.name,
            value = _a._ES5ProxyType ? _a.get("value") : _a.value;
        return valueToObjectRepresentation(argObj, name, value, variables);
      });
    }

    return getStoreKeyName((_name4 = field._ES5ProxyType ? field.get("name") : field.name, _value4 = _name4._ES5ProxyType ? _name4.get("value") : _name4.value), argObj, directivesObj);
  }

  var KNOWN_DIRECTIVES = ['connection', 'include', 'skip', 'client', 'rest', 'export'];

  function getStoreKeyName(fieldName, args, directives) {
    var _connection, _key2;

    if (directives && (directives._ES5ProxyType ? directives.get('connection') : directives['connection']) && (_connection = directives._ES5ProxyType ? directives.get('connection') : directives['connection'], _key2 = _connection._ES5ProxyType ? _connection.get('key') : _connection['key'])) {
      var _connection2, _filter, _connection3, _filter2, _length2;

      if ((_connection2 = directives._ES5ProxyType ? directives.get('connection') : directives['connection'], _filter = _connection2._ES5ProxyType ? _connection2.get('filter') : _connection2['filter']) && (_connection3 = directives._ES5ProxyType ? directives.get('connection') : directives['connection'], _filter2 = _connection3._ES5ProxyType ? _connection3.get('filter') : _connection3['filter'], _length2 = _filter2._ES5ProxyType ? _filter2.get("length") : _filter2.length) > 0) {
        var _connection4, _filter3, _connection5, _filter4, _connection6, _key3;

        var filterKeys = (_connection4 = directives._ES5ProxyType ? directives.get('connection') : directives['connection'], _filter3 = _connection4._ES5ProxyType ? _connection4.get('filter') : _connection4['filter']) ? (_connection5 = directives._ES5ProxyType ? directives.get('connection') : directives['connection'], _filter4 = _connection5._ES5ProxyType ? _connection5.get('filter') : _connection5['filter']) : [];

        __callKey0(filterKeys, "sort");

        var queryArgs_1 = args;
        var filteredArgs_1 = {};

        __callKey1$1(filterKeys, "forEach", function (key) {
          __setKey(filteredArgs_1, key, queryArgs_1._ES5ProxyType ? queryArgs_1.get(key) : queryArgs_1[key]);
        });

        return (_connection6 = directives._ES5ProxyType ? directives.get('connection') : directives['connection'], _key3 = _connection6._ES5ProxyType ? _connection6.get('key') : _connection6['key']) + "(" + JSON.stringify(filteredArgs_1) + ")";
      } else {
        var _connection7, _key4;

        return _connection7 = directives._ES5ProxyType ? directives.get('connection') : directives['connection'], _key4 = _connection7._ES5ProxyType ? _connection7.get('key') : _connection7['key'];
      }
    }

    var completeFieldName = fieldName;

    if (args) {
      var stringifiedArgs = fastJsonStableStringify(args);
      completeFieldName += "(" + stringifiedArgs + ")";
    }

    if (directives) {
      __callKey1$1(Object.compatKeys(directives), "forEach", function (key) {
        var _Object$compatKeys, _length3;

        if (__callKey1$1(KNOWN_DIRECTIVES, "indexOf", key) !== -1) return;

        if ((directives._ES5ProxyType ? directives.get(key) : directives[key]) && (_Object$compatKeys = Object.compatKeys(directives._ES5ProxyType ? directives.get(key) : directives[key]), _length3 = _Object$compatKeys._ES5ProxyType ? _Object$compatKeys.get("length") : _Object$compatKeys.length)) {
          completeFieldName += "@" + key + "(" + JSON.stringify(directives._ES5ProxyType ? directives.get(key) : directives[key]) + ")";
        } else {
          completeFieldName += "@" + key;
        }
      });
    }

    return completeFieldName;
  }

  function argumentsObjectFromField(field, variables) {
    var _arguments2, _length4;

    if ((field._ES5ProxyType ? field.get("arguments") : field.arguments) && (_arguments2 = field._ES5ProxyType ? field.get("arguments") : field.arguments, _length4 = _arguments2._ES5ProxyType ? _arguments2.get("length") : _arguments2.length)) {
      var argObj_1 = {};

      __callKey1$1(field._ES5ProxyType ? field.get("arguments") : field.arguments, "forEach", function (_a) {
        var name = _a._ES5ProxyType ? _a.get("name") : _a.name,
            value = _a._ES5ProxyType ? _a.get("value") : _a.value;
        return valueToObjectRepresentation(argObj_1, name, value, variables);
      });

      return argObj_1;
    }

    return null;
  }

  function resultKeyNameFromField(field) {
    var _alias, _value5, _name5, _value6;

    return (field._ES5ProxyType ? field.get("alias") : field.alias) ? (_alias = field._ES5ProxyType ? field.get("alias") : field.alias, _value5 = _alias._ES5ProxyType ? _alias.get("value") : _alias.value) : (_name5 = field._ES5ProxyType ? field.get("name") : field.name, _value6 = _name5._ES5ProxyType ? _name5.get("value") : _name5.value);
  }

  function isField(selection) {
    return (selection._ES5ProxyType ? selection.get("kind") : selection.kind) === 'Field';
  }

  function isInlineFragment(selection) {
    return (selection._ES5ProxyType ? selection.get("kind") : selection.kind) === 'InlineFragment';
  }

  function isIdValue(idObject) {
    return idObject && (idObject._ES5ProxyType ? idObject.get("type") : idObject.type) === 'id' && typeof (idObject._ES5ProxyType ? idObject.get("generated") : idObject.generated) === 'boolean';
  }

  function toIdValue(idConfig, generated) {
    if (generated === void 0) {
      generated = false;
    }

    return _assign({
      type: 'id',
      generated: generated
    }, typeof idConfig === 'string' ? {
      id: idConfig,
      typename: undefined
    } : idConfig);
  }

  function isJsonValue(jsonObject) {
    return jsonObject != null && _typeof_1(jsonObject) === 'object' && (jsonObject._ES5ProxyType ? jsonObject.get("type") : jsonObject.type) === 'json';
  }

  function getDirectiveInfoFromField(field, variables) {
    var _directives, _length5;

    if ((field._ES5ProxyType ? field.get("directives") : field.directives) && (_directives = field._ES5ProxyType ? field.get("directives") : field.directives, _length5 = _directives._ES5ProxyType ? _directives.get("length") : _directives.length)) {
      var directiveObj_1 = {};

      __callKey1$1(field._ES5ProxyType ? field.get("directives") : field.directives, "forEach", function (directive) {
        var _name7, _value8;

        __setKey(directiveObj_1, (_name7 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value8 = _name7._ES5ProxyType ? _name7.get("value") : _name7.value), argumentsObjectFromField(directive, variables));
      });

      return directiveObj_1;
    }

    return null;
  }

  function shouldInclude(selection, variables) {
    if (variables === void 0) {
      variables = {};
    }

    return __callKey1$1(getInclusionDirectives(selection._ES5ProxyType ? selection.get("directives") : selection.directives), "every", function (_a) {
      var _value9, _kind, _name10, _value15;

      var directive = _a._ES5ProxyType ? _a.get("directive") : _a.directive,
          ifArgument = _a._ES5ProxyType ? _a.get("ifArgument") : _a.ifArgument;
      var evaledValue = false;

      if ((_value9 = ifArgument._ES5ProxyType ? ifArgument.get("value") : ifArgument.value, _kind = _value9._ES5ProxyType ? _value9.get("kind") : _value9.kind) === 'Variable') {
        var _ifArgument$value$nam, _ifArgument$value$nam2, _value10, _name8, _value11, _name9, _value12;

        evaledValue = (_ifArgument$value$nam = (_value10 = ifArgument._ES5ProxyType ? ifArgument.get("value") : ifArgument.value, _name8 = _value10._ES5ProxyType ? _value10.get("name") : _value10.name, _value11 = _name8._ES5ProxyType ? _name8.get("value") : _name8.value), _ifArgument$value$nam2 = variables._ES5ProxyType ? variables.get(_ifArgument$value$nam) : variables[_ifArgument$value$nam]);
         invariant$3(evaledValue !== void 0, "Invalid variable referenced in @" + (_name9 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value12 = _name9._ES5ProxyType ? _name9.get("value") : _name9.value) + " directive.");
      } else {
        var _value13, _value14;

        evaledValue = (_value13 = ifArgument._ES5ProxyType ? ifArgument.get("value") : ifArgument.value, _value14 = _value13._ES5ProxyType ? _value13.get("value") : _value13.value);
      }

      return (_name10 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value15 = _name10._ES5ProxyType ? _name10.get("value") : _name10.value) === 'skip' ? !evaledValue : evaledValue;
    });
  }

  function getDirectiveNames(doc) {
    var names = [];
    visit(doc, {
      Directive: function Directive(node) {
        var _name11, _value16;

        names.push((_name11 = node._ES5ProxyType ? node.get("name") : node.name, _value16 = _name11._ES5ProxyType ? _name11.get("value") : _name11.value));
      }
    });
    return names;
  }

  function hasDirectives(names, doc) {
    return __callKey1$1(getDirectiveNames(doc), "some", function (name) {
      return __callKey1$1(names, "indexOf", name) > -1;
    });
  }

  function hasClientExports(document) {
    return document && hasDirectives(['client'], document) && hasDirectives(['export'], document);
  }

  function isInclusionDirective(_a) {
    var _name12, _value17;

    var value = (_name12 = _a._ES5ProxyType ? _a.get("name") : _a.name, _value17 = _name12._ES5ProxyType ? _name12.get("value") : _name12.value);
    return value === 'skip' || value === 'include';
  }

  function getInclusionDirectives(directives) {
    return directives ? __callKey1$1(__callKey1$1(directives, "filter", isInclusionDirective), "map", function (directive) {
      var _name13, _value18, _name15, _value20;

      var directiveArguments = directive._ES5ProxyType ? directive.get("arguments") : directive.arguments;
      var directiveName = (_name13 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value18 = _name13._ES5ProxyType ? _name13.get("value") : _name13.value);
       invariant$3(directiveArguments && (directiveArguments._ES5ProxyType ? directiveArguments.get("length") : directiveArguments.length) === 1, "Incorrect number of arguments for the @" + directiveName + " directive.");
      var ifArgument = directiveArguments._ES5ProxyType ? directiveArguments.get(0) : directiveArguments[0];
       invariant$3((ifArgument._ES5ProxyType ? ifArgument.get("name") : ifArgument.name) && (_name15 = ifArgument._ES5ProxyType ? ifArgument.get("name") : ifArgument.name, _value20 = _name15._ES5ProxyType ? _name15.get("value") : _name15.value) === 'if', "Invalid argument for the @" + directiveName + " directive.");
      var ifValue = ifArgument._ES5ProxyType ? ifArgument.get("value") : ifArgument.value;
       invariant$3(ifValue && ((ifValue._ES5ProxyType ? ifValue.get("kind") : ifValue.kind) === 'Variable' || (ifValue._ES5ProxyType ? ifValue.get("kind") : ifValue.kind) === 'BooleanValue'), "Argument for the @" + directiveName + " directive must be a variable or a boolean value.");
      return {
        directive: directive,
        ifArgument: ifArgument
      };
    }) : [];
  }

  function getFragmentQueryDocument(document, fragmentName) {
    var actualFragmentName = fragmentName;
    var fragments = [];

    __callKey1$1(document._ES5ProxyType ? document.get("definitions") : document.definitions, "forEach", function (definition) {
      if ((definition._ES5ProxyType ? definition.get("kind") : definition.kind) === 'OperationDefinition') {
        var _name16, _value21;

        throw  new InvariantError("Found a " + (definition._ES5ProxyType ? definition.get("operation") : definition.operation) + " operation" + ((definition._ES5ProxyType ? definition.get("name") : definition.name) ? " named '" + (_name16 = definition._ES5ProxyType ? definition.get("name") : definition.name, _value21 = _name16._ES5ProxyType ? _name16.get("value") : _name16.value) + "'" : '') + ". " + 'No operations are allowed when using a fragment as a query. Only fragments are allowed.');
      }

      if ((definition._ES5ProxyType ? definition.get("kind") : definition.kind) === 'FragmentDefinition') {
        fragments.push(definition);
      }
    });

    if (typeof actualFragmentName === 'undefined') {
      var _, _name17, _value22;

       invariant$3((fragments._ES5ProxyType ? fragments.get("length") : fragments.length) === 1, "Found " + (fragments._ES5ProxyType ? fragments.get("length") : fragments.length) + " fragments. `fragmentName` must be provided when there is not exactly 1 fragment.");
      actualFragmentName = (_ = fragments._ES5ProxyType ? fragments.get(0) : fragments[0], _name17 = _._ES5ProxyType ? _.get("name") : _.name, _value22 = _name17._ES5ProxyType ? _name17.get("value") : _name17.value);
    }

    var query = _assign(_assign({}, document), {
      definitions: __spreadArrays([{
        kind: 'OperationDefinition',
        operation: 'query',
        selectionSet: {
          kind: 'SelectionSet',
          selections: [{
            kind: 'FragmentSpread',
            name: {
              kind: 'Name',
              value: actualFragmentName
            }
          }]
        }
      }], document._ES5ProxyType ? document.get("definitions") : document.definitions)
    });

    return query;
  }

  function assign$2(target) {
    var sources = [];

    for (var _i = 1; _i < arguments.length; _i++) {
      __setKey(sources, _i - 1, arguments[_i]);
    }

    __callKey1$1(sources, "forEach", function (source) {
      if (typeof source === 'undefined' || source === null) {
        return;
      }

      __callKey1$1(Object.compatKeys(source), "forEach", function (key) {
        __setKey(target, key, source._ES5ProxyType ? source.get(key) : source[key]);
      });
    });

    return target;
  }

  function checkDocument(doc) {
     invariant$3(doc && (doc._ES5ProxyType ? doc.get("kind") : doc.kind) === 'Document', "Expecting a parsed GraphQL document. Perhaps you need to wrap the query string in a \"gql\" tag? http://docs.apollostack.com/apollo-client/core.html#gql");

    var operations = __callKey1$1(__callKey1$1(doc._ES5ProxyType ? doc.get("definitions") : doc.definitions, "filter", function (d) {
      return (d._ES5ProxyType ? d.get("kind") : d.kind) !== 'FragmentDefinition';
    }), "map", function (definition) {
      if ((definition._ES5ProxyType ? definition.get("kind") : definition.kind) !== 'OperationDefinition') {
        throw  new InvariantError("Schema type definitions not allowed in queries. Found: \"" + (definition._ES5ProxyType ? definition.get("kind") : definition.kind) + "\"");
      }

      return definition;
    });

     invariant$3((operations._ES5ProxyType ? operations.get("length") : operations.length) <= 1, "Ambiguous GraphQL document: contains " + (operations._ES5ProxyType ? operations.get("length") : operations.length) + " operations");
    return doc;
  }

  function getOperationDefinition(doc) {
    var _doc$definitions$filt2, _3;

    checkDocument(doc);
    return _doc$definitions$filt2 = __callKey1$1(doc._ES5ProxyType ? doc.get("definitions") : doc.definitions, "filter", function (definition) {
      return (definition._ES5ProxyType ? definition.get("kind") : definition.kind) === 'OperationDefinition';
    }), _3 = _doc$definitions$filt2._ES5ProxyType ? _doc$definitions$filt2.get(0) : _doc$definitions$filt2[0];
  }

  function getOperationName(doc) {
    var _doc$definitions$filt3, _4;

    return (_doc$definitions$filt3 = __callKey1$1(__callKey1$1(doc._ES5ProxyType ? doc.get("definitions") : doc.definitions, "filter", function (definition) {
      return (definition._ES5ProxyType ? definition.get("kind") : definition.kind) === 'OperationDefinition' && (definition._ES5ProxyType ? definition.get("name") : definition.name);
    }), "map", function (x) {
      var _name18, _value23;

      return _name18 = x._ES5ProxyType ? x.get("name") : x.name, _value23 = _name18._ES5ProxyType ? _name18.get("value") : _name18.value;
    }), _4 = _doc$definitions$filt3._ES5ProxyType ? _doc$definitions$filt3.get(0) : _doc$definitions$filt3[0]) || null;
  }

  function getFragmentDefinitions(doc) {
    return __callKey1$1(doc._ES5ProxyType ? doc.get("definitions") : doc.definitions, "filter", function (definition) {
      return (definition._ES5ProxyType ? definition.get("kind") : definition.kind) === 'FragmentDefinition';
    });
  }

  function getQueryDefinition(doc) {
    var queryDef = getOperationDefinition(doc);
     invariant$3(queryDef && (queryDef._ES5ProxyType ? queryDef.get("operation") : queryDef.operation) === 'query', 'Must contain a query definition.');
    return queryDef;
  }

  function getFragmentDefinition(doc) {
    var _definitions2, _length7, _definitions3, _5;

     invariant$3((doc._ES5ProxyType ? doc.get("kind") : doc.kind) === 'Document', "Expecting a parsed GraphQL document. Perhaps you need to wrap the query string in a \"gql\" tag? http://docs.apollostack.com/apollo-client/core.html#gql");
     invariant$3((_definitions2 = doc._ES5ProxyType ? doc.get("definitions") : doc.definitions, _length7 = _definitions2._ES5ProxyType ? _definitions2.get("length") : _definitions2.length) <= 1, 'Fragment must have exactly one definition.');
    var fragmentDef = (_definitions3 = doc._ES5ProxyType ? doc.get("definitions") : doc.definitions, _5 = _definitions3._ES5ProxyType ? _definitions3.get(0) : _definitions3[0]);
     invariant$3((fragmentDef._ES5ProxyType ? fragmentDef.get("kind") : fragmentDef.kind) === 'FragmentDefinition', 'Must be a fragment definition.');
    return fragmentDef;
  }

  function getMainDefinition(queryDoc) {
    checkDocument(queryDoc);
    var fragmentDefinition;

    for (var _i = 0, _a = queryDoc._ES5ProxyType ? queryDoc.get("definitions") : queryDoc.definitions; _i < (_a._ES5ProxyType ? _a.get("length") : _a.length); _i++) {
      var definition = _a._ES5ProxyType ? _a.get(_i) : _a[_i];

      if ((definition._ES5ProxyType ? definition.get("kind") : definition.kind) === 'OperationDefinition') {
        var operation = definition._ES5ProxyType ? definition.get("operation") : definition.operation;

        if (operation === 'query' || operation === 'mutation' || operation === 'subscription') {
          return definition;
        }
      }

      if ((definition._ES5ProxyType ? definition.get("kind") : definition.kind) === 'FragmentDefinition' && !fragmentDefinition) {
        fragmentDefinition = definition;
      }
    }

    if (fragmentDefinition) {
      return fragmentDefinition;
    }

    throw  new InvariantError('Expected a parsed GraphQL query with a query, mutation, subscription, or a fragment.');
  }

  function createFragmentMap(fragments) {
    if (fragments === void 0) {
      fragments = [];
    }

    var symTable = {};

    __callKey1$1(fragments, "forEach", function (fragment) {
      var _name19, _value24;

      __setKey(symTable, (_name19 = fragment._ES5ProxyType ? fragment.get("name") : fragment.name, _value24 = _name19._ES5ProxyType ? _name19.get("value") : _name19.value), fragment);
    });

    return symTable;
  }

  function getDefaultValues(definition) {
    var _variableDefinitions, _length8;

    if (definition && (definition._ES5ProxyType ? definition.get("variableDefinitions") : definition.variableDefinitions) && (_variableDefinitions = definition._ES5ProxyType ? definition.get("variableDefinitions") : definition.variableDefinitions, _length8 = _variableDefinitions._ES5ProxyType ? _variableDefinitions.get("length") : _variableDefinitions.length)) {
      var defaultValues = __callKey1$1(__callKey1$1(definition._ES5ProxyType ? definition.get("variableDefinitions") : definition.variableDefinitions, "filter", function (_a) {
        var defaultValue = _a._ES5ProxyType ? _a.get("defaultValue") : _a.defaultValue;
        return defaultValue;
      }), "map", function (_a) {
        var variable = _a._ES5ProxyType ? _a.get("variable") : _a.variable,
            defaultValue = _a._ES5ProxyType ? _a.get("defaultValue") : _a.defaultValue;
        var defaultValueObj = {};
        valueToObjectRepresentation(defaultValueObj, variable._ES5ProxyType ? variable.get("name") : variable.name, defaultValue);
        return defaultValueObj;
      });

      return __callKey2(assign$2, "apply", void 0, __spreadArrays([{}], defaultValues));
    }

    return {};
  }

  function filterInPlace(array, test, context) {
    var target = 0;

    __callKey2(array, "forEach", function (elem, i) {
      if (__callKey4(test, "call", this, elem, i, array)) {
        __setKey(array, target++, elem);
      }
    }, context);

    __setKey(array, "length", target);

    return array;
  }

  var TYPENAME_FIELD = {
    kind: 'Field',
    name: {
      kind: 'Name',
      value: '__typename'
    }
  };

  function isEmpty(op, fragments) {
    var _selectionSet, _selections;

    return __callKey1$1((_selectionSet = op._ES5ProxyType ? op.get("selectionSet") : op.selectionSet, _selections = _selectionSet._ES5ProxyType ? _selectionSet.get("selections") : _selectionSet.selections), "every", function (selection) {
      var _selection$name$value, _selection$name$value2, _name21, _value26;

      return (selection._ES5ProxyType ? selection.get("kind") : selection.kind) === 'FragmentSpread' && isEmpty((_selection$name$value = (_name21 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value26 = _name21._ES5ProxyType ? _name21.get("value") : _name21.value), _selection$name$value2 = fragments._ES5ProxyType ? fragments.get(_selection$name$value) : fragments[_selection$name$value]), fragments);
    });
  }

  function nullIfDocIsEmpty(doc) {
    return isEmpty(getOperationDefinition(doc) || getFragmentDefinition(doc), createFragmentMap(getFragmentDefinitions(doc))) ? null : doc;
  }

  function getDirectiveMatcher(directives) {
    return function directiveMatcher(directive) {
      return __callKey1$1(directives, "some", function (dir) {
        var _name22, _value27;

        return (dir._ES5ProxyType ? dir.get("name") : dir.name) && (dir._ES5ProxyType ? dir.get("name") : dir.name) === (_name22 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value27 = _name22._ES5ProxyType ? _name22.get("value") : _name22.value) || (dir._ES5ProxyType ? dir.get("test") : dir.test) && __callKey1$1(dir, "test", directive);
      });
    };
  }

  function removeDirectivesFromDocument(directives, doc) {
    var _filterInPlace, _length9, _filterInPlace2, _length10;

    var variablesInUse = Object.create(null);
    var variablesToRemove = [];
    var fragmentSpreadsInUse = Object.create(null);
    var fragmentSpreadsToRemove = [];
    var modifiedDoc = nullIfDocIsEmpty(visit(doc, {
      Variable: {
        enter: function enter(node, _key, parent) {
          if ((parent._ES5ProxyType ? parent.get("kind") : parent.kind) !== 'VariableDefinition') {
            var _name23, _value28;

            __setKey(variablesInUse, (_name23 = node._ES5ProxyType ? node.get("name") : node.name, _value28 = _name23._ES5ProxyType ? _name23.get("value") : _name23.value), true);
          }
        }
      },
      Field: {
        enter: function enter(node) {
          if (directives && (node._ES5ProxyType ? node.get("directives") : node.directives)) {
            var shouldRemoveField = __callKey1$1(directives, "some", function (directive) {
              return directive._ES5ProxyType ? directive.get("remove") : directive.remove;
            });

            if (shouldRemoveField && (node._ES5ProxyType ? node.get("directives") : node.directives) && __callKey1$1(node._ES5ProxyType ? node.get("directives") : node.directives, "some", getDirectiveMatcher(directives))) {
              if (node._ES5ProxyType ? node.get("arguments") : node.arguments) {
                __callKey1$1(node._ES5ProxyType ? node.get("arguments") : node.arguments, "forEach", function (arg) {
                  var _value29, _kind2;

                  if ((_value29 = arg._ES5ProxyType ? arg.get("value") : arg.value, _kind2 = _value29._ES5ProxyType ? _value29.get("kind") : _value29.kind) === 'Variable') {
                    var _value30, _name24, _value31;

                    variablesToRemove.push({
                      name: (_value30 = arg._ES5ProxyType ? arg.get("value") : arg.value, _name24 = _value30._ES5ProxyType ? _value30.get("name") : _value30.name, _value31 = _name24._ES5ProxyType ? _name24.get("value") : _name24.value)
                    });
                  }
                });
              }

              if (node._ES5ProxyType ? node.get("selectionSet") : node.selectionSet) {
                __callKey1$1(getAllFragmentSpreadsFromSelectionSet(node._ES5ProxyType ? node.get("selectionSet") : node.selectionSet), "forEach", function (frag) {
                  var _name25, _value32;

                  fragmentSpreadsToRemove.push({
                    name: (_name25 = frag._ES5ProxyType ? frag.get("name") : frag.name, _value32 = _name25._ES5ProxyType ? _name25.get("value") : _name25.value)
                  });
                });
              }

              return null;
            }
          }
        }
      },
      FragmentSpread: {
        enter: function enter(node) {
          var _name26, _value33;

          __setKey(fragmentSpreadsInUse, (_name26 = node._ES5ProxyType ? node.get("name") : node.name, _value33 = _name26._ES5ProxyType ? _name26.get("value") : _name26.value), true);
        }
      },
      Directive: {
        enter: function enter(node) {
          if (getDirectiveMatcher(directives)(node)) {
            return null;
          }
        }
      }
    }));

    if (modifiedDoc && (_filterInPlace = filterInPlace(variablesToRemove, function (v) {
      var _v$name, _v$name2;

      return !(_v$name = v._ES5ProxyType ? v.get("name") : v.name, _v$name2 = variablesInUse._ES5ProxyType ? variablesInUse.get(_v$name) : variablesInUse[_v$name]);
    }), _length9 = _filterInPlace._ES5ProxyType ? _filterInPlace.get("length") : _filterInPlace.length)) {
      modifiedDoc = removeArgumentsFromDocument(variablesToRemove, modifiedDoc);
    }

    if (modifiedDoc && (_filterInPlace2 = filterInPlace(fragmentSpreadsToRemove, function (fs) {
      var _fs$name, _fs$name2;

      return !(_fs$name = fs._ES5ProxyType ? fs.get("name") : fs.name, _fs$name2 = fragmentSpreadsInUse._ES5ProxyType ? fragmentSpreadsInUse.get(_fs$name) : fragmentSpreadsInUse[_fs$name]);
    }), _length10 = _filterInPlace2._ES5ProxyType ? _filterInPlace2.get("length") : _filterInPlace2.length)) {
      modifiedDoc = removeFragmentSpreadFromDocument(fragmentSpreadsToRemove, modifiedDoc);
    }

    return modifiedDoc;
  }

  function addTypenameToDocument(doc) {
    return visit(checkDocument(doc), {
      SelectionSet: {
        enter: function enter(node, _key, parent) {
          if (parent && (parent._ES5ProxyType ? parent.get("kind") : parent.kind) === 'OperationDefinition') {
            return;
          }

          var selections = node._ES5ProxyType ? node.get("selections") : node.selections;

          if (!selections) {
            return;
          }

          var skip = __callKey1$1(selections, "some", function (selection) {
            var _name27, _value34, _name28, _value35;

            return isField(selection) && ((_name27 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value34 = _name27._ES5ProxyType ? _name27.get("value") : _name27.value) === '__typename' || __callKey2((_name28 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value35 = _name28._ES5ProxyType ? _name28.get("value") : _name28.value), "lastIndexOf", '__', 0) === 0);
          });

          if (skip) {
            return;
          }

          var field = parent;

          if (isField(field) && (field._ES5ProxyType ? field.get("directives") : field.directives) && __callKey1$1(field._ES5ProxyType ? field.get("directives") : field.directives, "some", function (d) {
            var _name29, _value36;

            return (_name29 = d._ES5ProxyType ? d.get("name") : d.name, _value36 = _name29._ES5ProxyType ? _name29.get("value") : _name29.value) === 'export';
          })) {
            return;
          }

          return _assign(_assign({}, node), {
            selections: __spreadArrays(selections, [TYPENAME_FIELD])
          });
        }
      }
    });
  }

  var connectionRemoveConfig = {
    test: function test(directive) {
      var _name30, _value37;

      var willRemove = (_name30 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value37 = _name30._ES5ProxyType ? _name30.get("value") : _name30.value) === 'connection';

      if (willRemove) {
        if (!(directive._ES5ProxyType ? directive.get("arguments") : directive.arguments) || !__callKey1$1(directive._ES5ProxyType ? directive.get("arguments") : directive.arguments, "some", function (arg) {
          var _name31, _value38;

          return (_name31 = arg._ES5ProxyType ? arg.get("name") : arg.name, _value38 = _name31._ES5ProxyType ? _name31.get("value") : _name31.value) === 'key';
        })) {
           __callKey1$1(invariant$3, "warn", 'Removing an @connection directive even though it does not have a key. ' + 'You may want to use the key parameter to specify a store key.');
        }
      }

      return willRemove;
    }
  };

  function removeConnectionDirectiveFromDocument(doc) {
    return removeDirectivesFromDocument([connectionRemoveConfig], checkDocument(doc));
  }

  function getArgumentMatcher(config) {
    return function argumentMatcher(argument) {
      return __callKey1$1(config, "some", function (aConfig) {
        var _value39, _kind3, _value40, _name32, _value41, _name33, _value42;

        return (argument._ES5ProxyType ? argument.get("value") : argument.value) && (_value39 = argument._ES5ProxyType ? argument.get("value") : argument.value, _kind3 = _value39._ES5ProxyType ? _value39.get("kind") : _value39.kind) === 'Variable' && (_value40 = argument._ES5ProxyType ? argument.get("value") : argument.value, _name32 = _value40._ES5ProxyType ? _value40.get("name") : _value40.name) && ((aConfig._ES5ProxyType ? aConfig.get("name") : aConfig.name) === (_value41 = argument._ES5ProxyType ? argument.get("value") : argument.value, _name33 = _value41._ES5ProxyType ? _value41.get("name") : _value41.name, _value42 = _name33._ES5ProxyType ? _name33.get("value") : _name33.value) || (aConfig._ES5ProxyType ? aConfig.get("test") : aConfig.test) && __callKey1$1(aConfig, "test", argument));
      });
    };
  }

  function removeArgumentsFromDocument(config, doc) {
    var argMatcher = getArgumentMatcher(config);
    return nullIfDocIsEmpty(visit(doc, {
      OperationDefinition: {
        enter: function enter(node) {
          return _assign(_assign({}, node), {
            variableDefinitions: __callKey1$1(node._ES5ProxyType ? node.get("variableDefinitions") : node.variableDefinitions, "filter", function (varDef) {
              return !__callKey1$1(config, "some", function (arg) {
                var _variable2, _name34, _value43;

                return (arg._ES5ProxyType ? arg.get("name") : arg.name) === (_variable2 = varDef._ES5ProxyType ? varDef.get("variable") : varDef.variable, _name34 = _variable2._ES5ProxyType ? _variable2.get("name") : _variable2.name, _value43 = _name34._ES5ProxyType ? _name34.get("value") : _name34.value);
              });
            })
          });
        }
      },
      Field: {
        enter: function enter(node) {
          var shouldRemoveField = __callKey1$1(config, "some", function (argConfig) {
            return argConfig._ES5ProxyType ? argConfig.get("remove") : argConfig.remove;
          });

          if (shouldRemoveField) {
            var argMatchCount_1 = 0;

            __callKey1$1(node._ES5ProxyType ? node.get("arguments") : node.arguments, "forEach", function (arg) {
              if (argMatcher(arg)) {
                argMatchCount_1 += 1;
              }
            });

            if (argMatchCount_1 === 1) {
              return null;
            }
          }
        }
      },
      Argument: {
        enter: function enter(node) {
          if (argMatcher(node)) {
            return null;
          }
        }
      }
    }));
  }

  function removeFragmentSpreadFromDocument(config, doc) {
    function enter(node) {
      if (__callKey1$1(config, "some", function (def) {
        var _name35, _value44;

        return (def._ES5ProxyType ? def.get("name") : def.name) === (_name35 = node._ES5ProxyType ? node.get("name") : node.name, _value44 = _name35._ES5ProxyType ? _name35.get("value") : _name35.value);
      })) {
        return null;
      }
    }

    return nullIfDocIsEmpty(visit(doc, {
      FragmentSpread: {
        enter: enter
      },
      FragmentDefinition: {
        enter: enter
      }
    }));
  }

  function getAllFragmentSpreadsFromSelectionSet(selectionSet) {
    var allFragments = [];

    __callKey1$1(selectionSet._ES5ProxyType ? selectionSet.get("selections") : selectionSet.selections, "forEach", function (selection) {
      if ((isField(selection) || isInlineFragment(selection)) && (selection._ES5ProxyType ? selection.get("selectionSet") : selection.selectionSet)) {
        __callKey1$1(getAllFragmentSpreadsFromSelectionSet(selection._ES5ProxyType ? selection.get("selectionSet") : selection.selectionSet), "forEach", function (frag) {
          return allFragments.push(frag);
        });
      } else if ((selection._ES5ProxyType ? selection.get("kind") : selection.kind) === 'FragmentSpread') {
        allFragments.push(selection);
      }
    });

    return allFragments;
  }

  function buildQueryFromSelectionSet(document) {
    var definition = getMainDefinition(document);
    var definitionOperation = definition._ES5ProxyType ? definition.get("operation") : definition.operation;

    if (definitionOperation === 'query') {
      return document;
    }

    var modifiedDoc = visit(document, {
      OperationDefinition: {
        enter: function enter(node) {
          return _assign(_assign({}, node), {
            operation: 'query'
          });
        }
      }
    });
    return modifiedDoc;
  }

  function removeClientSetsFromDocument(document) {
    checkDocument(document);
    var modifiedDoc = removeDirectivesFromDocument([{
      test: function test(directive) {
        var _name36, _value45;

        return (_name36 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value45 = _name36._ES5ProxyType ? _name36.get("value") : _name36.value) === 'client';
      },
      remove: true
    }], document);

    if (modifiedDoc) {
      modifiedDoc = visit(modifiedDoc, {
        FragmentDefinition: {
          enter: function enter(node) {
            if (node._ES5ProxyType ? node.get("selectionSet") : node.selectionSet) {
              var _selectionSet2, _selections2;

              var isTypenameOnly = __callKey1$1((_selectionSet2 = node._ES5ProxyType ? node.get("selectionSet") : node.selectionSet, _selections2 = _selectionSet2._ES5ProxyType ? _selectionSet2.get("selections") : _selectionSet2.selections), "every", function (selection) {
                var _name37, _value46;

                return isField(selection) && (_name37 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value46 = _name37._ES5ProxyType ? _name37.get("value") : _name37.value) === '__typename';
              });

              if (isTypenameOnly) {
                return null;
              }
            }
          }
        }
      });
    }

    return modifiedDoc;
  }

  var canUseWeakMap = typeof WeakMap === 'function' && !((typeof navigator === "undefined" ? "undefined" : _typeof_1(navigator)) === 'object' && (navigator._ES5ProxyType ? navigator.get("product") : navigator.product) === 'ReactNative');
  var toString$3 = Object.prototype._ES5ProxyType ? Object.prototype.get("toString") : Object.prototype.toString;

  function cloneDeep(value) {
    return cloneDeepHelper(value, new Map());
  }

  function cloneDeepHelper(val, seen) {
    switch (__callKey1$1(toString$3, "call", val)) {
      case "[object Array]":
        {
          if (__callKey1$1(seen, "has", val)) return __callKey1$1(seen, "get", val);

          var copy_1 = __callKey1$1(val, "slice", 0);

          __callKey2(seen, "set", val, copy_1);

          __callKey1$1(copy_1, "forEach", function (child, i) {
            __setKey(copy_1, i, cloneDeepHelper(child, seen));
          });

          return copy_1;
        }

      case "[object Object]":
        {
          if (__callKey1$1(seen, "has", val)) return __callKey1$1(seen, "get", val);
          var copy_2 = Object.create(Object.getPrototypeOf(val));

          __callKey2(seen, "set", val, copy_2);

          __callKey1$1(Object.compatKeys(val), "forEach", function (key) {
            __setKey(copy_2, key, cloneDeepHelper(val._ES5ProxyType ? val.get(key) : val[key], seen));
          });

          return copy_2;
        }

      default:
        return val;
    }
  }

  function getEnv() {
    if (typeof process !== 'undefined' && "development") {
      return "development";
    }

    return 'development';
  }

  function isEnv(env) {
    return getEnv() === env;
  }

  function isProduction() {
    return isEnv('production') === true;
  }

  function isDevelopment() {
    return isEnv('development') === true;
  }

  function isTest() {
    return isEnv('test') === true;
  }

  function tryFunctionOrLogError(f) {
    try {
      return f();
    } catch (e) {
      if (console._ES5ProxyType ? console.get("error") : console.error) {
        __callKey1$1(console, "error", e);
      }
    }
  }

  function graphQLResultHasError(result) {
    var _errors, _length11;

    return (result._ES5ProxyType ? result.get("errors") : result.errors) && (_errors = result._ES5ProxyType ? result.get("errors") : result.errors, _length11 = _errors._ES5ProxyType ? _errors.get("length") : _errors.length);
  }

  function deepFreeze(o) {
    Object.freeze(o);

    __callKey1$1(Object.getOwnPropertyNames(o), "forEach", function (prop) {
      if ((o._ES5ProxyType ? o.get(prop) : o[prop]) !== null && (_typeof_1(o._ES5ProxyType ? o.get(prop) : o[prop]) === 'object' || typeof (o._ES5ProxyType ? o.get(prop) : o[prop]) === 'function') && !Object.isFrozen(o._ES5ProxyType ? o.get(prop) : o[prop])) {
        deepFreeze(o._ES5ProxyType ? o.get(prop) : o[prop]);
      }
    });

    return o;
  }

  function maybeDeepFreeze(obj) {
    if (isDevelopment() || isTest()) {
      var symbolIsPolyfilled = typeof Symbol === 'function' && typeof Symbol('') === 'string';

      if (!symbolIsPolyfilled) {
        return deepFreeze(obj);
      }
    }

    return obj;
  }

  var hasOwnProperty$3 = Object.prototype._ES5ProxyType ? Object.prototype.get("compatHasOwnProperty") : Object.prototype.compatHasOwnProperty;

  function mergeDeep() {
    var sources = [];

    for (var _i = 0; _i < arguments.length; _i++) {
      __setKey(sources, _i, arguments[_i]);
    }

    return mergeDeepArray(sources);
  }

  function mergeDeepArray(sources) {
    var target = (sources._ES5ProxyType ? sources.get(0) : sources[0]) || {};
    var count = sources._ES5ProxyType ? sources.get("length") : sources.length;

    if (count > 1) {
      var pastCopies = [];
      target = shallowCopyForMerge(target, pastCopies);

      for (var i = 1; i < count; ++i) {
        target = mergeHelper(target, sources._ES5ProxyType ? sources.get(i) : sources[i], pastCopies);
      }
    }

    return target;
  }

  function isObject$3(obj) {
    return obj !== null && _typeof_1(obj) === 'object';
  }

  function mergeHelper(target, source, pastCopies) {
    if (isObject$3(source) && isObject$3(target)) {
      if (Object.isExtensible && !Object.isExtensible(target)) {
        target = shallowCopyForMerge(target, pastCopies);
      }

      __callKey1$1(Object.compatKeys(source), "forEach", function (sourceKey) {
        var sourceValue = source._ES5ProxyType ? source.get(sourceKey) : source[sourceKey];

        if (__callKey2(hasOwnProperty$3, "call", target, sourceKey)) {
          var targetValue = target._ES5ProxyType ? target.get(sourceKey) : target[sourceKey];

          if (sourceValue !== targetValue) {
            __setKey(target, sourceKey, mergeHelper(shallowCopyForMerge(targetValue, pastCopies), sourceValue, pastCopies));
          }
        } else {
          __setKey(target, sourceKey, sourceValue);
        }
      });

      return target;
    }

    return source;
  }

  function shallowCopyForMerge(value, pastCopies) {
    if (value !== null && _typeof_1(value) === 'object' && __callKey1$1(pastCopies, "indexOf", value) < 0) {
      if (Array.compatIsArray(value)) {
        value = __callKey1$1(value, "slice", 0);
      } else {
        value = _assign({
          __proto__: Object.getPrototypeOf(value)
        }, value);
      }

      pastCopies.push(value);
    }

    return value;
  }

  var __inKey$1 = Proxy.inKey;

  var Observable_1 = __callKey1$1(commonjsHelpers, "createCommonjsModule", function (module, exports) {

    Object.compatDefineProperty(exports, "__esModule", {
      value: true
    });

    __setKey(exports, "Observable", void 0);

    function _classCallCheck(instance, Constructor) {
      if (!_instanceof_1(instance, Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }

    function _defineProperties(target, props) {
      for (var i = 0; i < (props._ES5ProxyType ? props.get("length") : props.length); i++) {
        var descriptor = props._ES5ProxyType ? props.get(i) : props[i];

        __setKey(descriptor, "enumerable", (descriptor._ES5ProxyType ? descriptor.get("enumerable") : descriptor.enumerable) || false);

        __setKey(descriptor, "configurable", true);

        if (__inKey$1(descriptor, "value")) __setKey(descriptor, "writable", true);
        Object.compatDefineProperty(target, descriptor._ES5ProxyType ? descriptor.get("key") : descriptor.key, descriptor);
      }
    }

    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps) _defineProperties(Constructor._ES5ProxyType ? Constructor.get("prototype") : Constructor.prototype, protoProps);
      if (staticProps) _defineProperties(Constructor, staticProps);
      return Constructor;
    } // === Symbol Support ===


    var hasSymbols = function hasSymbols() {
      return typeof Symbol === 'function';
    };

    var hasSymbol = function hasSymbol(name) {
      return hasSymbols() && Boolean(Symbol[name]);
    };

    var getSymbol = function getSymbol(name) {
      return hasSymbol(name) ? Symbol[name] : '@@' + name;
    };

    if (hasSymbols() && !hasSymbol('observable')) {
      __setKey(Symbol, "observable", Symbol('observable'));
    }

    var SymbolIterator = getSymbol('iterator');
    var SymbolObservable = getSymbol('observable');
    var SymbolSpecies = getSymbol('species'); // === Abstract Operations ===

    function getMethod(obj, key) {
      var value = obj._ES5ProxyType ? obj.get(key) : obj[key];
      if (value == null) return undefined;
      if (typeof value !== 'function') throw new TypeError(value + ' is not a function');
      return value;
    }

    function getSpecies(obj) {
      var ctor = obj._ES5ProxyType ? obj.get("constructor") : obj.constructor;

      if (ctor !== undefined) {
        ctor = ctor._ES5ProxyType ? ctor.get(SymbolSpecies) : ctor[SymbolSpecies];

        if (ctor === null) {
          ctor = undefined;
        }
      }

      return ctor !== undefined ? ctor : Observable;
    }

    function isObservable(x) {
      return _instanceof_1(x, Observable); // SPEC: Brand check
    }

    function hostReportError(e) {
      if (hostReportError._ES5ProxyType ? hostReportError.get("log") : hostReportError.log) {
        __callKey1$1(hostReportError, "log", e);
      } else {
        setTimeout(function () {
          throw e;
        });
      }
    }

    function enqueue(fn) {
      __callKey1$1(Promise.resolve(), "then", function () {
        try {
          fn();
        } catch (e) {
          hostReportError(e);
        }
      });
    }

    function cleanupSubscription(subscription) {
      var cleanup = subscription._ES5ProxyType ? subscription.get("_cleanup") : subscription._cleanup;
      if (cleanup === undefined) return;

      __setKey(subscription, "_cleanup", undefined);

      if (!cleanup) {
        return;
      }

      try {
        if (typeof cleanup === 'function') {
          cleanup();
        } else {
          var unsubscribe = getMethod(cleanup, 'unsubscribe');

          if (unsubscribe) {
            __callKey1$1(unsubscribe, "call", cleanup);
          }
        }
      } catch (e) {
        hostReportError(e);
      }
    }

    function closeSubscription(subscription) {
      __setKey(subscription, "_observer", undefined);

      __setKey(subscription, "_queue", undefined);

      __setKey(subscription, "_state", 'closed');
    }

    function flushSubscription(subscription) {
      var queue = subscription._ES5ProxyType ? subscription.get("_queue") : subscription._queue;

      if (!queue) {
        return;
      }

      __setKey(subscription, "_queue", undefined);

      __setKey(subscription, "_state", 'ready');

      for (var i = 0; i < (queue._ES5ProxyType ? queue.get("length") : queue.length); ++i) {
        var _i, _type, _i2, _value;

        notifySubscription(subscription, (_i = queue._ES5ProxyType ? queue.get(i) : queue[i], _type = _i._ES5ProxyType ? _i.get("type") : _i.type), (_i2 = queue._ES5ProxyType ? queue.get(i) : queue[i], _value = _i2._ES5ProxyType ? _i2.get("value") : _i2.value));
        if ((subscription._ES5ProxyType ? subscription.get("_state") : subscription._state) === 'closed') break;
      }
    }

    function notifySubscription(subscription, type, value) {
      __setKey(subscription, "_state", 'running');

      var observer = subscription._ES5ProxyType ? subscription.get("_observer") : subscription._observer;

      try {
        var m = getMethod(observer, type);

        switch (type) {
          case 'next':
            if (m) __callKey2(m, "call", observer, value);
            break;

          case 'error':
            closeSubscription(subscription);
            if (m) __callKey2(m, "call", observer, value);else throw value;
            break;

          case 'complete':
            closeSubscription(subscription);
            if (m) __callKey1$1(m, "call", observer);
            break;
        }
      } catch (e) {
        hostReportError(e);
      }

      if ((subscription._ES5ProxyType ? subscription.get("_state") : subscription._state) === 'closed') cleanupSubscription(subscription);else if ((subscription._ES5ProxyType ? subscription.get("_state") : subscription._state) === 'running') __setKey(subscription, "_state", 'ready');
    }

    function onNotify(subscription, type, value) {
      if ((subscription._ES5ProxyType ? subscription.get("_state") : subscription._state) === 'closed') return;

      if ((subscription._ES5ProxyType ? subscription.get("_state") : subscription._state) === 'buffering') {
        (subscription._ES5ProxyType ? subscription.get("_queue") : subscription._queue).push({
          type: type,
          value: value
        });
        return;
      }

      if ((subscription._ES5ProxyType ? subscription.get("_state") : subscription._state) !== 'ready') {
        __setKey(subscription, "_state", 'buffering');

        __setKey(subscription, "_queue", [{
          type: type,
          value: value
        }]);

        enqueue(function () {
          return flushSubscription(subscription);
        });
        return;
      }

      notifySubscription(subscription, type, value);
    }

    var Subscription =
    /*#__PURE__*/
    function () {
      function Subscription(observer, subscriber) {
        _classCallCheck(this, Subscription); // ASSERT: observer is an object
        // ASSERT: subscriber is callable


        __setKey(this, "_cleanup", undefined);

        __setKey(this, "_observer", observer);

        __setKey(this, "_queue", undefined);

        __setKey(this, "_state", 'initializing');

        var subscriptionObserver = new SubscriptionObserver(this);

        try {
          __setKey(this, "_cleanup", __callKey2(subscriber, "call", undefined, subscriptionObserver));
        } catch (e) {
          __callKey1$1(subscriptionObserver, "error", e);
        }

        if ((this._ES5ProxyType ? this.get("_state") : this._state) === 'initializing') __setKey(this, "_state", 'ready');
      }

      _createClass(Subscription, [{
        key: "unsubscribe",
        value: function unsubscribe() {
          if ((this._ES5ProxyType ? this.get("_state") : this._state) !== 'closed') {
            closeSubscription(this);
            cleanupSubscription(this);
          }
        }
      }, {
        key: "closed",
        get: function get() {
          return (this._ES5ProxyType ? this.get("_state") : this._state) === 'closed';
        }
      }]);

      return Subscription;
    }();

    var SubscriptionObserver =
    /*#__PURE__*/
    function () {
      function SubscriptionObserver(subscription) {
        _classCallCheck(this, SubscriptionObserver);

        __setKey(this, "_subscription", subscription);
      }

      _createClass(SubscriptionObserver, [{
        key: "next",
        value: function next(value) {
          onNotify(this._ES5ProxyType ? this.get("_subscription") : this._subscription, 'next', value);
        }
      }, {
        key: "error",
        value: function error(value) {
          onNotify(this._ES5ProxyType ? this.get("_subscription") : this._subscription, 'error', value);
        }
      }, {
        key: "complete",
        value: function complete() {
          onNotify(this._ES5ProxyType ? this.get("_subscription") : this._subscription, 'complete');
        }
      }, {
        key: "closed",
        get: function get() {
          var _subscription, _state;

          return (_subscription = this._ES5ProxyType ? this.get("_subscription") : this._subscription, _state = _subscription._ES5ProxyType ? _subscription.get("_state") : _subscription._state) === 'closed';
        }
      }]);

      return SubscriptionObserver;
    }();

    var Observable =
    /*#__PURE__*/
    function () {
      function Observable(subscriber) {
        _classCallCheck(this, Observable);

        if (!_instanceof_1(this, Observable)) throw new TypeError('Observable cannot be called as a function');
        if (typeof subscriber !== 'function') throw new TypeError('Observable initializer must be a function');

        __setKey(this, "_subscriber", subscriber);
      }

      _createClass(Observable, [{
        key: "subscribe",
        value: function subscribe(observer) {
          if (_typeof_1(observer) !== 'object' || observer === null) {
            observer = {
              next: observer,
              error: arguments[1],
              complete: arguments[2]
            };
          }

          return new Subscription(observer, this._ES5ProxyType ? this.get("_subscriber") : this._subscriber);
        }
      }, {
        key: "forEach",
        value: function forEach(fn) {
          var _this = this;

          return new Promise(function (resolve, reject) {
            if (typeof fn !== 'function') {
              reject(new TypeError(fn + ' is not a function'));
              return;
            }

            function done() {
              __callKey0(subscription, "unsubscribe");

              resolve();
            }

            var subscription = __callKey1$1(_this, "subscribe", {
              next: function next(value) {
                try {
                  fn(value, done);
                } catch (e) {
                  reject(e);

                  __callKey0(subscription, "unsubscribe");
                }
              },
              error: reject,
              complete: resolve
            });
          });
        }
      }, {
        key: "map",
        value: function map(fn) {
          var _this2 = this;

          if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
          var C = getSpecies(this);
          return new C(function (observer) {
            return __callKey1$1(_this2, "subscribe", {
              next: function next(value) {
                try {
                  value = fn(value);
                } catch (e) {
                  return __callKey1$1(observer, "error", e);
                }

                __callKey1$1(observer, "next", value);
              },
              error: function error(e) {
                __callKey1$1(observer, "error", e);
              },
              complete: function complete() {
                __callKey0(observer, "complete");
              }
            });
          });
        }
      }, {
        key: "filter",
        value: function filter(fn) {
          var _this3 = this;

          if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
          var C = getSpecies(this);
          return new C(function (observer) {
            return __callKey1$1(_this3, "subscribe", {
              next: function next(value) {
                try {
                  if (!fn(value)) return;
                } catch (e) {
                  return __callKey1$1(observer, "error", e);
                }

                __callKey1$1(observer, "next", value);
              },
              error: function error(e) {
                __callKey1$1(observer, "error", e);
              },
              complete: function complete() {
                __callKey0(observer, "complete");
              }
            });
          });
        }
      }, {
        key: "reduce",
        value: function reduce(fn) {
          var _this4 = this;

          if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
          var C = getSpecies(this);
          var hasSeed = arguments.length > 1;
          var hasValue = false;
          var seed = arguments[1];
          var acc = seed;
          return new C(function (observer) {
            return __callKey1$1(_this4, "subscribe", {
              next: function next(value) {
                var first = !hasValue;
                hasValue = true;

                if (!first || hasSeed) {
                  try {
                    acc = fn(acc, value);
                  } catch (e) {
                    return __callKey1$1(observer, "error", e);
                  }
                } else {
                  acc = value;
                }
              },
              error: function error(e) {
                __callKey1$1(observer, "error", e);
              },
              complete: function complete() {
                if (!hasValue && !hasSeed) return __callKey1$1(observer, "error", new TypeError('Cannot reduce an empty sequence'));

                __callKey1$1(observer, "next", acc);

                __callKey0(observer, "complete");
              }
            });
          });
        }
      }, {
        key: "concat",
        value: function concat() {
          var _this5 = this;

          for (var _len = arguments.length, sources = new Array(_len), _key = 0; _key < _len; _key++) {
            __setKey(sources, _key, arguments[_key]);
          }

          var C = getSpecies(this);
          return new C(function (observer) {
            var subscription;
            var index = 0;

            function startNext(next) {
              subscription = __callKey1$1(next, "subscribe", {
                next: function next(v) {
                  __callKey1$1(observer, "next", v);
                },
                error: function error(e) {
                  __callKey1$1(observer, "error", e);
                },
                complete: function complete() {
                  if (index === (sources._ES5ProxyType ? sources.get("length") : sources.length)) {
                    subscription = undefined;

                    __callKey0(observer, "complete");
                  } else {
                    var _ref, _ref2;

                    startNext(__callKey1$1(C, "from", (_ref = index++, _ref2 = sources._ES5ProxyType ? sources.get(_ref) : sources[_ref])));
                  }
                }
              });
            }

            startNext(_this5);
            return function () {
              if (subscription) {
                __callKey0(subscription, "unsubscribe");

                subscription = undefined;
              }
            };
          });
        }
      }, {
        key: "flatMap",
        value: function flatMap(fn) {
          var _this6 = this;

          if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
          var C = getSpecies(this);
          return new C(function (observer) {
            var subscriptions = [];

            var outer = __callKey1$1(_this6, "subscribe", {
              next: function next(value) {
                if (fn) {
                  try {
                    value = fn(value);
                  } catch (e) {
                    return __callKey1$1(observer, "error", e);
                  }
                }

                var inner = __callKey1$1(__callKey1$1(C, "from", value), "subscribe", {
                  next: function next(value) {
                    __callKey1$1(observer, "next", value);
                  },
                  error: function error(e) {
                    __callKey1$1(observer, "error", e);
                  },
                  complete: function complete() {
                    var i = __callKey1$1(subscriptions, "indexOf", inner);

                    if (i >= 0) subscriptions.splice(i, 1);
                    completeIfDone();
                  }
                });

                subscriptions.push(inner);
              },
              error: function error(e) {
                __callKey1$1(observer, "error", e);
              },
              complete: function complete() {
                completeIfDone();
              }
            });

            function completeIfDone() {
              if ((outer._ES5ProxyType ? outer.get("closed") : outer.closed) && (subscriptions._ES5ProxyType ? subscriptions.get("length") : subscriptions.length) === 0) __callKey0(observer, "complete");
            }

            return function () {
              __callKey1$1(subscriptions, "forEach", function (s) {
                return __callKey0(s, "unsubscribe");
              });

              __callKey0(outer, "unsubscribe");
            };
          });
        }
      }, {
        key: SymbolObservable,
        value: function value() {
          return this;
        }
      }], [{
        key: "from",
        value: function from(x) {
          var C = typeof this === 'function' ? this : Observable;
          if (x == null) throw new TypeError(x + ' is not an object');
          var method = getMethod(x, SymbolObservable);

          if (method) {
            var observable = __callKey1$1(method, "call", x);

            if (Object(observable) !== observable) throw new TypeError(observable + ' is not an object');
            if (isObservable(observable) && (observable._ES5ProxyType ? observable.get("constructor") : observable.constructor) === C) return observable;
            return new C(function (observer) {
              return __callKey1$1(observable, "subscribe", observer);
            });
          }

          if (hasSymbol('iterator')) {
            method = getMethod(x, SymbolIterator);

            if (method) {
              return new C(function (observer) {
                enqueue(function () {
                  if (observer._ES5ProxyType ? observer.get("closed") : observer.closed) return;
                  var _iteratorNormalCompletion = true;
                  var _didIteratorError = false;
                  var _iteratorError = undefined;

                  try {
                    for (var _iterator = __callKey0(__callKey1$1(method, "call", x), Symbol.iterator), _step; !(_iteratorNormalCompletion = (_step2 = _step = __callKey0(_iterator, "next"), _done = _step2._ES5ProxyType ? _step2.get("done") : _step2.done)); _iteratorNormalCompletion = true) {
                      var _step2, _done;

                      var _item = _step._ES5ProxyType ? _step.get("value") : _step.value;

                      __callKey1$1(observer, "next", _item);

                      if (observer._ES5ProxyType ? observer.get("closed") : observer.closed) return;
                    }
                  } catch (err) {
                    _didIteratorError = true;
                    _iteratorError = err;
                  } finally {
                    try {
                      if (!_iteratorNormalCompletion && (_iterator._ES5ProxyType ? _iterator.get("return") : _iterator.return) != null) {
                        __callKey0(_iterator, "return");
                      }
                    } finally {
                      if (_didIteratorError) {
                        throw _iteratorError;
                      }
                    }
                  }

                  __callKey0(observer, "complete");
                });
              });
            }
          }

          if (Array.compatIsArray(x)) {
            return new C(function (observer) {
              enqueue(function () {
                if (observer._ES5ProxyType ? observer.get("closed") : observer.closed) return;

                for (var i = 0; i < (x._ES5ProxyType ? x.get("length") : x.length); ++i) {
                  __callKey1$1(observer, "next", x._ES5ProxyType ? x.get(i) : x[i]);

                  if (observer._ES5ProxyType ? observer.get("closed") : observer.closed) return;
                }

                __callKey0(observer, "complete");
              });
            });
          }

          throw new TypeError(x + ' is not observable');
        }
      }, {
        key: "of",
        value: function of() {
          for (var _len2 = arguments.length, items = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
            __setKey(items, _key2, arguments[_key2]);
          }

          var C = typeof this === 'function' ? this : Observable;
          return new C(function (observer) {
            enqueue(function () {
              if (observer._ES5ProxyType ? observer.get("closed") : observer.closed) return;

              for (var i = 0; i < (items._ES5ProxyType ? items.get("length") : items.length); ++i) {
                __callKey1$1(observer, "next", items._ES5ProxyType ? items.get(i) : items[i]);

                if (observer._ES5ProxyType ? observer.get("closed") : observer.closed) return;
              }

              __callKey0(observer, "complete");
            });
          });
        }
      }, {
        key: SymbolSpecies,
        get: function get() {
          return this;
        }
      }]);

      return Observable;
    }();

    __setKey(exports, "Observable", Observable);

    if (hasSymbols()) {
      Object.compatDefineProperty(Observable, Symbol('extensions'), {
        value: {
          symbol: SymbolObservable,
          hostReportError: hostReportError
        },
        configurable: true
      });
    }
  });

  __callKey1$1(commonjsHelpers, "unwrapExports", Observable_1);
  var Observable_2 = Observable_1._ES5ProxyType ? Observable_1.get("Observable") : Observable_1.Observable;

  var zenObservable = Observable_1._ES5ProxyType ? Observable_1.get("Observable") : Observable_1.Observable;

  var Observable = zenObservable;
  var Observable$1 = registerComponent(Observable, {
    tmpl: _tmpl
  });

  function validateOperation(operation) {
    var OPERATION_FIELDS = ['query', 'operationName', 'variables', 'extensions', 'context'];

    for (var _i = 0, _a = Object.compatKeys(operation); _i < (_a._ES5ProxyType ? _a.get("length") : _a.length); _i++) {
      var key = _a._ES5ProxyType ? _a.get(_i) : _a[_i];

      if (__callKey1$1(OPERATION_FIELDS, "indexOf", key) < 0) {
        throw  new InvariantError("illegal argument: " + key);
      }
    }

    return operation;
  }

  var LinkError = function (_super) {
    __extends(LinkError, _super);

    function LinkError(message, link) {
      var _this = __callKey2(_super, "call", this, message) || this;

      __setKey(_this, "link", link);

      return _this;
    }

    return LinkError;
  }(Error);

  function isTerminating(link) {
    var _request, _length;

    return (_request = link._ES5ProxyType ? link.get("request") : link.request, _length = _request._ES5ProxyType ? _request.get("length") : _request.length) <= 1;
  }

  function fromError(errorValue) {
    return new Observable$1(function (observer) {
      __callKey1$1(observer, "error", errorValue);
    });
  }

  function transformOperation(operation) {
    var transformedOperation = {
      variables: (operation._ES5ProxyType ? operation.get("variables") : operation.variables) || {},
      extensions: (operation._ES5ProxyType ? operation.get("extensions") : operation.extensions) || {},
      operationName: operation._ES5ProxyType ? operation.get("operationName") : operation.operationName,
      query: operation._ES5ProxyType ? operation.get("query") : operation.query
    };

    if (!(transformedOperation._ES5ProxyType ? transformedOperation.get("operationName") : transformedOperation.operationName)) {
      __setKey(transformedOperation, "operationName", typeof (transformedOperation._ES5ProxyType ? transformedOperation.get("query") : transformedOperation.query) !== 'string' ? getOperationName(transformedOperation._ES5ProxyType ? transformedOperation.get("query") : transformedOperation.query) : '');
    }

    return transformedOperation;
  }

  function createOperation(starting, operation) {
    var context = _assign({}, starting);

    var setContext = function setContext(next) {
      if (typeof next === 'function') {
        context = _assign({}, context, next(context));
      } else {
        context = _assign({}, context, next);
      }
    };

    var getContext = function getContext() {
      return _assign({}, context);
    };

    Object.compatDefineProperty(operation, 'setContext', {
      enumerable: false,
      value: setContext
    });
    Object.compatDefineProperty(operation, 'getContext', {
      enumerable: false,
      value: getContext
    });
    Object.compatDefineProperty(operation, 'toKey', {
      enumerable: false,
      value: function value() {
        return getKey(operation);
      }
    });
    return operation;
  }

  function getKey(operation) {
    var query = operation._ES5ProxyType ? operation.get("query") : operation.query,
        variables = operation._ES5ProxyType ? operation.get("variables") : operation.variables,
        operationName = operation._ES5ProxyType ? operation.get("operationName") : operation.operationName;
    return JSON.stringify([operationName, query, variables]);
  }

  function passthrough(op, forward) {
    return forward ? forward(op) : __callKey0(Observable$1, "of");
  }

  function toLink(handler) {
    return typeof handler === 'function' ? new ApolloLink(handler) : handler;
  }

  function empty() {
    return new ApolloLink(function () {
      return __callKey0(Observable$1, "of");
    });
  }

  function from(links) {
    if ((links._ES5ProxyType ? links.get("length") : links.length) === 0) return empty();
    return __callKey1$1(__callKey1$1(links, "map", toLink), "reduce", function (x, y) {
      return __concat(x, y);
    });
  }

  function split(test, left, right) {
    var leftLink = toLink(left);
    var rightLink = toLink(right || new ApolloLink(passthrough));

    if (isTerminating(leftLink) && isTerminating(rightLink)) {
      return new ApolloLink(function (operation) {
        return test(operation) ? __callKey1$1(leftLink, "request", operation) || __callKey0(Observable$1, "of") : __callKey1$1(rightLink, "request", operation) || __callKey0(Observable$1, "of");
      });
    } else {
      return new ApolloLink(function (operation, forward) {
        return test(operation) ? __callKey2(leftLink, "request", operation, forward) || __callKey0(Observable$1, "of") : __callKey2(rightLink, "request", operation, forward) || __callKey0(Observable$1, "of");
      });
    }
  }

  var concat = function concat(first, second) {
    var firstLink = toLink(first);

    if (isTerminating(firstLink)) {
       __callKey1$1(invariant$3, "warn", new LinkError("You are calling concat on a terminating link, which will have no effect", firstLink));
      return firstLink;
    }

    var nextLink = toLink(second);

    if (isTerminating(nextLink)) {
      return new ApolloLink(function (operation) {
        return __callKey2(firstLink, "request", operation, function (op) {
          return __callKey1$1(nextLink, "request", op) || __callKey0(Observable$1, "of");
        }) || __callKey0(Observable$1, "of");
      });
    } else {
      return new ApolloLink(function (operation, forward) {
        return __callKey2(firstLink, "request", operation, function (op) {
          return __callKey2(nextLink, "request", op, forward) || __callKey0(Observable$1, "of");
        }) || __callKey0(Observable$1, "of");
      });
    }
  };

  var ApolloLink = function () {
    function ApolloLink(request) {
      if (request) __setKey(this, "request", request);
    }

    __setKey(ApolloLink._ES5ProxyType ? ApolloLink.get("prototype") : ApolloLink.prototype, "split", function (test, left, right) {
      return __concat(this, split(test, left, right || new ApolloLink(passthrough)));
    });

    __setKey(ApolloLink._ES5ProxyType ? ApolloLink.get("prototype") : ApolloLink.prototype, "concat", function (next) {
      return concat(this, next);
    });

    __setKey(ApolloLink._ES5ProxyType ? ApolloLink.get("prototype") : ApolloLink.prototype, "request", function (operation, forward) {
      throw  new InvariantError('request is not implemented');
    });

    __setKey(ApolloLink, "empty", empty);

    __setKey(ApolloLink, "from", from);

    __setKey(ApolloLink, "split", split);

    __setKey(ApolloLink, "execute", execute);

    return ApolloLink;
  }();

  function execute(link, operation) {
    return __callKey1$1(link, "request", createOperation(operation._ES5ProxyType ? operation.get("context") : operation.context, transformOperation(validateOperation(operation)))) || __callKey0(Observable$1, "of");
  }

  function symbolObservablePonyfill(root) {
    var result;

    var _Symbol = root._ES5ProxyType ? root.get("Symbol") : root.Symbol;

    if (typeof _Symbol === 'function') {
      if (_Symbol._ES5ProxyType ? _Symbol.get("observable") : _Symbol.observable) {
        result = _Symbol._ES5ProxyType ? _Symbol.get("observable") : _Symbol.observable;
      } else {
        result = _Symbol('observable');

        __setKey(_Symbol, "observable", result);
      }
    } else {
      result = '@@observable';
    }

    return result;
  }

  var root;

  if (typeof self !== 'undefined') {
    root = self;
  } else if (typeof window !== 'undefined') {
    root = window;
  } else if (typeof global !== 'undefined') {
    root = global;
  } else if (typeof module !== 'undefined') {
    root = module;
  } else {
    root = Function('return this')();
  }

  var result = symbolObservablePonyfill(root);
  var $$observable = registerComponent(result, {
    tmpl: _tmpl
  });

  var NetworkStatus;

  (function (NetworkStatus) {
    __setKey(NetworkStatus, __setKey(NetworkStatus, "loading", 1), "loading");

    __setKey(NetworkStatus, __setKey(NetworkStatus, "setVariables", 2), "setVariables");

    __setKey(NetworkStatus, __setKey(NetworkStatus, "fetchMore", 3), "fetchMore");

    __setKey(NetworkStatus, __setKey(NetworkStatus, "refetch", 4), "refetch");

    __setKey(NetworkStatus, __setKey(NetworkStatus, "poll", 6), "poll");

    __setKey(NetworkStatus, __setKey(NetworkStatus, "ready", 7), "ready");

    __setKey(NetworkStatus, __setKey(NetworkStatus, "error", 8), "error");
  })(NetworkStatus || (NetworkStatus = {}));

  function isNetworkRequestInFlight(networkStatus) {
    return networkStatus < 7;
  }

  var Observable$2 = function (_super) {
    __extends(Observable, _super);

    function Observable() {
      return _super !== null && __callKey2(_super, "apply", this, arguments) || this;
    }

    __setKey(Observable._ES5ProxyType ? Observable.get("prototype") : Observable.prototype, $$observable, function () {
      return this;
    });

    __setKey(Observable._ES5ProxyType ? Observable.get("prototype") : Observable.prototype, '@@observable', function () {
      return this;
    });

    return Observable;
  }(Observable$1);

  function isNonEmptyArray(value) {
    return Array.compatIsArray(value) && (value._ES5ProxyType ? value.get("length") : value.length) > 0;
  }

  function isApolloError(err) {
    return __hasOwnProperty(err, 'graphQLErrors');
  }

  var generateErrorMessage = function generateErrorMessage(err) {
    var message = '';

    if (isNonEmptyArray(err._ES5ProxyType ? err.get("graphQLErrors") : err.graphQLErrors)) {
      __callKey1$1(err._ES5ProxyType ? err.get("graphQLErrors") : err.graphQLErrors, "forEach", function (graphQLError) {
        var errorMessage = graphQLError ? graphQLError._ES5ProxyType ? graphQLError.get("message") : graphQLError.message : 'Error message not found.';
        message += "GraphQL error: " + errorMessage + "\n";
      });
    }

    if (err._ES5ProxyType ? err.get("networkError") : err.networkError) {
      var _networkError, _message;

      message += 'Network error: ' + (_networkError = err._ES5ProxyType ? err.get("networkError") : err.networkError, _message = _networkError._ES5ProxyType ? _networkError.get("message") : _networkError.message) + '\n';
    }

    message = __callKey2(message, "replace", /\n$/, '');
    return message;
  };

  var ApolloError = function (_super) {
    __extends(ApolloError, _super);

    function ApolloError(_a) {
      var graphQLErrors = _a._ES5ProxyType ? _a.get("graphQLErrors") : _a.graphQLErrors,
          networkError = _a._ES5ProxyType ? _a.get("networkError") : _a.networkError,
          errorMessage = _a._ES5ProxyType ? _a.get("errorMessage") : _a.errorMessage,
          extraInfo = _a._ES5ProxyType ? _a.get("extraInfo") : _a.extraInfo;

      var _this = __callKey2(_super, "call", this, errorMessage) || this;

      __setKey(_this, "graphQLErrors", graphQLErrors || []);

      __setKey(_this, "networkError", networkError || null);

      if (!errorMessage) {
        __setKey(_this, "message", generateErrorMessage(_this));
      } else {
        __setKey(_this, "message", errorMessage);
      }

      __setKey(_this, "extraInfo", extraInfo);

      __setKey(_this, "__proto__", ApolloError._ES5ProxyType ? ApolloError.get("prototype") : ApolloError.prototype);

      return _this;
    }

    return ApolloError;
  }(Error);

  var FetchType;

  (function (FetchType) {
    __setKey(FetchType, __setKey(FetchType, "normal", 1), "normal");

    __setKey(FetchType, __setKey(FetchType, "refetch", 2), "refetch");

    __setKey(FetchType, __setKey(FetchType, "poll", 3), "poll");
  })(FetchType || (FetchType = {}));

  var hasError = function hasError(storeValue, policy) {
    if (policy === void 0) {
      policy = 'none';
    }

    return storeValue && ((storeValue._ES5ProxyType ? storeValue.get("networkError") : storeValue.networkError) || policy === 'none' && isNonEmptyArray(storeValue._ES5ProxyType ? storeValue.get("graphQLErrors") : storeValue.graphQLErrors));
  };

  var ObservableQuery = function (_super) {
    __extends(ObservableQuery, _super);

    function ObservableQuery(_a) {
      var _name, _value;

      var queryManager = _a._ES5ProxyType ? _a.get("queryManager") : _a.queryManager,
          options = _a._ES5ProxyType ? _a.get("options") : _a.options,
          _b = _a._ES5ProxyType ? _a.get("shouldSubscribe") : _a.shouldSubscribe,
          shouldSubscribe = _b === void 0 ? true : _b;

      var _this = __callKey2(_super, "call", this, function (observer) {
        return __callKey1$1(_this, "onSubscribe", observer);
      }) || this;

      __setKey(_this, "observers", new Set());

      __setKey(_this, "subscriptions", new Set());

      __setKey(_this, "isTornDown", false);

      __setKey(_this, "options", options);

      __setKey(_this, "variables", (options._ES5ProxyType ? options.get("variables") : options.variables) || {});

      __setKey(_this, "queryId", __callKey0(queryManager, "generateQueryId"));

      __setKey(_this, "shouldSubscribe", shouldSubscribe);

      var opDef = getOperationDefinition(options._ES5ProxyType ? options.get("query") : options.query);

      __setKey(_this, "queryName", opDef && (opDef._ES5ProxyType ? opDef.get("name") : opDef.name) && (_name = opDef._ES5ProxyType ? opDef.get("name") : opDef.name, _value = _name._ES5ProxyType ? _name.get("value") : _name.value));

      __setKey(_this, "queryManager", queryManager);

      return _this;
    }

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "result", function () {
      var _this = this;

      return new Promise(function (resolve, reject) {
        var observer = {
          next: function next(result) {
            var _observers, _size;

            resolve(result);

            __callKey1$1(_this._ES5ProxyType ? _this.get("observers") : _this.observers, "delete", observer);

            if (!(_observers = _this._ES5ProxyType ? _this.get("observers") : _this.observers, _size = _observers._ES5ProxyType ? _observers.get("size") : _observers.size)) {
              __callKey1$1(_this._ES5ProxyType ? _this.get("queryManager") : _this.queryManager, "removeQuery", _this._ES5ProxyType ? _this.get("queryId") : _this.queryId);
            }

            setTimeout(function () {
              __callKey0(subscription, "unsubscribe");
            }, 0);
          },
          error: reject
        };

        var subscription = __callKey1$1(_this, "subscribe", observer);
      });
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "currentResult", function () {
      var result = __callKey0(this, "getCurrentResult");

      if ((result._ES5ProxyType ? result.get("data") : result.data) === undefined) {
        __setKey(result, "data", {});
      }

      return result;
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "getCurrentResult", function () {
      var _queryManager, _queryStore, _options, _fetchPolicy;

      if (this._ES5ProxyType ? this.get("isTornDown") : this.isTornDown) {
        var lastResult = this._ES5ProxyType ? this.get("lastResult") : this.lastResult;
        return {
          data: !(this._ES5ProxyType ? this.get("lastError") : this.lastError) && lastResult && (lastResult._ES5ProxyType ? lastResult.get("data") : lastResult.data) || void 0,
          error: this._ES5ProxyType ? this.get("lastError") : this.lastError,
          loading: false,
          networkStatus: NetworkStatus._ES5ProxyType ? NetworkStatus.get("error") : NetworkStatus.error
        };
      }

      var _a = __callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "getCurrentQueryResult", this),
          data = _a._ES5ProxyType ? _a.get("data") : _a.data,
          partial = _a._ES5ProxyType ? _a.get("partial") : _a.partial;

      var queryStoreValue = __callKey1$1((_queryManager = this._ES5ProxyType ? this.get("queryManager") : this.queryManager, _queryStore = _queryManager._ES5ProxyType ? _queryManager.get("queryStore") : _queryManager.queryStore), "get", this._ES5ProxyType ? this.get("queryId") : this.queryId);

      var result;
      var fetchPolicy = (_options = this._ES5ProxyType ? this.get("options") : this.options, _fetchPolicy = _options._ES5ProxyType ? _options.get("fetchPolicy") : _options.fetchPolicy);
      var isNetworkFetchPolicy = fetchPolicy === 'network-only' || fetchPolicy === 'no-cache';

      if (queryStoreValue) {
        var _options2, _errorPolicy, _options5, _errorPolicy2;

        var networkStatus = queryStoreValue._ES5ProxyType ? queryStoreValue.get("networkStatus") : queryStoreValue.networkStatus;

        if (hasError(queryStoreValue, (_options2 = this._ES5ProxyType ? this.get("options") : this.options, _errorPolicy = _options2._ES5ProxyType ? _options2.get("errorPolicy") : _options2.errorPolicy))) {
          return {
            data: void 0,
            loading: false,
            networkStatus: networkStatus,
            error: new ApolloError({
              graphQLErrors: queryStoreValue._ES5ProxyType ? queryStoreValue.get("graphQLErrors") : queryStoreValue.graphQLErrors,
              networkError: queryStoreValue._ES5ProxyType ? queryStoreValue.get("networkError") : queryStoreValue.networkError
            })
          };
        }

        if (queryStoreValue._ES5ProxyType ? queryStoreValue.get("variables") : queryStoreValue.variables) {
          var _options3, _variables, _options4, _variables2;

          __setKey(this._ES5ProxyType ? this.get("options") : this.options, "variables", _assign(_assign({}, (_options3 = this._ES5ProxyType ? this.get("options") : this.options, _variables = _options3._ES5ProxyType ? _options3.get("variables") : _options3.variables)), queryStoreValue._ES5ProxyType ? queryStoreValue.get("variables") : queryStoreValue.variables));

          __setKey(this, "variables", (_options4 = this._ES5ProxyType ? this.get("options") : this.options, _variables2 = _options4._ES5ProxyType ? _options4.get("variables") : _options4.variables));
        }

        result = {
          data: data,
          loading: isNetworkRequestInFlight(networkStatus),
          networkStatus: networkStatus
        };

        if ((queryStoreValue._ES5ProxyType ? queryStoreValue.get("graphQLErrors") : queryStoreValue.graphQLErrors) && (_options5 = this._ES5ProxyType ? this.get("options") : this.options, _errorPolicy2 = _options5._ES5ProxyType ? _options5.get("errorPolicy") : _options5.errorPolicy) === 'all') {
          __setKey(result, "errors", queryStoreValue._ES5ProxyType ? queryStoreValue.get("graphQLErrors") : queryStoreValue.graphQLErrors);
        }
      } else {
        var loading = isNetworkFetchPolicy || partial && fetchPolicy !== 'cache-only';
        result = {
          data: data,
          loading: loading,
          networkStatus: loading ? NetworkStatus._ES5ProxyType ? NetworkStatus.get("loading") : NetworkStatus.loading : NetworkStatus._ES5ProxyType ? NetworkStatus.get("ready") : NetworkStatus.ready
        };
      }

      if (!partial) {
        __callKey1$1(this, "updateLastResult", _assign(_assign({}, result), {
          stale: false
        }));
      }

      return _assign(_assign({}, result), {
        partial: partial
      });
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "isDifferentFromLastResult", function (newResult) {
      var snapshot = this._ES5ProxyType ? this.get("lastResultSnapshot") : this.lastResultSnapshot;
      return !(snapshot && newResult && (snapshot._ES5ProxyType ? snapshot.get("networkStatus") : snapshot.networkStatus) === (newResult._ES5ProxyType ? newResult.get("networkStatus") : newResult.networkStatus) && (snapshot._ES5ProxyType ? snapshot.get("stale") : snapshot.stale) === (newResult._ES5ProxyType ? newResult.get("stale") : newResult.stale) && equal(snapshot._ES5ProxyType ? snapshot.get("data") : snapshot.data, newResult._ES5ProxyType ? newResult.get("data") : newResult.data));
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "getLastResult", function () {
      return this._ES5ProxyType ? this.get("lastResult") : this.lastResult;
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "getLastError", function () {
      return this._ES5ProxyType ? this.get("lastError") : this.lastError;
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "resetLastResults", function () {
      __deleteKey(this, "lastResult");

      __deleteKey(this, "lastResultSnapshot");

      __deleteKey(this, "lastError");

      __setKey(this, "isTornDown", false);
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "resetQueryStoreErrors", function () {
      var _queryManager2, _queryStore2;

      var queryStore = __callKey1$1((_queryManager2 = this._ES5ProxyType ? this.get("queryManager") : this.queryManager, _queryStore2 = _queryManager2._ES5ProxyType ? _queryManager2.get("queryStore") : _queryManager2.queryStore), "get", this._ES5ProxyType ? this.get("queryId") : this.queryId);

      if (queryStore) {
        __setKey(queryStore, "networkError", null);

        __setKey(queryStore, "graphQLErrors", []);
      }
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "refetch", function (variables) {
      var _options6, _fetchPolicy2, _options7, _variables3;

      var fetchPolicy = (_options6 = this._ES5ProxyType ? this.get("options") : this.options, _fetchPolicy2 = _options6._ES5ProxyType ? _options6.get("fetchPolicy") : _options6.fetchPolicy);

      if (fetchPolicy === 'cache-only') {
        return Promise.reject( new InvariantError('cache-only fetchPolicy option should not be used together with query refetch.'));
      }

      if (fetchPolicy !== 'no-cache' && fetchPolicy !== 'cache-and-network') {
        fetchPolicy = 'network-only';
      }

      if (!equal(this._ES5ProxyType ? this.get("variables") : this.variables, variables)) {
        __setKey(this, "variables", _assign(_assign({}, this._ES5ProxyType ? this.get("variables") : this.variables), variables));
      }

      if (!equal((_options7 = this._ES5ProxyType ? this.get("options") : this.options, _variables3 = _options7._ES5ProxyType ? _options7.get("variables") : _options7.variables), this._ES5ProxyType ? this.get("variables") : this.variables)) {
        var _options8, _variables4;

        __setKey(this._ES5ProxyType ? this.get("options") : this.options, "variables", _assign(_assign({}, (_options8 = this._ES5ProxyType ? this.get("options") : this.options, _variables4 = _options8._ES5ProxyType ? _options8.get("variables") : _options8.variables)), this._ES5ProxyType ? this.get("variables") : this.variables));
      }

      return __callKey3(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "fetchQuery", this._ES5ProxyType ? this.get("queryId") : this.queryId, _assign(_assign({}, this._ES5ProxyType ? this.get("options") : this.options), {
        fetchPolicy: fetchPolicy
      }), FetchType._ES5ProxyType ? FetchType.get("refetch") : FetchType.refetch);
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "fetchMore", function (fetchMoreOptions) {
      var _this = this;

       invariant$3(fetchMoreOptions._ES5ProxyType ? fetchMoreOptions.get("updateQuery") : fetchMoreOptions.updateQuery, 'updateQuery option is required. This function defines how to update the query data with the new results.');

      var combinedOptions = _assign(_assign({}, (fetchMoreOptions._ES5ProxyType ? fetchMoreOptions.get("query") : fetchMoreOptions.query) ? fetchMoreOptions : _assign(_assign(_assign({}, this._ES5ProxyType ? this.get("options") : this.options), fetchMoreOptions), {
        variables: _assign(_assign({}, this._ES5ProxyType ? this.get("variables") : this.variables), fetchMoreOptions._ES5ProxyType ? fetchMoreOptions.get("variables") : fetchMoreOptions.variables)
      })), {
        fetchPolicy: 'network-only'
      });

      var qid = __callKey0(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "generateQueryId");

      return __callKey2(__callKey4(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "fetchQuery", qid, combinedOptions, FetchType._ES5ProxyType ? FetchType.get("normal") : FetchType.normal, this._ES5ProxyType ? this.get("queryId") : this.queryId), "then", function (fetchMoreResult) {
        __callKey1$1(_this, "updateQuery", function (previousResult) {
          return __callKey2(fetchMoreOptions, "updateQuery", previousResult, {
            fetchMoreResult: fetchMoreResult._ES5ProxyType ? fetchMoreResult.get("data") : fetchMoreResult.data,
            variables: combinedOptions._ES5ProxyType ? combinedOptions.get("variables") : combinedOptions.variables
          });
        });

        __callKey1$1(_this._ES5ProxyType ? _this.get("queryManager") : _this.queryManager, "stopQuery", qid);

        return fetchMoreResult;
      }, function (error) {
        __callKey1$1(_this._ES5ProxyType ? _this.get("queryManager") : _this.queryManager, "stopQuery", qid);

        throw error;
      });
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "subscribeToMore", function (options) {
      var _this = this;

      var subscription = __callKey1$1(__callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "startGraphQLSubscription", {
        query: options._ES5ProxyType ? options.get("document") : options.document,
        variables: options._ES5ProxyType ? options.get("variables") : options.variables
      }), "subscribe", {
        next: function next(subscriptionData) {
          var updateQuery = options._ES5ProxyType ? options.get("updateQuery") : options.updateQuery;

          if (updateQuery) {
            __callKey1$1(_this, "updateQuery", function (previous, _a) {
              var variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables;
              return updateQuery(previous, {
                subscriptionData: subscriptionData,
                variables: variables
              });
            });
          }
        },
        error: function error(err) {
          if (options._ES5ProxyType ? options.get("onError") : options.onError) {
            __callKey1$1(options, "onError", err);

            return;
          }

           __callKey2(invariant$3, "error", 'Unhandled GraphQL subscription error', err);
        }
      });

      __callKey1$1(this._ES5ProxyType ? this.get("subscriptions") : this.subscriptions, "add", subscription);

      return function () {
        if (__callKey1$1(_this._ES5ProxyType ? _this.get("subscriptions") : _this.subscriptions, "delete", subscription)) {
          __callKey0(subscription, "unsubscribe");
        }
      };
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "setOptions", function (opts) {
      var _options9, _fetchPolicy3, _options10, _variables5;

      var oldFetchPolicy = (_options9 = this._ES5ProxyType ? this.get("options") : this.options, _fetchPolicy3 = _options9._ES5ProxyType ? _options9.get("fetchPolicy") : _options9.fetchPolicy);

      __setKey(this, "options", _assign(_assign({}, this._ES5ProxyType ? this.get("options") : this.options), opts));

      if (opts._ES5ProxyType ? opts.get("pollInterval") : opts.pollInterval) {
        __callKey1$1(this, "startPolling", opts._ES5ProxyType ? opts.get("pollInterval") : opts.pollInterval);
      } else if ((opts._ES5ProxyType ? opts.get("pollInterval") : opts.pollInterval) === 0) {
        __callKey0(this, "stopPolling");
      }

      var fetchPolicy = opts._ES5ProxyType ? opts.get("fetchPolicy") : opts.fetchPolicy;
      return __callKey3(this, "setVariables", (_options10 = this._ES5ProxyType ? this.get("options") : this.options, _variables5 = _options10._ES5ProxyType ? _options10.get("variables") : _options10.variables), oldFetchPolicy !== fetchPolicy && (oldFetchPolicy === 'cache-only' || oldFetchPolicy === 'standby' || fetchPolicy === 'network-only'), opts._ES5ProxyType ? opts.get("fetchResults") : opts.fetchResults);
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "setVariables", function (variables, tryFetch, fetchResults) {
      var _observers3, _size3;

      if (tryFetch === void 0) {
        tryFetch = false;
      }

      if (fetchResults === void 0) {
        fetchResults = true;
      }

      __setKey(this, "isTornDown", false);

      variables = variables || (this._ES5ProxyType ? this.get("variables") : this.variables);

      if (!tryFetch && equal(variables, this._ES5ProxyType ? this.get("variables") : this.variables)) {
        var _observers2, _size2;

        return (_observers2 = this._ES5ProxyType ? this.get("observers") : this.observers, _size2 = _observers2._ES5ProxyType ? _observers2.get("size") : _observers2.size) && fetchResults ? __callKey0(this, "result") : Promise.resolve();
      }

      __setKey(this, "variables", __setKey(this._ES5ProxyType ? this.get("options") : this.options, "variables", variables));

      if (!(_observers3 = this._ES5ProxyType ? this.get("observers") : this.observers, _size3 = _observers3._ES5ProxyType ? _observers3.get("size") : _observers3.size)) {
        return Promise.resolve();
      }

      return __callKey2(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "fetchQuery", this._ES5ProxyType ? this.get("queryId") : this.queryId, this._ES5ProxyType ? this.get("options") : this.options);
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "updateQuery", function (mapFn) {
      var queryManager = this._ES5ProxyType ? this.get("queryManager") : this.queryManager;

      var _a = __callKey1$1(queryManager, "getQueryWithPreviousResult", this._ES5ProxyType ? this.get("queryId") : this.queryId),
          previousResult = _a._ES5ProxyType ? _a.get("previousResult") : _a.previousResult,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          document = _a._ES5ProxyType ? _a.get("document") : _a.document;

      var newResult = tryFunctionOrLogError(function () {
        return mapFn(previousResult, {
          variables: variables
        });
      });

      if (newResult) {
        __callKey3(queryManager._ES5ProxyType ? queryManager.get("dataStore") : queryManager.dataStore, "markUpdateQueryResult", document, variables, newResult);

        __callKey0(queryManager, "broadcastQueries");
      }
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "stopPolling", function () {
      __callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "stopPollingQuery", this._ES5ProxyType ? this.get("queryId") : this.queryId);

      __setKey(this._ES5ProxyType ? this.get("options") : this.options, "pollInterval", undefined);
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "startPolling", function (pollInterval) {
      assertNotCacheFirstOrOnly(this);

      __setKey(this._ES5ProxyType ? this.get("options") : this.options, "pollInterval", pollInterval);

      __callKey2(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "startPollingQuery", this._ES5ProxyType ? this.get("options") : this.options, this._ES5ProxyType ? this.get("queryId") : this.queryId);
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "updateLastResult", function (newResult) {
      var _queryManager3, _assumeImmutableResul;

      var previousResult = this._ES5ProxyType ? this.get("lastResult") : this.lastResult;

      __setKey(this, "lastResult", newResult);

      __setKey(this, "lastResultSnapshot", (_queryManager3 = this._ES5ProxyType ? this.get("queryManager") : this.queryManager, _assumeImmutableResul = _queryManager3._ES5ProxyType ? _queryManager3.get("assumeImmutableResults") : _queryManager3.assumeImmutableResults) ? newResult : cloneDeep(newResult));

      return previousResult;
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "onSubscribe", function (observer) {
      var _observers4, _size4;

      var _this = this;

      try {
        var _subscription, _observer;

        var subObserver = (_subscription = observer._ES5ProxyType ? observer.get("_subscription") : observer._subscription, _observer = _subscription._ES5ProxyType ? _subscription.get("_observer") : _subscription._observer);

        if (subObserver && !(subObserver._ES5ProxyType ? subObserver.get("error") : subObserver.error)) {
          __setKey(subObserver, "error", defaultSubscriptionObserverErrorCallback);
        }
      } catch (_a) {}

      var first = !(_observers4 = this._ES5ProxyType ? this.get("observers") : this.observers, _size4 = _observers4._ES5ProxyType ? _observers4.get("size") : _observers4.size);

      __callKey1$1(this._ES5ProxyType ? this.get("observers") : this.observers, "add", observer);

      if ((observer._ES5ProxyType ? observer.get("next") : observer.next) && (this._ES5ProxyType ? this.get("lastResult") : this.lastResult)) __callKey1$1(observer, "next", this._ES5ProxyType ? this.get("lastResult") : this.lastResult);
      if ((observer._ES5ProxyType ? observer.get("error") : observer.error) && (this._ES5ProxyType ? this.get("lastError") : this.lastError)) __callKey1$1(observer, "error", this._ES5ProxyType ? this.get("lastError") : this.lastError);

      if (first) {
        __callKey0(this, "setUpQuery");
      }

      return function () {
        var _observers5, _size5;

        if (__callKey1$1(_this._ES5ProxyType ? _this.get("observers") : _this.observers, "delete", observer) && !(_observers5 = _this._ES5ProxyType ? _this.get("observers") : _this.observers, _size5 = _observers5._ES5ProxyType ? _observers5.get("size") : _observers5.size)) {
          __callKey0(_this, "tearDownQuery");
        }
      };
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "setUpQuery", function () {
      var _options11, _pollInterval;

      var _this = this;

      var _a = this,
          queryManager = _a._ES5ProxyType ? _a.get("queryManager") : _a.queryManager,
          queryId = _a._ES5ProxyType ? _a.get("queryId") : _a.queryId;

      if (this._ES5ProxyType ? this.get("shouldSubscribe") : this.shouldSubscribe) {
        __callKey2(queryManager, "addObservableQuery", queryId, this);
      }

      if (_options11 = this._ES5ProxyType ? this.get("options") : this.options, _pollInterval = _options11._ES5ProxyType ? _options11.get("pollInterval") : _options11.pollInterval) {
        assertNotCacheFirstOrOnly(this);

        __callKey2(queryManager, "startPollingQuery", this._ES5ProxyType ? this.get("options") : this.options, queryId);
      }

      var onError = function onError(error) {
        __callKey1$1(_this, "updateLastResult", _assign(_assign({}, _this._ES5ProxyType ? _this.get("lastResult") : _this.lastResult), {
          errors: error._ES5ProxyType ? error.get("graphQLErrors") : error.graphQLErrors,
          networkStatus: NetworkStatus._ES5ProxyType ? NetworkStatus.get("error") : NetworkStatus.error,
          loading: false
        }));

        iterateObserversSafely(_this._ES5ProxyType ? _this.get("observers") : _this.observers, 'error', __setKey(_this, "lastError", error));
      };

      __callKey1$1(__callKey3(queryManager, "observeQuery", queryId, this._ES5ProxyType ? this.get("options") : this.options, {
        next: function next(result) {
          if ((_this._ES5ProxyType ? _this.get("lastError") : _this.lastError) || __callKey1$1(_this, "isDifferentFromLastResult", result)) {
            var _queryManager$transfo, _hasClientExports;

            var previousResult_1 = __callKey1$1(_this, "updateLastResult", result);

            var _a = _this._ES5ProxyType ? _this.get("options") : _this.options,
                query_1 = _a._ES5ProxyType ? _a.get("query") : _a.query,
                variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
                fetchPolicy_1 = _a._ES5ProxyType ? _a.get("fetchPolicy") : _a.fetchPolicy;

            if (_queryManager$transfo = __callKey1$1(queryManager, "transform", query_1), _hasClientExports = _queryManager$transfo._ES5ProxyType ? _queryManager$transfo.get("hasClientExports") : _queryManager$transfo.hasClientExports) {
              __callKey1$1(__callKey2(__callKey0(queryManager, "getLocalState"), "addExportedVariables", query_1, variables), "then", function (variables) {
                var _queryManager$transfo2, _serverQuery;

                var previousVariables = _this._ES5ProxyType ? _this.get("variables") : _this.variables;

                __setKey(_this, "variables", __setKey(_this._ES5ProxyType ? _this.get("options") : _this.options, "variables", variables));

                if (!(result._ES5ProxyType ? result.get("loading") : result.loading) && previousResult_1 && fetchPolicy_1 !== 'cache-only' && (_queryManager$transfo2 = __callKey1$1(queryManager, "transform", query_1), _serverQuery = _queryManager$transfo2._ES5ProxyType ? _queryManager$transfo2.get("serverQuery") : _queryManager$transfo2.serverQuery) && !equal(previousVariables, variables)) {
                  __callKey0(_this, "refetch");
                } else {
                  iterateObserversSafely(_this._ES5ProxyType ? _this.get("observers") : _this.observers, 'next', result);
                }
              });
            } else {
              iterateObserversSafely(_this._ES5ProxyType ? _this.get("observers") : _this.observers, 'next', result);
            }
          }
        },
        error: onError
      }), "catch", onError);
    });

    __setKey(ObservableQuery._ES5ProxyType ? ObservableQuery.get("prototype") : ObservableQuery.prototype, "tearDownQuery", function () {
      var queryManager = this._ES5ProxyType ? this.get("queryManager") : this.queryManager;

      __setKey(this, "isTornDown", true);

      __callKey1$1(queryManager, "stopPollingQuery", this._ES5ProxyType ? this.get("queryId") : this.queryId);

      __callKey1$1(this._ES5ProxyType ? this.get("subscriptions") : this.subscriptions, "forEach", function (sub) {
        return __callKey0(sub, "unsubscribe");
      });

      __callKey0(this._ES5ProxyType ? this.get("subscriptions") : this.subscriptions, "clear");

      __callKey1$1(queryManager, "removeObservableQuery", this._ES5ProxyType ? this.get("queryId") : this.queryId);

      __callKey1$1(queryManager, "stopQuery", this._ES5ProxyType ? this.get("queryId") : this.queryId);

      __callKey0(this._ES5ProxyType ? this.get("observers") : this.observers, "clear");
    });

    return ObservableQuery;
  }(Observable$2);

  function defaultSubscriptionObserverErrorCallback(error) {
     __callKey3(invariant$3, "error", 'Unhandled error', error._ES5ProxyType ? error.get("message") : error.message, error._ES5ProxyType ? error.get("stack") : error.stack);
  }

  function iterateObserversSafely(observers, method, argument) {
    var observersWithMethod = [];

    __callKey1$1(observers, "forEach", function (obs) {
      return (obs._ES5ProxyType ? obs.get(method) : obs[method]) && observersWithMethod.push(obs);
    });

    __callKey1$1(observersWithMethod, "forEach", function (obs) {
      return __callKey1$1(obs, method, argument);
    });
  }

  function assertNotCacheFirstOrOnly(obsQuery) {
    var _options12, _fetchPolicy4;

    var fetchPolicy = (_options12 = obsQuery._ES5ProxyType ? obsQuery.get("options") : obsQuery.options, _fetchPolicy4 = _options12._ES5ProxyType ? _options12.get("fetchPolicy") : _options12.fetchPolicy);
     invariant$3(fetchPolicy !== 'cache-first' && fetchPolicy !== 'cache-only', 'Queries that specify the cache-first and cache-only fetchPolicies cannot also be polling queries.');
  }

  var MutationStore = function () {
    function MutationStore() {
      __setKey(this, "store", {});
    }

    __setKey(MutationStore._ES5ProxyType ? MutationStore.get("prototype") : MutationStore.prototype, "getStore", function () {
      return this._ES5ProxyType ? this.get("store") : this.store;
    });

    __setKey(MutationStore._ES5ProxyType ? MutationStore.get("prototype") : MutationStore.prototype, "get", function (mutationId) {
      var _store, _mutationId;

      return _store = this._ES5ProxyType ? this.get("store") : this.store, _mutationId = _store._ES5ProxyType ? _store.get(mutationId) : _store[mutationId];
    });

    __setKey(MutationStore._ES5ProxyType ? MutationStore.get("prototype") : MutationStore.prototype, "initMutation", function (mutationId, mutation, variables) {
      __setKey(this._ES5ProxyType ? this.get("store") : this.store, mutationId, {
        mutation: mutation,
        variables: variables || {},
        loading: true,
        error: null
      });
    });

    __setKey(MutationStore._ES5ProxyType ? MutationStore.get("prototype") : MutationStore.prototype, "markMutationError", function (mutationId, error) {
      var _store2, _mutationId2;

      var mutation = (_store2 = this._ES5ProxyType ? this.get("store") : this.store, _mutationId2 = _store2._ES5ProxyType ? _store2.get(mutationId) : _store2[mutationId]);

      if (mutation) {
        __setKey(mutation, "loading", false);

        __setKey(mutation, "error", error);
      }
    });

    __setKey(MutationStore._ES5ProxyType ? MutationStore.get("prototype") : MutationStore.prototype, "markMutationResult", function (mutationId) {
      var _store3, _mutationId3;

      var mutation = (_store3 = this._ES5ProxyType ? this.get("store") : this.store, _mutationId3 = _store3._ES5ProxyType ? _store3.get(mutationId) : _store3[mutationId]);

      if (mutation) {
        __setKey(mutation, "loading", false);

        __setKey(mutation, "error", null);
      }
    });

    __setKey(MutationStore._ES5ProxyType ? MutationStore.get("prototype") : MutationStore.prototype, "reset", function () {
      __setKey(this, "store", {});
    });

    return MutationStore;
  }();

  var QueryStore = function () {
    function QueryStore() {
      __setKey(this, "store", {});
    }

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "getStore", function () {
      return this._ES5ProxyType ? this.get("store") : this.store;
    });

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "get", function (queryId) {
      var _store4, _queryId;

      return _store4 = this._ES5ProxyType ? this.get("store") : this.store, _queryId = _store4._ES5ProxyType ? _store4.get(queryId) : _store4[queryId];
    });

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "initQuery", function (query) {
      var _store5, _query$queryId, _query$queryId2, _store6, _query$fetchMoreForQu, _query$fetchMoreForQu2;

      var previousQuery = (_store5 = this._ES5ProxyType ? this.get("store") : this.store, _query$queryId = query._ES5ProxyType ? query.get("queryId") : query.queryId, _query$queryId2 = _store5._ES5ProxyType ? _store5.get(_query$queryId) : _store5[_query$queryId]);
       invariant$3(!previousQuery || (previousQuery._ES5ProxyType ? previousQuery.get("document") : previousQuery.document) === (query._ES5ProxyType ? query.get("document") : query.document) || equal(previousQuery._ES5ProxyType ? previousQuery.get("document") : previousQuery.document, query._ES5ProxyType ? query.get("document") : query.document), 'Internal Error: may not update existing query string in store');
      var isSetVariables = false;
      var previousVariables = null;

      if ((query._ES5ProxyType ? query.get("storePreviousVariables") : query.storePreviousVariables) && previousQuery && (previousQuery._ES5ProxyType ? previousQuery.get("networkStatus") : previousQuery.networkStatus) !== (NetworkStatus._ES5ProxyType ? NetworkStatus.get("loading") : NetworkStatus.loading)) {
        if (!equal(previousQuery._ES5ProxyType ? previousQuery.get("variables") : previousQuery.variables, query._ES5ProxyType ? query.get("variables") : query.variables)) {
          isSetVariables = true;
          previousVariables = previousQuery._ES5ProxyType ? previousQuery.get("variables") : previousQuery.variables;
        }
      }

      var networkStatus;

      if (isSetVariables) {
        networkStatus = NetworkStatus._ES5ProxyType ? NetworkStatus.get("setVariables") : NetworkStatus.setVariables;
      } else if (query._ES5ProxyType ? query.get("isPoll") : query.isPoll) {
        networkStatus = NetworkStatus._ES5ProxyType ? NetworkStatus.get("poll") : NetworkStatus.poll;
      } else if (query._ES5ProxyType ? query.get("isRefetch") : query.isRefetch) {
        networkStatus = NetworkStatus._ES5ProxyType ? NetworkStatus.get("refetch") : NetworkStatus.refetch;
      } else {
        networkStatus = NetworkStatus._ES5ProxyType ? NetworkStatus.get("loading") : NetworkStatus.loading;
      }

      var graphQLErrors = [];

      if (previousQuery && (previousQuery._ES5ProxyType ? previousQuery.get("graphQLErrors") : previousQuery.graphQLErrors)) {
        graphQLErrors = previousQuery._ES5ProxyType ? previousQuery.get("graphQLErrors") : previousQuery.graphQLErrors;
      }

      __setKey(this._ES5ProxyType ? this.get("store") : this.store, query._ES5ProxyType ? query.get("queryId") : query.queryId, {
        document: query._ES5ProxyType ? query.get("document") : query.document,
        variables: query._ES5ProxyType ? query.get("variables") : query.variables,
        previousVariables: previousVariables,
        networkError: null,
        graphQLErrors: graphQLErrors,
        networkStatus: networkStatus,
        metadata: query._ES5ProxyType ? query.get("metadata") : query.metadata
      });

      if (typeof (query._ES5ProxyType ? query.get("fetchMoreForQueryId") : query.fetchMoreForQueryId) === 'string' && (_store6 = this._ES5ProxyType ? this.get("store") : this.store, _query$fetchMoreForQu = query._ES5ProxyType ? query.get("fetchMoreForQueryId") : query.fetchMoreForQueryId, _query$fetchMoreForQu2 = _store6._ES5ProxyType ? _store6.get(_query$fetchMoreForQu) : _store6[_query$fetchMoreForQu])) {
        var _store7, _query$fetchMoreForQu3, _query$fetchMoreForQu4;

        __setKey((_store7 = this._ES5ProxyType ? this.get("store") : this.store, _query$fetchMoreForQu3 = query._ES5ProxyType ? query.get("fetchMoreForQueryId") : query.fetchMoreForQueryId, _query$fetchMoreForQu4 = _store7._ES5ProxyType ? _store7.get(_query$fetchMoreForQu3) : _store7[_query$fetchMoreForQu3]), "networkStatus", NetworkStatus._ES5ProxyType ? NetworkStatus.get("fetchMore") : NetworkStatus.fetchMore);
      }
    });

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "markQueryResult", function (queryId, result, fetchMoreForQueryId) {
      var _store8, _queryId2, _store9, _queryId3, _store10, _queryId4, _store11, _queryId5, _store12, _queryId6, _store13, _fetchMoreForQueryId;

      if (!(this._ES5ProxyType ? this.get("store") : this.store) || !(_store8 = this._ES5ProxyType ? this.get("store") : this.store, _queryId2 = _store8._ES5ProxyType ? _store8.get(queryId) : _store8[queryId])) return;

      __setKey((_store9 = this._ES5ProxyType ? this.get("store") : this.store, _queryId3 = _store9._ES5ProxyType ? _store9.get(queryId) : _store9[queryId]), "networkError", null);

      __setKey((_store10 = this._ES5ProxyType ? this.get("store") : this.store, _queryId4 = _store10._ES5ProxyType ? _store10.get(queryId) : _store10[queryId]), "graphQLErrors", isNonEmptyArray(result._ES5ProxyType ? result.get("errors") : result.errors) ? result._ES5ProxyType ? result.get("errors") : result.errors : []);

      __setKey((_store11 = this._ES5ProxyType ? this.get("store") : this.store, _queryId5 = _store11._ES5ProxyType ? _store11.get(queryId) : _store11[queryId]), "previousVariables", null);

      __setKey((_store12 = this._ES5ProxyType ? this.get("store") : this.store, _queryId6 = _store12._ES5ProxyType ? _store12.get(queryId) : _store12[queryId]), "networkStatus", NetworkStatus._ES5ProxyType ? NetworkStatus.get("ready") : NetworkStatus.ready);

      if (typeof fetchMoreForQueryId === 'string' && (_store13 = this._ES5ProxyType ? this.get("store") : this.store, _fetchMoreForQueryId = _store13._ES5ProxyType ? _store13.get(fetchMoreForQueryId) : _store13[fetchMoreForQueryId])) {
        var _store14, _fetchMoreForQueryId2;

        __setKey((_store14 = this._ES5ProxyType ? this.get("store") : this.store, _fetchMoreForQueryId2 = _store14._ES5ProxyType ? _store14.get(fetchMoreForQueryId) : _store14[fetchMoreForQueryId]), "networkStatus", NetworkStatus._ES5ProxyType ? NetworkStatus.get("ready") : NetworkStatus.ready);
      }
    });

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "markQueryError", function (queryId, error, fetchMoreForQueryId) {
      var _store15, _queryId7, _store16, _queryId8, _store17, _queryId9;

      if (!(this._ES5ProxyType ? this.get("store") : this.store) || !(_store15 = this._ES5ProxyType ? this.get("store") : this.store, _queryId7 = _store15._ES5ProxyType ? _store15.get(queryId) : _store15[queryId])) return;

      __setKey((_store16 = this._ES5ProxyType ? this.get("store") : this.store, _queryId8 = _store16._ES5ProxyType ? _store16.get(queryId) : _store16[queryId]), "networkError", error);

      __setKey((_store17 = this._ES5ProxyType ? this.get("store") : this.store, _queryId9 = _store17._ES5ProxyType ? _store17.get(queryId) : _store17[queryId]), "networkStatus", NetworkStatus._ES5ProxyType ? NetworkStatus.get("error") : NetworkStatus.error);

      if (typeof fetchMoreForQueryId === 'string') {
        __callKey2(this, "markQueryResultClient", fetchMoreForQueryId, true);
      }
    });

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "markQueryResultClient", function (queryId, complete) {
      var _store18, _queryId10;

      var storeValue = (this._ES5ProxyType ? this.get("store") : this.store) && (_store18 = this._ES5ProxyType ? this.get("store") : this.store, _queryId10 = _store18._ES5ProxyType ? _store18.get(queryId) : _store18[queryId]);

      if (storeValue) {
        __setKey(storeValue, "networkError", null);

        __setKey(storeValue, "previousVariables", null);

        if (complete) {
          __setKey(storeValue, "networkStatus", NetworkStatus._ES5ProxyType ? NetworkStatus.get("ready") : NetworkStatus.ready);
        }
      }
    });

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "stopQuery", function (queryId) {
      __deleteKey(this._ES5ProxyType ? this.get("store") : this.store, queryId);
    });

    __setKey(QueryStore._ES5ProxyType ? QueryStore.get("prototype") : QueryStore.prototype, "reset", function (observableQueryIds) {
      var _this = this;

      __callKey1$1(Object.compatKeys(this._ES5ProxyType ? this.get("store") : this.store), "forEach", function (queryId) {
        if (__callKey1$1(observableQueryIds, "indexOf", queryId) < 0) {
          __callKey1$1(_this, "stopQuery", queryId);
        } else {
          var _store19, _queryId11;

          __setKey((_store19 = _this._ES5ProxyType ? _this.get("store") : _this.store, _queryId11 = _store19._ES5ProxyType ? _store19.get(queryId) : _store19[queryId]), "networkStatus", NetworkStatus._ES5ProxyType ? NetworkStatus.get("loading") : NetworkStatus.loading);
        }
      });
    });

    return QueryStore;
  }();

  function capitalizeFirstLetter(str) {
    return __callKey0(__callKey1$1(str, "charAt", 0), "toUpperCase") + __callKey1$1(str, "slice", 1);
  }

  var LocalState = function () {
    function LocalState(_a) {
      var cache = _a._ES5ProxyType ? _a.get("cache") : _a.cache,
          client = _a._ES5ProxyType ? _a.get("client") : _a.client,
          resolvers = _a._ES5ProxyType ? _a.get("resolvers") : _a.resolvers,
          fragmentMatcher = _a._ES5ProxyType ? _a.get("fragmentMatcher") : _a.fragmentMatcher;

      __setKey(this, "cache", cache);

      if (client) {
        __setKey(this, "client", client);
      }

      if (resolvers) {
        __callKey1$1(this, "addResolvers", resolvers);
      }

      if (fragmentMatcher) {
        __callKey1$1(this, "setFragmentMatcher", fragmentMatcher);
      }
    }

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "addResolvers", function (resolvers) {
      var _this = this;

      __setKey(this, "resolvers", (this._ES5ProxyType ? this.get("resolvers") : this.resolvers) || {});

      if (Array.compatIsArray(resolvers)) {
        __callKey1$1(resolvers, "forEach", function (resolverGroup) {
          __setKey(_this, "resolvers", mergeDeep(_this._ES5ProxyType ? _this.get("resolvers") : _this.resolvers, resolverGroup));
        });
      } else {
        __setKey(this, "resolvers", mergeDeep(this._ES5ProxyType ? this.get("resolvers") : this.resolvers, resolvers));
      }
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "setResolvers", function (resolvers) {
      __setKey(this, "resolvers", {});

      __callKey1$1(this, "addResolvers", resolvers);
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "getResolvers", function () {
      return (this._ES5ProxyType ? this.get("resolvers") : this.resolvers) || {};
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "runResolvers", function (_a) {
      var document = _a._ES5ProxyType ? _a.get("document") : _a.document,
          remoteResult = _a._ES5ProxyType ? _a.get("remoteResult") : _a.remoteResult,
          context = _a._ES5ProxyType ? _a.get("context") : _a.context,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          _b = _a._ES5ProxyType ? _a.get("onlyRunForcedResolvers") : _a.onlyRunForcedResolvers,
          onlyRunForcedResolvers = _b === void 0 ? false : _b;

      return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_c) {
          if (document) {
            return [2, __callKey1$1(__callKey(this, "resolveDocument", document, remoteResult._ES5ProxyType ? remoteResult.get("data") : remoteResult.data, context, variables, this._ES5ProxyType ? this.get("fragmentMatcher") : this.fragmentMatcher, onlyRunForcedResolvers), "then", function (localResult) {
              return _assign(_assign({}, remoteResult), {
                data: localResult._ES5ProxyType ? localResult.get("result") : localResult.result
              });
            })];
          }

          return [2, remoteResult];
        });
      });
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "setFragmentMatcher", function (fragmentMatcher) {
      __setKey(this, "fragmentMatcher", fragmentMatcher);
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "getFragmentMatcher", function () {
      return this._ES5ProxyType ? this.get("fragmentMatcher") : this.fragmentMatcher;
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "clientQuery", function (document) {
      if (hasDirectives(['client'], document)) {
        if (this._ES5ProxyType ? this.get("resolvers") : this.resolvers) {
          return document;
        }

         __callKey1$1(invariant$3, "warn", 'Found @client directives in a query but no ApolloClient resolvers ' + 'were specified. This means ApolloClient local resolver handling ' + 'has been disabled, and @client directives will be passed through ' + 'to your link chain.');
      }

      return null;
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "serverQuery", function (document) {
      return (this._ES5ProxyType ? this.get("resolvers") : this.resolvers) ? removeClientSetsFromDocument(document) : document;
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "prepareContext", function (context) {
      if (context === void 0) {
        context = {};
      }

      var cache = this._ES5ProxyType ? this.get("cache") : this.cache;

      var newContext = _assign(_assign({}, context), {
        cache: cache,
        getCacheKey: function getCacheKey(obj) {
          if (cache._ES5ProxyType ? cache.get("config") : cache.config) {
            return __callKey1$1(cache._ES5ProxyType ? cache.get("config") : cache.config, "dataIdFromObject", obj);
          } else {
             invariant$3(false, 'To use context.getCacheKey, you need to use a cache that has ' + 'a configurable dataIdFromObject, like apollo-cache-inmemory.');
          }
        }
      });

      return newContext;
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "addExportedVariables", function (document, variables, context) {
      if (variables === void 0) {
        variables = {};
      }

      if (context === void 0) {
        context = {};
      }

      return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
          if (document) {
            return [2, __callKey1$1(__callKey4(this, "resolveDocument", document, __callKey2(this, "buildRootValueFromCache", document, variables) || {}, __callKey1$1(this, "prepareContext", context), variables), "then", function (data) {
              return _assign(_assign({}, variables), data._ES5ProxyType ? data.get("exportedVariables") : data.exportedVariables);
            })];
          }

          return [2, _assign({}, variables)];
        });
      });
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "shouldForceResolvers", function (document) {
      var forceResolvers = false;
      visit(document, {
        Directive: {
          enter: function enter(node) {
            var _name2, _value2;

            if ((_name2 = node._ES5ProxyType ? node.get("name") : node.name, _value2 = _name2._ES5ProxyType ? _name2.get("value") : _name2.value) === 'client' && (node._ES5ProxyType ? node.get("arguments") : node.arguments)) {
              forceResolvers = __callKey1$1(node._ES5ProxyType ? node.get("arguments") : node.arguments, "some", function (arg) {
                var _name3, _value3, _value4, _kind, _value5, _value6;

                return (_name3 = arg._ES5ProxyType ? arg.get("name") : arg.name, _value3 = _name3._ES5ProxyType ? _name3.get("value") : _name3.value) === 'always' && (_value4 = arg._ES5ProxyType ? arg.get("value") : arg.value, _kind = _value4._ES5ProxyType ? _value4.get("kind") : _value4.kind) === 'BooleanValue' && (_value5 = arg._ES5ProxyType ? arg.get("value") : arg.value, _value6 = _value5._ES5ProxyType ? _value5.get("value") : _value5.value) === true;
              });

              if (forceResolvers) {
                return BREAK;
              }
            }
          }
        }
      });
      return forceResolvers;
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "buildRootValueFromCache", function (document, variables) {
      var _this$cache$diff, _result;

      return _this$cache$diff = __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "diff", {
        query: buildQueryFromSelectionSet(document),
        variables: variables,
        returnPartialData: true,
        optimistic: false
      }), _result = _this$cache$diff._ES5ProxyType ? _this$cache$diff.get("result") : _this$cache$diff.result;
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "resolveDocument", function (document, rootValue, context, variables, fragmentMatcher, onlyRunForcedResolvers) {
      if (context === void 0) {
        context = {};
      }

      if (variables === void 0) {
        variables = {};
      }

      if (fragmentMatcher === void 0) {
        fragmentMatcher = function fragmentMatcher() {
          return true;
        };
      }

      if (onlyRunForcedResolvers === void 0) {
        onlyRunForcedResolvers = false;
      }

      return __awaiter(this, void 0, void 0, function () {
        var mainDefinition, fragments, fragmentMap, definitionOperation, defaultOperationType, _a, cache, client, execContext;

        return __generator(this, function (_b) {
          mainDefinition = getMainDefinition(document);
          fragments = getFragmentDefinitions(document);
          fragmentMap = createFragmentMap(fragments);
          definitionOperation = mainDefinition._ES5ProxyType ? mainDefinition.get("operation") : mainDefinition.operation;
          defaultOperationType = definitionOperation ? capitalizeFirstLetter(definitionOperation) : 'Query';
          _a = this, cache = _a._ES5ProxyType ? _a.get("cache") : _a.cache, client = _a._ES5ProxyType ? _a.get("client") : _a.client;
          execContext = {
            fragmentMap: fragmentMap,
            context: _assign(_assign({}, context), {
              cache: cache,
              client: client
            }),
            variables: variables,
            fragmentMatcher: fragmentMatcher,
            defaultOperationType: defaultOperationType,
            exportedVariables: {},
            onlyRunForcedResolvers: onlyRunForcedResolvers
          };
          return [2, __callKey1$1(__callKey3(this, "resolveSelectionSet", mainDefinition._ES5ProxyType ? mainDefinition.get("selectionSet") : mainDefinition.selectionSet, rootValue, execContext), "then", function (result) {
            return {
              result: result,
              exportedVariables: execContext._ES5ProxyType ? execContext.get("exportedVariables") : execContext.exportedVariables
            };
          })];
        });
      });
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "resolveSelectionSet", function (selectionSet, rootValue, execContext) {
      return __awaiter(this, void 0, void 0, function () {
        var fragmentMap, context, variables, resultsToMerge, execute;

        var _this = this;

        return __generator(this, function (_a) {
          fragmentMap = execContext._ES5ProxyType ? execContext.get("fragmentMap") : execContext.fragmentMap, context = execContext._ES5ProxyType ? execContext.get("context") : execContext.context, variables = execContext._ES5ProxyType ? execContext.get("variables") : execContext.variables;
          resultsToMerge = [rootValue];

          execute = function execute(selection) {
            return __awaiter(_this, void 0, void 0, function () {
              var fragment, typeCondition;
              return __generator(this, function (_a) {
                if (!shouldInclude(selection, variables)) {
                  return [2];
                }

                if (isField(selection)) {
                  return [2, __callKey1$1(__callKey3(this, "resolveField", selection, rootValue, execContext), "then", function (fieldResult) {
                    var _a;

                    if (typeof fieldResult !== 'undefined') {
                      resultsToMerge.push((_a = {}, __setKey(_a, resultKeyNameFromField(selection), fieldResult), _a));
                    }
                  })];
                }

                if (isInlineFragment(selection)) {
                  fragment = selection;
                } else {
                  var _selection$name$value, _selection$name$value2, _name4, _value7, _name5, _value8;

                  fragment = (_selection$name$value = (_name4 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value7 = _name4._ES5ProxyType ? _name4.get("value") : _name4.value), _selection$name$value2 = fragmentMap._ES5ProxyType ? fragmentMap.get(_selection$name$value) : fragmentMap[_selection$name$value]);
                   invariant$3(fragment, "No fragment named " + (_name5 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value8 = _name5._ES5ProxyType ? _name5.get("value") : _name5.value));
                }

                if (fragment && (fragment._ES5ProxyType ? fragment.get("typeCondition") : fragment.typeCondition)) {
                  var _typeCondition, _name6, _value9;

                  typeCondition = (_typeCondition = fragment._ES5ProxyType ? fragment.get("typeCondition") : fragment.typeCondition, _name6 = _typeCondition._ES5ProxyType ? _typeCondition.get("name") : _typeCondition.name, _value9 = _name6._ES5ProxyType ? _name6.get("value") : _name6.value);

                  if (__callKey3(execContext, "fragmentMatcher", rootValue, typeCondition, context)) {
                    return [2, __callKey1$1(__callKey3(this, "resolveSelectionSet", fragment._ES5ProxyType ? fragment.get("selectionSet") : fragment.selectionSet, rootValue, execContext), "then", function (fragmentResult) {
                      resultsToMerge.push(fragmentResult);
                    })];
                  }
                }

                return [2];
              });
            });
          };

          return [2, __callKey1$1(Promise.all(__callKey1$1(selectionSet._ES5ProxyType ? selectionSet.get("selections") : selectionSet.selections, "map", execute)), "then", function () {
            return mergeDeepArray(resultsToMerge);
          })];
        });
      });
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "resolveField", function (field, rootValue, execContext) {
      return __awaiter(this, void 0, void 0, function () {
        var variables, fieldName, aliasedFieldName, aliasUsed, defaultResult, resultPromise, resolverType, resolverMap, resolve;

        var _this = this;

        return __generator(this, function (_a) {
          var _name7, _value10;

          variables = execContext._ES5ProxyType ? execContext.get("variables") : execContext.variables;
          fieldName = (_name7 = field._ES5ProxyType ? field.get("name") : field.name, _value10 = _name7._ES5ProxyType ? _name7.get("value") : _name7.value);
          aliasedFieldName = resultKeyNameFromField(field);
          aliasUsed = fieldName !== aliasedFieldName;
          defaultResult = (rootValue._ES5ProxyType ? rootValue.get(aliasedFieldName) : rootValue[aliasedFieldName]) || (rootValue._ES5ProxyType ? rootValue.get(fieldName) : rootValue[fieldName]);
          resultPromise = Promise.resolve(defaultResult);

          if (!(execContext._ES5ProxyType ? execContext.get("onlyRunForcedResolvers") : execContext.onlyRunForcedResolvers) || __callKey1$1(this, "shouldForceResolvers", field)) {
            var _resolvers, _resolverType;

            resolverType = (rootValue._ES5ProxyType ? rootValue.get("__typename") : rootValue.__typename) || (execContext._ES5ProxyType ? execContext.get("defaultOperationType") : execContext.defaultOperationType);
            resolverMap = (this._ES5ProxyType ? this.get("resolvers") : this.resolvers) && (_resolvers = this._ES5ProxyType ? this.get("resolvers") : this.resolvers, _resolverType = _resolvers._ES5ProxyType ? _resolvers.get(resolverType) : _resolvers[resolverType]);

            if (resolverMap) {
              var _ref, _ref2;

              resolve = (_ref = aliasUsed ? fieldName : aliasedFieldName, _ref2 = resolverMap._ES5ProxyType ? resolverMap.get(_ref) : resolverMap[_ref]);

              if (resolve) {
                resultPromise = Promise.resolve(resolve(rootValue, argumentsObjectFromField(field, variables), execContext._ES5ProxyType ? execContext.get("context") : execContext.context, {
                  field: field,
                  fragmentMap: execContext._ES5ProxyType ? execContext.get("fragmentMap") : execContext.fragmentMap
                }));
              }
            }
          }

          return [2, __callKey1$1(resultPromise, "then", function (result) {
            if (result === void 0) {
              result = defaultResult;
            }

            if (field._ES5ProxyType ? field.get("directives") : field.directives) {
              __callKey1$1(field._ES5ProxyType ? field.get("directives") : field.directives, "forEach", function (directive) {
                var _name8, _value11;

                if ((_name8 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value11 = _name8._ES5ProxyType ? _name8.get("value") : _name8.value) === 'export' && (directive._ES5ProxyType ? directive.get("arguments") : directive.arguments)) {
                  __callKey1$1(directive._ES5ProxyType ? directive.get("arguments") : directive.arguments, "forEach", function (arg) {
                    var _name9, _value12, _value13, _kind2;

                    if ((_name9 = arg._ES5ProxyType ? arg.get("name") : arg.name, _value12 = _name9._ES5ProxyType ? _name9.get("value") : _name9.value) === 'as' && (_value13 = arg._ES5ProxyType ? arg.get("value") : arg.value, _kind2 = _value13._ES5ProxyType ? _value13.get("kind") : _value13.kind) === 'StringValue') {
                      var _value14, _value15;

                      __setKey(execContext._ES5ProxyType ? execContext.get("exportedVariables") : execContext.exportedVariables, (_value14 = arg._ES5ProxyType ? arg.get("value") : arg.value, _value15 = _value14._ES5ProxyType ? _value14.get("value") : _value14.value), result);
                    }
                  });
                }
              });
            }

            if (!(field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet)) {
              return result;
            }

            if (result == null) {
              return result;
            }

            if (Array.compatIsArray(result)) {
              return __callKey3(_this, "resolveSubSelectedArray", field, result, execContext);
            }

            if (field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet) {
              return __callKey3(_this, "resolveSelectionSet", field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet, result, execContext);
            }
          })];
        });
      });
    });

    __setKey(LocalState._ES5ProxyType ? LocalState.get("prototype") : LocalState.prototype, "resolveSubSelectedArray", function (field, result, execContext) {
      var _this = this;

      return Promise.all(__callKey1$1(result, "map", function (item) {
        if (item === null) {
          return null;
        }

        if (Array.compatIsArray(item)) {
          return __callKey3(_this, "resolveSubSelectedArray", field, item, execContext);
        }

        if (field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet) {
          return __callKey3(_this, "resolveSelectionSet", field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet, item, execContext);
        }
      }));
    });

    return LocalState;
  }();

  function multiplex(inner) {
    var observers = new Set();
    var sub = null;
    return new Observable$2(function (observer) {
      __callKey1$1(observers, "add", observer);

      sub = sub || __callKey1$1(inner, "subscribe", {
        next: function next(value) {
          __callKey1$1(observers, "forEach", function (obs) {
            return (obs._ES5ProxyType ? obs.get("next") : obs.next) && __callKey1$1(obs, "next", value);
          });
        },
        error: function error(_error) {
          __callKey1$1(observers, "forEach", function (obs) {
            return (obs._ES5ProxyType ? obs.get("error") : obs.error) && __callKey1$1(obs, "error", _error);
          });
        },
        complete: function complete() {
          __callKey1$1(observers, "forEach", function (obs) {
            return (obs._ES5ProxyType ? obs.get("complete") : obs.complete) && __callKey0(obs, "complete");
          });
        }
      });
      return function () {
        if (__callKey1$1(observers, "delete", observer) && !(observers._ES5ProxyType ? observers.get("size") : observers.size) && sub) {
          __callKey0(sub, "unsubscribe");

          sub = null;
        }
      };
    });
  }

  function asyncMap(observable, mapFn) {
    return new Observable$2(function (observer) {
      var _next = observer._ES5ProxyType ? observer.get("next") : observer.next,
          _error2 = observer._ES5ProxyType ? observer.get("error") : observer.error,
          _complete = observer._ES5ProxyType ? observer.get("complete") : observer.complete;

      var activeNextCount = 0;
      var completed = false;
      var handler = {
        next: function next(value) {
          ++activeNextCount;

          __callKey2(new Promise(function (resolve) {
            resolve(mapFn(value));
          }), "then", function (result) {
            --activeNextCount;
            _next && __callKey2(_next, "call", observer, result);
            completed && __callKey0(handler, "complete");
          }, function (e) {
            --activeNextCount;
            _error2 && __callKey2(_error2, "call", observer, e);
          });
        },
        error: function error(e) {
          _error2 && __callKey2(_error2, "call", observer, e);
        },
        complete: function complete() {
          completed = true;

          if (!activeNextCount) {
            _complete && __callKey1$1(_complete, "call", observer);
          }
        }
      };

      var sub = __callKey1$1(observable, "subscribe", handler);

      return function () {
        return __callKey0(sub, "unsubscribe");
      };
    });
  }

  var hasOwnProperty$4 = Object.prototype._ES5ProxyType ? Object.prototype.get("compatHasOwnProperty") : Object.prototype.compatHasOwnProperty;

  var QueryManager = function () {
    function QueryManager(_a) {
      var link = _a._ES5ProxyType ? _a.get("link") : _a.link,
          _b = _a._ES5ProxyType ? _a.get("queryDeduplication") : _a.queryDeduplication,
          queryDeduplication = _b === void 0 ? false : _b,
          store = _a._ES5ProxyType ? _a.get("store") : _a.store,
          _c = _a._ES5ProxyType ? _a.get("onBroadcast") : _a.onBroadcast,
          onBroadcast = _c === void 0 ? function () {
        return undefined;
      } : _c,
          _d = _a._ES5ProxyType ? _a.get("ssrMode") : _a.ssrMode,
          ssrMode = _d === void 0 ? false : _d,
          _e = _a._ES5ProxyType ? _a.get("clientAwareness") : _a.clientAwareness,
          clientAwareness = _e === void 0 ? {} : _e,
          localState = _a._ES5ProxyType ? _a.get("localState") : _a.localState,
          assumeImmutableResults = _a._ES5ProxyType ? _a.get("assumeImmutableResults") : _a.assumeImmutableResults;

      __setKey(this, "mutationStore", new MutationStore());

      __setKey(this, "queryStore", new QueryStore());

      __setKey(this, "clientAwareness", {});

      __setKey(this, "idCounter", 1);

      __setKey(this, "queries", new Map());

      __setKey(this, "fetchQueryRejectFns", new Map());

      __setKey(this, "transformCache", new (canUseWeakMap ? WeakMap : Map)());

      __setKey(this, "inFlightLinkObservables", new Map());

      __setKey(this, "pollingInfoByQueryId", new Map());

      __setKey(this, "link", link);

      __setKey(this, "queryDeduplication", queryDeduplication);

      __setKey(this, "dataStore", store);

      __setKey(this, "onBroadcast", onBroadcast);

      __setKey(this, "clientAwareness", clientAwareness);

      __setKey(this, "localState", localState || new LocalState({
        cache: __callKey0(store, "getCache")
      }));

      __setKey(this, "ssrMode", ssrMode);

      __setKey(this, "assumeImmutableResults", !!assumeImmutableResults);
    }

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "stop", function () {
      var _this = this;

      __callKey1$1(this._ES5ProxyType ? this.get("queries") : this.queries, "forEach", function (_info, queryId) {
        __callKey1$1(_this, "stopQueryNoBroadcast", queryId);
      });

      __callKey1$1(this._ES5ProxyType ? this.get("fetchQueryRejectFns") : this.fetchQueryRejectFns, "forEach", function (reject) {
        reject( new InvariantError('QueryManager stopped while query was in flight'));
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "mutate", function (_a) {
      var mutation = _a._ES5ProxyType ? _a.get("mutation") : _a.mutation,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          optimisticResponse = _a._ES5ProxyType ? _a.get("optimisticResponse") : _a.optimisticResponse,
          updateQueriesByName = _a._ES5ProxyType ? _a.get("updateQueries") : _a.updateQueries,
          _b = _a._ES5ProxyType ? _a.get("refetchQueries") : _a.refetchQueries,
          refetchQueries = _b === void 0 ? [] : _b,
          _c = _a._ES5ProxyType ? _a.get("awaitRefetchQueries") : _a.awaitRefetchQueries,
          awaitRefetchQueries = _c === void 0 ? false : _c,
          updateWithProxyFn = _a._ES5ProxyType ? _a.get("update") : _a.update,
          _d = _a._ES5ProxyType ? _a.get("errorPolicy") : _a.errorPolicy,
          errorPolicy = _d === void 0 ? 'none' : _d,
          fetchPolicy = _a._ES5ProxyType ? _a.get("fetchPolicy") : _a.fetchPolicy,
          _e = _a._ES5ProxyType ? _a.get("context") : _a.context,
          context = _e === void 0 ? {} : _e;

      return __awaiter(this, void 0, void 0, function () {
        var mutationId, generateUpdateQueriesInfo, self;

        var _this = this;

        return __generator(this, function (_f) {
          var _this$transform, _document, _this$transform2, _hasClientExports2;

          switch (_f._ES5ProxyType ? _f.get("label") : _f.label) {
            case 0:
               invariant$3(mutation, 'mutation option is required. You must specify your GraphQL document in the mutation option.');
               invariant$3(!fetchPolicy || fetchPolicy === 'no-cache', "Mutations only support a 'no-cache' fetchPolicy. If you don't want to disable the cache, remove your fetchPolicy setting to proceed with the default mutation behavior.");
              mutationId = __callKey0(this, "generateQueryId");
              mutation = (_this$transform = __callKey1$1(this, "transform", mutation), _document = _this$transform._ES5ProxyType ? _this$transform.get("document") : _this$transform.document);

              __callKey2(this, "setQuery", mutationId, function () {
                return {
                  document: mutation
                };
              });

              variables = __callKey2(this, "getVariables", mutation, variables);
              if (!(_this$transform2 = __callKey1$1(this, "transform", mutation), _hasClientExports2 = _this$transform2._ES5ProxyType ? _this$transform2.get("hasClientExports") : _this$transform2.hasClientExports)) return [3, 2];
              return [4, __callKey3(this._ES5ProxyType ? this.get("localState") : this.localState, "addExportedVariables", mutation, variables, context)];

            case 1:
              variables = __callKey0(_f, "sent");

              __setKey(_f, "label", 2);

            case 2:
              generateUpdateQueriesInfo = function generateUpdateQueriesInfo() {
                var ret = {};

                if (updateQueriesByName) {
                  __callKey1$1(_this._ES5ProxyType ? _this.get("queries") : _this.queries, "forEach", function (_a, queryId) {
                    var observableQuery = _a._ES5ProxyType ? _a.get("observableQuery") : _a.observableQuery;

                    if (observableQuery) {
                      var queryName = observableQuery._ES5ProxyType ? observableQuery.get("queryName") : observableQuery.queryName;

                      if (queryName && __callKey2(hasOwnProperty$4, "call", updateQueriesByName, queryName)) {
                        __setKey(ret, queryId, {
                          updater: updateQueriesByName._ES5ProxyType ? updateQueriesByName.get(queryName) : updateQueriesByName[queryName],
                          query: __callKey1$1(_this._ES5ProxyType ? _this.get("queryStore") : _this.queryStore, "get", queryId)
                        });
                      }
                    }
                  });
                }

                return ret;
              };

              __callKey3(this._ES5ProxyType ? this.get("mutationStore") : this.mutationStore, "initMutation", mutationId, mutation, variables);

              __callKey1$1(this._ES5ProxyType ? this.get("dataStore") : this.dataStore, "markMutationInit", {
                mutationId: mutationId,
                document: mutation,
                variables: variables,
                updateQueries: generateUpdateQueriesInfo(),
                update: updateWithProxyFn,
                optimisticResponse: optimisticResponse
              });

              __callKey0(this, "broadcastQueries");

              self = this;
              return [2, new Promise(function (resolve, reject) {
                var storeResult;
                var error;

                __callKey1$1(__callKey4(self, "getObservableFromLink", mutation, _assign(_assign({}, context), {
                  optimisticResponse: optimisticResponse
                }), variables, false), "subscribe", {
                  next: function next(result) {
                    if (graphQLResultHasError(result) && errorPolicy === 'none') {
                      error = new ApolloError({
                        graphQLErrors: result._ES5ProxyType ? result.get("errors") : result.errors
                      });
                      return;
                    }

                    __callKey1$1(self._ES5ProxyType ? self.get("mutationStore") : self.mutationStore, "markMutationResult", mutationId);

                    if (fetchPolicy !== 'no-cache') {
                      __callKey1$1(self._ES5ProxyType ? self.get("dataStore") : self.dataStore, "markMutationResult", {
                        mutationId: mutationId,
                        result: result,
                        document: mutation,
                        variables: variables,
                        updateQueries: generateUpdateQueriesInfo(),
                        update: updateWithProxyFn
                      });
                    }

                    storeResult = result;
                  },
                  error: function error(err) {
                    __callKey2(self._ES5ProxyType ? self.get("mutationStore") : self.mutationStore, "markMutationError", mutationId, err);

                    __callKey1$1(self._ES5ProxyType ? self.get("dataStore") : self.dataStore, "markMutationComplete", {
                      mutationId: mutationId,
                      optimisticResponse: optimisticResponse
                    });

                    __callKey0(self, "broadcastQueries");

                    __callKey2(self, "setQuery", mutationId, function () {
                      return {
                        document: null
                      };
                    });

                    reject(new ApolloError({
                      networkError: err
                    }));
                  },
                  complete: function complete() {
                    if (error) {
                      __callKey2(self._ES5ProxyType ? self.get("mutationStore") : self.mutationStore, "markMutationError", mutationId, error);
                    }

                    __callKey1$1(self._ES5ProxyType ? self.get("dataStore") : self.dataStore, "markMutationComplete", {
                      mutationId: mutationId,
                      optimisticResponse: optimisticResponse
                    });

                    __callKey0(self, "broadcastQueries");

                    if (error) {
                      reject(error);
                      return;
                    }

                    if (typeof refetchQueries === 'function') {
                      refetchQueries = refetchQueries(storeResult);
                    }

                    var refetchQueryPromises = [];

                    if (isNonEmptyArray(refetchQueries)) {
                      __callKey1$1(refetchQueries, "forEach", function (refetchQuery) {
                        if (typeof refetchQuery === 'string') {
                          __callKey1$1(self._ES5ProxyType ? self.get("queries") : self.queries, "forEach", function (_a) {
                            var observableQuery = _a._ES5ProxyType ? _a.get("observableQuery") : _a.observableQuery;

                            if (observableQuery && (observableQuery._ES5ProxyType ? observableQuery.get("queryName") : observableQuery.queryName) === refetchQuery) {
                              refetchQueryPromises.push(__callKey0(observableQuery, "refetch"));
                            }
                          });
                        } else {
                          var queryOptions = {
                            query: refetchQuery._ES5ProxyType ? refetchQuery.get("query") : refetchQuery.query,
                            variables: refetchQuery._ES5ProxyType ? refetchQuery.get("variables") : refetchQuery.variables,
                            fetchPolicy: 'network-only'
                          };

                          if (refetchQuery._ES5ProxyType ? refetchQuery.get("context") : refetchQuery.context) {
                            __setKey(queryOptions, "context", refetchQuery._ES5ProxyType ? refetchQuery.get("context") : refetchQuery.context);
                          }

                          refetchQueryPromises.push(__callKey1$1(self, "query", queryOptions));
                        }
                      });
                    }

                    __callKey1$1(Promise.all(awaitRefetchQueries ? refetchQueryPromises : []), "then", function () {
                      __callKey2(self, "setQuery", mutationId, function () {
                        return {
                          document: null
                        };
                      });

                      if (errorPolicy === 'ignore' && storeResult && graphQLResultHasError(storeResult)) {
                        __deleteKey(storeResult, "errors");
                      }

                      resolve(storeResult);
                    });
                  }
                });
              })];
          }
        });
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "fetchQuery", function (queryId, options, fetchType, fetchMoreForQueryId) {
      return __awaiter(this, void 0, void 0, function () {
        var _a, metadata, _b, fetchPolicy, _c, context, query, variables, storeResult, isNetworkOnly, needToFetch, _d, complete, result, shouldFetch, requestId, cancel, networkResult;

        var _this = this;

        return __generator(this, function (_e) {
          var _this$transform3, _document2, _this$transform4, _hasClientExports3, _this$transform5, _hasForcedResolvers;

          switch (_e._ES5ProxyType ? _e.get("label") : _e.label) {
            case 0:
              _a = options._ES5ProxyType ? options.get("metadata") : options.metadata, metadata = _a === void 0 ? null : _a, _b = options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy, fetchPolicy = _b === void 0 ? 'cache-first' : _b, _c = options._ES5ProxyType ? options.get("context") : options.context, context = _c === void 0 ? {} : _c;
              query = (_this$transform3 = __callKey1$1(this, "transform", options._ES5ProxyType ? options.get("query") : options.query), _document2 = _this$transform3._ES5ProxyType ? _this$transform3.get("document") : _this$transform3.document);
              variables = __callKey2(this, "getVariables", query, options._ES5ProxyType ? options.get("variables") : options.variables);
              if (!(_this$transform4 = __callKey1$1(this, "transform", query), _hasClientExports3 = _this$transform4._ES5ProxyType ? _this$transform4.get("hasClientExports") : _this$transform4.hasClientExports)) return [3, 2];
              return [4, __callKey3(this._ES5ProxyType ? this.get("localState") : this.localState, "addExportedVariables", query, variables, context)];

            case 1:
              variables = __callKey0(_e, "sent");

              __setKey(_e, "label", 2);

            case 2:
              options = _assign(_assign({}, options), {
                variables: variables
              });
              isNetworkOnly = fetchPolicy === 'network-only' || fetchPolicy === 'no-cache';
              needToFetch = isNetworkOnly;

              if (!isNetworkOnly) {
                _d = __callKey1$1(__callKey0(this._ES5ProxyType ? this.get("dataStore") : this.dataStore, "getCache"), "diff", {
                  query: query,
                  variables: variables,
                  returnPartialData: true,
                  optimistic: false
                }), complete = _d._ES5ProxyType ? _d.get("complete") : _d.complete, result = _d._ES5ProxyType ? _d.get("result") : _d.result;
                needToFetch = !complete || fetchPolicy === 'cache-and-network';
                storeResult = result;
              }

              shouldFetch = needToFetch && fetchPolicy !== 'cache-only' && fetchPolicy !== 'standby';
              if (hasDirectives(['live'], query)) shouldFetch = true;
              requestId = __setKeyPostfixIncrement(this, "idCounter");
              cancel = fetchPolicy !== 'no-cache' ? __callKey3(this, "updateQueryWatch", queryId, query, options) : undefined;

              __callKey2(this, "setQuery", queryId, function () {
                return {
                  document: query,
                  lastRequestId: requestId,
                  invalidated: true,
                  cancel: cancel
                };
              });

              __callKey1$1(this, "invalidate", fetchMoreForQueryId);

              __callKey1$1(this._ES5ProxyType ? this.get("queryStore") : this.queryStore, "initQuery", {
                queryId: queryId,
                document: query,
                storePreviousVariables: shouldFetch,
                variables: variables,
                isPoll: fetchType === (FetchType._ES5ProxyType ? FetchType.get("poll") : FetchType.poll),
                isRefetch: fetchType === (FetchType._ES5ProxyType ? FetchType.get("refetch") : FetchType.refetch),
                metadata: metadata,
                fetchMoreForQueryId: fetchMoreForQueryId
              });

              __callKey0(this, "broadcastQueries");

              if (shouldFetch) {
                networkResult = __callKey1$1(__callKey1$1(this, "fetchRequest", {
                  requestId: requestId,
                  queryId: queryId,
                  document: query,
                  options: options,
                  fetchMoreForQueryId: fetchMoreForQueryId
                }), "catch", function (error) {
                  if (isApolloError(error)) {
                    throw error;
                  } else {
                    var _this$getQuery, _lastRequestId;

                    if (requestId >= (_this$getQuery = __callKey1$1(_this, "getQuery", queryId), _lastRequestId = _this$getQuery._ES5ProxyType ? _this$getQuery.get("lastRequestId") : _this$getQuery.lastRequestId)) {
                      __callKey3(_this._ES5ProxyType ? _this.get("queryStore") : _this.queryStore, "markQueryError", queryId, error, fetchMoreForQueryId);

                      __callKey1$1(_this, "invalidate", queryId);

                      __callKey1$1(_this, "invalidate", fetchMoreForQueryId);

                      __callKey0(_this, "broadcastQueries");
                    }

                    throw new ApolloError({
                      networkError: error
                    });
                  }
                });

                if (fetchPolicy !== 'cache-and-network') {
                  return [2, networkResult];
                }

                __callKey1$1(networkResult, "catch", function () {});
              }

              __callKey2(this._ES5ProxyType ? this.get("queryStore") : this.queryStore, "markQueryResultClient", queryId, !shouldFetch);

              __callKey1$1(this, "invalidate", queryId);

              __callKey1$1(this, "invalidate", fetchMoreForQueryId);

              if (_this$transform5 = __callKey1$1(this, "transform", query), _hasForcedResolvers = _this$transform5._ES5ProxyType ? _this$transform5.get("hasForcedResolvers") : _this$transform5.hasForcedResolvers) {
                return [2, __callKey1$1(__callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "runResolvers", {
                  document: query,
                  remoteResult: {
                    data: storeResult
                  },
                  context: context,
                  variables: variables,
                  onlyRunForcedResolvers: true
                }), "then", function (result) {
                  __callKey4(_this, "markQueryResult", queryId, result, options, fetchMoreForQueryId);

                  __callKey0(_this, "broadcastQueries");

                  return result;
                })];
              }

              __callKey0(this, "broadcastQueries");

              return [2, {
                data: storeResult
              }];
          }
        });
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "markQueryResult", function (queryId, result, _a, fetchMoreForQueryId) {
      var fetchPolicy = _a._ES5ProxyType ? _a.get("fetchPolicy") : _a.fetchPolicy,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          errorPolicy = _a._ES5ProxyType ? _a.get("errorPolicy") : _a.errorPolicy;

      if (fetchPolicy === 'no-cache') {
        __callKey2(this, "setQuery", queryId, function () {
          return {
            newData: {
              result: result._ES5ProxyType ? result.get("data") : result.data,
              complete: true
            }
          };
        });
      } else {
        var _this$getQuery2, _document3;

        __callKey(this._ES5ProxyType ? this.get("dataStore") : this.dataStore, "markQueryResult", result, (_this$getQuery2 = __callKey1$1(this, "getQuery", queryId), _document3 = _this$getQuery2._ES5ProxyType ? _this$getQuery2.get("document") : _this$getQuery2.document), variables, fetchMoreForQueryId, errorPolicy === 'ignore' || errorPolicy === 'all');
      }
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "queryListenerForObserver", function (queryId, options, observer) {
      var _this = this;

      function invoke(method, argument) {
        if (observer._ES5ProxyType ? observer.get(method) : observer[method]) {
          try {
            __callKey1$1(observer, method, argument);
          } catch (e) {
             __callKey1$1(invariant$3, "error", e);
          }
        } else if (method === 'error') {
           __callKey1$1(invariant$3, "error", argument);
        }
      }

      return function (queryStoreValue, newData) {
        var _options13, _fetchPolicy5, _options14, _errorPolicy3;

        __callKey2(_this, "invalidate", queryId, false);

        if (!queryStoreValue) return;

        var _a = __callKey1$1(_this, "getQuery", queryId),
            observableQuery = _a._ES5ProxyType ? _a.get("observableQuery") : _a.observableQuery,
            document = _a._ES5ProxyType ? _a.get("document") : _a.document;

        var fetchPolicy = observableQuery ? (_options13 = observableQuery._ES5ProxyType ? observableQuery.get("options") : observableQuery.options, _fetchPolicy5 = _options13._ES5ProxyType ? _options13.get("fetchPolicy") : _options13.fetchPolicy) : options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy;
        if (fetchPolicy === 'standby') return;
        var loading = isNetworkRequestInFlight(queryStoreValue._ES5ProxyType ? queryStoreValue.get("networkStatus") : queryStoreValue.networkStatus);

        var lastResult = observableQuery && __callKey0(observableQuery, "getLastResult");

        var networkStatusChanged = !!(lastResult && (lastResult._ES5ProxyType ? lastResult.get("networkStatus") : lastResult.networkStatus) !== (queryStoreValue._ES5ProxyType ? queryStoreValue.get("networkStatus") : queryStoreValue.networkStatus));
        var shouldNotifyIfLoading = (options._ES5ProxyType ? options.get("returnPartialData") : options.returnPartialData) || !newData && (queryStoreValue._ES5ProxyType ? queryStoreValue.get("previousVariables") : queryStoreValue.previousVariables) || networkStatusChanged && (options._ES5ProxyType ? options.get("notifyOnNetworkStatusChange") : options.notifyOnNetworkStatusChange) || fetchPolicy === 'cache-only' || fetchPolicy === 'cache-and-network';

        if (loading && !shouldNotifyIfLoading) {
          return;
        }

        var hasGraphQLErrors = isNonEmptyArray(queryStoreValue._ES5ProxyType ? queryStoreValue.get("graphQLErrors") : queryStoreValue.graphQLErrors);
        var errorPolicy = observableQuery && (_options14 = observableQuery._ES5ProxyType ? observableQuery.get("options") : observableQuery.options, _errorPolicy3 = _options14._ES5ProxyType ? _options14.get("errorPolicy") : _options14.errorPolicy) || (options._ES5ProxyType ? options.get("errorPolicy") : options.errorPolicy) || 'none';

        if (errorPolicy === 'none' && hasGraphQLErrors || (queryStoreValue._ES5ProxyType ? queryStoreValue.get("networkError") : queryStoreValue.networkError)) {
          return invoke('error', new ApolloError({
            graphQLErrors: queryStoreValue._ES5ProxyType ? queryStoreValue.get("graphQLErrors") : queryStoreValue.graphQLErrors,
            networkError: queryStoreValue._ES5ProxyType ? queryStoreValue.get("networkError") : queryStoreValue.networkError
          }));
        }

        try {
          var data = void 0;
          var isMissing = void 0;

          if (newData) {
            if (fetchPolicy !== 'no-cache' && fetchPolicy !== 'network-only') {
              __callKey2(_this, "setQuery", queryId, function () {
                return {
                  newData: null
                };
              });
            }

            data = newData._ES5ProxyType ? newData.get("result") : newData.result;
            isMissing = !(newData._ES5ProxyType ? newData.get("complete") : newData.complete);
          } else {
            var lastError = observableQuery && __callKey0(observableQuery, "getLastError");

            var errorStatusChanged = errorPolicy !== 'none' && (lastError && (lastError._ES5ProxyType ? lastError.get("graphQLErrors") : lastError.graphQLErrors)) !== (queryStoreValue._ES5ProxyType ? queryStoreValue.get("graphQLErrors") : queryStoreValue.graphQLErrors);

            if (lastResult && (lastResult._ES5ProxyType ? lastResult.get("data") : lastResult.data) && !errorStatusChanged) {
              data = lastResult._ES5ProxyType ? lastResult.get("data") : lastResult.data;
              isMissing = false;
            } else {
              var diffResult = __callKey1$1(__callKey0(_this._ES5ProxyType ? _this.get("dataStore") : _this.dataStore, "getCache"), "diff", {
                query: document,
                variables: (queryStoreValue._ES5ProxyType ? queryStoreValue.get("previousVariables") : queryStoreValue.previousVariables) || (queryStoreValue._ES5ProxyType ? queryStoreValue.get("variables") : queryStoreValue.variables),
                returnPartialData: true,
                optimistic: true
              });

              data = diffResult._ES5ProxyType ? diffResult.get("result") : diffResult.result;
              isMissing = !(diffResult._ES5ProxyType ? diffResult.get("complete") : diffResult.complete);
            }
          }

          var stale = isMissing && !((options._ES5ProxyType ? options.get("returnPartialData") : options.returnPartialData) || fetchPolicy === 'cache-only');
          var resultFromStore = {
            data: stale ? lastResult && (lastResult._ES5ProxyType ? lastResult.get("data") : lastResult.data) : data,
            loading: loading,
            networkStatus: queryStoreValue._ES5ProxyType ? queryStoreValue.get("networkStatus") : queryStoreValue.networkStatus,
            stale: stale
          };

          if (errorPolicy === 'all' && hasGraphQLErrors) {
            __setKey(resultFromStore, "errors", queryStoreValue._ES5ProxyType ? queryStoreValue.get("graphQLErrors") : queryStoreValue.graphQLErrors);
          }

          invoke('next', resultFromStore);
        } catch (networkError) {
          invoke('error', new ApolloError({
            networkError: networkError
          }));
        }
      };
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "transform", function (document) {
      var transformCache = this._ES5ProxyType ? this.get("transformCache") : this.transformCache;

      if (!__callKey1$1(transformCache, "has", document)) {
        var cache = __callKey0(this._ES5ProxyType ? this.get("dataStore") : this.dataStore, "getCache");

        var transformed = __callKey1$1(cache, "transformDocument", document);

        var forLink = removeConnectionDirectiveFromDocument(__callKey1$1(cache, "transformForLink", transformed));

        var clientQuery = __callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "clientQuery", transformed);

        var serverQuery = __callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "serverQuery", forLink);

        var cacheEntry_1 = {
          document: transformed,
          hasClientExports: hasClientExports(transformed),
          hasForcedResolvers: __callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "shouldForceResolvers", transformed),
          clientQuery: clientQuery,
          serverQuery: serverQuery,
          defaultVars: getDefaultValues(getOperationDefinition(transformed))
        };

        var add = function add(doc) {
          if (doc && !__callKey1$1(transformCache, "has", doc)) {
            __callKey2(transformCache, "set", doc, cacheEntry_1);
          }
        };

        add(document);
        add(transformed);
        add(clientQuery);
        add(serverQuery);
      }

      return __callKey1$1(transformCache, "get", document);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "getVariables", function (document, variables) {
      var _this$transform6, _defaultVars;

      return _assign(_assign({}, (_this$transform6 = __callKey1$1(this, "transform", document), _defaultVars = _this$transform6._ES5ProxyType ? _this$transform6.get("defaultVars") : _this$transform6.defaultVars)), variables);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "watchQuery", function (options, shouldSubscribe) {
      if (shouldSubscribe === void 0) {
        shouldSubscribe = true;
      }

       invariant$3((options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy) !== 'standby', 'client.watchQuery cannot be called with fetchPolicy set to "standby"');

      __setKey(options, "variables", __callKey2(this, "getVariables", options._ES5ProxyType ? options.get("query") : options.query, options._ES5ProxyType ? options.get("variables") : options.variables));

      if (typeof (options._ES5ProxyType ? options.get("notifyOnNetworkStatusChange") : options.notifyOnNetworkStatusChange) === 'undefined') {
        __setKey(options, "notifyOnNetworkStatusChange", false);
      }

      var transformedOptions = _assign({}, options);

      return new ObservableQuery({
        queryManager: this,
        options: transformedOptions,
        shouldSubscribe: shouldSubscribe
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "query", function (options) {
      var _query2, _kind4;

      var _this = this;

       invariant$3(options._ES5ProxyType ? options.get("query") : options.query, 'query option is required. You must specify your GraphQL document ' + 'in the query option.');
       invariant$3((_query2 = options._ES5ProxyType ? options.get("query") : options.query, _kind4 = _query2._ES5ProxyType ? _query2.get("kind") : _query2.kind) === 'Document', 'You must wrap the query string in a "gql" tag.');
       invariant$3(!(options._ES5ProxyType ? options.get("returnPartialData") : options.returnPartialData), 'returnPartialData option only supported on watchQuery.');
       invariant$3(!(options._ES5ProxyType ? options.get("pollInterval") : options.pollInterval), 'pollInterval option only supported on watchQuery.');
      return new Promise(function (resolve, reject) {
        var watchedQuery = __callKey2(_this, "watchQuery", options, false);

        __callKey2(_this._ES5ProxyType ? _this.get("fetchQueryRejectFns") : _this.fetchQueryRejectFns, "set", "query:" + (watchedQuery._ES5ProxyType ? watchedQuery.get("queryId") : watchedQuery.queryId), reject);

        __callKey1$1(__callKey2(__callKey0(watchedQuery, "result"), "then", resolve, reject), "then", function () {
          return __callKey1$1(_this._ES5ProxyType ? _this.get("fetchQueryRejectFns") : _this.fetchQueryRejectFns, "delete", "query:" + (watchedQuery._ES5ProxyType ? watchedQuery.get("queryId") : watchedQuery.queryId));
        });
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "generateQueryId", function () {
      return String(__setKeyPostfixIncrement(this, "idCounter"));
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "stopQueryInStore", function (queryId) {
      __callKey1$1(this, "stopQueryInStoreNoBroadcast", queryId);

      __callKey0(this, "broadcastQueries");
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "stopQueryInStoreNoBroadcast", function (queryId) {
      __callKey1$1(this, "stopPollingQuery", queryId);

      __callKey1$1(this._ES5ProxyType ? this.get("queryStore") : this.queryStore, "stopQuery", queryId);

      __callKey1$1(this, "invalidate", queryId);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "addQueryListener", function (queryId, listener) {
      __callKey2(this, "setQuery", queryId, function (_a) {
        var listeners = _a._ES5ProxyType ? _a.get("listeners") : _a.listeners;

        __callKey1$1(listeners, "add", listener);

        return {
          invalidated: false
        };
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "updateQueryWatch", function (queryId, document, options) {
      var _this$getQuery3, _cancel;

      var _this = this;

      var cancel = (_this$getQuery3 = __callKey1$1(this, "getQuery", queryId), _cancel = _this$getQuery3._ES5ProxyType ? _this$getQuery3.get("cancel") : _this$getQuery3.cancel);
      if (cancel) cancel();

      var previousResult = function previousResult() {
        var _this$getQuery4, _observableQuery;

        var previousResult = null;
        var observableQuery = (_this$getQuery4 = __callKey1$1(_this, "getQuery", queryId), _observableQuery = _this$getQuery4._ES5ProxyType ? _this$getQuery4.get("observableQuery") : _this$getQuery4.observableQuery);

        if (observableQuery) {
          var lastResult = __callKey0(observableQuery, "getLastResult");

          if (lastResult) {
            previousResult = lastResult._ES5ProxyType ? lastResult.get("data") : lastResult.data;
          }
        }

        return previousResult;
      };

      return __callKey1$1(__callKey0(this._ES5ProxyType ? this.get("dataStore") : this.dataStore, "getCache"), "watch", {
        query: document,
        variables: options._ES5ProxyType ? options.get("variables") : options.variables,
        optimistic: true,
        previousResult: previousResult,
        callback: function callback(newData) {
          __callKey2(_this, "setQuery", queryId, function () {
            return {
              invalidated: true,
              newData: newData
            };
          });
        }
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "addObservableQuery", function (queryId, observableQuery) {
      __callKey2(this, "setQuery", queryId, function () {
        return {
          observableQuery: observableQuery
        };
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "removeObservableQuery", function (queryId) {
      var _this$getQuery5, _cancel2;

      var cancel = (_this$getQuery5 = __callKey1$1(this, "getQuery", queryId), _cancel2 = _this$getQuery5._ES5ProxyType ? _this$getQuery5.get("cancel") : _this$getQuery5.cancel);

      __callKey2(this, "setQuery", queryId, function () {
        return {
          observableQuery: null
        };
      });

      if (cancel) cancel();
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "clearStore", function () {
      __callKey1$1(this._ES5ProxyType ? this.get("fetchQueryRejectFns") : this.fetchQueryRejectFns, "forEach", function (reject) {
        reject( new InvariantError('Store reset while query was in flight (not completed in link chain)'));
      });

      var resetIds = [];

      __callKey1$1(this._ES5ProxyType ? this.get("queries") : this.queries, "forEach", function (_a, queryId) {
        var observableQuery = _a._ES5ProxyType ? _a.get("observableQuery") : _a.observableQuery;
        if (observableQuery) resetIds.push(queryId);
      });

      __callKey1$1(this._ES5ProxyType ? this.get("queryStore") : this.queryStore, "reset", resetIds);

      __callKey0(this._ES5ProxyType ? this.get("mutationStore") : this.mutationStore, "reset");

      return __callKey0(this._ES5ProxyType ? this.get("dataStore") : this.dataStore, "reset");
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "resetStore", function () {
      var _this = this;

      return __callKey1$1(__callKey0(this, "clearStore"), "then", function () {
        return __callKey0(_this, "reFetchObservableQueries");
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "reFetchObservableQueries", function (includeStandby) {
      var _this = this;

      if (includeStandby === void 0) {
        includeStandby = false;
      }

      var observableQueryPromises = [];

      __callKey1$1(this._ES5ProxyType ? this.get("queries") : this.queries, "forEach", function (_a, queryId) {
        var observableQuery = _a._ES5ProxyType ? _a.get("observableQuery") : _a.observableQuery;

        if (observableQuery) {
          var _options15, _fetchPolicy6;

          var fetchPolicy = (_options15 = observableQuery._ES5ProxyType ? observableQuery.get("options") : observableQuery.options, _fetchPolicy6 = _options15._ES5ProxyType ? _options15.get("fetchPolicy") : _options15.fetchPolicy);

          __callKey0(observableQuery, "resetLastResults");

          if (fetchPolicy !== 'cache-only' && (includeStandby || fetchPolicy !== 'standby')) {
            observableQueryPromises.push(__callKey0(observableQuery, "refetch"));
          }

          __callKey2(_this, "setQuery", queryId, function () {
            return {
              newData: null
            };
          });

          __callKey1$1(_this, "invalidate", queryId);
        }
      });

      __callKey0(this, "broadcastQueries");

      return Promise.all(observableQueryPromises);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "observeQuery", function (queryId, options, observer) {
      __callKey2(this, "addQueryListener", queryId, __callKey3(this, "queryListenerForObserver", queryId, options, observer));

      return __callKey2(this, "fetchQuery", queryId, options);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "startQuery", function (queryId, options, listener) {
       __callKey1$1(invariant$3, "warn", "The QueryManager.startQuery method has been deprecated");

      __callKey2(this, "addQueryListener", queryId, listener);

      __callKey1$1(__callKey2(this, "fetchQuery", queryId, options), "catch", function () {
        return undefined;
      });

      return queryId;
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "startGraphQLSubscription", function (_a) {
      var _this$transform7, _document4, _this$transform8, _hasClientExports4;

      var _this = this;

      var query = _a._ES5ProxyType ? _a.get("query") : _a.query,
          fetchPolicy = _a._ES5ProxyType ? _a.get("fetchPolicy") : _a.fetchPolicy,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables;
      query = (_this$transform7 = __callKey1$1(this, "transform", query), _document4 = _this$transform7._ES5ProxyType ? _this$transform7.get("document") : _this$transform7.document);
      variables = __callKey2(this, "getVariables", query, variables);

      var makeObservable = function makeObservable(variables) {
        return __callKey1$1(__callKey4(_this, "getObservableFromLink", query, {}, variables, false), "map", function (result) {
          if (!fetchPolicy || fetchPolicy !== 'no-cache') {
            __callKey3(_this._ES5ProxyType ? _this.get("dataStore") : _this.dataStore, "markSubscriptionResult", result, query, variables);

            __callKey0(_this, "broadcastQueries");
          }

          if (graphQLResultHasError(result)) {
            throw new ApolloError({
              graphQLErrors: result._ES5ProxyType ? result.get("errors") : result.errors
            });
          }

          return result;
        });
      };

      if (_this$transform8 = __callKey1$1(this, "transform", query), _hasClientExports4 = _this$transform8._ES5ProxyType ? _this$transform8.get("hasClientExports") : _this$transform8.hasClientExports) {
        var observablePromise_1 = __callKey1$1(__callKey2(this._ES5ProxyType ? this.get("localState") : this.localState, "addExportedVariables", query, variables), "then", makeObservable);

        return new Observable$2(function (observer) {
          var sub = null;

          __callKey2(observablePromise_1, "then", function (observable) {
            return sub = __callKey1$1(observable, "subscribe", observer);
          }, observer._ES5ProxyType ? observer.get("error") : observer.error);

          return function () {
            return sub && __callKey0(sub, "unsubscribe");
          };
        });
      }

      return makeObservable(variables);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "stopQuery", function (queryId) {
      __callKey1$1(this, "stopQueryNoBroadcast", queryId);

      __callKey0(this, "broadcastQueries");
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "stopQueryNoBroadcast", function (queryId) {
      __callKey1$1(this, "stopQueryInStoreNoBroadcast", queryId);

      __callKey1$1(this, "removeQuery", queryId);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "removeQuery", function (queryId) {
      var _this$getQuery6, _subscriptions;

      __callKey1$1(this._ES5ProxyType ? this.get("fetchQueryRejectFns") : this.fetchQueryRejectFns, "delete", "query:" + queryId);

      __callKey1$1(this._ES5ProxyType ? this.get("fetchQueryRejectFns") : this.fetchQueryRejectFns, "delete", "fetchRequest:" + queryId);

      __callKey1$1((_this$getQuery6 = __callKey1$1(this, "getQuery", queryId), _subscriptions = _this$getQuery6._ES5ProxyType ? _this$getQuery6.get("subscriptions") : _this$getQuery6.subscriptions), "forEach", function (x) {
        return __callKey0(x, "unsubscribe");
      });

      __callKey1$1(this._ES5ProxyType ? this.get("queries") : this.queries, "delete", queryId);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "getCurrentQueryResult", function (observableQuery, optimistic) {
      var _this$getQuery7, _newData;

      if (optimistic === void 0) {
        optimistic = true;
      }

      var _a = observableQuery._ES5ProxyType ? observableQuery.get("options") : observableQuery.options,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          query = _a._ES5ProxyType ? _a.get("query") : _a.query,
          fetchPolicy = _a._ES5ProxyType ? _a.get("fetchPolicy") : _a.fetchPolicy,
          returnPartialData = _a._ES5ProxyType ? _a.get("returnPartialData") : _a.returnPartialData;

      var lastResult = __callKey0(observableQuery, "getLastResult");

      var newData = (_this$getQuery7 = __callKey1$1(this, "getQuery", observableQuery._ES5ProxyType ? observableQuery.get("queryId") : observableQuery.queryId), _newData = _this$getQuery7._ES5ProxyType ? _this$getQuery7.get("newData") : _this$getQuery7.newData);

      if (newData && (newData._ES5ProxyType ? newData.get("complete") : newData.complete)) {
        return {
          data: newData._ES5ProxyType ? newData.get("result") : newData.result,
          partial: false
        };
      }

      if (fetchPolicy === 'no-cache' || fetchPolicy === 'network-only') {
        return {
          data: undefined,
          partial: false
        };
      }

      var _b = __callKey1$1(__callKey0(this._ES5ProxyType ? this.get("dataStore") : this.dataStore, "getCache"), "diff", {
        query: query,
        variables: variables,
        previousResult: lastResult ? lastResult._ES5ProxyType ? lastResult.get("data") : lastResult.data : undefined,
        returnPartialData: true,
        optimistic: optimistic
      }),
          result = _b._ES5ProxyType ? _b.get("result") : _b.result,
          complete = _b._ES5ProxyType ? _b.get("complete") : _b.complete;

      return {
        data: complete || returnPartialData ? result : void 0,
        partial: !complete
      };
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "getQueryWithPreviousResult", function (queryIdOrObservable) {
      var _this$getCurrentQuery, _data;

      var observableQuery;

      if (typeof queryIdOrObservable === 'string') {
        var _this$getQuery8, _observableQuery2;

        var foundObserveableQuery = (_this$getQuery8 = __callKey1$1(this, "getQuery", queryIdOrObservable), _observableQuery2 = _this$getQuery8._ES5ProxyType ? _this$getQuery8.get("observableQuery") : _this$getQuery8.observableQuery);
         invariant$3(foundObserveableQuery, "ObservableQuery with this id doesn't exist: " + queryIdOrObservable);
        observableQuery = foundObserveableQuery;
      } else {
        observableQuery = queryIdOrObservable;
      }

      var _a = observableQuery._ES5ProxyType ? observableQuery.get("options") : observableQuery.options,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          query = _a._ES5ProxyType ? _a.get("query") : _a.query;

      return {
        previousResult: (_this$getCurrentQuery = __callKey2(this, "getCurrentQueryResult", observableQuery, false), _data = _this$getCurrentQuery._ES5ProxyType ? _this$getCurrentQuery.get("data") : _this$getCurrentQuery.data),
        variables: variables,
        document: query
      };
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "broadcastQueries", function () {
      var _this = this;

      __callKey0(this, "onBroadcast");

      __callKey1$1(this._ES5ProxyType ? this.get("queries") : this.queries, "forEach", function (info, id) {
        if (info._ES5ProxyType ? info.get("invalidated") : info.invalidated) {
          __callKey1$1(info._ES5ProxyType ? info.get("listeners") : info.listeners, "forEach", function (listener) {
            if (listener) {
              listener(__callKey1$1(_this._ES5ProxyType ? _this.get("queryStore") : _this.queryStore, "get", id), info._ES5ProxyType ? info.get("newData") : info.newData);
            }
          });
        }
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "getLocalState", function () {
      return this._ES5ProxyType ? this.get("localState") : this.localState;
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "getObservableFromLink", function (query, context, variables, deduplication) {
      var _this$transform9, _serverQuery2, _this$transform10, _clientQuery;

      var _this = this;

      if (deduplication === void 0) {
        deduplication = this._ES5ProxyType ? this.get("queryDeduplication") : this.queryDeduplication;
      }

      var observable;
      var serverQuery = (_this$transform9 = __callKey1$1(this, "transform", query), _serverQuery2 = _this$transform9._ES5ProxyType ? _this$transform9.get("serverQuery") : _this$transform9.serverQuery);

      if (serverQuery) {
        var _a = this,
            inFlightLinkObservables_1 = _a._ES5ProxyType ? _a.get("inFlightLinkObservables") : _a.inFlightLinkObservables,
            link = _a._ES5ProxyType ? _a.get("link") : _a.link;

        var operation = {
          query: serverQuery,
          variables: variables,
          operationName: getOperationName(serverQuery) || void 0,
          context: __callKey1$1(this, "prepareContext", _assign(_assign({}, context), {
            forceFetch: !deduplication
          }))
        };
        context = operation._ES5ProxyType ? operation.get("context") : operation.context;

        if (deduplication) {
          var byVariables_1 = __callKey1$1(inFlightLinkObservables_1, "get", serverQuery) || new Map();

          __callKey2(inFlightLinkObservables_1, "set", serverQuery, byVariables_1);

          var varJson_1 = JSON.stringify(variables);
          observable = __callKey1$1(byVariables_1, "get", varJson_1);

          if (!observable) {
            __callKey2(byVariables_1, "set", varJson_1, observable = multiplex(execute(link, operation)));

            var cleanup = function cleanup() {
              __callKey1$1(byVariables_1, "delete", varJson_1);

              if (!(byVariables_1._ES5ProxyType ? byVariables_1.get("size") : byVariables_1.size)) __callKey1$1(inFlightLinkObservables_1, "delete", serverQuery);

              __callKey0(cleanupSub_1, "unsubscribe");
            };

            var cleanupSub_1 = __callKey1$1(observable, "subscribe", {
              next: cleanup,
              error: cleanup,
              complete: cleanup
            });
          }
        } else {
          observable = multiplex(execute(link, operation));
        }
      } else {
        observable = __callKey1$1(Observable$2, "of", {
          data: {}
        });
        context = __callKey1$1(this, "prepareContext", context);
      }

      var clientQuery = (_this$transform10 = __callKey1$1(this, "transform", query), _clientQuery = _this$transform10._ES5ProxyType ? _this$transform10.get("clientQuery") : _this$transform10.clientQuery);

      if (clientQuery) {
        observable = asyncMap(observable, function (result) {
          return __callKey1$1(_this._ES5ProxyType ? _this.get("localState") : _this.localState, "runResolvers", {
            document: clientQuery,
            remoteResult: result,
            context: context,
            variables: variables
          });
        });
      }

      return observable;
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "fetchRequest", function (_a) {
      var _this = this;

      var requestId = _a._ES5ProxyType ? _a.get("requestId") : _a.requestId,
          queryId = _a._ES5ProxyType ? _a.get("queryId") : _a.queryId,
          document = _a._ES5ProxyType ? _a.get("document") : _a.document,
          options = _a._ES5ProxyType ? _a.get("options") : _a.options,
          fetchMoreForQueryId = _a._ES5ProxyType ? _a.get("fetchMoreForQueryId") : _a.fetchMoreForQueryId;

      var variables = options._ES5ProxyType ? options.get("variables") : options.variables,
          _b = options._ES5ProxyType ? options.get("errorPolicy") : options.errorPolicy,
          errorPolicy = _b === void 0 ? 'none' : _b,
          fetchPolicy = options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy;

      var resultFromStore;
      var errorsFromStore;
      return new Promise(function (resolve, reject) {
        var observable = __callKey3(_this, "getObservableFromLink", document, options._ES5ProxyType ? options.get("context") : options.context, variables);

        var fqrfId = "fetchRequest:" + queryId;

        __callKey2(_this._ES5ProxyType ? _this.get("fetchQueryRejectFns") : _this.fetchQueryRejectFns, "set", fqrfId, reject);

        var cleanup = function cleanup() {
          __callKey1$1(_this._ES5ProxyType ? _this.get("fetchQueryRejectFns") : _this.fetchQueryRejectFns, "delete", fqrfId);

          __callKey2(_this, "setQuery", queryId, function (_a) {
            var subscriptions = _a._ES5ProxyType ? _a.get("subscriptions") : _a.subscriptions;

            __callKey1$1(subscriptions, "delete", subscription);
          });
        };

        var subscription = __callKey1$1(__callKey1$1(observable, "map", function (result) {
          var _this$getQuery9, _lastRequestId2;

          if (requestId >= (_this$getQuery9 = __callKey1$1(_this, "getQuery", queryId), _lastRequestId2 = _this$getQuery9._ES5ProxyType ? _this$getQuery9.get("lastRequestId") : _this$getQuery9.lastRequestId)) {
            __callKey4(_this, "markQueryResult", queryId, result, options, fetchMoreForQueryId);

            __callKey3(_this._ES5ProxyType ? _this.get("queryStore") : _this.queryStore, "markQueryResult", queryId, result, fetchMoreForQueryId);

            __callKey1$1(_this, "invalidate", queryId);

            __callKey1$1(_this, "invalidate", fetchMoreForQueryId);

            __callKey0(_this, "broadcastQueries");
          }

          if (errorPolicy === 'none' && isNonEmptyArray(result._ES5ProxyType ? result.get("errors") : result.errors)) {
            return reject(new ApolloError({
              graphQLErrors: result._ES5ProxyType ? result.get("errors") : result.errors
            }));
          }

          if (errorPolicy === 'all') {
            errorsFromStore = result._ES5ProxyType ? result.get("errors") : result.errors;
          }

          if (fetchMoreForQueryId || fetchPolicy === 'no-cache') {
            resultFromStore = result._ES5ProxyType ? result.get("data") : result.data;
          } else {
            var _a = __callKey1$1(__callKey0(_this._ES5ProxyType ? _this.get("dataStore") : _this.dataStore, "getCache"), "diff", {
              variables: variables,
              query: document,
              optimistic: false,
              returnPartialData: true
            }),
                result_1 = _a._ES5ProxyType ? _a.get("result") : _a.result,
                complete = _a._ES5ProxyType ? _a.get("complete") : _a.complete;

            if (complete || (options._ES5ProxyType ? options.get("returnPartialData") : options.returnPartialData)) {
              resultFromStore = result_1;
            }
          }
        }), "subscribe", {
          error: function error(_error3) {
            cleanup();
            reject(_error3);
          },
          complete: function complete() {
            cleanup();
            resolve({
              data: resultFromStore,
              errors: errorsFromStore,
              loading: false,
              networkStatus: NetworkStatus._ES5ProxyType ? NetworkStatus.get("ready") : NetworkStatus.ready,
              stale: false
            });
          }
        });

        __callKey2(_this, "setQuery", queryId, function (_a) {
          var subscriptions = _a._ES5ProxyType ? _a.get("subscriptions") : _a.subscriptions;

          __callKey1$1(subscriptions, "add", subscription);
        });
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "getQuery", function (queryId) {
      return __callKey1$1(this._ES5ProxyType ? this.get("queries") : this.queries, "get", queryId) || {
        listeners: new Set(),
        invalidated: false,
        document: null,
        newData: null,
        lastRequestId: 1,
        observableQuery: null,
        subscriptions: new Set()
      };
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "setQuery", function (queryId, updater) {
      var prev = __callKey1$1(this, "getQuery", queryId);

      var newInfo = _assign(_assign({}, prev), updater(prev));

      __callKey2(this._ES5ProxyType ? this.get("queries") : this.queries, "set", queryId, newInfo);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "invalidate", function (queryId, invalidated) {
      if (invalidated === void 0) {
        invalidated = true;
      }

      if (queryId) {
        __callKey2(this, "setQuery", queryId, function () {
          return {
            invalidated: invalidated
          };
        });
      }
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "prepareContext", function (context) {
      if (context === void 0) {
        context = {};
      }

      var newContext = __callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "prepareContext", context);

      return _assign(_assign({}, newContext), {
        clientAwareness: this._ES5ProxyType ? this.get("clientAwareness") : this.clientAwareness
      });
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "checkInFlight", function (queryId) {
      var query = __callKey1$1(this._ES5ProxyType ? this.get("queryStore") : this.queryStore, "get", queryId);

      return query && (query._ES5ProxyType ? query.get("networkStatus") : query.networkStatus) !== (NetworkStatus._ES5ProxyType ? NetworkStatus.get("ready") : NetworkStatus.ready) && (query._ES5ProxyType ? query.get("networkStatus") : query.networkStatus) !== (NetworkStatus._ES5ProxyType ? NetworkStatus.get("error") : NetworkStatus.error);
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "startPollingQuery", function (options, queryId, listener) {
      var _this = this;

      var pollInterval = options._ES5ProxyType ? options.get("pollInterval") : options.pollInterval;
       invariant$3(pollInterval, 'Attempted to start a polling query without a polling interval.');

      if (!(this._ES5ProxyType ? this.get("ssrMode") : this.ssrMode)) {
        var info = __callKey1$1(this._ES5ProxyType ? this.get("pollingInfoByQueryId") : this.pollingInfoByQueryId, "get", queryId);

        if (!info) {
          __callKey2(this._ES5ProxyType ? this.get("pollingInfoByQueryId") : this.pollingInfoByQueryId, "set", queryId, info = {});
        }

        __setKey(info, "interval", pollInterval);

        __setKey(info, "options", _assign(_assign({}, options), {
          fetchPolicy: 'network-only'
        }));

        var maybeFetch_1 = function maybeFetch_1() {
          var info = __callKey1$1(_this._ES5ProxyType ? _this.get("pollingInfoByQueryId") : _this.pollingInfoByQueryId, "get", queryId);

          if (info) {
            if (__callKey1$1(_this, "checkInFlight", queryId)) {
              poll_1();
            } else {
              __callKey2(__callKey3(_this, "fetchQuery", queryId, info._ES5ProxyType ? info.get("options") : info.options, FetchType._ES5ProxyType ? FetchType.get("poll") : FetchType.poll), "then", poll_1, poll_1);
            }
          }
        };

        var poll_1 = function poll_1() {
          var info = __callKey1$1(_this._ES5ProxyType ? _this.get("pollingInfoByQueryId") : _this.pollingInfoByQueryId, "get", queryId);

          if (info) {
            clearTimeout(info._ES5ProxyType ? info.get("timeout") : info.timeout);

            __setKey(info, "timeout", setTimeout(maybeFetch_1, info._ES5ProxyType ? info.get("interval") : info.interval));
          }
        };

        if (listener) {
          __callKey2(this, "addQueryListener", queryId, listener);
        }

        poll_1();
      }

      return queryId;
    });

    __setKey(QueryManager._ES5ProxyType ? QueryManager.get("prototype") : QueryManager.prototype, "stopPollingQuery", function (queryId) {
      __callKey1$1(this._ES5ProxyType ? this.get("pollingInfoByQueryId") : this.pollingInfoByQueryId, "delete", queryId);
    });

    return QueryManager;
  }();

  var DataStore = function () {
    function DataStore(initialCache) {
      __setKey(this, "cache", initialCache);
    }

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "getCache", function () {
      return this._ES5ProxyType ? this.get("cache") : this.cache;
    });

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "markQueryResult", function (result, document, variables, fetchMoreForQueryId, ignoreErrors) {
      if (ignoreErrors === void 0) {
        ignoreErrors = false;
      }

      var writeWithErrors = !graphQLResultHasError(result);

      if (ignoreErrors && graphQLResultHasError(result) && (result._ES5ProxyType ? result.get("data") : result.data)) {
        writeWithErrors = true;
      }

      if (!fetchMoreForQueryId && writeWithErrors) {
        __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "write", {
          result: result._ES5ProxyType ? result.get("data") : result.data,
          dataId: 'ROOT_QUERY',
          query: document,
          variables: variables
        });
      }
    });

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "markSubscriptionResult", function (result, document, variables) {
      if (!graphQLResultHasError(result)) {
        __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "write", {
          result: result._ES5ProxyType ? result.get("data") : result.data,
          dataId: 'ROOT_SUBSCRIPTION',
          query: document,
          variables: variables
        });
      }
    });

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "markMutationInit", function (mutation) {
      var _this = this;

      if (mutation._ES5ProxyType ? mutation.get("optimisticResponse") : mutation.optimisticResponse) {
        var optimistic_1;

        if (typeof (mutation._ES5ProxyType ? mutation.get("optimisticResponse") : mutation.optimisticResponse) === 'function') {
          optimistic_1 = __callKey1$1(mutation, "optimisticResponse", mutation._ES5ProxyType ? mutation.get("variables") : mutation.variables);
        } else {
          optimistic_1 = mutation._ES5ProxyType ? mutation.get("optimisticResponse") : mutation.optimisticResponse;
        }

        __callKey2(this._ES5ProxyType ? this.get("cache") : this.cache, "recordOptimisticTransaction", function (c) {
          var orig = _this._ES5ProxyType ? _this.get("cache") : _this.cache;

          __setKey(_this, "cache", c);

          try {
            __callKey1$1(_this, "markMutationResult", {
              mutationId: mutation._ES5ProxyType ? mutation.get("mutationId") : mutation.mutationId,
              result: {
                data: optimistic_1
              },
              document: mutation._ES5ProxyType ? mutation.get("document") : mutation.document,
              variables: mutation._ES5ProxyType ? mutation.get("variables") : mutation.variables,
              updateQueries: mutation._ES5ProxyType ? mutation.get("updateQueries") : mutation.updateQueries,
              update: mutation._ES5ProxyType ? mutation.get("update") : mutation.update
            });
          } finally {
            __setKey(_this, "cache", orig);
          }
        }, mutation._ES5ProxyType ? mutation.get("mutationId") : mutation.mutationId);
      }
    });

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "markMutationResult", function (mutation) {
      var _this = this;

      if (!graphQLResultHasError(mutation._ES5ProxyType ? mutation.get("result") : mutation.result)) {
        var _result2, _data2;

        var cacheWrites_1 = [{
          result: (_result2 = mutation._ES5ProxyType ? mutation.get("result") : mutation.result, _data2 = _result2._ES5ProxyType ? _result2.get("data") : _result2.data),
          dataId: 'ROOT_MUTATION',
          query: mutation._ES5ProxyType ? mutation.get("document") : mutation.document,
          variables: mutation._ES5ProxyType ? mutation.get("variables") : mutation.variables
        }];
        var updateQueries_1 = mutation._ES5ProxyType ? mutation.get("updateQueries") : mutation.updateQueries;

        if (updateQueries_1) {
          __callKey1$1(Object.compatKeys(updateQueries_1), "forEach", function (id) {
            var _a = updateQueries_1._ES5ProxyType ? updateQueries_1.get(id) : updateQueries_1[id],
                query = _a._ES5ProxyType ? _a.get("query") : _a.query,
                updater = _a._ES5ProxyType ? _a.get("updater") : _a.updater;

            var _b = __callKey1$1(_this._ES5ProxyType ? _this.get("cache") : _this.cache, "diff", {
              query: query._ES5ProxyType ? query.get("document") : query.document,
              variables: query._ES5ProxyType ? query.get("variables") : query.variables,
              returnPartialData: true,
              optimistic: false
            }),
                currentQueryResult = _b._ES5ProxyType ? _b.get("result") : _b.result,
                complete = _b._ES5ProxyType ? _b.get("complete") : _b.complete;

            if (complete) {
              var nextQueryResult = tryFunctionOrLogError(function () {
                return updater(currentQueryResult, {
                  mutationResult: mutation._ES5ProxyType ? mutation.get("result") : mutation.result,
                  queryName: getOperationName(query._ES5ProxyType ? query.get("document") : query.document) || undefined,
                  queryVariables: query._ES5ProxyType ? query.get("variables") : query.variables
                });
              });

              if (nextQueryResult) {
                cacheWrites_1.push({
                  result: nextQueryResult,
                  dataId: 'ROOT_QUERY',
                  query: query._ES5ProxyType ? query.get("document") : query.document,
                  variables: query._ES5ProxyType ? query.get("variables") : query.variables
                });
              }
            }
          });
        }

        __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "performTransaction", function (c) {
          __callKey1$1(cacheWrites_1, "forEach", function (write) {
            return __callKey1$1(c, "write", write);
          });

          var update = mutation._ES5ProxyType ? mutation.get("update") : mutation.update;

          if (update) {
            tryFunctionOrLogError(function () {
              return update(c, mutation._ES5ProxyType ? mutation.get("result") : mutation.result);
            });
          }
        });
      }
    });

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "markMutationComplete", function (_a) {
      var mutationId = _a._ES5ProxyType ? _a.get("mutationId") : _a.mutationId,
          optimisticResponse = _a._ES5ProxyType ? _a.get("optimisticResponse") : _a.optimisticResponse;

      if (optimisticResponse) {
        __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "removeOptimistic", mutationId);
      }
    });

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "markUpdateQueryResult", function (document, variables, newResult) {
      __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "write", {
        result: newResult,
        dataId: 'ROOT_QUERY',
        variables: variables,
        query: document
      });
    });

    __setKey(DataStore._ES5ProxyType ? DataStore.get("prototype") : DataStore.prototype, "reset", function () {
      return __callKey0(this._ES5ProxyType ? this.get("cache") : this.cache, "reset");
    });

    return DataStore;
  }();

  var version = "2.6.10";
  var hasSuggestedDevtools = false;

  var ApolloClient = function () {
    function ApolloClient(options) {
      var _this = this;

      __setKey(this, "defaultOptions", {});

      __setKey(this, "resetStoreCallbacks", []);

      __setKey(this, "clearStoreCallbacks", []);

      var cache = options._ES5ProxyType ? options.get("cache") : options.cache,
          _a = options._ES5ProxyType ? options.get("ssrMode") : options.ssrMode,
          ssrMode = _a === void 0 ? false : _a,
          _b = options._ES5ProxyType ? options.get("ssrForceFetchDelay") : options.ssrForceFetchDelay,
          ssrForceFetchDelay = _b === void 0 ? 0 : _b,
          connectToDevTools = options._ES5ProxyType ? options.get("connectToDevTools") : options.connectToDevTools,
          _c = options._ES5ProxyType ? options.get("queryDeduplication") : options.queryDeduplication,
          queryDeduplication = _c === void 0 ? true : _c,
          defaultOptions = options._ES5ProxyType ? options.get("defaultOptions") : options.defaultOptions,
          _d = options._ES5ProxyType ? options.get("assumeImmutableResults") : options.assumeImmutableResults,
          assumeImmutableResults = _d === void 0 ? false : _d,
          resolvers = options._ES5ProxyType ? options.get("resolvers") : options.resolvers,
          typeDefs = options._ES5ProxyType ? options.get("typeDefs") : options.typeDefs,
          fragmentMatcher = options._ES5ProxyType ? options.get("fragmentMatcher") : options.fragmentMatcher,
          clientAwarenessName = options._ES5ProxyType ? options.get("name") : options.name,
          clientAwarenessVersion = options._ES5ProxyType ? options.get("version") : options.version;

      var link = options._ES5ProxyType ? options.get("link") : options.link;

      if (!link && resolvers) {
        link = __callKey0(ApolloLink, "empty");
      }

      if (!link || !cache) {
        throw  new InvariantError("In order to initialize Apollo Client, you must specify 'link' and 'cache' properties in the options object.\n" + "These options are part of the upgrade requirements when migrating from Apollo Client 1.x to Apollo Client 2.x.\n" + "For more information, please visit: https://www.apollographql.com/docs/tutorial/client.html#apollo-client-setup");
      }

      __setKey(this, "link", link);

      __setKey(this, "cache", cache);

      __setKey(this, "store", new DataStore(cache));

      __setKey(this, "disableNetworkFetches", ssrMode || ssrForceFetchDelay > 0);

      __setKey(this, "queryDeduplication", queryDeduplication);

      __setKey(this, "defaultOptions", defaultOptions || {});

      __setKey(this, "typeDefs", typeDefs);

      if (ssrForceFetchDelay) {
        setTimeout(function () {
          return __setKey(_this, "disableNetworkFetches", false);
        }, ssrForceFetchDelay);
      }

      __setKey(this, "watchQuery", __callKey1$1(this._ES5ProxyType ? this.get("watchQuery") : this.watchQuery, "bind", this));

      __setKey(this, "query", __callKey1$1(this._ES5ProxyType ? this.get("query") : this.query, "bind", this));

      __setKey(this, "mutate", __callKey1$1(this._ES5ProxyType ? this.get("mutate") : this.mutate, "bind", this));

      __setKey(this, "resetStore", __callKey1$1(this._ES5ProxyType ? this.get("resetStore") : this.resetStore, "bind", this));

      __setKey(this, "reFetchObservableQueries", __callKey1$1(this._ES5ProxyType ? this.get("reFetchObservableQueries") : this.reFetchObservableQueries, "bind", this));

      var defaultConnectToDevTools =  typeof window !== 'undefined' && !(window._ES5ProxyType ? window.get("__APOLLO_CLIENT__") : window.__APOLLO_CLIENT__);

      if (typeof connectToDevTools === 'undefined' ? defaultConnectToDevTools : connectToDevTools && typeof window !== 'undefined') {
        __setKey(window, "__APOLLO_CLIENT__", this);
      }

      if (!hasSuggestedDevtools && "development" !== 'production') {
        hasSuggestedDevtools = true;

        if (typeof window !== 'undefined' && (window._ES5ProxyType ? window.get("document") : window.document) && (window._ES5ProxyType ? window.get("top") : window.top) === (window._ES5ProxyType ? window.get("self") : window.self)) {
          if (typeof (window._ES5ProxyType ? window.get("__APOLLO_DEVTOOLS_GLOBAL_HOOK__") : window.__APOLLO_DEVTOOLS_GLOBAL_HOOK__) === 'undefined') {
            var _navigator, _userAgent, _navigator2, _userAgent2;

            if ((window._ES5ProxyType ? window.get("navigator") : window.navigator) && (_navigator = window._ES5ProxyType ? window.get("navigator") : window.navigator, _userAgent = _navigator._ES5ProxyType ? _navigator.get("userAgent") : _navigator.userAgent) && __callKey1$1((_navigator2 = window._ES5ProxyType ? window.get("navigator") : window.navigator, _userAgent2 = _navigator2._ES5ProxyType ? _navigator2.get("userAgent") : _navigator2.userAgent), "indexOf", 'Chrome') > -1) {
              __callKey1$1(console, "debug", 'Download the Apollo DevTools ' + 'for a better development experience: ' + 'https://chrome.google.com/webstore/detail/apollo-client-developer-t/jdkknkkbebbapilgoeccciglkfbmbnfm');
            }
          }
        }
      }

      __setKey(this, "version", version);

      __setKey(this, "localState", new LocalState({
        cache: cache,
        client: this,
        resolvers: resolvers,
        fragmentMatcher: fragmentMatcher
      }));

      __setKey(this, "queryManager", new QueryManager({
        link: this._ES5ProxyType ? this.get("link") : this.link,
        store: this._ES5ProxyType ? this.get("store") : this.store,
        queryDeduplication: queryDeduplication,
        ssrMode: ssrMode,
        clientAwareness: {
          name: clientAwarenessName,
          version: clientAwarenessVersion
        },
        localState: this._ES5ProxyType ? this.get("localState") : this.localState,
        assumeImmutableResults: assumeImmutableResults,
        onBroadcast: function onBroadcast() {
          if (_this._ES5ProxyType ? _this.get("devToolsHookCb") : _this.devToolsHookCb) {
            var _queryManager4, _queryStore3, _queryManager5, _mutationStore;

            __callKey1$1(_this, "devToolsHookCb", {
              action: {},
              state: {
                queries: __callKey0((_queryManager4 = _this._ES5ProxyType ? _this.get("queryManager") : _this.queryManager, _queryStore3 = _queryManager4._ES5ProxyType ? _queryManager4.get("queryStore") : _queryManager4.queryStore), "getStore"),
                mutations: __callKey0((_queryManager5 = _this._ES5ProxyType ? _this.get("queryManager") : _this.queryManager, _mutationStore = _queryManager5._ES5ProxyType ? _queryManager5.get("mutationStore") : _queryManager5.mutationStore), "getStore")
              },
              dataWithOptimisticResults: __callKey1$1(_this._ES5ProxyType ? _this.get("cache") : _this.cache, "extract", true)
            });
          }
        }
      }));
    }

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "stop", function () {
      __callKey0(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "stop");
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "watchQuery", function (options) {
      var _defaultOptions, _watchQuery;

      if (_defaultOptions = this._ES5ProxyType ? this.get("defaultOptions") : this.defaultOptions, _watchQuery = _defaultOptions._ES5ProxyType ? _defaultOptions.get("watchQuery") : _defaultOptions.watchQuery) {
        var _defaultOptions2, _watchQuery2;

        options = _assign(_assign({}, (_defaultOptions2 = this._ES5ProxyType ? this.get("defaultOptions") : this.defaultOptions, _watchQuery2 = _defaultOptions2._ES5ProxyType ? _defaultOptions2.get("watchQuery") : _defaultOptions2.watchQuery)), options);
      }

      if ((this._ES5ProxyType ? this.get("disableNetworkFetches") : this.disableNetworkFetches) && ((options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy) === 'network-only' || (options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy) === 'cache-and-network')) {
        options = _assign(_assign({}, options), {
          fetchPolicy: 'cache-first'
        });
      }

      return __callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "watchQuery", options);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "query", function (options) {
      var _defaultOptions3, _query3;

      if (_defaultOptions3 = this._ES5ProxyType ? this.get("defaultOptions") : this.defaultOptions, _query3 = _defaultOptions3._ES5ProxyType ? _defaultOptions3.get("query") : _defaultOptions3.query) {
        var _defaultOptions4, _query4;

        options = _assign(_assign({}, (_defaultOptions4 = this._ES5ProxyType ? this.get("defaultOptions") : this.defaultOptions, _query4 = _defaultOptions4._ES5ProxyType ? _defaultOptions4.get("query") : _defaultOptions4.query)), options);
      }

       invariant$3((options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy) !== 'cache-and-network', 'The cache-and-network fetchPolicy does not work with client.query, because ' + 'client.query can only return a single result. Please use client.watchQuery ' + 'to receive multiple results from the cache and the network, or consider ' + 'using a different fetchPolicy, such as cache-first or network-only.');

      if ((this._ES5ProxyType ? this.get("disableNetworkFetches") : this.disableNetworkFetches) && (options._ES5ProxyType ? options.get("fetchPolicy") : options.fetchPolicy) === 'network-only') {
        options = _assign(_assign({}, options), {
          fetchPolicy: 'cache-first'
        });
      }

      return __callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "query", options);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "mutate", function (options) {
      var _defaultOptions5, _mutate;

      if (_defaultOptions5 = this._ES5ProxyType ? this.get("defaultOptions") : this.defaultOptions, _mutate = _defaultOptions5._ES5ProxyType ? _defaultOptions5.get("mutate") : _defaultOptions5.mutate) {
        var _defaultOptions6, _mutate2;

        options = _assign(_assign({}, (_defaultOptions6 = this._ES5ProxyType ? this.get("defaultOptions") : this.defaultOptions, _mutate2 = _defaultOptions6._ES5ProxyType ? _defaultOptions6.get("mutate") : _defaultOptions6.mutate)), options);
      }

      return __callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "mutate", options);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "subscribe", function (options) {
      return __callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "startGraphQLSubscription", options);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "readQuery", function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return __callKey2(this._ES5ProxyType ? this.get("cache") : this.cache, "readQuery", options, optimistic);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "readFragment", function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return __callKey2(this._ES5ProxyType ? this.get("cache") : this.cache, "readFragment", options, optimistic);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "writeQuery", function (options) {
      var result = __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "writeQuery", options);

      __callKey0(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "broadcastQueries");

      return result;
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "writeFragment", function (options) {
      var result = __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "writeFragment", options);

      __callKey0(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "broadcastQueries");

      return result;
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "writeData", function (options) {
      var result = __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "writeData", options);

      __callKey0(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "broadcastQueries");

      return result;
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "__actionHookForDevTools", function (cb) {
      __setKey(this, "devToolsHookCb", cb);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "__requestRaw", function (payload) {
      return execute(this._ES5ProxyType ? this.get("link") : this.link, payload);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "initQueryManager", function () {
       __callKey1$1(invariant$3, "warn", 'Calling the initQueryManager method is no longer necessary, ' + 'and it will be removed from ApolloClient in version 3.0.');
      return this._ES5ProxyType ? this.get("queryManager") : this.queryManager;
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "resetStore", function () {
      var _this = this;

      return __callKey1$1(__callKey1$1(__callKey1$1(Promise.resolve(), "then", function () {
        return __callKey0(_this._ES5ProxyType ? _this.get("queryManager") : _this.queryManager, "clearStore");
      }), "then", function () {
        return Promise.all(__callKey1$1(_this._ES5ProxyType ? _this.get("resetStoreCallbacks") : _this.resetStoreCallbacks, "map", function (fn) {
          return fn();
        }));
      }), "then", function () {
        return __callKey0(_this, "reFetchObservableQueries");
      });
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "clearStore", function () {
      var _this = this;

      return __callKey1$1(__callKey1$1(Promise.resolve(), "then", function () {
        return __callKey0(_this._ES5ProxyType ? _this.get("queryManager") : _this.queryManager, "clearStore");
      }), "then", function () {
        return Promise.all(__callKey1$1(_this._ES5ProxyType ? _this.get("clearStoreCallbacks") : _this.clearStoreCallbacks, "map", function (fn) {
          return fn();
        }));
      });
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "onResetStore", function (cb) {
      var _this = this;

      (this._ES5ProxyType ? this.get("resetStoreCallbacks") : this.resetStoreCallbacks).push(cb);
      return function () {
        __setKey(_this, "resetStoreCallbacks", __callKey1$1(_this._ES5ProxyType ? _this.get("resetStoreCallbacks") : _this.resetStoreCallbacks, "filter", function (c) {
          return c !== cb;
        }));
      };
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "onClearStore", function (cb) {
      var _this = this;

      (this._ES5ProxyType ? this.get("clearStoreCallbacks") : this.clearStoreCallbacks).push(cb);
      return function () {
        __setKey(_this, "clearStoreCallbacks", __callKey1$1(_this._ES5ProxyType ? _this.get("clearStoreCallbacks") : _this.clearStoreCallbacks, "filter", function (c) {
          return c !== cb;
        }));
      };
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "reFetchObservableQueries", function (includeStandby) {
      return __callKey1$1(this._ES5ProxyType ? this.get("queryManager") : this.queryManager, "reFetchObservableQueries", includeStandby);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "extract", function (optimistic) {
      return __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "extract", optimistic);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "restore", function (serializedState) {
      return __callKey1$1(this._ES5ProxyType ? this.get("cache") : this.cache, "restore", serializedState);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "addResolvers", function (resolvers) {
      __callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "addResolvers", resolvers);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "setResolvers", function (resolvers) {
      __callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "setResolvers", resolvers);
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "getResolvers", function () {
      return __callKey0(this._ES5ProxyType ? this.get("localState") : this.localState, "getResolvers");
    });

    __setKey(ApolloClient._ES5ProxyType ? ApolloClient.get("prototype") : ApolloClient.prototype, "setLocalStateFragmentMatcher", function (fragmentMatcher) {
      __callKey1$1(this._ES5ProxyType ? this.get("localState") : this.localState, "setFragmentMatcher", fragmentMatcher);
    });

    return ApolloClient;
  }();

  registerComponent(ApolloClient, {
    tmpl: _tmpl
  });

  function queryFromPojo(obj) {
    var op = {
      kind: 'OperationDefinition',
      operation: 'query',
      name: {
        kind: 'Name',
        value: 'GeneratedClientQuery'
      },
      selectionSet: selectionSetFromObj(obj)
    };
    var out = {
      kind: 'Document',
      definitions: [op]
    };
    return out;
  }

  function fragmentFromPojo(obj, typename) {
    var frag = {
      kind: 'FragmentDefinition',
      typeCondition: {
        kind: 'NamedType',
        name: {
          kind: 'Name',
          value: typename || '__FakeType'
        }
      },
      name: {
        kind: 'Name',
        value: 'GeneratedClientQuery'
      },
      selectionSet: selectionSetFromObj(obj)
    };
    var out = {
      kind: 'Document',
      definitions: [frag]
    };
    return out;
  }

  function selectionSetFromObj(obj) {
    if (typeof obj === 'number' || typeof obj === 'boolean' || typeof obj === 'string' || typeof obj === 'undefined' || obj === null) {
      return null;
    }

    if (Array.compatIsArray(obj)) {
      return selectionSetFromObj(obj._ES5ProxyType ? obj.get(0) : obj[0]);
    }

    var selections = [];

    __callKey1$1(Object.compatKeys(obj), "forEach", function (key) {
      var nestedSelSet = selectionSetFromObj(obj._ES5ProxyType ? obj.get(key) : obj[key]);
      var field = {
        kind: 'Field',
        name: {
          kind: 'Name',
          value: key
        },
        selectionSet: nestedSelSet || undefined
      };
      selections.push(field);
    });

    var selectionSet = {
      kind: 'SelectionSet',
      selections: selections
    };
    return selectionSet;
  }

  var justTypenameQuery = {
    kind: 'Document',
    definitions: [{
      kind: 'OperationDefinition',
      operation: 'query',
      name: null,
      variableDefinitions: null,
      directives: [],
      selectionSet: {
        kind: 'SelectionSet',
        selections: [{
          kind: 'Field',
          alias: null,
          name: {
            kind: 'Name',
            value: '__typename'
          },
          arguments: [],
          directives: [],
          selectionSet: null
        }]
      }
    }]
  };

  var ApolloCache = function () {
    function ApolloCache() {}

    __setKey(ApolloCache._ES5ProxyType ? ApolloCache.get("prototype") : ApolloCache.prototype, "transformDocument", function (document) {
      return document;
    });

    __setKey(ApolloCache._ES5ProxyType ? ApolloCache.get("prototype") : ApolloCache.prototype, "transformForLink", function (document) {
      return document;
    });

    __setKey(ApolloCache._ES5ProxyType ? ApolloCache.get("prototype") : ApolloCache.prototype, "readQuery", function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return __callKey1$1(this, "read", {
        query: options._ES5ProxyType ? options.get("query") : options.query,
        variables: options._ES5ProxyType ? options.get("variables") : options.variables,
        optimistic: optimistic
      });
    });

    __setKey(ApolloCache._ES5ProxyType ? ApolloCache.get("prototype") : ApolloCache.prototype, "readFragment", function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return __callKey1$1(this, "read", {
        query: getFragmentQueryDocument(options._ES5ProxyType ? options.get("fragment") : options.fragment, options._ES5ProxyType ? options.get("fragmentName") : options.fragmentName),
        variables: options._ES5ProxyType ? options.get("variables") : options.variables,
        rootId: options._ES5ProxyType ? options.get("id") : options.id,
        optimistic: optimistic
      });
    });

    __setKey(ApolloCache._ES5ProxyType ? ApolloCache.get("prototype") : ApolloCache.prototype, "writeQuery", function (options) {
      __callKey1$1(this, "write", {
        dataId: 'ROOT_QUERY',
        result: options._ES5ProxyType ? options.get("data") : options.data,
        query: options._ES5ProxyType ? options.get("query") : options.query,
        variables: options._ES5ProxyType ? options.get("variables") : options.variables
      });
    });

    __setKey(ApolloCache._ES5ProxyType ? ApolloCache.get("prototype") : ApolloCache.prototype, "writeFragment", function (options) {
      __callKey1$1(this, "write", {
        dataId: options._ES5ProxyType ? options.get("id") : options.id,
        result: options._ES5ProxyType ? options.get("data") : options.data,
        variables: options._ES5ProxyType ? options.get("variables") : options.variables,
        query: getFragmentQueryDocument(options._ES5ProxyType ? options.get("fragment") : options.fragment, options._ES5ProxyType ? options.get("fragmentName") : options.fragmentName)
      });
    });

    __setKey(ApolloCache._ES5ProxyType ? ApolloCache.get("prototype") : ApolloCache.prototype, "writeData", function (_a) {
      var id = _a._ES5ProxyType ? _a.get("id") : _a.id,
          data = _a._ES5ProxyType ? _a.get("data") : _a.data;

      if (typeof id !== 'undefined') {
        var typenameResult = null;

        try {
          typenameResult = __callKey1$1(this, "read", {
            rootId: id,
            optimistic: false,
            query: justTypenameQuery
          });
        } catch (e) {}

        var __typename = typenameResult && (typenameResult._ES5ProxyType ? typenameResult.get("__typename") : typenameResult.__typename) || '__ClientData';

        var dataToWrite = Object.compatAssign({
          __typename: __typename
        }, data);

        __callKey1$1(this, "writeFragment", {
          id: id,
          fragment: fragmentFromPojo(dataToWrite, __typename),
          data: dataToWrite
        });
      } else {
        __callKey1$1(this, "writeQuery", {
          query: queryFromPojo(data),
          data: data
        });
      }
    });

    return ApolloCache;
  }();

  // This currentContext variable will only be used if the makeSlotClass
  // function is called, which happens only if this is the first copy of the
  // @wry/context package to be imported.
  var currentContext = null; // This unique internal object is used to denote the absence of a value
  // for a given Slot, and is never exposed to outside code.

  var MISSING_VALUE = {};
  var idCounter = 1; // Although we can't do anything about the cost of duplicated code from
  // accidentally bundling multiple copies of the @wry/context package, we can
  // avoid creating the Slot class more than once using makeSlotClass.

  var makeSlotClass = function makeSlotClass() {
    return (
      /** @class */
      function () {
        function Slot() {
          // If you have a Slot object, you can find out its slot.id, but you cannot
          // guess the slot.id of a Slot you don't have access to, thanks to the
          // randomized suffix.
          __setKey(this, "id", __callKey1$1(["slot", idCounter++, Date.now(), __callKey1$1(__callKey1$1(Math.random(), "toString", 36), "slice", 2)], "join", ":"));
        }

        __setKey(Slot._ES5ProxyType ? Slot.get("prototype") : Slot.prototype, "hasValue", function () {
          for (var context_1 = currentContext; context_1; context_1 = context_1._ES5ProxyType ? context_1.get("parent") : context_1.parent) {
            // We use the Slot object iself as a key to its value, which means the
            // value cannot be obtained without a reference to the Slot object.
            if (__inKey$1(context_1._ES5ProxyType ? context_1.get("slots") : context_1.slots, this._ES5ProxyType ? this.get("id") : this.id)) {
              var _slots, _this$id, _this$id2;

              var value = (_slots = context_1._ES5ProxyType ? context_1.get("slots") : context_1.slots, _this$id = this._ES5ProxyType ? this.get("id") : this.id, _this$id2 = _slots._ES5ProxyType ? _slots.get(_this$id) : _slots[_this$id]);
              if (value === MISSING_VALUE) break;

              if (context_1 !== currentContext) {
                // Cache the value in currentContext.slots so the next lookup will
                // be faster. This caching is safe because the tree of contexts and
                // the values of the slots are logically immutable.
                __setKey(currentContext._ES5ProxyType ? currentContext.get("slots") : currentContext.slots, this._ES5ProxyType ? this.get("id") : this.id, value);
              }

              return true;
            }
          }

          if (currentContext) {
            // If a value was not found for this Slot, it's never going to be found
            // no matter how many times we look it up, so we might as well cache
            // the absence of the value, too.
            __setKey(currentContext._ES5ProxyType ? currentContext.get("slots") : currentContext.slots, this._ES5ProxyType ? this.get("id") : this.id, MISSING_VALUE);
          }

          return false;
        });

        __setKey(Slot._ES5ProxyType ? Slot.get("prototype") : Slot.prototype, "getValue", function () {
          if (__callKey0(this, "hasValue")) {
            var _slots2, _this$id3, _this$id4;

            return _slots2 = currentContext._ES5ProxyType ? currentContext.get("slots") : currentContext.slots, _this$id3 = this._ES5ProxyType ? this.get("id") : this.id, _this$id4 = _slots2._ES5ProxyType ? _slots2.get(_this$id3) : _slots2[_this$id3];
          }
        });

        __setKey(Slot._ES5ProxyType ? Slot.get("prototype") : Slot.prototype, "withValue", function (value, callback, // Given the prevalence of arrow functions, specifying arguments is likely
        // to be much more common than specifying `this`, hence this ordering:
        args, thisArg) {
          var _a;

          var slots = (_a = {
            __proto__: null
          }, __setKey(_a, this._ES5ProxyType ? this.get("id") : this.id, value), _a);
          var parent = currentContext;
          currentContext = {
            parent: parent,
            slots: slots
          };

          try {
            // Function.prototype.apply allows the arguments array argument to be
            // omitted or undefined, so args! is fine here.
            return __callKey2(callback, "apply", thisArg, args);
          } finally {
            currentContext = parent;
          }
        }); // Capture the current context and wrap a callback function so that it
        // reestablishes the captured context when called.


        __setKey(Slot, "bind", function (callback) {
          var context = currentContext;
          return function () {
            var saved = currentContext;

            try {
              currentContext = context;
              return __callKey2(callback, "apply", this, arguments);
            } finally {
              currentContext = saved;
            }
          };
        }); // Immediately run a callback function without any captured context.


        __setKey(Slot, "noContext", function (callback, // Given the prevalence of arrow functions, specifying arguments is likely
        // to be much more common than specifying `this`, hence this ordering:
        args, thisArg) {
          if (currentContext) {
            var saved = currentContext;

            try {
              currentContext = null; // Function.prototype.apply allows the arguments array argument to be
              // omitted or undefined, so args! is fine here.

              return __callKey2(callback, "apply", thisArg, args);
            } finally {
              currentContext = saved;
            }
          } else {
            return __callKey2(callback, "apply", thisArg, args);
          }
        });

        return Slot;
      }()
    );
  }; // We store a single global implementation of the Slot class as a permanent
  // non-enumerable symbol property of the Array constructor. This obfuscation
  // does nothing to prevent access to the Slot class, but at least it ensures
  // the implementation (i.e. currentContext) cannot be tampered with, and all
  // copies of the @wry/context package (hopefully just one) will share the
  // same Slot implementation. Since the first copy of the @wry/context package
  // to be imported wins, this technique imposes a very high cost for any
  // future breaking changes to the Slot class.


  var globalKey = "@wry/context:Slot";
  var host = Array;

  var Slot = (host._ES5ProxyType ? host.get(globalKey) : host[globalKey]) || function () {
    var Slot = makeSlotClass();

    try {
      Object.compatDefineProperty(host, globalKey, {
        value: __setKey(host, globalKey, Slot),
        enumerable: false,
        writable: false,
        configurable: false
      });
    } finally {
      return Slot;
    }
  }();

  var bind = Slot._ES5ProxyType ? Slot.get("bind") : Slot.bind,
      noContext = Slot._ES5ProxyType ? Slot.get("noContext") : Slot.noContext;

  function defaultDispose() {}

  var Cache =
  /** @class */
  function () {
    function Cache(max, dispose) {
      if (max === void 0) {
        max = Infinity;
      }

      if (dispose === void 0) {
        dispose = defaultDispose;
      }

      __setKey(this, "max", max);

      __setKey(this, "dispose", dispose);

      __setKey(this, "map", new Map());

      __setKey(this, "newest", null);

      __setKey(this, "oldest", null);
    }

    __setKey(Cache._ES5ProxyType ? Cache.get("prototype") : Cache.prototype, "has", function (key) {
      return __callKey1$1(this._ES5ProxyType ? this.get("map") : this.map, "has", key);
    });

    __setKey(Cache._ES5ProxyType ? Cache.get("prototype") : Cache.prototype, "get", function (key) {
      var entry = __callKey1$1(this, "getEntry", key);

      return entry && (entry._ES5ProxyType ? entry.get("value") : entry.value);
    });

    __setKey(Cache._ES5ProxyType ? Cache.get("prototype") : Cache.prototype, "getEntry", function (key) {
      var entry = __callKey1$1(this._ES5ProxyType ? this.get("map") : this.map, "get", key);

      if (entry && entry !== (this._ES5ProxyType ? this.get("newest") : this.newest)) {
        var older = entry._ES5ProxyType ? entry.get("older") : entry.older,
            newer = entry._ES5ProxyType ? entry.get("newer") : entry.newer;

        if (newer) {
          __setKey(newer, "older", older);
        }

        if (older) {
          __setKey(older, "newer", newer);
        }

        __setKey(entry, "older", this._ES5ProxyType ? this.get("newest") : this.newest);

        __setKey(entry._ES5ProxyType ? entry.get("older") : entry.older, "newer", entry);

        __setKey(entry, "newer", null);

        __setKey(this, "newest", entry);

        if (entry === (this._ES5ProxyType ? this.get("oldest") : this.oldest)) {
          __setKey(this, "oldest", newer);
        }
      }

      return entry;
    });

    __setKey(Cache._ES5ProxyType ? Cache.get("prototype") : Cache.prototype, "set", function (key, value) {
      var entry = __callKey1$1(this, "getEntry", key);

      if (entry) {
        return __setKey(entry, "value", value);
      }

      entry = {
        key: key,
        value: value,
        newer: null,
        older: this._ES5ProxyType ? this.get("newest") : this.newest
      };

      if (this._ES5ProxyType ? this.get("newest") : this.newest) {
        __setKey(this._ES5ProxyType ? this.get("newest") : this.newest, "newer", entry);
      }

      __setKey(this, "newest", entry);

      __setKey(this, "oldest", (this._ES5ProxyType ? this.get("oldest") : this.oldest) || entry);

      __callKey2(this._ES5ProxyType ? this.get("map") : this.map, "set", key, entry);

      return entry._ES5ProxyType ? entry.get("value") : entry.value;
    });

    __setKey(Cache._ES5ProxyType ? Cache.get("prototype") : Cache.prototype, "clean", function () {
      while ((this._ES5ProxyType ? this.get("oldest") : this.oldest) && (_map = this._ES5ProxyType ? this.get("map") : this.map, _size = _map._ES5ProxyType ? _map.get("size") : _map.size) > (this._ES5ProxyType ? this.get("max") : this.max)) {
        var _map, _size, _oldest, _key;

        __callKey1$1(this, "delete", (_oldest = this._ES5ProxyType ? this.get("oldest") : this.oldest, _key = _oldest._ES5ProxyType ? _oldest.get("key") : _oldest.key));
      }
    });

    __setKey(Cache._ES5ProxyType ? Cache.get("prototype") : Cache.prototype, "delete", function (key) {
      var entry = __callKey1$1(this._ES5ProxyType ? this.get("map") : this.map, "get", key);

      if (entry) {
        if (entry === (this._ES5ProxyType ? this.get("newest") : this.newest)) {
          __setKey(this, "newest", entry._ES5ProxyType ? entry.get("older") : entry.older);
        }

        if (entry === (this._ES5ProxyType ? this.get("oldest") : this.oldest)) {
          __setKey(this, "oldest", entry._ES5ProxyType ? entry.get("newer") : entry.newer);
        }

        if (entry._ES5ProxyType ? entry.get("newer") : entry.newer) {
          __setKey(entry._ES5ProxyType ? entry.get("newer") : entry.newer, "older", entry._ES5ProxyType ? entry.get("older") : entry.older);
        }

        if (entry._ES5ProxyType ? entry.get("older") : entry.older) {
          __setKey(entry._ES5ProxyType ? entry.get("older") : entry.older, "newer", entry._ES5ProxyType ? entry.get("newer") : entry.newer);
        }

        __callKey1$1(this._ES5ProxyType ? this.get("map") : this.map, "delete", key);

        __callKey2(this, "dispose", entry._ES5ProxyType ? entry.get("value") : entry.value, key);

        return true;
      }

      return false;
    });

    return Cache;
  }();

  var parentEntrySlot = new Slot();
  var reusableEmptyArray = [];
  var emptySetPool = [];
  var POOL_TARGET_SIZE = 100; // Since this package might be used browsers, we should avoid using the
  // Node built-in assert module.

  function assert$2(condition, optionalMessage) {
    if (!condition) {
      throw new Error(optionalMessage || "assertion failure");
    }
  }

  function valueIs(a, b) {
    var _ref, _ref2, _ref3, _ref4;

    var len = a._ES5ProxyType ? a.get("length") : a.length;
    return (// Unknown values are not equal to each other.
      len > 0 && // Both values must be ordinary (or both exceptional) to be equal.
      len === (b._ES5ProxyType ? b.get("length") : b.length) && // The underlying value or exception must be the same.
      (_ref = len - 1, _ref2 = a._ES5ProxyType ? a.get(_ref) : a[_ref]) === (_ref3 = len - 1, _ref4 = b._ES5ProxyType ? b.get(_ref3) : b[_ref3])
    );
  }

  function valueGet(value) {
    switch (value._ES5ProxyType ? value.get("length") : value.length) {
      case 0:
        throw new Error("unknown value");

      case 1:
        return value._ES5ProxyType ? value.get(0) : value[0];

      case 2:
        throw value._ES5ProxyType ? value.get(1) : value[1];
    }
  }

  function valueCopy(value) {
    return __callKey1$1(value, "slice", 0);
  }

  var Entry =
  /** @class */
  function () {
    function Entry(fn, args) {
      __setKey(this, "fn", fn);

      __setKey(this, "args", args);

      __setKey(this, "parents", new Set());

      __setKey(this, "childValues", new Map()); // When this Entry has children that are dirty, this property becomes
      // a Set containing other Entry objects, borrowed from emptySetPool.
      // When the set becomes empty, it gets recycled back to emptySetPool.


      __setKey(this, "dirtyChildren", null);

      __setKey(this, "dirty", true);

      __setKey(this, "recomputing", false);

      __setKey(this, "value", []);

      __setKey(Entry, "count", (Entry._ES5ProxyType ? Entry.get("count") : Entry.count) + 1);
    } // This is the most important method of the Entry API, because it
    // determines whether the cached this.value can be returned immediately,
    // or must be recomputed. The overall performance of the caching system
    // depends on the truth of the following observations: (1) this.dirty is
    // usually false, (2) this.dirtyChildren is usually null/empty, and thus
    // (3) valueGet(this.value) is usually returned without recomputation.


    __setKey(Entry._ES5ProxyType ? Entry.get("prototype") : Entry.prototype, "recompute", function () {
      assert$2(!(this._ES5ProxyType ? this.get("recomputing") : this.recomputing), "already recomputing");

      if (!rememberParent(this) && maybeReportOrphan(this)) {
        // The recipient of the entry.reportOrphan callback decided to dispose
        // of this orphan entry by calling entry.dispose(), so we don't need to
        // (and should not) proceed with the recomputation.
        return void 0;
      }

      return mightBeDirty(this) ? reallyRecompute(this) : valueGet(this._ES5ProxyType ? this.get("value") : this.value);
    });

    __setKey(Entry._ES5ProxyType ? Entry.get("prototype") : Entry.prototype, "setDirty", function () {
      if (this._ES5ProxyType ? this.get("dirty") : this.dirty) return;

      __setKey(this, "dirty", true);

      __setKey(this._ES5ProxyType ? this.get("value") : this.value, "length", 0);

      reportDirty(this); // We can go ahead and unsubscribe here, since any further dirty
      // notifications we receive will be redundant, and unsubscribing may
      // free up some resources, e.g. file watchers.

      maybeUnsubscribe(this);
    });

    __setKey(Entry._ES5ProxyType ? Entry.get("prototype") : Entry.prototype, "dispose", function () {
      var _this = this;

      __callKey1$1(forgetChildren(this), "forEach", maybeReportOrphan);

      maybeUnsubscribe(this); // Because this entry has been kicked out of the cache (in index.js),
      // we've lost the ability to find out if/when this entry becomes dirty,
      // whether that happens through a subscription, because of a direct call
      // to entry.setDirty(), or because one of its children becomes dirty.
      // Because of this loss of future information, we have to assume the
      // worst (that this entry might have become dirty very soon), so we must
      // immediately mark this entry's parents as dirty. Normally we could
      // just call entry.setDirty() rather than calling parent.setDirty() for
      // each parent, but that would leave this entry in parent.childValues
      // and parent.dirtyChildren, which would prevent the child from being
      // truly forgotten.

      __callKey1$1(this._ES5ProxyType ? this.get("parents") : this.parents, "forEach", function (parent) {
        __callKey0(parent, "setDirty");

        forgetChild(parent, _this);
      });
    });

    __setKey(Entry, "count", 0);

    return Entry;
  }();

  function rememberParent(child) {
    var parent = __callKey0(parentEntrySlot, "getValue");

    if (parent) {
      __callKey1$1(child._ES5ProxyType ? child.get("parents") : child.parents, "add", parent);

      if (!__callKey1$1(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "has", child)) {
        __callKey2(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "set", child, []);
      }

      if (mightBeDirty(child)) {
        reportDirtyChild(parent, child);
      } else {
        reportCleanChild(parent, child);
      }

      return parent;
    }
  }

  function reallyRecompute(entry) {
    // Since this recomputation is likely to re-remember some of this
    // entry's children, we forget our children here but do not call
    // maybeReportOrphan until after the recomputation finishes.
    var originalChildren = forgetChildren(entry); // Set entry as the parent entry while calling recomputeNewValue(entry).

    __callKey3(parentEntrySlot, "withValue", entry, recomputeNewValue, [entry]);

    if (maybeSubscribe(entry)) {
      // If we successfully recomputed entry.value and did not fail to
      // (re)subscribe, then this Entry is no longer explicitly dirty.
      setClean(entry);
    } // Now that we've had a chance to re-remember any children that were
    // involved in the recomputation, we can safely report any orphan
    // children that remain.


    __callKey1$1(originalChildren, "forEach", maybeReportOrphan);

    return valueGet(entry._ES5ProxyType ? entry.get("value") : entry.value);
  }

  function recomputeNewValue(entry) {
    __setKey(entry, "recomputing", true); // Set entry.value as unknown.


    __setKey(entry._ES5ProxyType ? entry.get("value") : entry.value, "length", 0);

    try {
      // If entry.fn succeeds, entry.value will become a normal Value.
      __setKey(entry._ES5ProxyType ? entry.get("value") : entry.value, 0, __callKey2(entry._ES5ProxyType ? entry.get("fn") : entry.fn, "apply", null, entry._ES5ProxyType ? entry.get("args") : entry.args));
    } catch (e) {
      // If entry.fn throws, entry.value will become exceptional.
      __setKey(entry._ES5ProxyType ? entry.get("value") : entry.value, 1, e);
    } // Either way, this line is always reached.


    __setKey(entry, "recomputing", false);
  }

  function mightBeDirty(entry) {
    var _dirtyChildren, _size2;

    return (entry._ES5ProxyType ? entry.get("dirty") : entry.dirty) || !!((entry._ES5ProxyType ? entry.get("dirtyChildren") : entry.dirtyChildren) && (_dirtyChildren = entry._ES5ProxyType ? entry.get("dirtyChildren") : entry.dirtyChildren, _size2 = _dirtyChildren._ES5ProxyType ? _dirtyChildren.get("size") : _dirtyChildren.size));
  }

  function setClean(entry) {
    __setKey(entry, "dirty", false);

    if (mightBeDirty(entry)) {
      // This Entry may still have dirty children, in which case we can't
      // let our parents know we're clean just yet.
      return;
    }

    reportClean(entry);
  }

  function reportDirty(child) {
    __callKey1$1(child._ES5ProxyType ? child.get("parents") : child.parents, "forEach", function (parent) {
      return reportDirtyChild(parent, child);
    });
  }

  function reportClean(child) {
    __callKey1$1(child._ES5ProxyType ? child.get("parents") : child.parents, "forEach", function (parent) {
      return reportCleanChild(parent, child);
    });
  } // Let a parent Entry know that one of its children may be dirty.


  function reportDirtyChild(parent, child) {
    // Must have called rememberParent(child) before calling
    // reportDirtyChild(parent, child).
    assert$2(__callKey1$1(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "has", child));
    assert$2(mightBeDirty(child));

    if (!(parent._ES5ProxyType ? parent.get("dirtyChildren") : parent.dirtyChildren)) {
      __setKey(parent, "dirtyChildren", emptySetPool.pop() || new Set());
    } else if (__callKey1$1(parent._ES5ProxyType ? parent.get("dirtyChildren") : parent.dirtyChildren, "has", child)) {
      // If we already know this child is dirty, then we must have already
      // informed our own parents that we are dirty, so we can terminate
      // the recursion early.
      return;
    }

    __callKey1$1(parent._ES5ProxyType ? parent.get("dirtyChildren") : parent.dirtyChildren, "add", child);

    reportDirty(parent);
  } // Let a parent Entry know that one of its children is no longer dirty.


  function reportCleanChild(parent, child) {
    // Must have called rememberChild(child) before calling
    // reportCleanChild(parent, child).
    assert$2(__callKey1$1(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "has", child));
    assert$2(!mightBeDirty(child));

    var childValue = __callKey1$1(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "get", child);

    if ((childValue._ES5ProxyType ? childValue.get("length") : childValue.length) === 0) {
      __callKey2(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "set", child, valueCopy(child._ES5ProxyType ? child.get("value") : child.value));
    } else if (!valueIs(childValue, child._ES5ProxyType ? child.get("value") : child.value)) {
      __callKey0(parent, "setDirty");
    }

    removeDirtyChild(parent, child);

    if (mightBeDirty(parent)) {
      return;
    }

    reportClean(parent);
  }

  function removeDirtyChild(parent, child) {
    var dc = parent._ES5ProxyType ? parent.get("dirtyChildren") : parent.dirtyChildren;

    if (dc) {
      __callKey1$1(dc, "delete", child);

      if ((dc._ES5ProxyType ? dc.get("size") : dc.size) === 0) {
        if ((emptySetPool._ES5ProxyType ? emptySetPool.get("length") : emptySetPool.length) < POOL_TARGET_SIZE) {
          emptySetPool.push(dc);
        }

        __setKey(parent, "dirtyChildren", null);
      }
    }
  } // If the given entry has a reportOrphan method, and no remaining parents,
  // call entry.reportOrphan and return true iff it returns true. The
  // reportOrphan function should return true to indicate entry.dispose()
  // has been called, and the entry has been removed from any other caches
  // (see index.js for the only current example).


  function maybeReportOrphan(entry) {
    var _parents, _size3;

    return (_parents = entry._ES5ProxyType ? entry.get("parents") : entry.parents, _size3 = _parents._ES5ProxyType ? _parents.get("size") : _parents.size) === 0 && typeof (entry._ES5ProxyType ? entry.get("reportOrphan") : entry.reportOrphan) === "function" && __callKey0(entry, "reportOrphan") === true;
  } // Removes all children from this entry and returns an array of the
  // removed children.


  function forgetChildren(parent) {
    var _childValues, _size4;

    var children = reusableEmptyArray;

    if ((_childValues = parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, _size4 = _childValues._ES5ProxyType ? _childValues.get("size") : _childValues.size) > 0) {
      children = [];

      __callKey1$1(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "forEach", function (_value, child) {
        forgetChild(parent, child);
        children.push(child);
      });
    } // After we forget all our children, this.dirtyChildren must be empty
    // and therefore must have been reset to null.


    assert$2((parent._ES5ProxyType ? parent.get("dirtyChildren") : parent.dirtyChildren) === null);
    return children;
  }

  function forgetChild(parent, child) {
    __callKey1$1(child._ES5ProxyType ? child.get("parents") : child.parents, "delete", parent);

    __callKey1$1(parent._ES5ProxyType ? parent.get("childValues") : parent.childValues, "delete", child);

    removeDirtyChild(parent, child);
  }

  function maybeSubscribe(entry) {
    if (typeof (entry._ES5ProxyType ? entry.get("subscribe") : entry.subscribe) === "function") {
      try {
        maybeUnsubscribe(entry); // Prevent double subscriptions.

        __setKey(entry, "unsubscribe", __callKey2(entry._ES5ProxyType ? entry.get("subscribe") : entry.subscribe, "apply", null, entry._ES5ProxyType ? entry.get("args") : entry.args));
      } catch (e) {
        // If this Entry has a subscribe function and it threw an exception
        // (or an unsubscribe function it previously returned now throws),
        // return false to indicate that we were not able to subscribe (or
        // unsubscribe), and this Entry should remain dirty.
        __callKey0(entry, "setDirty");

        return false;
      }
    } // Returning true indicates either that there was no entry.subscribe
    // function or that it succeeded.


    return true;
  }

  function maybeUnsubscribe(entry) {
    var unsubscribe = entry._ES5ProxyType ? entry.get("unsubscribe") : entry.unsubscribe;

    if (typeof unsubscribe === "function") {
      __setKey(entry, "unsubscribe", void 0);

      unsubscribe();
    }
  } // A trie data structure that holds object keys weakly, yet can also hold
  // non-object keys, unlike the native `WeakMap`.


  var KeyTrie =
  /** @class */
  function () {
    function KeyTrie(weakness) {
      __setKey(this, "weakness", weakness);
    }

    __setKey(KeyTrie._ES5ProxyType ? KeyTrie.get("prototype") : KeyTrie.prototype, "lookup", function () {
      var array = [];

      for (var _i = 0; _i < arguments.length; _i++) {
        __setKey(array, _i, arguments[_i]);
      }

      return __callKey1$1(this, "lookupArray", array);
    });

    __setKey(KeyTrie._ES5ProxyType ? KeyTrie.get("prototype") : KeyTrie.prototype, "lookupArray", function (array) {
      var node = this;

      __callKey1$1(array, "forEach", function (key) {
        return node = __callKey1$1(node, "getChildTrie", key);
      });

      return (node._ES5ProxyType ? node.get("data") : node.data) || __setKey(node, "data", Object.create(null));
    });

    __setKey(KeyTrie._ES5ProxyType ? KeyTrie.get("prototype") : KeyTrie.prototype, "getChildTrie", function (key) {
      var map = (this._ES5ProxyType ? this.get("weakness") : this.weakness) && isObjRef(key) ? (this._ES5ProxyType ? this.get("weak") : this.weak) || __setKey(this, "weak", new WeakMap()) : (this._ES5ProxyType ? this.get("strong") : this.strong) || __setKey(this, "strong", new Map());

      var child = __callKey1$1(map, "get", key);

      if (!child) __callKey2(map, "set", key, child = new KeyTrie(this._ES5ProxyType ? this.get("weakness") : this.weakness));
      return child;
    });

    return KeyTrie;
  }();

  function isObjRef(value) {
    switch (_typeof_1(value)) {
      case "object":
        if (value === null) break;
      // Fall through to return true...

      case "function":
        return true;
    }

    return false;
  } // The defaultMakeCacheKey function is remarkably powerful, because it gives
  // a unique object for any shallow-identical list of arguments. If you need
  // to implement a custom makeCacheKey function, you may find it helpful to
  // delegate the final work to defaultMakeCacheKey, which is why we export it
  // here. However, you may want to avoid defaultMakeCacheKey if your runtime
  // does not support WeakMap, or you have the ability to return a string key.
  // In those cases, just write your own custom makeCacheKey functions.


  var keyTrie = new KeyTrie(typeof WeakMap === "function");

  function defaultMakeCacheKey() {
    var args = [];

    for (var _i = 0; _i < arguments.length; _i++) {
      __setKey(args, _i, arguments[_i]);
    }

    return __callKey1$1(keyTrie, "lookupArray", args);
  }

  var caches = new Set();

  function wrap(originalFunction, options) {
    if (options === void 0) {
      options = Object.create(null);
    }

    var cache = new Cache((options._ES5ProxyType ? options.get("max") : options.max) || Math.pow(2, 16), function (entry) {
      return __callKey0(entry, "dispose");
    });
    var disposable = !!(options._ES5ProxyType ? options.get("disposable") : options.disposable);
    var makeCacheKey = (options._ES5ProxyType ? options.get("makeCacheKey") : options.makeCacheKey) || defaultMakeCacheKey;

    function optimistic() {
      if (disposable && !__callKey0(parentEntrySlot, "hasValue")) {
        // If there's no current parent computation, and this wrapped
        // function is disposable (meaning we don't care about entry.value,
        // just dependency tracking), then we can short-cut everything else
        // in this function, because entry.recompute() is going to recycle
        // the entry object without recomputing anything, anyway.
        return void 0;
      }

      var key = __callKey2(makeCacheKey, "apply", null, arguments);

      if (key === void 0) {
        return __callKey2(originalFunction, "apply", null, arguments);
      }

      var args = __callKey1$1(Array.prototype._ES5ProxyType ? Array.prototype.get("slice") : Array.prototype.slice, "call", arguments);

      var entry = __callKey1$1(cache, "get", key);

      if (entry) {
        __setKey(entry, "args", args);
      } else {
        entry = new Entry(originalFunction, args);

        __callKey2(cache, "set", key, entry);

        __setKey(entry, "subscribe", options._ES5ProxyType ? options.get("subscribe") : options.subscribe);

        if (disposable) {
          __setKey(entry, "reportOrphan", function () {
            return __callKey1$1(cache, "delete", key);
          });
        }
      }

      var value = __callKey0(entry, "recompute"); // Move this entry to the front of the least-recently used queue,
      // since we just finished computing its value.


      __callKey2(cache, "set", key, entry);

      __callKey1$1(caches, "add", cache); // Clean up any excess entries in the cache, but only if there is no
      // active parent entry, meaning we're not in the middle of a larger
      // computation that might be flummoxed by the cleaning.


      if (!__callKey0(parentEntrySlot, "hasValue")) {
        __callKey1$1(caches, "forEach", function (cache) {
          return __callKey0(cache, "clean");
        });

        __callKey0(caches, "clear");
      } // If options.disposable is truthy, the caller of wrap is telling us
      // they don't care about the result of entry.recompute(), so we should
      // avoid returning the value, so it won't be accidentally used.


      return disposable ? void 0 : value;
    }

    __setKey(optimistic, "dirty", function () {
      var key = __callKey2(makeCacheKey, "apply", null, arguments);

      var child = key !== void 0 && __callKey1$1(cache, "get", key);

      if (child) {
        __callKey0(child, "setDirty");
      }
    });

    return optimistic;
  }

  var haveWarned = false;

  function shouldWarn() {
    var answer = !haveWarned;

    if (!isTest()) {
      haveWarned = true;
    }

    return answer;
  }

  var HeuristicFragmentMatcher = function () {
    function HeuristicFragmentMatcher() {}

    __setKey(HeuristicFragmentMatcher._ES5ProxyType ? HeuristicFragmentMatcher.get("prototype") : HeuristicFragmentMatcher.prototype, "ensureReady", function () {
      return Promise.resolve();
    });

    __setKey(HeuristicFragmentMatcher._ES5ProxyType ? HeuristicFragmentMatcher.get("prototype") : HeuristicFragmentMatcher.prototype, "canBypassInit", function () {
      return true;
    });

    __setKey(HeuristicFragmentMatcher._ES5ProxyType ? HeuristicFragmentMatcher.get("prototype") : HeuristicFragmentMatcher.prototype, "match", function (idValue, typeCondition, context) {
      var obj = __callKey1$1(context._ES5ProxyType ? context.get("store") : context.store, "get", idValue._ES5ProxyType ? idValue.get("id") : idValue.id);

      var isRootQuery = (idValue._ES5ProxyType ? idValue.get("id") : idValue.id) === 'ROOT_QUERY';

      if (!obj) {
        return isRootQuery;
      }

      var _a = obj._ES5ProxyType ? obj.get("__typename") : obj.__typename,
          __typename = _a === void 0 ? isRootQuery && 'Query' : _a;

      if (!__typename) {
        if (shouldWarn()) {
           __callKey1$1(invariant$3, "warn", "You're using fragments in your queries, but either don't have the addTypename:\n  true option set in Apollo Client, or you are trying to write a fragment to the store without the __typename.\n   Please turn on the addTypename option and include __typename when writing fragments so that Apollo Client\n   can accurately match fragments.");
           __callKey3(invariant$3, "warn", 'Could not find __typename on Fragment ', typeCondition, obj);
           __callKey1$1(invariant$3, "warn", "DEPRECATION WARNING: using fragments without __typename is unsupported behavior " + "and will be removed in future versions of Apollo client. You should fix this and set addTypename to true now.");
        }

        return 'heuristic';
      }

      if (__typename === typeCondition) {
        return true;
      }

      if (shouldWarn()) {
         __callKey1$1(invariant$3, "error", 'You are using the simple (heuristic) fragment matcher, but your ' + 'queries contain union or interface types. Apollo Client will not be ' + 'able to accurately map fragments. To make this error go away, use ' + 'the `IntrospectionFragmentMatcher` as described in the docs: ' + 'https://www.apollographql.com/docs/react/advanced/fragments.html#fragment-matcher');
      }

      return 'heuristic';
    });

    return HeuristicFragmentMatcher;
  }();

  var IntrospectionFragmentMatcher = function () {
    function IntrospectionFragmentMatcher(options) {
      if (options && (options._ES5ProxyType ? options.get("introspectionQueryResultData") : options.introspectionQueryResultData)) {
        __setKey(this, "possibleTypesMap", __callKey1$1(this, "parseIntrospectionResult", options._ES5ProxyType ? options.get("introspectionQueryResultData") : options.introspectionQueryResultData));

        __setKey(this, "isReady", true);
      } else {
        __setKey(this, "isReady", false);
      }

      __setKey(this, "match", __callKey1$1(this._ES5ProxyType ? this.get("match") : this.match, "bind", this));
    }

    __setKey(IntrospectionFragmentMatcher._ES5ProxyType ? IntrospectionFragmentMatcher.get("prototype") : IntrospectionFragmentMatcher.prototype, "match", function (idValue, typeCondition, context) {
      var _possibleTypesMap, _typeCondition;

       invariant$3(this._ES5ProxyType ? this.get("isReady") : this.isReady, 'FragmentMatcher.match() was called before FragmentMatcher.init()');

      var obj = __callKey1$1(context._ES5ProxyType ? context.get("store") : context.store, "get", idValue._ES5ProxyType ? idValue.get("id") : idValue.id);

      var isRootQuery = (idValue._ES5ProxyType ? idValue.get("id") : idValue.id) === 'ROOT_QUERY';

      if (!obj) {
        return isRootQuery;
      }

      var _a = obj._ES5ProxyType ? obj.get("__typename") : obj.__typename,
          __typename = _a === void 0 ? isRootQuery && 'Query' : _a;

       invariant$3(__typename, "Cannot match fragment because __typename property is missing: " + JSON.stringify(obj));

      if (__typename === typeCondition) {
        return true;
      }

      var implementingTypes = (_possibleTypesMap = this._ES5ProxyType ? this.get("possibleTypesMap") : this.possibleTypesMap, _typeCondition = _possibleTypesMap._ES5ProxyType ? _possibleTypesMap.get(typeCondition) : _possibleTypesMap[typeCondition]);

      if (__typename && implementingTypes && __callKey1$1(implementingTypes, "indexOf", __typename) > -1) {
        return true;
      }

      return false;
    });

    __setKey(IntrospectionFragmentMatcher._ES5ProxyType ? IntrospectionFragmentMatcher.get("prototype") : IntrospectionFragmentMatcher.prototype, "parseIntrospectionResult", function (introspectionResultData) {
      var _schema, _types;

      var typeMap = {};

      __callKey1$1((_schema = introspectionResultData._ES5ProxyType ? introspectionResultData.get("__schema") : introspectionResultData.__schema, _types = _schema._ES5ProxyType ? _schema.get("types") : _schema.types), "forEach", function (type) {
        if ((type._ES5ProxyType ? type.get("kind") : type.kind) === 'UNION' || (type._ES5ProxyType ? type.get("kind") : type.kind) === 'INTERFACE') {
          __setKey(typeMap, type._ES5ProxyType ? type.get("name") : type.name, __callKey1$1(type._ES5ProxyType ? type.get("possibleTypes") : type.possibleTypes, "map", function (implementingType) {
            return implementingType._ES5ProxyType ? implementingType.get("name") : implementingType.name;
          }));
        }
      });

      return typeMap;
    });

    return IntrospectionFragmentMatcher;
  }();

  var hasOwn = Object.prototype._ES5ProxyType ? Object.prototype.get("compatHasOwnProperty") : Object.prototype.compatHasOwnProperty;

  var DepTrackingCache = function () {
    function DepTrackingCache(data) {
      var _this = this;

      if (data === void 0) {
        data = Object.create(null);
      }

      __setKey(this, "data", data);

      __setKey(this, "depend", wrap(function (dataId) {
        var _data, _dataId;

        return _data = _this._ES5ProxyType ? _this.get("data") : _this.data, _dataId = _data._ES5ProxyType ? _data.get(dataId) : _data[dataId];
      }, {
        disposable: true,
        makeCacheKey: function makeCacheKey(dataId) {
          return dataId;
        }
      }));
    }

    __setKey(DepTrackingCache._ES5ProxyType ? DepTrackingCache.get("prototype") : DepTrackingCache.prototype, "toObject", function () {
      return this._ES5ProxyType ? this.get("data") : this.data;
    });

    __setKey(DepTrackingCache._ES5ProxyType ? DepTrackingCache.get("prototype") : DepTrackingCache.prototype, "get", function (dataId) {
      var _data2, _dataId2;

      __callKey1$1(this, "depend", dataId);

      return _data2 = this._ES5ProxyType ? this.get("data") : this.data, _dataId2 = _data2._ES5ProxyType ? _data2.get(dataId) : _data2[dataId];
    });

    __setKey(DepTrackingCache._ES5ProxyType ? DepTrackingCache.get("prototype") : DepTrackingCache.prototype, "set", function (dataId, value) {
      var _data3, _dataId3;

      var oldValue = (_data3 = this._ES5ProxyType ? this.get("data") : this.data, _dataId3 = _data3._ES5ProxyType ? _data3.get(dataId) : _data3[dataId]);

      if (value !== oldValue) {
        __setKey(this._ES5ProxyType ? this.get("data") : this.data, dataId, value);

        __callKey1$1(this._ES5ProxyType ? this.get("depend") : this.depend, "dirty", dataId);
      }
    });

    __setKey(DepTrackingCache._ES5ProxyType ? DepTrackingCache.get("prototype") : DepTrackingCache.prototype, "delete", function (dataId) {
      if (__callKey2(hasOwn, "call", this._ES5ProxyType ? this.get("data") : this.data, dataId)) {
        __deleteKey(this._ES5ProxyType ? this.get("data") : this.data, dataId);

        __callKey1$1(this._ES5ProxyType ? this.get("depend") : this.depend, "dirty", dataId);
      }
    });

    __setKey(DepTrackingCache._ES5ProxyType ? DepTrackingCache.get("prototype") : DepTrackingCache.prototype, "clear", function () {
      __callKey1$1(this, "replace", null);
    });

    __setKey(DepTrackingCache._ES5ProxyType ? DepTrackingCache.get("prototype") : DepTrackingCache.prototype, "replace", function (newData) {
      var _this = this;

      if (newData) {
        __callKey1$1(Object.compatKeys(newData), "forEach", function (dataId) {
          __callKey2(_this, "set", dataId, newData._ES5ProxyType ? newData.get(dataId) : newData[dataId]);
        });

        __callKey1$1(Object.compatKeys(this._ES5ProxyType ? this.get("data") : this.data), "forEach", function (dataId) {
          if (!__callKey2(hasOwn, "call", newData, dataId)) {
            __callKey1$1(_this, "delete", dataId);
          }
        });
      } else {
        __callKey1$1(Object.compatKeys(this._ES5ProxyType ? this.get("data") : this.data), "forEach", function (dataId) {
          __callKey1$1(_this, "delete", dataId);
        });
      }
    });

    return DepTrackingCache;
  }();

  function defaultNormalizedCacheFactory(seed) {
    return new DepTrackingCache(seed);
  }

  var StoreReader = function () {
    function StoreReader(_a) {
      var _this = this;

      var _b = _a === void 0 ? {} : _a,
          _c = _b._ES5ProxyType ? _b.get("cacheKeyRoot") : _b.cacheKeyRoot,
          cacheKeyRoot = _c === void 0 ? new KeyTrie(canUseWeakMap) : _c,
          _d = _b._ES5ProxyType ? _b.get("freezeResults") : _b.freezeResults,
          freezeResults = _d === void 0 ? false : _d;

      var _e = this,
          executeStoreQuery = _e._ES5ProxyType ? _e.get("executeStoreQuery") : _e.executeStoreQuery,
          executeSelectionSet = _e._ES5ProxyType ? _e.get("executeSelectionSet") : _e.executeSelectionSet,
          executeSubSelectedArray = _e._ES5ProxyType ? _e.get("executeSubSelectedArray") : _e.executeSubSelectedArray;

      __setKey(this, "freezeResults", freezeResults);

      __setKey(this, "executeStoreQuery", wrap(function (options) {
        return __callKey2(executeStoreQuery, "call", _this, options);
      }, {
        makeCacheKey: function makeCacheKey(_a) {
          var query = _a._ES5ProxyType ? _a.get("query") : _a.query,
              rootValue = _a._ES5ProxyType ? _a.get("rootValue") : _a.rootValue,
              contextValue = _a._ES5ProxyType ? _a.get("contextValue") : _a.contextValue,
              variableValues = _a._ES5ProxyType ? _a.get("variableValues") : _a.variableValues,
              fragmentMatcher = _a._ES5ProxyType ? _a.get("fragmentMatcher") : _a.fragmentMatcher;

          if (_instanceof_1(contextValue._ES5ProxyType ? contextValue.get("store") : contextValue.store, DepTrackingCache)) {
            return __callKey(cacheKeyRoot, "lookup", contextValue._ES5ProxyType ? contextValue.get("store") : contextValue.store, query, fragmentMatcher, JSON.stringify(variableValues), rootValue._ES5ProxyType ? rootValue.get("id") : rootValue.id);
          }
        }
      }));

      __setKey(this, "executeSelectionSet", wrap(function (options) {
        return __callKey2(executeSelectionSet, "call", _this, options);
      }, {
        makeCacheKey: function makeCacheKey(_a) {
          var _contextValue, _store;

          var selectionSet = _a._ES5ProxyType ? _a.get("selectionSet") : _a.selectionSet,
              rootValue = _a._ES5ProxyType ? _a.get("rootValue") : _a.rootValue,
              execContext = _a._ES5ProxyType ? _a.get("execContext") : _a.execContext;

          if (_instanceof_1((_contextValue = execContext._ES5ProxyType ? execContext.get("contextValue") : execContext.contextValue, _store = _contextValue._ES5ProxyType ? _contextValue.get("store") : _contextValue.store), DepTrackingCache)) {
            var _contextValue2, _store2;

            return __callKey(cacheKeyRoot, "lookup", (_contextValue2 = execContext._ES5ProxyType ? execContext.get("contextValue") : execContext.contextValue, _store2 = _contextValue2._ES5ProxyType ? _contextValue2.get("store") : _contextValue2.store), selectionSet, execContext._ES5ProxyType ? execContext.get("fragmentMatcher") : execContext.fragmentMatcher, JSON.stringify(execContext._ES5ProxyType ? execContext.get("variableValues") : execContext.variableValues), rootValue._ES5ProxyType ? rootValue.get("id") : rootValue.id);
          }
        }
      }));

      __setKey(this, "executeSubSelectedArray", wrap(function (options) {
        return __callKey2(executeSubSelectedArray, "call", _this, options);
      }, {
        makeCacheKey: function makeCacheKey(_a) {
          var _contextValue3, _store3;

          var field = _a._ES5ProxyType ? _a.get("field") : _a.field,
              array = _a._ES5ProxyType ? _a.get("array") : _a.array,
              execContext = _a._ES5ProxyType ? _a.get("execContext") : _a.execContext;

          if (_instanceof_1((_contextValue3 = execContext._ES5ProxyType ? execContext.get("contextValue") : execContext.contextValue, _store3 = _contextValue3._ES5ProxyType ? _contextValue3.get("store") : _contextValue3.store), DepTrackingCache)) {
            var _contextValue4, _store4;

            return __callKey4(cacheKeyRoot, "lookup", (_contextValue4 = execContext._ES5ProxyType ? execContext.get("contextValue") : execContext.contextValue, _store4 = _contextValue4._ES5ProxyType ? _contextValue4.get("store") : _contextValue4.store), field, array, JSON.stringify(execContext._ES5ProxyType ? execContext.get("variableValues") : execContext.variableValues));
          }
        }
      }));
    }

    __setKey(StoreReader._ES5ProxyType ? StoreReader.get("prototype") : StoreReader.prototype, "readQueryFromStore", function (options) {
      var _this$diffQueryAgains, _result;

      return _this$diffQueryAgains = __callKey1$1(this, "diffQueryAgainstStore", _assign(_assign({}, options), {
        returnPartialData: false
      })), _result = _this$diffQueryAgains._ES5ProxyType ? _this$diffQueryAgains.get("result") : _this$diffQueryAgains.result;
    });

    __setKey(StoreReader._ES5ProxyType ? StoreReader.get("prototype") : StoreReader.prototype, "diffQueryAgainstStore", function (_a) {
      var _missing, _length;

      var store = _a._ES5ProxyType ? _a.get("store") : _a.store,
          query = _a._ES5ProxyType ? _a.get("query") : _a.query,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          previousResult = _a._ES5ProxyType ? _a.get("previousResult") : _a.previousResult,
          _b = _a._ES5ProxyType ? _a.get("returnPartialData") : _a.returnPartialData,
          returnPartialData = _b === void 0 ? true : _b,
          _c = _a._ES5ProxyType ? _a.get("rootId") : _a.rootId,
          rootId = _c === void 0 ? 'ROOT_QUERY' : _c,
          fragmentMatcherFunction = _a._ES5ProxyType ? _a.get("fragmentMatcherFunction") : _a.fragmentMatcherFunction,
          config = _a._ES5ProxyType ? _a.get("config") : _a.config;

      var queryDefinition = getQueryDefinition(query);
      variables = assign$2({}, getDefaultValues(queryDefinition), variables);
      var context = {
        store: store,
        dataIdFromObject: config && (config._ES5ProxyType ? config.get("dataIdFromObject") : config.dataIdFromObject),
        cacheRedirects: config && (config._ES5ProxyType ? config.get("cacheRedirects") : config.cacheRedirects) || {}
      };

      var execResult = __callKey1$1(this, "executeStoreQuery", {
        query: query,
        rootValue: {
          type: 'id',
          id: rootId,
          generated: true,
          typename: 'Query'
        },
        contextValue: context,
        variableValues: variables,
        fragmentMatcher: fragmentMatcherFunction
      });

      var hasMissingFields = (execResult._ES5ProxyType ? execResult.get("missing") : execResult.missing) && (_missing = execResult._ES5ProxyType ? execResult.get("missing") : execResult.missing, _length = _missing._ES5ProxyType ? _missing.get("length") : _missing.length) > 0;

      if (hasMissingFields && !returnPartialData) {
        __callKey1$1(execResult._ES5ProxyType ? execResult.get("missing") : execResult.missing, "forEach", function (info) {
          if (info._ES5ProxyType ? info.get("tolerable") : info.tolerable) return;
          throw  new InvariantError("Can't find field " + (info._ES5ProxyType ? info.get("fieldName") : info.fieldName) + " on object " + JSON.stringify(info._ES5ProxyType ? info.get("object") : info.object, null, 2) + ".");
        });
      }

      if (previousResult) {
        if (equal(previousResult, execResult._ES5ProxyType ? execResult.get("result") : execResult.result)) {
          __setKey(execResult, "result", previousResult);
        }
      }

      return {
        result: execResult._ES5ProxyType ? execResult.get("result") : execResult.result,
        complete: !hasMissingFields
      };
    });

    __setKey(StoreReader._ES5ProxyType ? StoreReader.get("prototype") : StoreReader.prototype, "executeStoreQuery", function (_a) {
      var query = _a._ES5ProxyType ? _a.get("query") : _a.query,
          rootValue = _a._ES5ProxyType ? _a.get("rootValue") : _a.rootValue,
          contextValue = _a._ES5ProxyType ? _a.get("contextValue") : _a.contextValue,
          variableValues = _a._ES5ProxyType ? _a.get("variableValues") : _a.variableValues,
          _b = _a._ES5ProxyType ? _a.get("fragmentMatcher") : _a.fragmentMatcher,
          fragmentMatcher = _b === void 0 ? defaultFragmentMatcher : _b;

      var mainDefinition = getMainDefinition(query);
      var fragments = getFragmentDefinitions(query);
      var fragmentMap = createFragmentMap(fragments);
      var execContext = {
        query: query,
        fragmentMap: fragmentMap,
        contextValue: contextValue,
        variableValues: variableValues,
        fragmentMatcher: fragmentMatcher
      };
      return __callKey1$1(this, "executeSelectionSet", {
        selectionSet: mainDefinition._ES5ProxyType ? mainDefinition.get("selectionSet") : mainDefinition.selectionSet,
        rootValue: rootValue,
        execContext: execContext
      });
    });

    __setKey(StoreReader._ES5ProxyType ? StoreReader.get("prototype") : StoreReader.prototype, "executeSelectionSet", function (_a) {
      var _this = this;

      var selectionSet = _a._ES5ProxyType ? _a.get("selectionSet") : _a.selectionSet,
          rootValue = _a._ES5ProxyType ? _a.get("rootValue") : _a.rootValue,
          execContext = _a._ES5ProxyType ? _a.get("execContext") : _a.execContext;
      var fragmentMap = execContext._ES5ProxyType ? execContext.get("fragmentMap") : execContext.fragmentMap,
          contextValue = execContext._ES5ProxyType ? execContext.get("contextValue") : execContext.contextValue,
          variables = execContext._ES5ProxyType ? execContext.get("variableValues") : execContext.variableValues;
      var finalResult = {
        result: null
      };
      var objectsToMerge = [];

      var object = __callKey1$1(contextValue._ES5ProxyType ? contextValue.get("store") : contextValue.store, "get", rootValue._ES5ProxyType ? rootValue.get("id") : rootValue.id);

      var typename = object && (object._ES5ProxyType ? object.get("__typename") : object.__typename) || (rootValue._ES5ProxyType ? rootValue.get("id") : rootValue.id) === 'ROOT_QUERY' && 'Query' || void 0;

      function handleMissing(result) {
        var _a;

        if (result._ES5ProxyType ? result.get("missing") : result.missing) {
          __setKey(finalResult, "missing", (finalResult._ES5ProxyType ? finalResult.get("missing") : finalResult.missing) || []);

          __callKey2((_a = finalResult._ES5ProxyType ? finalResult.get("missing") : finalResult.missing).push, "apply", _a, result._ES5ProxyType ? result.get("missing") : result.missing);
        }

        return result._ES5ProxyType ? result.get("result") : result.result;
      }

      __callKey1$1(selectionSet._ES5ProxyType ? selectionSet.get("selections") : selectionSet.selections, "forEach", function (selection) {
        var _a;

        if (!shouldInclude(selection, variables)) {
          return;
        }

        if (isField(selection)) {
          var fieldResult = handleMissing(__callKey4(_this, "executeField", object, typename, selection, execContext));

          if (typeof fieldResult !== 'undefined') {
            objectsToMerge.push((_a = {}, __setKey(_a, resultKeyNameFromField(selection), fieldResult), _a));
          }
        } else {
          var _typeCondition2, _name3, _value3;

          var fragment = void 0;

          if (isInlineFragment(selection)) {
            fragment = selection;
          } else {
            var _selection$name$value, _selection$name$value2, _name, _value;

            fragment = (_selection$name$value = (_name = selection._ES5ProxyType ? selection.get("name") : selection.name, _value = _name._ES5ProxyType ? _name.get("value") : _name.value), _selection$name$value2 = fragmentMap._ES5ProxyType ? fragmentMap.get(_selection$name$value) : fragmentMap[_selection$name$value]);

            if (!fragment) {
              var _name2, _value2;

              throw  new InvariantError("No fragment named " + (_name2 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value2 = _name2._ES5ProxyType ? _name2.get("value") : _name2.value));
            }
          }

          var typeCondition = (fragment._ES5ProxyType ? fragment.get("typeCondition") : fragment.typeCondition) && (_typeCondition2 = fragment._ES5ProxyType ? fragment.get("typeCondition") : fragment.typeCondition, _name3 = _typeCondition2._ES5ProxyType ? _typeCondition2.get("name") : _typeCondition2.name, _value3 = _name3._ES5ProxyType ? _name3.get("value") : _name3.value);

          var match = !typeCondition || __callKey3(execContext, "fragmentMatcher", rootValue, typeCondition, contextValue);

          if (match) {
            var fragmentExecResult = __callKey1$1(_this, "executeSelectionSet", {
              selectionSet: fragment._ES5ProxyType ? fragment.get("selectionSet") : fragment.selectionSet,
              rootValue: rootValue,
              execContext: execContext
            });

            if (match === 'heuristic' && (fragmentExecResult._ES5ProxyType ? fragmentExecResult.get("missing") : fragmentExecResult.missing)) {
              fragmentExecResult = _assign(_assign({}, fragmentExecResult), {
                missing: __callKey1$1(fragmentExecResult._ES5ProxyType ? fragmentExecResult.get("missing") : fragmentExecResult.missing, "map", function (info) {
                  return _assign(_assign({}, info), {
                    tolerable: true
                  });
                })
              });
            }

            objectsToMerge.push(handleMissing(fragmentExecResult));
          }
        }
      });

      __setKey(finalResult, "result", mergeDeepArray(objectsToMerge));

      if ((this._ES5ProxyType ? this.get("freezeResults") : this.freezeResults) && "development" !== 'production') {
        Object.freeze(finalResult._ES5ProxyType ? finalResult.get("result") : finalResult.result);
      }

      return finalResult;
    });

    __setKey(StoreReader._ES5ProxyType ? StoreReader.get("prototype") : StoreReader.prototype, "executeField", function (object, typename, field, execContext) {
      var _name4, _value4;

      var variables = execContext._ES5ProxyType ? execContext.get("variableValues") : execContext.variableValues,
          contextValue = execContext._ES5ProxyType ? execContext.get("contextValue") : execContext.contextValue;
      var fieldName = (_name4 = field._ES5ProxyType ? field.get("name") : field.name, _value4 = _name4._ES5ProxyType ? _name4.get("value") : _name4.value);
      var args = argumentsObjectFromField(field, variables);
      var info = {
        resultKey: resultKeyNameFromField(field),
        directives: getDirectiveInfoFromField(field, variables)
      };
      var readStoreResult = readStoreResolver(object, typename, fieldName, args, contextValue, info);

      if (Array.compatIsArray(readStoreResult._ES5ProxyType ? readStoreResult.get("result") : readStoreResult.result)) {
        return __callKey2(this, "combineExecResults", readStoreResult, __callKey1$1(this, "executeSubSelectedArray", {
          field: field,
          array: readStoreResult._ES5ProxyType ? readStoreResult.get("result") : readStoreResult.result,
          execContext: execContext
        }));
      }

      if (!(field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet)) {
        assertSelectionSetForIdValue(field, readStoreResult._ES5ProxyType ? readStoreResult.get("result") : readStoreResult.result);

        if ((this._ES5ProxyType ? this.get("freezeResults") : this.freezeResults) && "development" !== 'production') {
          maybeDeepFreeze(readStoreResult);
        }

        return readStoreResult;
      }

      if ((readStoreResult._ES5ProxyType ? readStoreResult.get("result") : readStoreResult.result) == null) {
        return readStoreResult;
      }

      return __callKey2(this, "combineExecResults", readStoreResult, __callKey1$1(this, "executeSelectionSet", {
        selectionSet: field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet,
        rootValue: readStoreResult._ES5ProxyType ? readStoreResult.get("result") : readStoreResult.result,
        execContext: execContext
      }));
    });

    __setKey(StoreReader._ES5ProxyType ? StoreReader.get("prototype") : StoreReader.prototype, "combineExecResults", function () {
      var _execResults$pop, _result2;

      var execResults = [];

      for (var _i = 0; _i < arguments.length; _i++) {
        __setKey(execResults, _i, arguments[_i]);
      }

      var missing;

      __callKey1$1(execResults, "forEach", function (execResult) {
        if (execResult._ES5ProxyType ? execResult.get("missing") : execResult.missing) {
          missing = missing || [];

          __callKey2(missing.push, "apply", missing, execResult._ES5ProxyType ? execResult.get("missing") : execResult.missing);
        }
      });

      return {
        result: (_execResults$pop = execResults.pop(), _result2 = _execResults$pop._ES5ProxyType ? _execResults$pop.get("result") : _execResults$pop.result),
        missing: missing
      };
    });

    __setKey(StoreReader._ES5ProxyType ? StoreReader.get("prototype") : StoreReader.prototype, "executeSubSelectedArray", function (_a) {
      var _this = this;

      var field = _a._ES5ProxyType ? _a.get("field") : _a.field,
          array = _a._ES5ProxyType ? _a.get("array") : _a.array,
          execContext = _a._ES5ProxyType ? _a.get("execContext") : _a.execContext;
      var missing;

      function handleMissing(childResult) {
        if (childResult._ES5ProxyType ? childResult.get("missing") : childResult.missing) {
          missing = missing || [];

          __callKey2(missing.push, "apply", missing, childResult._ES5ProxyType ? childResult.get("missing") : childResult.missing);
        }

        return childResult._ES5ProxyType ? childResult.get("result") : childResult.result;
      }

      array = __callKey1$1(array, "map", function (item) {
        if (item === null) {
          return null;
        }

        if (Array.compatIsArray(item)) {
          return handleMissing(__callKey1$1(_this, "executeSubSelectedArray", {
            field: field,
            array: item,
            execContext: execContext
          }));
        }

        if (field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet) {
          return handleMissing(__callKey1$1(_this, "executeSelectionSet", {
            selectionSet: field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet,
            rootValue: item,
            execContext: execContext
          }));
        }

        assertSelectionSetForIdValue(field, item);
        return item;
      });

      if ((this._ES5ProxyType ? this.get("freezeResults") : this.freezeResults) && "development" !== 'production') {
        Object.freeze(array);
      }

      return {
        result: array,
        missing: missing
      };
    });

    return StoreReader;
  }();

  function assertSelectionSetForIdValue(field, value) {
    if (!(field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet) && isIdValue(value)) {
      var _name5, _value5;

      throw  new InvariantError("Missing selection set for object of type " + (value._ES5ProxyType ? value.get("typename") : value.typename) + " returned for query field " + (_name5 = field._ES5ProxyType ? field.get("name") : field.name, _value5 = _name5._ES5ProxyType ? _name5.get("value") : _name5.value));
    }
  }

  function defaultFragmentMatcher() {
    return true;
  }

  function readStoreResolver(object, typename, fieldName, args, context, _a) {
    var resultKey = _a._ES5ProxyType ? _a.get("resultKey") : _a.resultKey,
        directives = _a._ES5ProxyType ? _a.get("directives") : _a.directives;
    var storeKeyName = fieldName;

    if (args || directives) {
      storeKeyName = getStoreKeyName(storeKeyName, args, directives);
    }

    var fieldValue = void 0;

    if (object) {
      fieldValue = object._ES5ProxyType ? object.get(storeKeyName) : object[storeKeyName];

      if (typeof fieldValue === 'undefined' && (context._ES5ProxyType ? context.get("cacheRedirects") : context.cacheRedirects) && typeof typename === 'string') {
        var _cacheRedirects, _typename;

        var type = (_cacheRedirects = context._ES5ProxyType ? context.get("cacheRedirects") : context.cacheRedirects, _typename = _cacheRedirects._ES5ProxyType ? _cacheRedirects.get(typename) : _cacheRedirects[typename]);

        if (type) {
          var resolver = type._ES5ProxyType ? type.get(fieldName) : type[fieldName];

          if (resolver) {
            fieldValue = resolver(object, args, {
              getCacheKey: function getCacheKey(storeObj) {
                var id = __callKey1$1(context, "dataIdFromObject", storeObj);

                return id && toIdValue({
                  id: id,
                  typename: storeObj._ES5ProxyType ? storeObj.get("__typename") : storeObj.__typename
                });
              }
            });
          }
        }
      }
    }

    if (typeof fieldValue === 'undefined') {
      return {
        result: fieldValue,
        missing: [{
          object: object,
          fieldName: storeKeyName,
          tolerable: false
        }]
      };
    }

    if (isJsonValue(fieldValue)) {
      fieldValue = fieldValue._ES5ProxyType ? fieldValue.get("json") : fieldValue.json;
    }

    return {
      result: fieldValue
    };
  }

  var ObjectCache = function () {
    function ObjectCache(data) {
      if (data === void 0) {
        data = Object.create(null);
      }

      __setKey(this, "data", data);
    }

    __setKey(ObjectCache._ES5ProxyType ? ObjectCache.get("prototype") : ObjectCache.prototype, "toObject", function () {
      return this._ES5ProxyType ? this.get("data") : this.data;
    });

    __setKey(ObjectCache._ES5ProxyType ? ObjectCache.get("prototype") : ObjectCache.prototype, "get", function (dataId) {
      var _data4, _dataId4;

      return _data4 = this._ES5ProxyType ? this.get("data") : this.data, _dataId4 = _data4._ES5ProxyType ? _data4.get(dataId) : _data4[dataId];
    });

    __setKey(ObjectCache._ES5ProxyType ? ObjectCache.get("prototype") : ObjectCache.prototype, "set", function (dataId, value) {
      __setKey(this._ES5ProxyType ? this.get("data") : this.data, dataId, value);
    });

    __setKey(ObjectCache._ES5ProxyType ? ObjectCache.get("prototype") : ObjectCache.prototype, "delete", function (dataId) {
      __setKey(this._ES5ProxyType ? this.get("data") : this.data, dataId, void 0);
    });

    __setKey(ObjectCache._ES5ProxyType ? ObjectCache.get("prototype") : ObjectCache.prototype, "clear", function () {
      __setKey(this, "data", Object.create(null));
    });

    __setKey(ObjectCache._ES5ProxyType ? ObjectCache.get("prototype") : ObjectCache.prototype, "replace", function (newData) {
      __setKey(this, "data", newData || Object.create(null));
    });

    return ObjectCache;
  }();

  var WriteError = function (_super) {
    __extends(WriteError, _super);

    function WriteError() {
      var _this = _super !== null && __callKey2(_super, "apply", this, arguments) || this;

      __setKey(_this, "type", 'WriteError');

      return _this;
    }

    return WriteError;
  }(Error);

  function enhanceErrorWithDocument(error, document) {
    var enhancedError = new WriteError("Error writing result to store for query:\n " + JSON.stringify(document));

    __setKey(enhancedError, "message", (enhancedError._ES5ProxyType ? enhancedError.get("message") : enhancedError.message) + ('\n' + (error._ES5ProxyType ? error.get("message") : error.message)));

    __setKey(enhancedError, "stack", error._ES5ProxyType ? error.get("stack") : error.stack);

    return enhancedError;
  }

  var StoreWriter = function () {
    function StoreWriter() {}

    __setKey(StoreWriter._ES5ProxyType ? StoreWriter.get("prototype") : StoreWriter.prototype, "writeQueryToStore", function (_a) {
      var query = _a._ES5ProxyType ? _a.get("query") : _a.query,
          result = _a._ES5ProxyType ? _a.get("result") : _a.result,
          _b = _a._ES5ProxyType ? _a.get("store") : _a.store,
          store = _b === void 0 ? defaultNormalizedCacheFactory() : _b,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          dataIdFromObject = _a._ES5ProxyType ? _a.get("dataIdFromObject") : _a.dataIdFromObject,
          fragmentMatcherFunction = _a._ES5ProxyType ? _a.get("fragmentMatcherFunction") : _a.fragmentMatcherFunction;

      return __callKey1$1(this, "writeResultToStore", {
        dataId: 'ROOT_QUERY',
        result: result,
        document: query,
        store: store,
        variables: variables,
        dataIdFromObject: dataIdFromObject,
        fragmentMatcherFunction: fragmentMatcherFunction
      });
    });

    __setKey(StoreWriter._ES5ProxyType ? StoreWriter.get("prototype") : StoreWriter.prototype, "writeResultToStore", function (_a) {
      var dataId = _a._ES5ProxyType ? _a.get("dataId") : _a.dataId,
          result = _a._ES5ProxyType ? _a.get("result") : _a.result,
          document = _a._ES5ProxyType ? _a.get("document") : _a.document,
          _b = _a._ES5ProxyType ? _a.get("store") : _a.store,
          store = _b === void 0 ? defaultNormalizedCacheFactory() : _b,
          variables = _a._ES5ProxyType ? _a.get("variables") : _a.variables,
          dataIdFromObject = _a._ES5ProxyType ? _a.get("dataIdFromObject") : _a.dataIdFromObject,
          fragmentMatcherFunction = _a._ES5ProxyType ? _a.get("fragmentMatcherFunction") : _a.fragmentMatcherFunction;

      var operationDefinition = getOperationDefinition(document);

      try {
        return __callKey1$1(this, "writeSelectionSetToStore", {
          result: result,
          dataId: dataId,
          selectionSet: operationDefinition._ES5ProxyType ? operationDefinition.get("selectionSet") : operationDefinition.selectionSet,
          context: {
            store: store,
            processedData: {},
            variables: assign$2({}, getDefaultValues(operationDefinition), variables),
            dataIdFromObject: dataIdFromObject,
            fragmentMap: createFragmentMap(getFragmentDefinitions(document)),
            fragmentMatcherFunction: fragmentMatcherFunction
          }
        });
      } catch (e) {
        throw enhanceErrorWithDocument(e, document);
      }
    });

    __setKey(StoreWriter._ES5ProxyType ? StoreWriter.get("prototype") : StoreWriter.prototype, "writeSelectionSetToStore", function (_a) {
      var _this = this;

      var result = _a._ES5ProxyType ? _a.get("result") : _a.result,
          dataId = _a._ES5ProxyType ? _a.get("dataId") : _a.dataId,
          selectionSet = _a._ES5ProxyType ? _a.get("selectionSet") : _a.selectionSet,
          context = _a._ES5ProxyType ? _a.get("context") : _a.context;
      var variables = context._ES5ProxyType ? context.get("variables") : context.variables,
          store = context._ES5ProxyType ? context.get("store") : context.store,
          fragmentMap = context._ES5ProxyType ? context.get("fragmentMap") : context.fragmentMap;

      __callKey1$1(selectionSet._ES5ProxyType ? selectionSet.get("selections") : selectionSet.selections, "forEach", function (selection) {
        var _a;

        if (!shouldInclude(selection, variables)) {
          return;
        }

        if (isField(selection)) {
          var resultFieldKey = resultKeyNameFromField(selection);
          var value = result._ES5ProxyType ? result.get(resultFieldKey) : result[resultFieldKey];

          if (typeof value !== 'undefined') {
            __callKey1$1(_this, "writeFieldToStore", {
              dataId: dataId,
              value: value,
              field: selection,
              context: context
            });
          } else {
            var _directives, _length2;

            var isDefered = false;
            var isClient = false;

            if ((selection._ES5ProxyType ? selection.get("directives") : selection.directives) && (_directives = selection._ES5ProxyType ? selection.get("directives") : selection.directives, _length2 = _directives._ES5ProxyType ? _directives.get("length") : _directives.length)) {
              isDefered = __callKey1$1(selection._ES5ProxyType ? selection.get("directives") : selection.directives, "some", function (directive) {
                var _name6, _value6;

                return (directive._ES5ProxyType ? directive.get("name") : directive.name) && (_name6 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value6 = _name6._ES5ProxyType ? _name6.get("value") : _name6.value) === 'defer';
              });
              isClient = __callKey1$1(selection._ES5ProxyType ? selection.get("directives") : selection.directives, "some", function (directive) {
                var _name7, _value7;

                return (directive._ES5ProxyType ? directive.get("name") : directive.name) && (_name7 = directive._ES5ProxyType ? directive.get("name") : directive.name, _value7 = _name7._ES5ProxyType ? _name7.get("value") : _name7.value) === 'client';
              });
            }

            if (!isDefered && !isClient && (context._ES5ProxyType ? context.get("fragmentMatcherFunction") : context.fragmentMatcherFunction)) {
               __callKey1$1(invariant$3, "warn", "Missing field " + resultFieldKey + " in " + __callKey2(JSON.stringify(result, null, 2), "substring", 0, 100));
            }
          }
        } else {
          var fragment = void 0;

          if (isInlineFragment(selection)) {
            fragment = selection;
          } else {
            var _ref, _selection$name$value3, _selection$name$value4, _name8, _value8, _name9, _value9;

            fragment = (_ref = fragmentMap || {}, _selection$name$value3 = (_name8 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value8 = _name8._ES5ProxyType ? _name8.get("value") : _name8.value), _selection$name$value4 = _ref._ES5ProxyType ? _ref.get(_selection$name$value3) : _ref[_selection$name$value3]);
             invariant$3(fragment, "No fragment named " + (_name9 = selection._ES5ProxyType ? selection.get("name") : selection.name, _value9 = _name9._ES5ProxyType ? _name9.get("value") : _name9.value) + ".");
          }

          var matches = true;

          if ((context._ES5ProxyType ? context.get("fragmentMatcherFunction") : context.fragmentMatcherFunction) && (fragment._ES5ProxyType ? fragment.get("typeCondition") : fragment.typeCondition)) {
            var _typeCondition3, _name10, _value10;

            var id = dataId || 'self';
            var idValue = toIdValue({
              id: id,
              typename: undefined
            });
            var fakeContext = {
              store: new ObjectCache((_a = {}, __setKey(_a, id, result), _a)),
              cacheRedirects: {}
            };

            var match = __callKey3(context, "fragmentMatcherFunction", idValue, (_typeCondition3 = fragment._ES5ProxyType ? fragment.get("typeCondition") : fragment.typeCondition, _name10 = _typeCondition3._ES5ProxyType ? _typeCondition3.get("name") : _typeCondition3.name, _value10 = _name10._ES5ProxyType ? _name10.get("value") : _name10.value), fakeContext);

            if (!isProduction() && match === 'heuristic') {
               __callKey1$1(invariant$3, "error", 'WARNING: heuristic fragment matching going on!');
            }

            matches = !!match;
          }

          if (matches) {
            __callKey1$1(_this, "writeSelectionSetToStore", {
              result: result,
              selectionSet: fragment._ES5ProxyType ? fragment.get("selectionSet") : fragment.selectionSet,
              dataId: dataId,
              context: context
            });
          }
        }
      });

      return store;
    });

    __setKey(StoreWriter._ES5ProxyType ? StoreWriter.get("prototype") : StoreWriter.prototype, "writeFieldToStore", function (_a) {
      var _b;

      var field = _a._ES5ProxyType ? _a.get("field") : _a.field,
          value = _a._ES5ProxyType ? _a.get("value") : _a.value,
          dataId = _a._ES5ProxyType ? _a.get("dataId") : _a.dataId,
          context = _a._ES5ProxyType ? _a.get("context") : _a.context;
      var variables = context._ES5ProxyType ? context.get("variables") : context.variables,
          dataIdFromObject = context._ES5ProxyType ? context.get("dataIdFromObject") : context.dataIdFromObject,
          store = context._ES5ProxyType ? context.get("store") : context.store;
      var storeValue;
      var storeObject;
      var storeFieldName = storeKeyNameFromField(field, variables);

      if (!(field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet) || value === null) {
        storeValue = value != null && _typeof_1(value) === 'object' ? {
          type: 'json',
          json: value
        } : value;
      } else if (Array.compatIsArray(value)) {
        var generatedId = dataId + "." + storeFieldName;
        storeValue = __callKey4(this, "processArrayValue", value, generatedId, field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet, context);
      } else {
        var valueDataId = dataId + "." + storeFieldName;
        var generated = true;

        if (!isGeneratedId(valueDataId)) {
          valueDataId = '$' + valueDataId;
        }

        if (dataIdFromObject) {
          var semanticId = dataIdFromObject(value);
           invariant$3(!semanticId || !isGeneratedId(semanticId), 'IDs returned by dataIdFromObject cannot begin with the "$" character.');

          if (semanticId || typeof semanticId === 'number' && semanticId === 0) {
            valueDataId = semanticId;
            generated = false;
          }
        }

        if (!isDataProcessed(valueDataId, field, context._ES5ProxyType ? context.get("processedData") : context.processedData)) {
          __callKey1$1(this, "writeSelectionSetToStore", {
            dataId: valueDataId,
            result: value,
            selectionSet: field._ES5ProxyType ? field.get("selectionSet") : field.selectionSet,
            context: context
          });
        }

        var typename = value._ES5ProxyType ? value.get("__typename") : value.__typename;
        storeValue = toIdValue({
          id: valueDataId,
          typename: typename
        }, generated);
        storeObject = __callKey1$1(store, "get", dataId);
        var escapedId = storeObject && (storeObject._ES5ProxyType ? storeObject.get(storeFieldName) : storeObject[storeFieldName]);

        if (escapedId !== storeValue && isIdValue(escapedId)) {
          var hadTypename = (escapedId._ES5ProxyType ? escapedId.get("typename") : escapedId.typename) !== undefined;
          var hasTypename = typename !== undefined;
          var typenameChanged = hadTypename && hasTypename && (escapedId._ES5ProxyType ? escapedId.get("typename") : escapedId.typename) !== typename;
           invariant$3(!generated || (escapedId._ES5ProxyType ? escapedId.get("generated") : escapedId.generated) || typenameChanged, "Store error: the application attempted to write an object with no provided id but the store already contains an id of " + (escapedId._ES5ProxyType ? escapedId.get("id") : escapedId.id) + " for this object. The selectionSet that was trying to be written is:\n" + JSON.stringify(field));
           invariant$3(!hadTypename || hasTypename, "Store error: the application attempted to write an object with no provided typename but the store already contains an object with typename of " + (escapedId._ES5ProxyType ? escapedId.get("typename") : escapedId.typename) + " for the object of id " + (escapedId._ES5ProxyType ? escapedId.get("id") : escapedId.id) + ". The selectionSet that was trying to be written is:\n" + JSON.stringify(field));

          if (escapedId._ES5ProxyType ? escapedId.get("generated") : escapedId.generated) {
            if (typenameChanged) {
              if (!generated) {
                __callKey1$1(store, "delete", escapedId._ES5ProxyType ? escapedId.get("id") : escapedId.id);
              }
            } else {
              mergeWithGenerated(escapedId._ES5ProxyType ? escapedId.get("id") : escapedId.id, storeValue._ES5ProxyType ? storeValue.get("id") : storeValue.id, store);
            }
          }
        }
      }

      storeObject = __callKey1$1(store, "get", dataId);

      if (!storeObject || !equal(storeValue, storeObject._ES5ProxyType ? storeObject.get(storeFieldName) : storeObject[storeFieldName])) {
        __callKey2(store, "set", dataId, _assign(_assign({}, storeObject), (_b = {}, __setKey(_b, storeFieldName, storeValue), _b)));
      }
    });

    __setKey(StoreWriter._ES5ProxyType ? StoreWriter.get("prototype") : StoreWriter.prototype, "processArrayValue", function (value, generatedId, selectionSet, context) {
      var _this = this;

      return __callKey1$1(value, "map", function (item, index) {
        if (item === null) {
          return null;
        }

        var itemDataId = generatedId + "." + index;

        if (Array.compatIsArray(item)) {
          return __callKey4(_this, "processArrayValue", item, itemDataId, selectionSet, context);
        }

        var generated = true;

        if (context._ES5ProxyType ? context.get("dataIdFromObject") : context.dataIdFromObject) {
          var semanticId = __callKey1$1(context, "dataIdFromObject", item);

          if (semanticId) {
            itemDataId = semanticId;
            generated = false;
          }
        }

        if (!isDataProcessed(itemDataId, selectionSet, context._ES5ProxyType ? context.get("processedData") : context.processedData)) {
          __callKey1$1(_this, "writeSelectionSetToStore", {
            dataId: itemDataId,
            result: item,
            selectionSet: selectionSet,
            context: context
          });
        }

        return toIdValue({
          id: itemDataId,
          typename: item._ES5ProxyType ? item.get("__typename") : item.__typename
        }, generated);
      });
    });

    return StoreWriter;
  }();

  function isGeneratedId(id) {
    return (id._ES5ProxyType ? id.get(0) : id[0]) === '$';
  }

  function mergeWithGenerated(generatedKey, realKey, cache) {
    if (generatedKey === realKey) {
      return false;
    }

    var generated = __callKey1$1(cache, "get", generatedKey);

    var real = __callKey1$1(cache, "get", realKey);

    var madeChanges = false;

    __callKey1$1(Object.compatKeys(generated), "forEach", function (key) {
      var value = generated._ES5ProxyType ? generated.get(key) : generated[key];
      var realValue = real._ES5ProxyType ? real.get(key) : real[key];

      if (isIdValue(value) && isGeneratedId(value._ES5ProxyType ? value.get("id") : value.id) && isIdValue(realValue) && !equal(value, realValue) && mergeWithGenerated(value._ES5ProxyType ? value.get("id") : value.id, realValue._ES5ProxyType ? realValue.get("id") : realValue.id, cache)) {
        madeChanges = true;
      }
    });

    __callKey1$1(cache, "delete", generatedKey);

    var newRealValue = _assign(_assign({}, generated), real);

    if (equal(newRealValue, real)) {
      return madeChanges;
    }

    __callKey2(cache, "set", realKey, newRealValue);

    return true;
  }

  function isDataProcessed(dataId, field, processedData) {
    if (!processedData) {
      return false;
    }

    if (processedData._ES5ProxyType ? processedData.get(dataId) : processedData[dataId]) {
      if (__callKey1$1(processedData._ES5ProxyType ? processedData.get(dataId) : processedData[dataId], "indexOf", field) >= 0) {
        return true;
      } else {
        (processedData._ES5ProxyType ? processedData.get(dataId) : processedData[dataId]).push(field);
      }
    } else {
      __setKey(processedData, dataId, [field]);
    }

    return false;
  }

  var defaultConfig = {
    fragmentMatcher: new HeuristicFragmentMatcher(),
    dataIdFromObject: defaultDataIdFromObject,
    addTypename: true,
    resultCaching: true,
    freezeResults: false
  };

  function defaultDataIdFromObject(result) {
    if (result._ES5ProxyType ? result.get("__typename") : result.__typename) {
      if ((result._ES5ProxyType ? result.get("id") : result.id) !== undefined) {
        return (result._ES5ProxyType ? result.get("__typename") : result.__typename) + ":" + (result._ES5ProxyType ? result.get("id") : result.id);
      }

      if ((result._ES5ProxyType ? result.get("_id") : result._id) !== undefined) {
        return (result._ES5ProxyType ? result.get("__typename") : result.__typename) + ":" + (result._ES5ProxyType ? result.get("_id") : result._id);
      }
    }

    return null;
  }

  var hasOwn$1 = Object.prototype._ES5ProxyType ? Object.prototype.get("compatHasOwnProperty") : Object.prototype.compatHasOwnProperty;

  var OptimisticCacheLayer = function (_super) {
    __extends(OptimisticCacheLayer, _super);

    function OptimisticCacheLayer(optimisticId, parent, transaction) {
      var _this = __callKey2(_super, "call", this, Object.create(null)) || this;

      __setKey(_this, "optimisticId", optimisticId);

      __setKey(_this, "parent", parent);

      __setKey(_this, "transaction", transaction);

      return _this;
    }

    __setKey(OptimisticCacheLayer._ES5ProxyType ? OptimisticCacheLayer.get("prototype") : OptimisticCacheLayer.prototype, "toObject", function () {
      return _assign(_assign({}, __callKey0(this._ES5ProxyType ? this.get("parent") : this.parent, "toObject")), this._ES5ProxyType ? this.get("data") : this.data);
    });

    __setKey(OptimisticCacheLayer._ES5ProxyType ? OptimisticCacheLayer.get("prototype") : OptimisticCacheLayer.prototype, "get", function (dataId) {
      var _data5, _dataId5;

      return __callKey2(hasOwn$1, "call", this._ES5ProxyType ? this.get("data") : this.data, dataId) ? (_data5 = this._ES5ProxyType ? this.get("data") : this.data, _dataId5 = _data5._ES5ProxyType ? _data5.get(dataId) : _data5[dataId]) : __callKey1$1(this._ES5ProxyType ? this.get("parent") : this.parent, "get", dataId);
    });

    return OptimisticCacheLayer;
  }(ObjectCache);

  var InMemoryCache = function (_super) {
    __extends(InMemoryCache, _super);

    function InMemoryCache(config) {
      var _config, _customResolvers, _config3, _cacheResolvers, _config5, _addTypename, _config6, _resultCaching;

      if (config === void 0) {
        config = {};
      }

      var _this = __callKey1$1(_super, "call", this) || this;

      __setKey(_this, "watches", new Set());

      __setKey(_this, "typenameDocumentCache", new Map());

      __setKey(_this, "cacheKeyRoot", new KeyTrie(canUseWeakMap));

      __setKey(_this, "silenceBroadcast", false);

      __setKey(_this, "config", _assign(_assign({}, defaultConfig), config));

      if (_config = _this._ES5ProxyType ? _this.get("config") : _this.config, _customResolvers = _config._ES5ProxyType ? _config.get("customResolvers") : _config.customResolvers) {
        var _config2, _customResolvers2;

         __callKey1$1(invariant$3, "warn", 'customResolvers have been renamed to cacheRedirects. Please update your config as we will be deprecating customResolvers in the next major version.');

        __setKey(_this._ES5ProxyType ? _this.get("config") : _this.config, "cacheRedirects", (_config2 = _this._ES5ProxyType ? _this.get("config") : _this.config, _customResolvers2 = _config2._ES5ProxyType ? _config2.get("customResolvers") : _config2.customResolvers));
      }

      if (_config3 = _this._ES5ProxyType ? _this.get("config") : _this.config, _cacheResolvers = _config3._ES5ProxyType ? _config3.get("cacheResolvers") : _config3.cacheResolvers) {
        var _config4, _cacheResolvers2;

         __callKey1$1(invariant$3, "warn", 'cacheResolvers have been renamed to cacheRedirects. Please update your config as we will be deprecating cacheResolvers in the next major version.');

        __setKey(_this._ES5ProxyType ? _this.get("config") : _this.config, "cacheRedirects", (_config4 = _this._ES5ProxyType ? _this.get("config") : _this.config, _cacheResolvers2 = _config4._ES5ProxyType ? _config4.get("cacheResolvers") : _config4.cacheResolvers));
      }

      __setKey(_this, "addTypename", !!(_config5 = _this._ES5ProxyType ? _this.get("config") : _this.config, _addTypename = _config5._ES5ProxyType ? _config5.get("addTypename") : _config5.addTypename));

      __setKey(_this, "data", (_config6 = _this._ES5ProxyType ? _this.get("config") : _this.config, _resultCaching = _config6._ES5ProxyType ? _config6.get("resultCaching") : _config6.resultCaching) ? new DepTrackingCache() : new ObjectCache());

      __setKey(_this, "optimisticData", _this._ES5ProxyType ? _this.get("data") : _this.data);

      __setKey(_this, "storeWriter", new StoreWriter());

      __setKey(_this, "storeReader", new StoreReader({
        cacheKeyRoot: _this._ES5ProxyType ? _this.get("cacheKeyRoot") : _this.cacheKeyRoot,
        freezeResults: config._ES5ProxyType ? config.get("freezeResults") : config.freezeResults
      }));

      var cache = _this;
      var maybeBroadcastWatch = cache._ES5ProxyType ? cache.get("maybeBroadcastWatch") : cache.maybeBroadcastWatch;

      __setKey(_this, "maybeBroadcastWatch", wrap(function (c) {
        return __callKey2(maybeBroadcastWatch, "call", _this, c);
      }, {
        makeCacheKey: function makeCacheKey(c) {
          if (c._ES5ProxyType ? c.get("optimistic") : c.optimistic) {
            return;
          }

          if (c._ES5ProxyType ? c.get("previousResult") : c.previousResult) {
            return;
          }

          if (_instanceof_1(cache._ES5ProxyType ? cache.get("data") : cache.data, DepTrackingCache)) {
            return __callKey2(cache._ES5ProxyType ? cache.get("cacheKeyRoot") : cache.cacheKeyRoot, "lookup", c._ES5ProxyType ? c.get("query") : c.query, JSON.stringify(c._ES5ProxyType ? c.get("variables") : c.variables));
          }
        }
      }));

      return _this;
    }

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "restore", function (data) {
      if (data) __callKey1$1(this._ES5ProxyType ? this.get("data") : this.data, "replace", data);
      return this;
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "extract", function (optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return __callKey0(optimistic ? this._ES5ProxyType ? this.get("optimisticData") : this.optimisticData : this._ES5ProxyType ? this.get("data") : this.data, "toObject");
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "read", function (options) {
      var _config7, _fragmentMatcher;

      if (typeof (options._ES5ProxyType ? options.get("rootId") : options.rootId) === 'string' && typeof __callKey1$1(this._ES5ProxyType ? this.get("data") : this.data, "get", options._ES5ProxyType ? options.get("rootId") : options.rootId) === 'undefined') {
        return null;
      }

      var fragmentMatcher = (_config7 = this._ES5ProxyType ? this.get("config") : this.config, _fragmentMatcher = _config7._ES5ProxyType ? _config7.get("fragmentMatcher") : _config7.fragmentMatcher);
      var fragmentMatcherFunction = fragmentMatcher && (fragmentMatcher._ES5ProxyType ? fragmentMatcher.get("match") : fragmentMatcher.match);
      return __callKey1$1(this._ES5ProxyType ? this.get("storeReader") : this.storeReader, "readQueryFromStore", {
        store: (options._ES5ProxyType ? options.get("optimistic") : options.optimistic) ? this._ES5ProxyType ? this.get("optimisticData") : this.optimisticData : this._ES5ProxyType ? this.get("data") : this.data,
        query: __callKey1$1(this, "transformDocument", options._ES5ProxyType ? options.get("query") : options.query),
        variables: options._ES5ProxyType ? options.get("variables") : options.variables,
        rootId: options._ES5ProxyType ? options.get("rootId") : options.rootId,
        fragmentMatcherFunction: fragmentMatcherFunction,
        previousResult: options._ES5ProxyType ? options.get("previousResult") : options.previousResult,
        config: this._ES5ProxyType ? this.get("config") : this.config
      }) || null;
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "write", function (write) {
      var _config8, _fragmentMatcher2, _config9, _dataIdFromObject;

      var fragmentMatcher = (_config8 = this._ES5ProxyType ? this.get("config") : this.config, _fragmentMatcher2 = _config8._ES5ProxyType ? _config8.get("fragmentMatcher") : _config8.fragmentMatcher);
      var fragmentMatcherFunction = fragmentMatcher && (fragmentMatcher._ES5ProxyType ? fragmentMatcher.get("match") : fragmentMatcher.match);

      __callKey1$1(this._ES5ProxyType ? this.get("storeWriter") : this.storeWriter, "writeResultToStore", {
        dataId: write._ES5ProxyType ? write.get("dataId") : write.dataId,
        result: write._ES5ProxyType ? write.get("result") : write.result,
        variables: write._ES5ProxyType ? write.get("variables") : write.variables,
        document: __callKey1$1(this, "transformDocument", write._ES5ProxyType ? write.get("query") : write.query),
        store: this._ES5ProxyType ? this.get("data") : this.data,
        dataIdFromObject: (_config9 = this._ES5ProxyType ? this.get("config") : this.config, _dataIdFromObject = _config9._ES5ProxyType ? _config9.get("dataIdFromObject") : _config9.dataIdFromObject),
        fragmentMatcherFunction: fragmentMatcherFunction
      });

      __callKey0(this, "broadcastWatches");
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "diff", function (query) {
      var _config10, _fragmentMatcher3;

      var fragmentMatcher = (_config10 = this._ES5ProxyType ? this.get("config") : this.config, _fragmentMatcher3 = _config10._ES5ProxyType ? _config10.get("fragmentMatcher") : _config10.fragmentMatcher);
      var fragmentMatcherFunction = fragmentMatcher && (fragmentMatcher._ES5ProxyType ? fragmentMatcher.get("match") : fragmentMatcher.match);
      return __callKey1$1(this._ES5ProxyType ? this.get("storeReader") : this.storeReader, "diffQueryAgainstStore", {
        store: (query._ES5ProxyType ? query.get("optimistic") : query.optimistic) ? this._ES5ProxyType ? this.get("optimisticData") : this.optimisticData : this._ES5ProxyType ? this.get("data") : this.data,
        query: __callKey1$1(this, "transformDocument", query._ES5ProxyType ? query.get("query") : query.query),
        variables: query._ES5ProxyType ? query.get("variables") : query.variables,
        returnPartialData: query._ES5ProxyType ? query.get("returnPartialData") : query.returnPartialData,
        previousResult: query._ES5ProxyType ? query.get("previousResult") : query.previousResult,
        fragmentMatcherFunction: fragmentMatcherFunction,
        config: this._ES5ProxyType ? this.get("config") : this.config
      });
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "watch", function (watch) {
      var _this = this;

      __callKey1$1(this._ES5ProxyType ? this.get("watches") : this.watches, "add", watch);

      return function () {
        __callKey1$1(_this._ES5ProxyType ? _this.get("watches") : _this.watches, "delete", watch);
      };
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "evict", function (query) {
      throw  new InvariantError("eviction is not implemented on InMemory Cache");
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "reset", function () {
      __callKey0(this._ES5ProxyType ? this.get("data") : this.data, "clear");

      __callKey0(this, "broadcastWatches");

      return Promise.resolve();
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "removeOptimistic", function (idToRemove) {
      var toReapply = [];
      var removedCount = 0;
      var layer = this._ES5ProxyType ? this.get("optimisticData") : this.optimisticData;

      while (_instanceof_1(layer, OptimisticCacheLayer)) {
        if ((layer._ES5ProxyType ? layer.get("optimisticId") : layer.optimisticId) === idToRemove) {
          ++removedCount;
        } else {
          toReapply.push(layer);
        }

        layer = layer._ES5ProxyType ? layer.get("parent") : layer.parent;
      }

      if (removedCount > 0) {
        __setKey(this, "optimisticData", layer);

        while ((toReapply._ES5ProxyType ? toReapply.get("length") : toReapply.length) > 0) {
          var layer_1 = toReapply.pop();

          __callKey2(this, "performTransaction", layer_1._ES5ProxyType ? layer_1.get("transaction") : layer_1.transaction, layer_1._ES5ProxyType ? layer_1.get("optimisticId") : layer_1.optimisticId);
        }

        __callKey0(this, "broadcastWatches");
      }
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "performTransaction", function (transaction, optimisticId) {
      var _a = this,
          data = _a._ES5ProxyType ? _a.get("data") : _a.data,
          silenceBroadcast = _a._ES5ProxyType ? _a.get("silenceBroadcast") : _a.silenceBroadcast;

      __setKey(this, "silenceBroadcast", true);

      if (typeof optimisticId === 'string') {
        __setKey(this, "data", __setKey(this, "optimisticData", new OptimisticCacheLayer(optimisticId, this._ES5ProxyType ? this.get("optimisticData") : this.optimisticData, transaction)));
      }

      try {
        transaction(this);
      } finally {
        __setKey(this, "silenceBroadcast", silenceBroadcast);

        __setKey(this, "data", data);
      }

      __callKey0(this, "broadcastWatches");
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "recordOptimisticTransaction", function (transaction, id) {
      return __callKey2(this, "performTransaction", transaction, id);
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "transformDocument", function (document) {
      if (this._ES5ProxyType ? this.get("addTypename") : this.addTypename) {
        var result = __callKey1$1(this._ES5ProxyType ? this.get("typenameDocumentCache") : this.typenameDocumentCache, "get", document);

        if (!result) {
          result = addTypenameToDocument(document);

          __callKey2(this._ES5ProxyType ? this.get("typenameDocumentCache") : this.typenameDocumentCache, "set", document, result);

          __callKey2(this._ES5ProxyType ? this.get("typenameDocumentCache") : this.typenameDocumentCache, "set", result, result);
        }

        return result;
      }

      return document;
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "broadcastWatches", function () {
      var _this = this;

      if (!(this._ES5ProxyType ? this.get("silenceBroadcast") : this.silenceBroadcast)) {
        __callKey1$1(this._ES5ProxyType ? this.get("watches") : this.watches, "forEach", function (c) {
          return __callKey1$1(_this, "maybeBroadcastWatch", c);
        });
      }
    });

    __setKey(InMemoryCache._ES5ProxyType ? InMemoryCache.get("prototype") : InMemoryCache.prototype, "maybeBroadcastWatch", function (c) {
      __callKey1$1(c, "callback", __callKey1$1(this, "diff", {
        query: c._ES5ProxyType ? c.get("query") : c.query,
        variables: c._ES5ProxyType ? c.get("variables") : c.variables,
        previousResult: (c._ES5ProxyType ? c.get("previousResult") : c.previousResult) && __callKey0(c, "previousResult"),
        optimistic: c._ES5ProxyType ? c.get("optimistic") : c.optimistic
      }));
    });

    return InMemoryCache;
  }(ApolloCache);

  /**
   * Produces the value of a block string from its parsed raw value, similar to
   * CoffeeScript's block string, Python's docstring trim or Ruby's strip_heredoc.
   *
   * This implements the GraphQL spec's BlockStringValue() static algorithm.
   *
   * @internal
   */
  function dedentBlockStringValue(rawString) {
    // Expand a block string's raw value into independent lines.
    var lines = __callKey1$1(rawString, "split", /\r\n|[\n\r]/g); // Remove common indentation from all lines but first.


    var commonIndent = getBlockStringIndentation(lines);

    if (commonIndent !== 0) {
      for (var i = 1; i < (lines._ES5ProxyType ? lines.get("length") : lines.length); i++) {
        __setKey(lines, i, __callKey1$1(lines._ES5ProxyType ? lines.get(i) : lines[i], "slice", commonIndent));
      }
    } // Remove leading and trailing blank lines.


    while ((lines._ES5ProxyType ? lines.get("length") : lines.length) > 0 && isBlank(lines._ES5ProxyType ? lines.get(0) : lines[0])) {
      lines.shift();
    }

    while ((lines._ES5ProxyType ? lines.get("length") : lines.length) > 0 && isBlank((_ref = (lines._ES5ProxyType ? lines.get("length") : lines.length) - 1, _ref2 = lines._ES5ProxyType ? lines.get(_ref) : lines[_ref]))) {
      var _ref, _ref2;

      lines.pop();
    } // Return a string of the lines joined with U+000A.


    return __callKey1$1(lines, "join", '\n');
  }
  /**
   * @internal
   */

  function getBlockStringIndentation(lines) {
    var commonIndent = null;

    for (var i = 1; i < (lines._ES5ProxyType ? lines.get("length") : lines.length); i++) {
      var line = lines._ES5ProxyType ? lines.get(i) : lines[i];
      var indent = leadingWhitespace(line);

      if (indent === (line._ES5ProxyType ? line.get("length") : line.length)) {
        continue; // skip empty lines
      }

      if (commonIndent === null || indent < commonIndent) {
        commonIndent = indent;

        if (commonIndent === 0) {
          break;
        }
      }
    }

    return commonIndent === null ? 0 : commonIndent;
  }

  function leadingWhitespace(str) {
    var i = 0;

    while (i < (str._ES5ProxyType ? str.get("length") : str.length) && ((str._ES5ProxyType ? str.get(i) : str[i]) === ' ' || (str._ES5ProxyType ? str.get(i) : str[i]) === '\t')) {
      i++;
    }

    return i;
  }

  function isBlank(str) {
    return leadingWhitespace(str) === (str._ES5ProxyType ? str.get("length") : str.length);
  }
  /**
   * Print a block string in the indented block form by adding a leading and
   * trailing blank line. However, if a block string starts with whitespace and is
   * a single-line, adding a leading blank line would strip that whitespace.
   *
   * @internal
   */


  function printBlockString(value) {
    var _ref3, _ref4, _ref5, _ref6;

    var indentation = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    var preferMultipleLines = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    var isSingleLine = __callKey1$1(value, "indexOf", '\n') === -1;
    var hasLeadingSpace = (value._ES5ProxyType ? value.get(0) : value[0]) === ' ' || (value._ES5ProxyType ? value.get(0) : value[0]) === '\t';
    var hasTrailingQuote = (_ref3 = (value._ES5ProxyType ? value.get("length") : value.length) - 1, _ref4 = value._ES5ProxyType ? value.get(_ref3) : value[_ref3]) === '"';
    var hasTrailingSlash = (_ref5 = (value._ES5ProxyType ? value.get("length") : value.length) - 1, _ref6 = value._ES5ProxyType ? value.get(_ref5) : value[_ref5]) === '\\';
    var printAsMultipleLines = !isSingleLine || hasTrailingQuote || hasTrailingSlash || preferMultipleLines;
    var result = ''; // Format a multi-line block quote to account for leading space.

    if (printAsMultipleLines && !(isSingleLine && hasLeadingSpace)) {
      result += '\n' + indentation;
    }

    result += indentation ? __callKey2(value, "replace", /\n/g, '\n' + indentation) : value;

    if (printAsMultipleLines) {
      result += '\n';
    }

    return '"""' + __callKey2(result, "replace", /"""/g, '\\"""') + '"""';
  }

  /**
   * Converts an AST into a string, using one set of reasonable
   * formatting rules.
   */

  function print(ast) {
    return visit(ast, {
      leave: printDocASTReducer
    });
  } // TODO: provide better type coverage in future

  var printDocASTReducer = {
    Name: function Name(node) {
      return node._ES5ProxyType ? node.get("value") : node.value;
    },
    Variable: function Variable(node) {
      return '$' + (node._ES5ProxyType ? node.get("name") : node.name);
    },
    // Document
    Document: function Document(node) {
      return join(node._ES5ProxyType ? node.get("definitions") : node.definitions, '\n\n') + '\n';
    },
    OperationDefinition: function OperationDefinition(node) {
      var op = node._ES5ProxyType ? node.get("operation") : node.operation;
      var name = node._ES5ProxyType ? node.get("name") : node.name;
      var varDefs = wrap$1('(', join(node._ES5ProxyType ? node.get("variableDefinitions") : node.variableDefinitions, ', '), ')');
      var directives = join(node._ES5ProxyType ? node.get("directives") : node.directives, ' ');
      var selectionSet = node._ES5ProxyType ? node.get("selectionSet") : node.selectionSet; // Anonymous queries with no directives or variable definitions can use
      // the query short form.

      return !name && !directives && !varDefs && op === 'query' ? selectionSet : join([op, join([name, varDefs]), directives, selectionSet], ' ');
    },
    VariableDefinition: function VariableDefinition(_ref) {
      var variable = _ref._ES5ProxyType ? _ref.get("variable") : _ref.variable,
          type = _ref._ES5ProxyType ? _ref.get("type") : _ref.type,
          defaultValue = _ref._ES5ProxyType ? _ref.get("defaultValue") : _ref.defaultValue,
          directives = _ref._ES5ProxyType ? _ref.get("directives") : _ref.directives;
      return variable + ': ' + type + wrap$1(' = ', defaultValue) + wrap$1(' ', join(directives, ' '));
    },
    SelectionSet: function SelectionSet(_ref2) {
      var selections = _ref2._ES5ProxyType ? _ref2.get("selections") : _ref2.selections;
      return block(selections);
    },
    Field: function Field(_ref3) {
      var alias = _ref3._ES5ProxyType ? _ref3.get("alias") : _ref3.alias,
          name = _ref3._ES5ProxyType ? _ref3.get("name") : _ref3.name,
          args = _ref3._ES5ProxyType ? _ref3.get("arguments") : _ref3.arguments,
          directives = _ref3._ES5ProxyType ? _ref3.get("directives") : _ref3.directives,
          selectionSet = _ref3._ES5ProxyType ? _ref3.get("selectionSet") : _ref3.selectionSet;
      return join([wrap$1('', alias, ': ') + name + wrap$1('(', join(args, ', '), ')'), join(directives, ' '), selectionSet], ' ');
    },
    Argument: function Argument(_ref4) {
      var name = _ref4._ES5ProxyType ? _ref4.get("name") : _ref4.name,
          value = _ref4._ES5ProxyType ? _ref4.get("value") : _ref4.value;
      return name + ': ' + value;
    },
    // Fragments
    FragmentSpread: function FragmentSpread(_ref5) {
      var name = _ref5._ES5ProxyType ? _ref5.get("name") : _ref5.name,
          directives = _ref5._ES5ProxyType ? _ref5.get("directives") : _ref5.directives;
      return '...' + name + wrap$1(' ', join(directives, ' '));
    },
    InlineFragment: function InlineFragment(_ref6) {
      var typeCondition = _ref6._ES5ProxyType ? _ref6.get("typeCondition") : _ref6.typeCondition,
          directives = _ref6._ES5ProxyType ? _ref6.get("directives") : _ref6.directives,
          selectionSet = _ref6._ES5ProxyType ? _ref6.get("selectionSet") : _ref6.selectionSet;
      return join(['...', wrap$1('on ', typeCondition), join(directives, ' '), selectionSet], ' ');
    },
    FragmentDefinition: function FragmentDefinition(_ref7) {
      var name = _ref7._ES5ProxyType ? _ref7.get("name") : _ref7.name,
          typeCondition = _ref7._ES5ProxyType ? _ref7.get("typeCondition") : _ref7.typeCondition,
          variableDefinitions = _ref7._ES5ProxyType ? _ref7.get("variableDefinitions") : _ref7.variableDefinitions,
          directives = _ref7._ES5ProxyType ? _ref7.get("directives") : _ref7.directives,
          selectionSet = _ref7._ES5ProxyType ? _ref7.get("selectionSet") : _ref7.selectionSet;
      return (// Note: fragment variable definitions are experimental and may be changed
        // or removed in the future.
        __concat(__concat("fragment ", name), wrap$1('(', join(variableDefinitions, ', '), ')'), " ") + __concat(__concat("on ", typeCondition, " "), wrap$1('', join(directives, ' '), ' ')) + selectionSet
      );
    },
    // Value
    IntValue: function IntValue(_ref8) {
      var value = _ref8._ES5ProxyType ? _ref8.get("value") : _ref8.value;
      return value;
    },
    FloatValue: function FloatValue(_ref9) {
      var value = _ref9._ES5ProxyType ? _ref9.get("value") : _ref9.value;
      return value;
    },
    StringValue: function StringValue(_ref10, key) {
      var value = _ref10._ES5ProxyType ? _ref10.get("value") : _ref10.value,
          isBlockString = _ref10._ES5ProxyType ? _ref10.get("block") : _ref10.block;
      return isBlockString ? printBlockString(value, key === 'description' ? '' : '  ') : JSON.stringify(value);
    },
    BooleanValue: function BooleanValue(_ref11) {
      var value = _ref11._ES5ProxyType ? _ref11.get("value") : _ref11.value;
      return value ? 'true' : 'false';
    },
    NullValue: function NullValue() {
      return 'null';
    },
    EnumValue: function EnumValue(_ref12) {
      var value = _ref12._ES5ProxyType ? _ref12.get("value") : _ref12.value;
      return value;
    },
    ListValue: function ListValue(_ref13) {
      var values = _ref13._ES5ProxyType ? _ref13.get("values") : _ref13.values;
      return '[' + join(values, ', ') + ']';
    },
    ObjectValue: function ObjectValue(_ref14) {
      var fields = _ref14._ES5ProxyType ? _ref14.get("fields") : _ref14.fields;
      return '{' + join(fields, ', ') + '}';
    },
    ObjectField: function ObjectField(_ref15) {
      var name = _ref15._ES5ProxyType ? _ref15.get("name") : _ref15.name,
          value = _ref15._ES5ProxyType ? _ref15.get("value") : _ref15.value;
      return name + ': ' + value;
    },
    // Directive
    Directive: function Directive(_ref16) {
      var name = _ref16._ES5ProxyType ? _ref16.get("name") : _ref16.name,
          args = _ref16._ES5ProxyType ? _ref16.get("arguments") : _ref16.arguments;
      return '@' + name + wrap$1('(', join(args, ', '), ')');
    },
    // Type
    NamedType: function NamedType(_ref17) {
      var name = _ref17._ES5ProxyType ? _ref17.get("name") : _ref17.name;
      return name;
    },
    ListType: function ListType(_ref18) {
      var type = _ref18._ES5ProxyType ? _ref18.get("type") : _ref18.type;
      return '[' + type + ']';
    },
    NonNullType: function NonNullType(_ref19) {
      var type = _ref19._ES5ProxyType ? _ref19.get("type") : _ref19.type;
      return type + '!';
    },
    // Type System Definitions
    SchemaDefinition: addDescription(function (_ref20) {
      var directives = _ref20._ES5ProxyType ? _ref20.get("directives") : _ref20.directives,
          operationTypes = _ref20._ES5ProxyType ? _ref20.get("operationTypes") : _ref20.operationTypes;
      return join(['schema', join(directives, ' '), block(operationTypes)], ' ');
    }),
    OperationTypeDefinition: function OperationTypeDefinition(_ref21) {
      var operation = _ref21._ES5ProxyType ? _ref21.get("operation") : _ref21.operation,
          type = _ref21._ES5ProxyType ? _ref21.get("type") : _ref21.type;
      return operation + ': ' + type;
    },
    ScalarTypeDefinition: addDescription(function (_ref22) {
      var name = _ref22._ES5ProxyType ? _ref22.get("name") : _ref22.name,
          directives = _ref22._ES5ProxyType ? _ref22.get("directives") : _ref22.directives;
      return join(['scalar', name, join(directives, ' ')], ' ');
    }),
    ObjectTypeDefinition: addDescription(function (_ref23) {
      var name = _ref23._ES5ProxyType ? _ref23.get("name") : _ref23.name,
          interfaces = _ref23._ES5ProxyType ? _ref23.get("interfaces") : _ref23.interfaces,
          directives = _ref23._ES5ProxyType ? _ref23.get("directives") : _ref23.directives,
          fields = _ref23._ES5ProxyType ? _ref23.get("fields") : _ref23.fields;
      return join(['type', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    }),
    FieldDefinition: addDescription(function (_ref24) {
      var name = _ref24._ES5ProxyType ? _ref24.get("name") : _ref24.name,
          args = _ref24._ES5ProxyType ? _ref24.get("arguments") : _ref24.arguments,
          type = _ref24._ES5ProxyType ? _ref24.get("type") : _ref24.type,
          directives = _ref24._ES5ProxyType ? _ref24.get("directives") : _ref24.directives;
      return name + (hasMultilineItems(args) ? wrap$1('(\n', indent(join(args, '\n')), '\n)') : wrap$1('(', join(args, ', '), ')')) + ': ' + type + wrap$1(' ', join(directives, ' '));
    }),
    InputValueDefinition: addDescription(function (_ref25) {
      var name = _ref25._ES5ProxyType ? _ref25.get("name") : _ref25.name,
          type = _ref25._ES5ProxyType ? _ref25.get("type") : _ref25.type,
          defaultValue = _ref25._ES5ProxyType ? _ref25.get("defaultValue") : _ref25.defaultValue,
          directives = _ref25._ES5ProxyType ? _ref25.get("directives") : _ref25.directives;
      return join([name + ': ' + type, wrap$1('= ', defaultValue), join(directives, ' ')], ' ');
    }),
    InterfaceTypeDefinition: addDescription(function (_ref26) {
      var name = _ref26._ES5ProxyType ? _ref26.get("name") : _ref26.name,
          interfaces = _ref26._ES5ProxyType ? _ref26.get("interfaces") : _ref26.interfaces,
          directives = _ref26._ES5ProxyType ? _ref26.get("directives") : _ref26.directives,
          fields = _ref26._ES5ProxyType ? _ref26.get("fields") : _ref26.fields;
      return join(['interface', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    }),
    UnionTypeDefinition: addDescription(function (_ref27) {
      var name = _ref27._ES5ProxyType ? _ref27.get("name") : _ref27.name,
          directives = _ref27._ES5ProxyType ? _ref27.get("directives") : _ref27.directives,
          types = _ref27._ES5ProxyType ? _ref27.get("types") : _ref27.types;
      return join(['union', name, join(directives, ' '), types && (types._ES5ProxyType ? types.get("length") : types.length) !== 0 ? '= ' + join(types, ' | ') : ''], ' ');
    }),
    EnumTypeDefinition: addDescription(function (_ref28) {
      var name = _ref28._ES5ProxyType ? _ref28.get("name") : _ref28.name,
          directives = _ref28._ES5ProxyType ? _ref28.get("directives") : _ref28.directives,
          values = _ref28._ES5ProxyType ? _ref28.get("values") : _ref28.values;
      return join(['enum', name, join(directives, ' '), block(values)], ' ');
    }),
    EnumValueDefinition: addDescription(function (_ref29) {
      var name = _ref29._ES5ProxyType ? _ref29.get("name") : _ref29.name,
          directives = _ref29._ES5ProxyType ? _ref29.get("directives") : _ref29.directives;
      return join([name, join(directives, ' ')], ' ');
    }),
    InputObjectTypeDefinition: addDescription(function (_ref30) {
      var name = _ref30._ES5ProxyType ? _ref30.get("name") : _ref30.name,
          directives = _ref30._ES5ProxyType ? _ref30.get("directives") : _ref30.directives,
          fields = _ref30._ES5ProxyType ? _ref30.get("fields") : _ref30.fields;
      return join(['input', name, join(directives, ' '), block(fields)], ' ');
    }),
    DirectiveDefinition: addDescription(function (_ref31) {
      var name = _ref31._ES5ProxyType ? _ref31.get("name") : _ref31.name,
          args = _ref31._ES5ProxyType ? _ref31.get("arguments") : _ref31.arguments,
          repeatable = _ref31._ES5ProxyType ? _ref31.get("repeatable") : _ref31.repeatable,
          locations = _ref31._ES5ProxyType ? _ref31.get("locations") : _ref31.locations;
      return 'directive @' + name + (hasMultilineItems(args) ? wrap$1('(\n', indent(join(args, '\n')), '\n)') : wrap$1('(', join(args, ', '), ')')) + (repeatable ? ' repeatable' : '') + ' on ' + join(locations, ' | ');
    }),
    SchemaExtension: function SchemaExtension(_ref32) {
      var directives = _ref32._ES5ProxyType ? _ref32.get("directives") : _ref32.directives,
          operationTypes = _ref32._ES5ProxyType ? _ref32.get("operationTypes") : _ref32.operationTypes;
      return join(['extend schema', join(directives, ' '), block(operationTypes)], ' ');
    },
    ScalarTypeExtension: function ScalarTypeExtension(_ref33) {
      var name = _ref33._ES5ProxyType ? _ref33.get("name") : _ref33.name,
          directives = _ref33._ES5ProxyType ? _ref33.get("directives") : _ref33.directives;
      return join(['extend scalar', name, join(directives, ' ')], ' ');
    },
    ObjectTypeExtension: function ObjectTypeExtension(_ref34) {
      var name = _ref34._ES5ProxyType ? _ref34.get("name") : _ref34.name,
          interfaces = _ref34._ES5ProxyType ? _ref34.get("interfaces") : _ref34.interfaces,
          directives = _ref34._ES5ProxyType ? _ref34.get("directives") : _ref34.directives,
          fields = _ref34._ES5ProxyType ? _ref34.get("fields") : _ref34.fields;
      return join(['extend type', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    },
    InterfaceTypeExtension: function InterfaceTypeExtension(_ref35) {
      var name = _ref35._ES5ProxyType ? _ref35.get("name") : _ref35.name,
          interfaces = _ref35._ES5ProxyType ? _ref35.get("interfaces") : _ref35.interfaces,
          directives = _ref35._ES5ProxyType ? _ref35.get("directives") : _ref35.directives,
          fields = _ref35._ES5ProxyType ? _ref35.get("fields") : _ref35.fields;
      return join(['extend interface', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    },
    UnionTypeExtension: function UnionTypeExtension(_ref36) {
      var name = _ref36._ES5ProxyType ? _ref36.get("name") : _ref36.name,
          directives = _ref36._ES5ProxyType ? _ref36.get("directives") : _ref36.directives,
          types = _ref36._ES5ProxyType ? _ref36.get("types") : _ref36.types;
      return join(['extend union', name, join(directives, ' '), types && (types._ES5ProxyType ? types.get("length") : types.length) !== 0 ? '= ' + join(types, ' | ') : ''], ' ');
    },
    EnumTypeExtension: function EnumTypeExtension(_ref37) {
      var name = _ref37._ES5ProxyType ? _ref37.get("name") : _ref37.name,
          directives = _ref37._ES5ProxyType ? _ref37.get("directives") : _ref37.directives,
          values = _ref37._ES5ProxyType ? _ref37.get("values") : _ref37.values;
      return join(['extend enum', name, join(directives, ' '), block(values)], ' ');
    },
    InputObjectTypeExtension: function InputObjectTypeExtension(_ref38) {
      var name = _ref38._ES5ProxyType ? _ref38.get("name") : _ref38.name,
          directives = _ref38._ES5ProxyType ? _ref38.get("directives") : _ref38.directives,
          fields = _ref38._ES5ProxyType ? _ref38.get("fields") : _ref38.fields;
      return join(['extend input', name, join(directives, ' '), block(fields)], ' ');
    }
  };

  function addDescription(cb) {
    return function (node) {
      return join([node._ES5ProxyType ? node.get("description") : node.description, cb(node)], '\n');
    };
  }
  /**
   * Given maybeArray, print an empty string if it is null or empty, otherwise
   * print all items together separated by separator if provided
   */


  function join(maybeArray) {
    var _maybeArray$filter$jo;

    var separator = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    return (_maybeArray$filter$jo = maybeArray === null || maybeArray === void 0 ? void 0 : __callKey1$1(__callKey1$1(maybeArray, "filter", function (x) {
      return x;
    }), "join", separator)) !== null && _maybeArray$filter$jo !== void 0 ? _maybeArray$filter$jo : '';
  }
  /**
   * Given array, print each item on its own line, wrapped in an
   * indented "{ }" block.
   */


  function block(array) {
    return array && (array._ES5ProxyType ? array.get("length") : array.length) !== 0 ? '{\n' + indent(join(array, '\n')) + '\n}' : '';
  }
  /**
   * If maybeString is not null or empty, then wrap with start and end, otherwise
   * print an empty string.
   */


  function wrap$1(start, maybeString) {
    var end = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
    return maybeString ? start + maybeString + end : '';
  }

  function indent(maybeString) {
    return maybeString && '  ' + __callKey2(maybeString, "replace", /\n/g, '\n  ');
  }

  function isMultiline(string) {
    return __callKey1$1(string, "indexOf", '\n') !== -1;
  }

  function hasMultilineItems(maybeArray) {
    return maybeArray && __callKey1$1(maybeArray, "some", isMultiline);
  }

  var defaultHttpOptions = {
    includeQuery: true,
    includeExtensions: false
  };
  var defaultHeaders = {
    accept: '*/*',
    'content-type': 'application/json'
  };
  var defaultOptions = {
    method: 'POST'
  };
  var fallbackHttpConfig = {
    http: defaultHttpOptions,
    headers: defaultHeaders,
    options: defaultOptions
  };

  var throwServerError = function throwServerError(response, result, message) {
    var error = new Error(message);

    __setKey(error, "name", 'ServerError');

    __setKey(error, "response", response);

    __setKey(error, "statusCode", response._ES5ProxyType ? response.get("status") : response.status);

    __setKey(error, "result", result);

    throw error;
  };

  var parseAndCheckHttpResponse = function parseAndCheckHttpResponse(operations) {
    return function (response) {
      return __callKey1$1(__callKey1$1(__callKey0(response, "text"), "then", function (bodyText) {
        try {
          return JSON.parse(bodyText);
        } catch (err) {
          var parseError = err;

          __setKey(parseError, "name", 'ServerParseError');

          __setKey(parseError, "response", response);

          __setKey(parseError, "statusCode", response._ES5ProxyType ? response.get("status") : response.status);

          __setKey(parseError, "bodyText", bodyText);

          return Promise.reject(parseError);
        }
      }), "then", function (result) {
        if ((response._ES5ProxyType ? response.get("status") : response.status) >= 300) {
          throwServerError(response, result, "Response not successful: Received status code " + (response._ES5ProxyType ? response.get("status") : response.status));
        }

        if (!Array.compatIsArray(result) && !__hasOwnProperty(result, 'data') && !__hasOwnProperty(result, 'errors')) {
          throwServerError(response, result, "Server response was missing for query '" + (Array.compatIsArray(operations) ? __callKey1$1(operations, "map", function (op) {
            return op._ES5ProxyType ? op.get("operationName") : op.operationName;
          }) : operations._ES5ProxyType ? operations.get("operationName") : operations.operationName) + "'.");
        }

        return result;
      });
    };
  };

  var checkFetcher = function checkFetcher(fetcher) {
    if (!fetcher && typeof fetch === 'undefined') {
      var library = 'unfetch';
      if (typeof window === 'undefined') library = 'node-fetch';
      throw  new InvariantError("\nfetch is not found globally and no fetcher passed, to fix pass a fetch for\nyour environment like https://www.npmjs.com/package/" + library + ".\n\nFor example:\nimport fetch from '" + library + "';\nimport { createHttpLink } from 'apollo-link-http';\n\nconst link = createHttpLink({ uri: '/graphql', fetch: fetch });");
    }
  };

  var createSignalIfSupported = function createSignalIfSupported() {
    if (typeof AbortController === 'undefined') return {
      controller: false,
      signal: false
    };
    var controller = new AbortController();
    var signal = controller._ES5ProxyType ? controller.get("signal") : controller.signal;
    return {
      controller: controller,
      signal: signal
    };
  };

  var selectHttpOptionsAndBody = function selectHttpOptionsAndBody(operation, fallbackConfig) {
    var configs = [];

    for (var _i = 2; _i < arguments.length; _i++) {
      __setKey(configs, _i - 2, arguments[_i]);
    }

    var options = _assign({}, fallbackConfig._ES5ProxyType ? fallbackConfig.get("options") : fallbackConfig.options, {
      headers: fallbackConfig._ES5ProxyType ? fallbackConfig.get("headers") : fallbackConfig.headers,
      credentials: fallbackConfig._ES5ProxyType ? fallbackConfig.get("credentials") : fallbackConfig.credentials
    });

    var http = fallbackConfig._ES5ProxyType ? fallbackConfig.get("http") : fallbackConfig.http;

    __callKey1$1(configs, "forEach", function (config) {
      options = _assign({}, options, config._ES5ProxyType ? config.get("options") : config.options, {
        headers: _assign({}, options._ES5ProxyType ? options.get("headers") : options.headers, config._ES5ProxyType ? config.get("headers") : config.headers)
      });
      if (config._ES5ProxyType ? config.get("credentials") : config.credentials) __setKey(options, "credentials", config._ES5ProxyType ? config.get("credentials") : config.credentials);
      http = _assign({}, http, config._ES5ProxyType ? config.get("http") : config.http);
    });

    var operationName = operation._ES5ProxyType ? operation.get("operationName") : operation.operationName,
        extensions = operation._ES5ProxyType ? operation.get("extensions") : operation.extensions,
        variables = operation._ES5ProxyType ? operation.get("variables") : operation.variables,
        query = operation._ES5ProxyType ? operation.get("query") : operation.query;
    var body = {
      operationName: operationName,
      variables: variables
    };
    if (http._ES5ProxyType ? http.get("includeExtensions") : http.includeExtensions) __setKey(body, "extensions", extensions);
    if (http._ES5ProxyType ? http.get("includeQuery") : http.includeQuery) __setKey(body, "query", print(query));
    return {
      options: options,
      body: body
    };
  };

  var serializeFetchParameter = function serializeFetchParameter(p, label) {
    var serialized;

    try {
      serialized = JSON.stringify(p);
    } catch (e) {
      var parseError =  new InvariantError("Network request failed. " + label + " is not serializable: " + (e._ES5ProxyType ? e.get("message") : e.message));

      __setKey(parseError, "parseError", e);

      throw parseError;
    }

    return serialized;
  };

  var selectURI = function selectURI(operation, fallbackURI) {
    var context = __callKey0(operation, "getContext");

    var contextURI = context._ES5ProxyType ? context.get("uri") : context.uri;

    if (contextURI) {
      return contextURI;
    } else if (typeof fallbackURI === 'function') {
      return fallbackURI(operation);
    } else {
      return fallbackURI || '/graphql';
    }
  };

  var createHttpLink = function createHttpLink(linkOptions) {
    if (linkOptions === void 0) {
      linkOptions = {};
    }

    var _a = linkOptions._ES5ProxyType ? linkOptions.get("uri") : linkOptions.uri,
        uri = _a === void 0 ? '/graphql' : _a,
        fetcher = linkOptions._ES5ProxyType ? linkOptions.get("fetch") : linkOptions.fetch,
        includeExtensions = linkOptions._ES5ProxyType ? linkOptions.get("includeExtensions") : linkOptions.includeExtensions,
        useGETForQueries = linkOptions._ES5ProxyType ? linkOptions.get("useGETForQueries") : linkOptions.useGETForQueries,
        requestOptions = __rest(linkOptions, ["uri", "fetch", "includeExtensions", "useGETForQueries"]);

    checkFetcher(fetcher);

    if (!fetcher) {
      fetcher = fetch;
    }

    var linkConfig = {
      http: {
        includeExtensions: includeExtensions
      },
      options: requestOptions._ES5ProxyType ? requestOptions.get("fetchOptions") : requestOptions.fetchOptions,
      credentials: requestOptions._ES5ProxyType ? requestOptions.get("credentials") : requestOptions.credentials,
      headers: requestOptions._ES5ProxyType ? requestOptions.get("headers") : requestOptions.headers
    };
    return new ApolloLink(function (operation) {
      var _query, _definitions;

      var chosenURI = selectURI(operation, uri);

      var context = __callKey0(operation, "getContext");

      var clientAwarenessHeaders = {};

      if (context._ES5ProxyType ? context.get("clientAwareness") : context.clientAwareness) {
        var _a = context._ES5ProxyType ? context.get("clientAwareness") : context.clientAwareness,
            name_1 = _a._ES5ProxyType ? _a.get("name") : _a.name,
            version = _a._ES5ProxyType ? _a.get("version") : _a.version;

        if (name_1) {
          __setKey(clientAwarenessHeaders, 'apollographql-client-name', name_1);
        }

        if (version) {
          __setKey(clientAwarenessHeaders, 'apollographql-client-version', version);
        }
      }

      var contextHeaders = _assign({}, clientAwarenessHeaders, context._ES5ProxyType ? context.get("headers") : context.headers);

      var contextConfig = {
        http: context._ES5ProxyType ? context.get("http") : context.http,
        options: context._ES5ProxyType ? context.get("fetchOptions") : context.fetchOptions,
        credentials: context._ES5ProxyType ? context.get("credentials") : context.credentials,
        headers: contextHeaders
      };

      var _b = selectHttpOptionsAndBody(operation, fallbackHttpConfig, linkConfig, contextConfig),
          options = _b._ES5ProxyType ? _b.get("options") : _b.options,
          body = _b._ES5ProxyType ? _b.get("body") : _b.body;

      var controller;

      if (!(options._ES5ProxyType ? options.get("signal") : options.signal)) {
        var _c = createSignalIfSupported(),
            _controller = _c._ES5ProxyType ? _c.get("controller") : _c.controller,
            signal = _c._ES5ProxyType ? _c.get("signal") : _c.signal;

        controller = _controller;
        if (controller) __setKey(options, "signal", signal);
      }

      var definitionIsMutation = function definitionIsMutation(d) {
        return (d._ES5ProxyType ? d.get("kind") : d.kind) === 'OperationDefinition' && (d._ES5ProxyType ? d.get("operation") : d.operation) === 'mutation';
      };

      if (useGETForQueries && !__callKey1$1((_query = operation._ES5ProxyType ? operation.get("query") : operation.query, _definitions = _query._ES5ProxyType ? _query.get("definitions") : _query.definitions), "some", definitionIsMutation)) {
        __setKey(options, "method", 'GET');
      }

      if ((options._ES5ProxyType ? options.get("method") : options.method) === 'GET') {
        var _d = rewriteURIForGET(chosenURI, body),
            newURI = _d._ES5ProxyType ? _d.get("newURI") : _d.newURI,
            parseError = _d._ES5ProxyType ? _d.get("parseError") : _d.parseError;

        if (parseError) {
          return fromError(parseError);
        }

        chosenURI = newURI;
      } else {
        try {
          __setKey(options, "body", serializeFetchParameter(body, 'Payload'));
        } catch (parseError) {
          return fromError(parseError);
        }
      }

      return new Observable$1(function (observer) {
        __callKey1$1(__callKey1$1(__callKey1$1(__callKey1$1(fetcher(chosenURI, options), "then", function (response) {
          __callKey1$1(operation, "setContext", {
            response: response
          });

          return response;
        }), "then", parseAndCheckHttpResponse(operation)), "then", function (result) {
          __callKey1$1(observer, "next", result);

          __callKey0(observer, "complete");

          return result;
        }), "catch", function (err) {
          var _result, _errors, _result2, _data;

          if ((err._ES5ProxyType ? err.get("name") : err.name) === 'AbortError') return;

          if ((err._ES5ProxyType ? err.get("result") : err.result) && (_result = err._ES5ProxyType ? err.get("result") : err.result, _errors = _result._ES5ProxyType ? _result.get("errors") : _result.errors) && (_result2 = err._ES5ProxyType ? err.get("result") : err.result, _data = _result2._ES5ProxyType ? _result2.get("data") : _result2.data)) {
            __callKey1$1(observer, "next", err._ES5ProxyType ? err.get("result") : err.result);
          }

          __callKey1$1(observer, "error", err);
        });

        return function () {
          if (controller) __callKey0(controller, "abort");
        };
      });
    });
  };

  function rewriteURIForGET(chosenURI, body) {
    var queryParams = [];

    var addQueryParam = function addQueryParam(key, value) {
      queryParams.push(key + "=" + encodeURIComponent(value));
    };

    if (__inKey$1(body, 'query')) {
      addQueryParam('query', body._ES5ProxyType ? body.get("query") : body.query);
    }

    if (body._ES5ProxyType ? body.get("operationName") : body.operationName) {
      addQueryParam('operationName', body._ES5ProxyType ? body.get("operationName") : body.operationName);
    }

    if (body._ES5ProxyType ? body.get("variables") : body.variables) {
      var serializedVariables = void 0;

      try {
        serializedVariables = serializeFetchParameter(body._ES5ProxyType ? body.get("variables") : body.variables, 'Variables map');
      } catch (parseError) {
        return {
          parseError: parseError
        };
      }

      addQueryParam('variables', serializedVariables);
    }

    if (body._ES5ProxyType ? body.get("extensions") : body.extensions) {
      var serializedExtensions = void 0;

      try {
        serializedExtensions = serializeFetchParameter(body._ES5ProxyType ? body.get("extensions") : body.extensions, 'Extensions map');
      } catch (parseError) {
        return {
          parseError: parseError
        };
      }

      addQueryParam('extensions', serializedExtensions);
    }

    var fragment = '',
        preFragment = chosenURI;

    var fragmentStart = __callKey1$1(chosenURI, "indexOf", '#');

    if (fragmentStart !== -1) {
      fragment = __callKey1$1(chosenURI, "substr", fragmentStart);
      preFragment = __callKey2(chosenURI, "substr", 0, fragmentStart);
    }

    var queryParamsPrefix = __callKey1$1(preFragment, "indexOf", '?') === -1 ? '?' : '&';
    var newURI = preFragment + queryParamsPrefix + __callKey1$1(queryParams, "join", '&') + fragment;
    return {
      newURI: newURI
    };
  }

  var HttpLink = function (_super) {
    __extends(HttpLink, _super);

    function HttpLink(opts) {
      var _createHttpLink, _request;

      return __callKey2(_super, "call", this, (_createHttpLink = createHttpLink(opts), _request = _createHttpLink._ES5ProxyType ? _createHttpLink.get("request") : _createHttpLink.request)) || this;
    }

    return HttpLink;
  }(ApolloLink);

  function devAssert(condition, message) {
    var booleanCondition = Boolean(condition); // istanbul ignore else (See transformation done in './resources/inlineInvariant.js')

    if (!booleanCondition) {
      throw new Error(message);
    }
  }

  function _typeof$1(obj) {
    "@babel/helpers - typeof";

    if (typeof Symbol === "function" && _typeof_1(Symbol.iterator) === "symbol") {
      _typeof$1 = function _typeof(obj) {
        return _typeof_1(obj);
      };
    } else {
      _typeof$1 = function _typeof(obj) {
        return obj && typeof Symbol === "function" && (obj._ES5ProxyType ? obj.get("constructor") : obj.constructor) === Symbol && obj !== Symbol.prototype ? "symbol" : _typeof_1(obj);
      };
    }

    return _typeof$1(obj);
  }
  /**
   * Return true if `value` is object-like. A value is object-like if it's not
   * `null` and has a `typeof` result of "object".
   */


  function isObjectLike(value) {
    return _typeof$1(value) == 'object' && value !== null;
  }

  // In ES2015 (or a polyfilled) environment, this will be Symbol.iterator

  var SYMBOL_TO_STRING_TAG = // $FlowFixMe Flow doesn't define `Symbol.toStringTag` yet
  typeof Symbol === 'function' ? Symbol.toStringTag : '@@toStringTag';

  /**
   * Represents a location in a Source.
   */

  /**
   * Takes a Source and a UTF-8 character offset, and returns the corresponding
   * line and column as a SourceLocation.
   */
  function getLocation(source, position) {
    var lineRegexp = /\r\n|[\n\r]/g;
    var line = 1;
    var column = position + 1;
    var match;

    while ((match = __callKey1$1(lineRegexp, "exec", source._ES5ProxyType ? source.get("body") : source.body)) && (match._ES5ProxyType ? match.get("index") : match.index) < position) {
      var _, _length;

      line += 1;
      column = position + 1 - ((match._ES5ProxyType ? match.get("index") : match.index) + (_ = match._ES5ProxyType ? match.get(0) : match[0], _length = _._ES5ProxyType ? _.get("length") : _.length));
    }

    return {
      line: line,
      column: column
    };
  }

  /**
   * Render a helpful description of the location in the GraphQL Source document.
   */

  function printLocation(location) {
    return printSourceLocation(location._ES5ProxyType ? location.get("source") : location.source, getLocation(location._ES5ProxyType ? location.get("source") : location.source, location._ES5ProxyType ? location.get("start") : location.start));
  }
  /**
   * Render a helpful description of the location in the GraphQL Source document.
   */

  function printSourceLocation(source, sourceLocation) {
    var _locationOffset, _column, _locationOffset2, _line, _ref6, _ref7, _ref8, _ref9;

    var firstLineColumnOffset = (_locationOffset = source._ES5ProxyType ? source.get("locationOffset") : source.locationOffset, _column = _locationOffset._ES5ProxyType ? _locationOffset.get("column") : _locationOffset.column) - 1;
    var body = whitespace(firstLineColumnOffset) + (source._ES5ProxyType ? source.get("body") : source.body);
    var lineIndex = (sourceLocation._ES5ProxyType ? sourceLocation.get("line") : sourceLocation.line) - 1;
    var lineOffset = (_locationOffset2 = source._ES5ProxyType ? source.get("locationOffset") : source.locationOffset, _line = _locationOffset2._ES5ProxyType ? _locationOffset2.get("line") : _locationOffset2.line) - 1;
    var lineNum = (sourceLocation._ES5ProxyType ? sourceLocation.get("line") : sourceLocation.line) + lineOffset;
    var columnOffset = (sourceLocation._ES5ProxyType ? sourceLocation.get("line") : sourceLocation.line) === 1 ? firstLineColumnOffset : 0;
    var columnNum = (sourceLocation._ES5ProxyType ? sourceLocation.get("column") : sourceLocation.column) + columnOffset;

    var locationStr = __concat(__concat(__concat("", source._ES5ProxyType ? source.get("name") : source.name, ":"), lineNum, ":"), columnNum, "\n");

    var lines = __callKey1$1(body, "split", /\r\n|[\n\r]/g);

    var locationLine = lines._ES5ProxyType ? lines.get(lineIndex) : lines[lineIndex]; // Special case for minified documents

    if ((locationLine._ES5ProxyType ? locationLine.get("length") : locationLine.length) > 120) {
      var _ref4, _ref5;

      var subLineIndex = Math.floor(columnNum / 80);
      var subLineColumnNum = columnNum % 80;
      var subLines = [];

      for (var i = 0; i < (locationLine._ES5ProxyType ? locationLine.get("length") : locationLine.length); i += 80) {
        subLines.push(__callKey2(locationLine, "slice", i, i + 80));
      }

      return locationStr + printPrefixedLines(__concat([[__concat("", lineNum), subLines._ES5ProxyType ? subLines.get(0) : subLines[0]]], __callKey1$1(__callKey2(subLines, "slice", 1, subLineIndex + 1), "map", function (subLine) {
        return ['', subLine];
      }), [[' ', whitespace(subLineColumnNum - 1) + '^'], ['', (_ref4 = subLineIndex + 1, _ref5 = subLines._ES5ProxyType ? subLines.get(_ref4) : subLines[_ref4])]]));
    }

    return locationStr + printPrefixedLines([// Lines specified like this: ["prefix", "string"],
    [__concat("", lineNum - 1), (_ref6 = lineIndex - 1, _ref7 = lines._ES5ProxyType ? lines.get(_ref6) : lines[_ref6])], [__concat("", lineNum), locationLine], ['', whitespace(columnNum - 1) + '^'], [__concat("", lineNum + 1), (_ref8 = lineIndex + 1, _ref9 = lines._ES5ProxyType ? lines.get(_ref8) : lines[_ref8])]]);
  }

  function printPrefixedLines(lines) {
    var existingLines = __callKey1$1(lines, "filter", function (_ref) {
      var _ = _ref._ES5ProxyType ? _ref.get(0) : _ref[0],
          line = _ref._ES5ProxyType ? _ref.get(1) : _ref[1];

      return line !== undefined;
    });

    var padLen = __callKey2(Math.max, "apply", Math, __callKey1$1(existingLines, "map", function (_ref2) {
      var prefix = _ref2._ES5ProxyType ? _ref2.get(0) : _ref2[0];
      return prefix._ES5ProxyType ? prefix.get("length") : prefix.length;
    }));

    return __callKey1$1(__callKey1$1(existingLines, "map", function (_ref3) {
      var prefix = _ref3._ES5ProxyType ? _ref3.get(0) : _ref3[0],
          line = _ref3._ES5ProxyType ? _ref3.get(1) : _ref3[1];
      return leftPad(padLen, prefix) + (line ? ' | ' + line : ' |');
    }), "join", '\n');
  }

  function whitespace(len) {
    return __callKey1$1(Array(len + 1), "join", ' ');
  }

  function leftPad(len, str) {
    return whitespace(len - (str._ES5ProxyType ? str.get("length") : str.length)) + str;
  }

  function _typeof$2(obj) {
    "@babel/helpers - typeof";

    if (typeof Symbol === "function" && _typeof_1(Symbol.iterator) === "symbol") {
      _typeof$2 = function _typeof(obj) {
        return _typeof_1(obj);
      };
    } else {
      _typeof$2 = function _typeof(obj) {
        return obj && typeof Symbol === "function" && (obj._ES5ProxyType ? obj.get("constructor") : obj.constructor) === Symbol && obj !== Symbol.prototype ? "symbol" : _typeof_1(obj);
      };
    }

    return _typeof$2(obj);
  }

  function _classCallCheck$1(instance, Constructor) {
    if (!_instanceof_1(instance, Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties$1(target, props) {
    for (var i = 0; i < (props._ES5ProxyType ? props.get("length") : props.length); i++) {
      var descriptor = props._ES5ProxyType ? props.get(i) : props[i];

      __setKey(descriptor, "enumerable", (descriptor._ES5ProxyType ? descriptor.get("enumerable") : descriptor.enumerable) || false);

      __setKey(descriptor, "configurable", true);

      if (__inKey$1(descriptor, "value")) __setKey(descriptor, "writable", true);
      Object.compatDefineProperty(target, descriptor._ES5ProxyType ? descriptor.get("key") : descriptor.key, descriptor);
    }
  }

  function _createClass$1(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties$1(Constructor._ES5ProxyType ? Constructor.get("prototype") : Constructor.prototype, protoProps);
    if (staticProps) _defineProperties$1(Constructor, staticProps);
    return Constructor;
  }

  function _inherits$1(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    __setKey(subClass, "prototype", Object.create(superClass && (superClass._ES5ProxyType ? superClass.get("prototype") : superClass.prototype), {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    }));

    if (superClass) _setPrototypeOf(subClass, superClass);
  }

  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();

    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
          result;

      if (hasNativeReflectConstruct) {
        var _getPrototypeOf2, _constructor;

        var NewTarget = (_getPrototypeOf2 = _getPrototypeOf(this), _constructor = _getPrototypeOf2._ES5ProxyType ? _getPrototypeOf2.get("constructor") : _getPrototypeOf2.constructor);
        result = __callKey3(Reflect, "construct", Super, arguments, NewTarget);
      } else {
        result = __callKey2(Super, "apply", this, arguments);
      }

      return _possibleConstructorReturn$1(this, result);
    };
  }

  function _possibleConstructorReturn$1(self, call) {
    if (call && (_typeof$2(call) === "object" || typeof call === "function")) {
      return call;
    }

    return _assertThisInitialized$1(self);
  }

  function _assertThisInitialized$1(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  function _wrapNativeSuper(Class) {
    var _cache = typeof Map === "function" ? new Map() : undefined;

    _wrapNativeSuper = function _wrapNativeSuper(Class) {
      if (Class === null || !_isNativeFunction(Class)) return Class;

      if (typeof Class !== "function") {
        throw new TypeError("Super expression must either be null or a function");
      }

      if (typeof _cache !== "undefined") {
        if (__callKey1$1(_cache, "has", Class)) return __callKey1$1(_cache, "get", Class);

        __callKey2(_cache, "set", Class, Wrapper);
      }

      function Wrapper() {
        var _getPrototypeOf3, _constructor2;

        return _construct(Class, arguments, (_getPrototypeOf3 = _getPrototypeOf(this), _constructor2 = _getPrototypeOf3._ES5ProxyType ? _getPrototypeOf3.get("constructor") : _getPrototypeOf3.constructor));
      }

      __setKey(Wrapper, "prototype", Object.create(Class._ES5ProxyType ? Class.get("prototype") : Class.prototype, {
        constructor: {
          value: Wrapper,
          enumerable: false,
          writable: true,
          configurable: true
        }
      }));

      return _setPrototypeOf(Wrapper, Class);
    };

    return _wrapNativeSuper(Class);
  }

  function _construct(Parent, args, Class) {
    if (_isNativeReflectConstruct()) {
      _construct = Reflect._ES5ProxyType ? Reflect.get("construct") : Reflect.construct;
    } else {
      _construct = function _construct(Parent, args, Class) {
        var a = [null];

        __callKey2(a.push, "apply", a, args);

        var Constructor = __callKey2(Function.bind, "apply", Parent, a);

        var instance = new Constructor();
        if (Class) _setPrototypeOf(instance, Class._ES5ProxyType ? Class.get("prototype") : Class.prototype);
        return instance;
      };
    }

    return __callKey2(_construct, "apply", null, arguments);
  }

  function _isNativeReflectConstruct() {
    var _construct2, _sham;

    if (typeof Reflect === "undefined" || !(Reflect._ES5ProxyType ? Reflect.get("construct") : Reflect.construct)) return false;
    if (_construct2 = Reflect._ES5ProxyType ? Reflect.get("construct") : Reflect.construct, _sham = _construct2._ES5ProxyType ? _construct2.get("sham") : _construct2.sham) return false;
    if (typeof Proxy === "function") return true;

    try {
      __callKey1$1(Date.prototype._ES5ProxyType ? Date.prototype.get("toString") : Date.prototype.toString, "call", __callKey3(Reflect, "construct", Date, [], function () {}));

      return true;
    } catch (e) {
      return false;
    }
  }

  function _isNativeFunction(fn) {
    return __callKey1$1(__callKey1$1(Function.toString, "call", fn), "indexOf", "[native code]") !== -1;
  }

  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
      __setKey(o, "__proto__", p);

      return o;
    };

    return _setPrototypeOf(o, p);
  }

  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
      return (o._ES5ProxyType ? o.get("__proto__") : o.__proto__) || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  } // FIXME:
  /**
   * A GraphQLError describes an Error found during the parse, validate, or
   * execute phases of performing a GraphQL operation. In addition to a message
   * and stack trace, it also includes information about the locations in a
   * GraphQL document and/or execution result that correspond to the Error.
   */

  var GraphQLError =
  /*#__PURE__*/
  function (_Error) {
    _inherits$1(GraphQLError, _Error);

    var _super = _createSuper(GraphQLError);
    /**
     * A message describing the Error for debugging purposes.
     *
     * Enumerable, and appears in the result of JSON.stringify().
     *
     * Note: should be treated as readonly, despite invariant usage.
     */

    /**
     * An array of { line, column } locations within the source GraphQL document
     * which correspond to this error.
     *
     * Errors during validation often contain multiple locations, for example to
     * point out two things with the same name. Errors during execution include a
     * single location, the field which produced the error.
     *
     * Enumerable, and appears in the result of JSON.stringify().
     */

    /**
     * An array describing the JSON-path into the execution response which
     * corresponds to this error. Only included for errors during execution.
     *
     * Enumerable, and appears in the result of JSON.stringify().
     */

    /**
     * An array of GraphQL AST Nodes corresponding to this error.
     */

    /**
     * The source GraphQL document for the first location of this error.
     *
     * Note that if this Error represents more than one node, the source may not
     * represent nodes after the first node.
     */

    /**
     * An array of character offsets within the source GraphQL document
     * which correspond to this error.
     */

    /**
     * The original error thrown from a field resolver during execution.
     */

    /**
     * Extension fields to add to the formatted error.
     */


    function GraphQLError(message, nodes, source, positions, path, originalError, extensions) {
      var _locations2, _source2, _positions2, _extensions2;

      var _this;

      _classCallCheck$1(this, GraphQLError);

      _this = __callKey2(_super, "call", this, message); // Compute list of blame nodes.

      var _nodes = Array.compatIsArray(nodes) ? (nodes._ES5ProxyType ? nodes.get("length") : nodes.length) !== 0 ? nodes : undefined : nodes ? [nodes] : undefined; // Compute locations in the source for the given nodes/positions.


      var _source = source;

      if (!_source && _nodes) {
        var _, _loc;

        var _nodes$0$loc;

        _source = (_nodes$0$loc = (_ = _nodes._ES5ProxyType ? _nodes.get(0) : _nodes[0], _loc = _._ES5ProxyType ? _.get("loc") : _.loc)) === null || _nodes$0$loc === void 0 ? void 0 : _nodes$0$loc._ES5ProxyType ? _nodes$0$loc.get("source") : _nodes$0$loc.source;
      }

      var _positions = positions;

      if (!_positions && _nodes) {
        _positions = __callKey2(_nodes, "reduce", function (list, node) {
          if (node._ES5ProxyType ? node.get("loc") : node.loc) {
            var _loc2, _start;

            list.push((_loc2 = node._ES5ProxyType ? node.get("loc") : node.loc, _start = _loc2._ES5ProxyType ? _loc2.get("start") : _loc2.start));
          }

          return list;
        }, []);
      }

      if (_positions && (_positions._ES5ProxyType ? _positions.get("length") : _positions.length) === 0) {
        _positions = undefined;
      }

      var _locations;

      if (positions && source) {
        _locations = __callKey1$1(positions, "map", function (pos) {
          return getLocation(source, pos);
        });
      } else if (_nodes) {
        _locations = __callKey2(_nodes, "reduce", function (list, node) {
          if (node._ES5ProxyType ? node.get("loc") : node.loc) {
            var _loc3, _source3, _loc4, _start2;

            list.push(getLocation((_loc3 = node._ES5ProxyType ? node.get("loc") : node.loc, _source3 = _loc3._ES5ProxyType ? _loc3.get("source") : _loc3.source), (_loc4 = node._ES5ProxyType ? node.get("loc") : node.loc, _start2 = _loc4._ES5ProxyType ? _loc4.get("start") : _loc4.start)));
          }

          return list;
        }, []);
      }

      var _extensions = extensions;

      if (_extensions == null && originalError != null) {
        var originalExtensions = originalError._ES5ProxyType ? originalError.get("extensions") : originalError.extensions;

        if (isObjectLike(originalExtensions)) {
          _extensions = originalExtensions;
        }
      }

      Object.defineProperties(_assertThisInitialized$1(_this), {
        name: {
          value: 'GraphQLError'
        },
        message: {
          value: message,
          // By being enumerable, JSON.stringify will include `message` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: true,
          writable: true
        },
        locations: {
          // Coercing falsy values to undefined ensures they will not be included
          // in JSON.stringify() when not provided.
          value: (_locations2 = _locations) !== null && _locations2 !== void 0 ? _locations2 : undefined,
          // By being enumerable, JSON.stringify will include `locations` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: _locations != null
        },
        path: {
          // Coercing falsy values to undefined ensures they will not be included
          // in JSON.stringify() when not provided.
          value: path !== null && path !== void 0 ? path : undefined,
          // By being enumerable, JSON.stringify will include `path` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: path != null
        },
        nodes: {
          value: _nodes !== null && _nodes !== void 0 ? _nodes : undefined
        },
        source: {
          value: (_source2 = _source) !== null && _source2 !== void 0 ? _source2 : undefined
        },
        positions: {
          value: (_positions2 = _positions) !== null && _positions2 !== void 0 ? _positions2 : undefined
        },
        originalError: {
          value: originalError
        },
        extensions: {
          // Coercing falsy values to undefined ensures they will not be included
          // in JSON.stringify() when not provided.
          value: (_extensions2 = _extensions) !== null && _extensions2 !== void 0 ? _extensions2 : undefined,
          // By being enumerable, JSON.stringify will include `path` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: _extensions != null
        }
      }); // Include (non-enumerable) stack trace.

      if (originalError === null || originalError === void 0 ? void 0 : originalError._ES5ProxyType ? originalError.get("stack") : originalError.stack) {
        Object.compatDefineProperty(_assertThisInitialized$1(_this), 'stack', {
          value: originalError._ES5ProxyType ? originalError.get("stack") : originalError.stack,
          writable: true,
          configurable: true
        });
        return _possibleConstructorReturn$1(_this);
      } // istanbul ignore next (See: 'https://github.com/graphql/graphql-js/issues/2317')


      if (Error._ES5ProxyType ? Error.get("captureStackTrace") : Error.captureStackTrace) {
        __callKey2(Error, "captureStackTrace", _assertThisInitialized$1(_this), GraphQLError);
      } else {
        var _Error2, _stack;

        Object.compatDefineProperty(_assertThisInitialized$1(_this), 'stack', {
          value: (_Error2 = Error(), _stack = _Error2._ES5ProxyType ? _Error2.get("stack") : _Error2.stack),
          writable: true,
          configurable: true
        });
      }

      return _this;
    }

    _createClass$1(GraphQLError, [{
      key: "toString",
      value: function toString() {
        return printError(this);
      } // FIXME: workaround to not break chai comparisons, should be remove in v16
      // $FlowFixMe Flow doesn't support computed properties yet

    }, {
      key: SYMBOL_TO_STRING_TAG,
      get: function get() {
        return 'Object';
      }
    }]);

    return GraphQLError;
  }(
  /*#__PURE__*/
  _wrapNativeSuper(Error));
  /**
   * Prints a GraphQLError to a string, representing useful location information
   * about the error's position in the source.
   */

  function printError(error) {
    var output = error._ES5ProxyType ? error.get("message") : error.message;

    if (error._ES5ProxyType ? error.get("nodes") : error.nodes) {
      for (var _i2 = 0, _error$nodes2 = error._ES5ProxyType ? error.get("nodes") : error.nodes; _i2 < (_error$nodes2._ES5ProxyType ? _error$nodes2.get("length") : _error$nodes2.length); _i2++) {
        var node = _error$nodes2._ES5ProxyType ? _error$nodes2.get(_i2) : _error$nodes2[_i2];

        if (node._ES5ProxyType ? node.get("loc") : node.loc) {
          output += '\n\n' + printLocation(node._ES5ProxyType ? node.get("loc") : node.loc);
        }
      }
    } else if ((error._ES5ProxyType ? error.get("source") : error.source) && (error._ES5ProxyType ? error.get("locations") : error.locations)) {
      for (var _i4 = 0, _error$locations2 = error._ES5ProxyType ? error.get("locations") : error.locations; _i4 < (_error$locations2._ES5ProxyType ? _error$locations2.get("length") : _error$locations2.length); _i4++) {
        var location = _error$locations2._ES5ProxyType ? _error$locations2.get(_i4) : _error$locations2[_i4];
        output += '\n\n' + printSourceLocation(error._ES5ProxyType ? error.get("source") : error.source, location);
      }
    }

    return output;
  }

  /**
   * Produces a GraphQLError representing a syntax error, containing useful
   * descriptive information about the syntax error's position in the source.
   */

  function syntaxError(source, position, description) {
    return new GraphQLError(__concat("Syntax Error: ", description), undefined, source, [position]);
  }

  /**
   * The set of allowed kind values for AST nodes.
   */
  var Kind = Object.freeze({
    // Name
    NAME: 'Name',
    // Document
    DOCUMENT: 'Document',
    OPERATION_DEFINITION: 'OperationDefinition',
    VARIABLE_DEFINITION: 'VariableDefinition',
    SELECTION_SET: 'SelectionSet',
    FIELD: 'Field',
    ARGUMENT: 'Argument',
    // Fragments
    FRAGMENT_SPREAD: 'FragmentSpread',
    INLINE_FRAGMENT: 'InlineFragment',
    FRAGMENT_DEFINITION: 'FragmentDefinition',
    // Values
    VARIABLE: 'Variable',
    INT: 'IntValue',
    FLOAT: 'FloatValue',
    STRING: 'StringValue',
    BOOLEAN: 'BooleanValue',
    NULL: 'NullValue',
    ENUM: 'EnumValue',
    LIST: 'ListValue',
    OBJECT: 'ObjectValue',
    OBJECT_FIELD: 'ObjectField',
    // Directives
    DIRECTIVE: 'Directive',
    // Types
    NAMED_TYPE: 'NamedType',
    LIST_TYPE: 'ListType',
    NON_NULL_TYPE: 'NonNullType',
    // Type System Definitions
    SCHEMA_DEFINITION: 'SchemaDefinition',
    OPERATION_TYPE_DEFINITION: 'OperationTypeDefinition',
    // Type Definitions
    SCALAR_TYPE_DEFINITION: 'ScalarTypeDefinition',
    OBJECT_TYPE_DEFINITION: 'ObjectTypeDefinition',
    FIELD_DEFINITION: 'FieldDefinition',
    INPUT_VALUE_DEFINITION: 'InputValueDefinition',
    INTERFACE_TYPE_DEFINITION: 'InterfaceTypeDefinition',
    UNION_TYPE_DEFINITION: 'UnionTypeDefinition',
    ENUM_TYPE_DEFINITION: 'EnumTypeDefinition',
    ENUM_VALUE_DEFINITION: 'EnumValueDefinition',
    INPUT_OBJECT_TYPE_DEFINITION: 'InputObjectTypeDefinition',
    // Directive Definitions
    DIRECTIVE_DEFINITION: 'DirectiveDefinition',
    // Type System Extensions
    SCHEMA_EXTENSION: 'SchemaExtension',
    // Type Extensions
    SCALAR_TYPE_EXTENSION: 'ScalarTypeExtension',
    OBJECT_TYPE_EXTENSION: 'ObjectTypeExtension',
    INTERFACE_TYPE_EXTENSION: 'InterfaceTypeExtension',
    UNION_TYPE_EXTENSION: 'UnionTypeExtension',
    ENUM_TYPE_EXTENSION: 'EnumTypeExtension',
    INPUT_OBJECT_TYPE_EXTENSION: 'InputObjectTypeExtension'
  });
  /**
   * The enum type representing the possible kind values of AST nodes.
   */

  function _defineProperties$2(target, props) {
    for (var i = 0; i < (props._ES5ProxyType ? props.get("length") : props.length); i++) {
      var descriptor = props._ES5ProxyType ? props.get(i) : props[i];

      __setKey(descriptor, "enumerable", (descriptor._ES5ProxyType ? descriptor.get("enumerable") : descriptor.enumerable) || false);

      __setKey(descriptor, "configurable", true);

      if (__inKey$1(descriptor, "value")) __setKey(descriptor, "writable", true);
      Object.compatDefineProperty(target, descriptor._ES5ProxyType ? descriptor.get("key") : descriptor.key, descriptor);
    }
  }

  function _createClass$2(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties$2(Constructor._ES5ProxyType ? Constructor.get("prototype") : Constructor.prototype, protoProps);
    if (staticProps) _defineProperties$2(Constructor, staticProps);
    return Constructor;
  }
  /**
   * A representation of source input to GraphQL.
   * `name` and `locationOffset` are optional. They are useful for clients who
   * store GraphQL documents in source files; for example, if the GraphQL input
   * starts at line 40 in a file named Foo.graphql, it might be useful for name to
   * be "Foo.graphql" and location to be `{ line: 40, column: 0 }`.
   * line and column in locationOffset are 1-indexed
   */

  var Source =
  /*#__PURE__*/
  function () {
    function Source(body) {
      var _locationOffset, _line, _locationOffset2, _column;

      var name = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'GraphQL request';
      var locationOffset = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
        line: 1,
        column: 1
      };

      __setKey(this, "body", body);

      __setKey(this, "name", name);

      __setKey(this, "locationOffset", locationOffset);

      (_locationOffset = this._ES5ProxyType ? this.get("locationOffset") : this.locationOffset, _line = _locationOffset._ES5ProxyType ? _locationOffset.get("line") : _locationOffset.line) > 0 || devAssert(0, 'line in locationOffset is 1-indexed and must be positive.');
      (_locationOffset2 = this._ES5ProxyType ? this.get("locationOffset") : this.locationOffset, _column = _locationOffset2._ES5ProxyType ? _locationOffset2.get("column") : _locationOffset2.column) > 0 || devAssert(0, 'column in locationOffset is 1-indexed and must be positive.');
    } // $FlowFixMe Flow doesn't support computed properties yet


    _createClass$2(Source, [{
      key: SYMBOL_TO_STRING_TAG,
      get: function get() {
        return 'Source';
      }
    }]);

    return Source;
  }();

  /**
   * The set of allowed directive location values.
   */
  var DirectiveLocation = Object.freeze({
    // Request Definitions
    QUERY: 'QUERY',
    MUTATION: 'MUTATION',
    SUBSCRIPTION: 'SUBSCRIPTION',
    FIELD: 'FIELD',
    FRAGMENT_DEFINITION: 'FRAGMENT_DEFINITION',
    FRAGMENT_SPREAD: 'FRAGMENT_SPREAD',
    INLINE_FRAGMENT: 'INLINE_FRAGMENT',
    VARIABLE_DEFINITION: 'VARIABLE_DEFINITION',
    // Type System Definitions
    SCHEMA: 'SCHEMA',
    SCALAR: 'SCALAR',
    OBJECT: 'OBJECT',
    FIELD_DEFINITION: 'FIELD_DEFINITION',
    ARGUMENT_DEFINITION: 'ARGUMENT_DEFINITION',
    INTERFACE: 'INTERFACE',
    UNION: 'UNION',
    ENUM: 'ENUM',
    ENUM_VALUE: 'ENUM_VALUE',
    INPUT_OBJECT: 'INPUT_OBJECT',
    INPUT_FIELD_DEFINITION: 'INPUT_FIELD_DEFINITION'
  });
  /**
   * The enum type representing the directive location values.
   */

  /**
   * An exported enum describing the different kinds of tokens that the
   * lexer emits.
   */
  var TokenKind = Object.freeze({
    SOF: '<SOF>',
    EOF: '<EOF>',
    BANG: '!',
    DOLLAR: '$',
    AMP: '&',
    PAREN_L: '(',
    PAREN_R: ')',
    SPREAD: '...',
    COLON: ':',
    EQUALS: '=',
    AT: '@',
    BRACKET_L: '[',
    BRACKET_R: ']',
    BRACE_L: '{',
    PIPE: '|',
    BRACE_R: '}',
    NAME: 'Name',
    INT: 'Int',
    FLOAT: 'Float',
    STRING: 'String',
    BLOCK_STRING: 'BlockString',
    COMMENT: 'Comment'
  });
  /**
   * The enum type representing the token kinds values.
   */

  /**
   * Given a Source object, creates a Lexer for that source.
   * A Lexer is a stateful stream generator in that every time
   * it is advanced, it returns the next token in the Source. Assuming the
   * source lexes, the final Token emitted by the lexer will be of kind
   * EOF, after which the lexer will repeatedly return the same EOF token
   * whenever called.
   */

  var Lexer =
  /*#__PURE__*/
  function () {
    /**
     * The previously focused non-ignored token.
     */

    /**
     * The currently focused non-ignored token.
     */

    /**
     * The (1-indexed) line containing the current token.
     */

    /**
     * The character offset at which the current line begins.
     */
    function Lexer(source) {
      var startOfFileToken = new Token(TokenKind._ES5ProxyType ? TokenKind.get("SOF") : TokenKind.SOF, 0, 0, 0, 0, null);

      __setKey(this, "source", source);

      __setKey(this, "lastToken", startOfFileToken);

      __setKey(this, "token", startOfFileToken);

      __setKey(this, "line", 1);

      __setKey(this, "lineStart", 0);
    }
    /**
     * Advances the token stream to the next non-ignored token.
     */


    var _proto = Lexer._ES5ProxyType ? Lexer.get("prototype") : Lexer.prototype;

    __setKey(_proto, "advance", function advance() {
      __setKey(this, "lastToken", this._ES5ProxyType ? this.get("token") : this.token);

      var token = __setKey(this, "token", __callKey0(this, "lookahead"));

      return token;
    })
    /**
     * Looks ahead and returns the next non-ignored token, but does not change
     * the state of Lexer.
     */
    ;

    __setKey(_proto, "lookahead", function lookahead() {
      var token = this._ES5ProxyType ? this.get("token") : this.token;

      if ((token._ES5ProxyType ? token.get("kind") : token.kind) !== (TokenKind._ES5ProxyType ? TokenKind.get("EOF") : TokenKind.EOF)) {
        do {
          var _token$next; // Note: next is only mutable during parsing, so we cast to allow this.


          token = (_token$next = token._ES5ProxyType ? token.get("next") : token.next) !== null && _token$next !== void 0 ? _token$next : __setKey(token, "next", readToken(this, token));
        } while ((token._ES5ProxyType ? token.get("kind") : token.kind) === (TokenKind._ES5ProxyType ? TokenKind.get("COMMENT") : TokenKind.COMMENT));
      }

      return token;
    });

    return Lexer;
  }();
  /**
   * @internal
   */

  function isPunctuatorTokenKind(kind) {
    return kind === (TokenKind._ES5ProxyType ? TokenKind.get("BANG") : TokenKind.BANG) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("DOLLAR") : TokenKind.DOLLAR) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("AMP") : TokenKind.AMP) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("PAREN_L") : TokenKind.PAREN_L) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("PAREN_R") : TokenKind.PAREN_R) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("SPREAD") : TokenKind.SPREAD) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("EQUALS") : TokenKind.EQUALS) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("AT") : TokenKind.AT) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_L") : TokenKind.BRACKET_L) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_R") : TokenKind.BRACKET_R) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("PIPE") : TokenKind.PIPE) || kind === (TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R);
  }

  function printCharCode(code) {
    return (// NaN/undefined represents access beyond the end of the file.
      isNaN(code) ? TokenKind._ES5ProxyType ? TokenKind.get("EOF") : TokenKind.EOF : // Trust JSON for ASCII.
      code < 0x007f ? JSON.stringify(String.fromCharCode(code)) : // Otherwise print the escaped form.
      __concat("\"\\u", __callKey1$1('00' + __callKey0(__callKey1$1(code, "toString", 16), "toUpperCase"), "slice", -4), "\"")
    );
  }
  /**
   * Gets the next token from the source starting at the given position.
   *
   * This skips over whitespace until it finds the next lexable token, then lexes
   * punctuators immediately or calls the appropriate helper function for more
   * complicated tokens.
   */


  function readToken(lexer, prev) {
    var source = lexer._ES5ProxyType ? lexer.get("source") : lexer.source;
    var body = source._ES5ProxyType ? source.get("body") : source.body;
    var bodyLength = body._ES5ProxyType ? body.get("length") : body.length;
    var pos = positionAfterWhitespace(body, prev._ES5ProxyType ? prev.get("end") : prev.end, lexer);
    var line = lexer._ES5ProxyType ? lexer.get("line") : lexer.line;
    var col = 1 + pos - (lexer._ES5ProxyType ? lexer.get("lineStart") : lexer.lineStart);

    if (pos >= bodyLength) {
      return new Token(TokenKind._ES5ProxyType ? TokenKind.get("EOF") : TokenKind.EOF, bodyLength, bodyLength, line, col, prev);
    }

    var code = __callKey1$1(body, "charCodeAt", pos); // SourceCharacter


    switch (code) {
      // !
      case 33:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("BANG") : TokenKind.BANG, pos, pos + 1, line, col, prev);
      // #

      case 35:
        return readComment(source, pos, line, col, prev);
      // $

      case 36:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("DOLLAR") : TokenKind.DOLLAR, pos, pos + 1, line, col, prev);
      // &

      case 38:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("AMP") : TokenKind.AMP, pos, pos + 1, line, col, prev);
      // (

      case 40:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("PAREN_L") : TokenKind.PAREN_L, pos, pos + 1, line, col, prev);
      // )

      case 41:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("PAREN_R") : TokenKind.PAREN_R, pos, pos + 1, line, col, prev);
      // .

      case 46:
        if (__callKey1$1(body, "charCodeAt", pos + 1) === 46 && __callKey1$1(body, "charCodeAt", pos + 2) === 46) {
          return new Token(TokenKind._ES5ProxyType ? TokenKind.get("SPREAD") : TokenKind.SPREAD, pos, pos + 3, line, col, prev);
        }

        break;
      // :

      case 58:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON, pos, pos + 1, line, col, prev);
      // =

      case 61:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("EQUALS") : TokenKind.EQUALS, pos, pos + 1, line, col, prev);
      // @

      case 64:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("AT") : TokenKind.AT, pos, pos + 1, line, col, prev);
      // [

      case 91:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_L") : TokenKind.BRACKET_L, pos, pos + 1, line, col, prev);
      // ]

      case 93:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_R") : TokenKind.BRACKET_R, pos, pos + 1, line, col, prev);
      // {

      case 123:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, pos, pos + 1, line, col, prev);
      // |

      case 124:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("PIPE") : TokenKind.PIPE, pos, pos + 1, line, col, prev);
      // }

      case 125:
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R, pos, pos + 1, line, col, prev);
      // A-Z _ a-z

      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 78:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 86:
      case 87:
      case 88:
      case 89:
      case 90:
      case 95:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 102:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 110:
      case 111:
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 118:
      case 119:
      case 120:
      case 121:
      case 122:
        return readName(source, pos, line, col, prev);
      // - 0-9

      case 45:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
        return readNumber(source, pos, code, line, col, prev);
      // "

      case 34:
        if (__callKey1$1(body, "charCodeAt", pos + 1) === 34 && __callKey1$1(body, "charCodeAt", pos + 2) === 34) {
          return readBlockString(source, pos, line, col, prev, lexer);
        }

        return readString(source, pos, line, col, prev);
    }

    throw syntaxError(source, pos, unexpectedCharacterMessage(code));
  }
  /**
   * Report a message that an unexpected character was encountered.
   */


  function unexpectedCharacterMessage(code) {
    if (code < 0x0020 && code !== 0x0009 && code !== 0x000a && code !== 0x000d) {
      return __concat("Cannot contain the invalid character ", printCharCode(code), ".");
    }

    if (code === 39) {
      // '
      return 'Unexpected single quote character (\'), did you mean to use a double quote (")?';
    }

    return __concat("Cannot parse the unexpected character ", printCharCode(code), ".");
  }
  /**
   * Reads from body starting at startPosition until it finds a non-whitespace
   * character, then returns the position of that character for lexing.
   */


  function positionAfterWhitespace(body, startPosition, lexer) {
    var bodyLength = body._ES5ProxyType ? body.get("length") : body.length;
    var position = startPosition;

    while (position < bodyLength) {
      var code = __callKey1$1(body, "charCodeAt", position); // tab | space | comma | BOM


      if (code === 9 || code === 32 || code === 44 || code === 0xfeff) {
        ++position;
      } else if (code === 10) {
        // new line
        ++position;

        __setKey(lexer, "line", (lexer._ES5ProxyType ? lexer.get("line") : lexer.line) + 1);

        __setKey(lexer, "lineStart", position);
      } else if (code === 13) {
        // carriage return
        if (__callKey1$1(body, "charCodeAt", position + 1) === 10) {
          position += 2;
        } else {
          ++position;
        }

        __setKey(lexer, "line", (lexer._ES5ProxyType ? lexer.get("line") : lexer.line) + 1);

        __setKey(lexer, "lineStart", position);
      } else {
        break;
      }
    }

    return position;
  }
  /**
   * Reads a comment token from the source file.
   *
   * #[\u0009\u0020-\uFFFF]*
   */


  function readComment(source, start, line, col, prev) {
    var body = source._ES5ProxyType ? source.get("body") : source.body;
    var code;
    var position = start;

    do {
      code = __callKey1$1(body, "charCodeAt", ++position);
    } while (!isNaN(code) && ( // SourceCharacter but not LineTerminator
    code > 0x001f || code === 0x0009));

    return new Token(TokenKind._ES5ProxyType ? TokenKind.get("COMMENT") : TokenKind.COMMENT, start, position, line, col, prev, __callKey2(body, "slice", start + 1, position));
  }
  /**
   * Reads a number token from the source file, either a float
   * or an int depending on whether a decimal point appears.
   *
   * Int:   -?(0|[1-9][0-9]*)
   * Float: -?(0|[1-9][0-9]*)(\.[0-9]+)?((E|e)(+|-)?[0-9]+)?
   */


  function readNumber(source, start, firstCode, line, col, prev) {
    var body = source._ES5ProxyType ? source.get("body") : source.body;
    var code = firstCode;
    var position = start;
    var isFloat = false;

    if (code === 45) {
      // -
      code = __callKey1$1(body, "charCodeAt", ++position);
    }

    if (code === 48) {
      // 0
      code = __callKey1$1(body, "charCodeAt", ++position);

      if (code >= 48 && code <= 57) {
        throw syntaxError(source, position, __concat("Invalid number, unexpected digit after 0: ", printCharCode(code), "."));
      }
    } else {
      position = readDigits(source, position, code);
      code = __callKey1$1(body, "charCodeAt", position);
    }

    if (code === 46) {
      // .
      isFloat = true;
      code = __callKey1$1(body, "charCodeAt", ++position);
      position = readDigits(source, position, code);
      code = __callKey1$1(body, "charCodeAt", position);
    }

    if (code === 69 || code === 101) {
      // E e
      isFloat = true;
      code = __callKey1$1(body, "charCodeAt", ++position);

      if (code === 43 || code === 45) {
        // + -
        code = __callKey1$1(body, "charCodeAt", ++position);
      }

      position = readDigits(source, position, code);
      code = __callKey1$1(body, "charCodeAt", position);
    } // Numbers cannot be followed by . or NameStart


    if (code === 46 || isNameStart(code)) {
      throw syntaxError(source, position, __concat("Invalid number, expected digit but got: ", printCharCode(code), "."));
    }

    return new Token(isFloat ? TokenKind._ES5ProxyType ? TokenKind.get("FLOAT") : TokenKind.FLOAT : TokenKind._ES5ProxyType ? TokenKind.get("INT") : TokenKind.INT, start, position, line, col, prev, __callKey2(body, "slice", start, position));
  }
  /**
   * Returns the new position in the source after reading digits.
   */


  function readDigits(source, start, firstCode) {
    var body = source._ES5ProxyType ? source.get("body") : source.body;
    var position = start;
    var code = firstCode;

    if (code >= 48 && code <= 57) {
      // 0 - 9
      do {
        code = __callKey1$1(body, "charCodeAt", ++position);
      } while (code >= 48 && code <= 57); // 0 - 9


      return position;
    }

    throw syntaxError(source, position, __concat("Invalid number, expected digit but got: ", printCharCode(code), "."));
  }
  /**
   * Reads a string token from the source file.
   *
   * "([^"\\\u000A\u000D]|(\\(u[0-9a-fA-F]{4}|["\\/bfnrt])))*"
   */


  function readString(source, start, line, col, prev) {
    var body = source._ES5ProxyType ? source.get("body") : source.body;
    var position = start + 1;
    var chunkStart = position;
    var code = 0;
    var value = '';

    while (position < (body._ES5ProxyType ? body.get("length") : body.length) && !isNaN(code = __callKey1$1(body, "charCodeAt", position)) && // not LineTerminator
    code !== 0x000a && code !== 0x000d) {
      // Closing Quote (")
      if (code === 34) {
        value += __callKey2(body, "slice", chunkStart, position);
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("STRING") : TokenKind.STRING, start, position + 1, line, col, prev, value);
      } // SourceCharacter


      if (code < 0x0020 && code !== 0x0009) {
        throw syntaxError(source, position, __concat("Invalid character within String: ", printCharCode(code), "."));
      }

      ++position;

      if (code === 92) {
        // \
        value += __callKey2(body, "slice", chunkStart, position - 1);
        code = __callKey1$1(body, "charCodeAt", position);

        switch (code) {
          case 34:
            value += '"';
            break;

          case 47:
            value += '/';
            break;

          case 92:
            value += '\\';
            break;

          case 98:
            value += '\b';
            break;

          case 102:
            value += '\f';
            break;

          case 110:
            value += '\n';
            break;

          case 114:
            value += '\r';
            break;

          case 116:
            value += '\t';
            break;

          case 117:
            {
              // uXXXX
              var charCode = uniCharCode(__callKey1$1(body, "charCodeAt", position + 1), __callKey1$1(body, "charCodeAt", position + 2), __callKey1$1(body, "charCodeAt", position + 3), __callKey1$1(body, "charCodeAt", position + 4));

              if (charCode < 0) {
                var invalidSequence = __callKey2(body, "slice", position + 1, position + 5);

                throw syntaxError(source, position, __concat("Invalid character escape sequence: \\u", invalidSequence, "."));
              }

              value += String.fromCharCode(charCode);
              position += 4;
              break;
            }

          default:
            throw syntaxError(source, position, __concat("Invalid character escape sequence: \\", String.fromCharCode(code), "."));
        }

        ++position;
        chunkStart = position;
      }
    }

    throw syntaxError(source, position, 'Unterminated string.');
  }
  /**
   * Reads a block string token from the source file.
   *
   * """("?"?(\\"""|\\(?!=""")|[^"\\]))*"""
   */


  function readBlockString(source, start, line, col, prev, lexer) {
    var body = source._ES5ProxyType ? source.get("body") : source.body;
    var position = start + 3;
    var chunkStart = position;
    var code = 0;
    var rawValue = '';

    while (position < (body._ES5ProxyType ? body.get("length") : body.length) && !isNaN(code = __callKey1$1(body, "charCodeAt", position))) {
      // Closing Triple-Quote (""")
      if (code === 34 && __callKey1$1(body, "charCodeAt", position + 1) === 34 && __callKey1$1(body, "charCodeAt", position + 2) === 34) {
        rawValue += __callKey2(body, "slice", chunkStart, position);
        return new Token(TokenKind._ES5ProxyType ? TokenKind.get("BLOCK_STRING") : TokenKind.BLOCK_STRING, start, position + 3, line, col, prev, dedentBlockStringValue(rawValue));
      } // SourceCharacter


      if (code < 0x0020 && code !== 0x0009 && code !== 0x000a && code !== 0x000d) {
        throw syntaxError(source, position, __concat("Invalid character within String: ", printCharCode(code), "."));
      }

      if (code === 10) {
        // new line
        ++position;

        __setKey(lexer, "line", (lexer._ES5ProxyType ? lexer.get("line") : lexer.line) + 1);

        __setKey(lexer, "lineStart", position);
      } else if (code === 13) {
        // carriage return
        if (__callKey1$1(body, "charCodeAt", position + 1) === 10) {
          position += 2;
        } else {
          ++position;
        }

        __setKey(lexer, "line", (lexer._ES5ProxyType ? lexer.get("line") : lexer.line) + 1);

        __setKey(lexer, "lineStart", position);
      } else if ( // Escape Triple-Quote (\""")
      code === 92 && __callKey1$1(body, "charCodeAt", position + 1) === 34 && __callKey1$1(body, "charCodeAt", position + 2) === 34 && __callKey1$1(body, "charCodeAt", position + 3) === 34) {
        rawValue += __callKey2(body, "slice", chunkStart, position) + '"""';
        position += 4;
        chunkStart = position;
      } else {
        ++position;
      }
    }

    throw syntaxError(source, position, 'Unterminated string.');
  }
  /**
   * Converts four hexadecimal chars to the integer that the
   * string represents. For example, uniCharCode('0','0','0','f')
   * will return 15, and uniCharCode('0','0','f','f') returns 255.
   *
   * Returns a negative number on error, if a char was invalid.
   *
   * This is implemented by noting that char2hex() returns -1 on error,
   * which means the result of ORing the char2hex() will also be negative.
   */


  function uniCharCode(a, b, c, d) {
    return char2hex(a) << 12 | char2hex(b) << 8 | char2hex(c) << 4 | char2hex(d);
  }
  /**
   * Converts a hex character to its integer value.
   * '0' becomes 0, '9' becomes 9
   * 'A' becomes 10, 'F' becomes 15
   * 'a' becomes 10, 'f' becomes 15
   *
   * Returns -1 on error.
   */


  function char2hex(a) {
    return a >= 48 && a <= 57 ? a - 48 // 0-9
    : a >= 65 && a <= 70 ? a - 55 // A-F
    : a >= 97 && a <= 102 ? a - 87 // a-f
    : -1;
  }
  /**
   * Reads an alphanumeric + underscore name from the source.
   *
   * [_A-Za-z][_0-9A-Za-z]*
   */


  function readName(source, start, line, col, prev) {
    var body = source._ES5ProxyType ? source.get("body") : source.body;
    var bodyLength = body._ES5ProxyType ? body.get("length") : body.length;
    var position = start + 1;
    var code = 0;

    while (position !== bodyLength && !isNaN(code = __callKey1$1(body, "charCodeAt", position)) && (code === 95 || // _
    code >= 48 && code <= 57 || // 0-9
    code >= 65 && code <= 90 || // A-Z
    code >= 97 && code <= 122) // a-z
    ) {
      ++position;
    }

    return new Token(TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME, start, position, line, col, prev, __callKey2(body, "slice", start, position));
  } // _ A-Z a-z


  function isNameStart(code) {
    return code === 95 || code >= 65 && code <= 90 || code >= 97 && code <= 122;
  }

  /**
   * Configuration options to control parser behavior
   */

  /**
   * Given a GraphQL source, parses it into a Document.
   * Throws GraphQLError if a syntax error is encountered.
   */

  function parse(source, options) {
    var parser = new Parser(source, options);
    return __callKey0(parser, "parseDocument");
  }
  /**
   * Given a string containing a GraphQL value (ex. `[42]`), parse the AST for
   * that value.
   * Throws GraphQLError if a syntax error is encountered.
   *
   * This is useful within tools that operate upon GraphQL Values directly and
   * in isolation of complete GraphQL documents.
   *
   * Consider providing the results to the utility function: valueFromAST().
   */

  function parseValue(source, options) {
    var parser = new Parser(source, options);

    __callKey1$1(parser, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("SOF") : TokenKind.SOF);

    var value = __callKey1$1(parser, "parseValueLiteral", false);

    __callKey1$1(parser, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("EOF") : TokenKind.EOF);

    return value;
  }
  /**
   * Given a string containing a GraphQL Type (ex. `[Int!]`), parse the AST for
   * that type.
   * Throws GraphQLError if a syntax error is encountered.
   *
   * This is useful within tools that operate upon GraphQL Types directly and
   * in isolation of complete GraphQL documents.
   *
   * Consider providing the results to the utility function: typeFromAST().
   */

  function parseType(source, options) {
    var parser = new Parser(source, options);

    __callKey1$1(parser, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("SOF") : TokenKind.SOF);

    var type = __callKey0(parser, "parseTypeReference");

    __callKey1$1(parser, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("EOF") : TokenKind.EOF);

    return type;
  }

  var Parser =
  /*#__PURE__*/
  function () {
    function Parser(source, options) {
      var sourceObj = typeof source === 'string' ? new Source(source) : source;
      _instanceof_1(sourceObj, Source) || devAssert(0, __concat("Must provide Source. Received: ", inspect(sourceObj), "."));

      __setKey(this, "_lexer", new Lexer(sourceObj));

      __setKey(this, "_options", options);
    }
    /**
     * Converts a name lex token into a name parse node.
     */


    var _proto = Parser._ES5ProxyType ? Parser.get("prototype") : Parser.prototype;

    __setKey(_proto, "parseName", function parseName() {
      var token = __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("NAME") : Kind.NAME,
        value: token._ES5ProxyType ? token.get("value") : token.value,
        loc: __callKey1$1(this, "loc", token)
      };
    }) // Implements the parsing rules in the Document section.

    /**
     * Document : Definition+
     */
    ;

    __setKey(_proto, "parseDocument", function parseDocument() {
      var _lexer, _token;

      var start = (_lexer = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token = _lexer._ES5ProxyType ? _lexer.get("token") : _lexer.token);
      return {
        kind: Kind._ES5ProxyType ? Kind.get("DOCUMENT") : Kind.DOCUMENT,
        definitions: __callKey3(this, "many", TokenKind._ES5ProxyType ? TokenKind.get("SOF") : TokenKind.SOF, this._ES5ProxyType ? this.get("parseDefinition") : this.parseDefinition, TokenKind._ES5ProxyType ? TokenKind.get("EOF") : TokenKind.EOF),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * Definition :
     *   - ExecutableDefinition
     *   - TypeSystemDefinition
     *   - TypeSystemExtension
     *
     * ExecutableDefinition :
     *   - OperationDefinition
     *   - FragmentDefinition
     */
    ;

    __setKey(_proto, "parseDefinition", function parseDefinition() {
      var _lexer2, _token2, _value;

      if (__callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME)) {
        switch (_lexer2 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token2 = _lexer2._ES5ProxyType ? _lexer2.get("token") : _lexer2.token, _value = _token2._ES5ProxyType ? _token2.get("value") : _token2.value) {
          case 'query':
          case 'mutation':
          case 'subscription':
            return __callKey0(this, "parseOperationDefinition");

          case 'fragment':
            return __callKey0(this, "parseFragmentDefinition");

          case 'schema':
          case 'scalar':
          case 'type':
          case 'interface':
          case 'union':
          case 'enum':
          case 'input':
          case 'directive':
            return __callKey0(this, "parseTypeSystemDefinition");

          case 'extend':
            return __callKey0(this, "parseTypeSystemExtension");
        }
      } else if (__callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L)) {
        return __callKey0(this, "parseOperationDefinition");
      } else if (__callKey0(this, "peekDescription")) {
        return __callKey0(this, "parseTypeSystemDefinition");
      }

      throw __callKey0(this, "unexpected");
    }) // Implements the parsing rules in the Operations section.

    /**
     * OperationDefinition :
     *  - SelectionSet
     *  - OperationType Name? VariableDefinitions? Directives? SelectionSet
     */
    ;

    __setKey(_proto, "parseOperationDefinition", function parseOperationDefinition() {
      var _lexer3, _token3;

      var start = (_lexer3 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token3 = _lexer3._ES5ProxyType ? _lexer3.get("token") : _lexer3.token);

      if (__callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L)) {
        return {
          kind: Kind._ES5ProxyType ? Kind.get("OPERATION_DEFINITION") : Kind.OPERATION_DEFINITION,
          operation: 'query',
          name: undefined,
          variableDefinitions: [],
          directives: [],
          selectionSet: __callKey0(this, "parseSelectionSet"),
          loc: __callKey1$1(this, "loc", start)
        };
      }

      var operation = __callKey0(this, "parseOperationType");

      var name;

      if (__callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME)) {
        name = __callKey0(this, "parseName");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("OPERATION_DEFINITION") : Kind.OPERATION_DEFINITION,
        operation: operation,
        name: name,
        variableDefinitions: __callKey0(this, "parseVariableDefinitions"),
        directives: __callKey1$1(this, "parseDirectives", false),
        selectionSet: __callKey0(this, "parseSelectionSet"),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * OperationType : one of query mutation subscription
     */
    ;

    __setKey(_proto, "parseOperationType", function parseOperationType() {
      var operationToken = __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME);

      switch (operationToken._ES5ProxyType ? operationToken.get("value") : operationToken.value) {
        case 'query':
          return 'query';

        case 'mutation':
          return 'mutation';

        case 'subscription':
          return 'subscription';
      }

      throw __callKey1$1(this, "unexpected", operationToken);
    })
    /**
     * VariableDefinitions : ( VariableDefinition+ )
     */
    ;

    __setKey(_proto, "parseVariableDefinitions", function parseVariableDefinitions() {
      return __callKey3(this, "optionalMany", TokenKind._ES5ProxyType ? TokenKind.get("PAREN_L") : TokenKind.PAREN_L, this._ES5ProxyType ? this.get("parseVariableDefinition") : this.parseVariableDefinition, TokenKind._ES5ProxyType ? TokenKind.get("PAREN_R") : TokenKind.PAREN_R);
    })
    /**
     * VariableDefinition : Variable : Type DefaultValue? Directives[Const]?
     */
    ;

    __setKey(_proto, "parseVariableDefinition", function parseVariableDefinition() {
      var _lexer4, _token4;

      var start = (_lexer4 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token4 = _lexer4._ES5ProxyType ? _lexer4.get("token") : _lexer4.token);
      return {
        kind: Kind._ES5ProxyType ? Kind.get("VARIABLE_DEFINITION") : Kind.VARIABLE_DEFINITION,
        variable: __callKey0(this, "parseVariable"),
        type: (__callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON), __callKey0(this, "parseTypeReference")),
        defaultValue: __callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("EQUALS") : TokenKind.EQUALS) ? __callKey1$1(this, "parseValueLiteral", true) : undefined,
        directives: __callKey1$1(this, "parseDirectives", true),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * Variable : $ Name
     */
    ;

    __setKey(_proto, "parseVariable", function parseVariable() {
      var _lexer5, _token5;

      var start = (_lexer5 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token5 = _lexer5._ES5ProxyType ? _lexer5.get("token") : _lexer5.token);

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("DOLLAR") : TokenKind.DOLLAR);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("VARIABLE") : Kind.VARIABLE,
        name: __callKey0(this, "parseName"),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * SelectionSet : { Selection+ }
     */
    ;

    __setKey(_proto, "parseSelectionSet", function parseSelectionSet() {
      var _lexer6, _token6;

      var start = (_lexer6 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token6 = _lexer6._ES5ProxyType ? _lexer6.get("token") : _lexer6.token);
      return {
        kind: Kind._ES5ProxyType ? Kind.get("SELECTION_SET") : Kind.SELECTION_SET,
        selections: __callKey3(this, "many", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, this._ES5ProxyType ? this.get("parseSelection") : this.parseSelection, TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * Selection :
     *   - Field
     *   - FragmentSpread
     *   - InlineFragment
     */
    ;

    __setKey(_proto, "parseSelection", function parseSelection() {
      return __callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("SPREAD") : TokenKind.SPREAD) ? __callKey0(this, "parseFragment") : __callKey0(this, "parseField");
    })
    /**
     * Field : Alias? Name Arguments? Directives? SelectionSet?
     *
     * Alias : Name :
     */
    ;

    __setKey(_proto, "parseField", function parseField() {
      var _lexer7, _token7;

      var start = (_lexer7 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token7 = _lexer7._ES5ProxyType ? _lexer7.get("token") : _lexer7.token);

      var nameOrAlias = __callKey0(this, "parseName");

      var alias;
      var name;

      if (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON)) {
        alias = nameOrAlias;
        name = __callKey0(this, "parseName");
      } else {
        name = nameOrAlias;
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("FIELD") : Kind.FIELD,
        alias: alias,
        name: name,
        arguments: __callKey1$1(this, "parseArguments", false),
        directives: __callKey1$1(this, "parseDirectives", false),
        selectionSet: __callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L) ? __callKey0(this, "parseSelectionSet") : undefined,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * Arguments[Const] : ( Argument[?Const]+ )
     */
    ;

    __setKey(_proto, "parseArguments", function parseArguments(isConst) {
      var item = isConst ? this._ES5ProxyType ? this.get("parseConstArgument") : this.parseConstArgument : this._ES5ProxyType ? this.get("parseArgument") : this.parseArgument;
      return __callKey3(this, "optionalMany", TokenKind._ES5ProxyType ? TokenKind.get("PAREN_L") : TokenKind.PAREN_L, item, TokenKind._ES5ProxyType ? TokenKind.get("PAREN_R") : TokenKind.PAREN_R);
    })
    /**
     * Argument[Const] : Name : Value[?Const]
     */
    ;

    __setKey(_proto, "parseArgument", function parseArgument() {
      var _lexer8, _token8;

      var start = (_lexer8 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token8 = _lexer8._ES5ProxyType ? _lexer8.get("token") : _lexer8.token);

      var name = __callKey0(this, "parseName");

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("ARGUMENT") : Kind.ARGUMENT,
        name: name,
        value: __callKey1$1(this, "parseValueLiteral", false),
        loc: __callKey1$1(this, "loc", start)
      };
    });

    __setKey(_proto, "parseConstArgument", function parseConstArgument() {
      var _lexer9, _token9;

      var start = (_lexer9 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token9 = _lexer9._ES5ProxyType ? _lexer9.get("token") : _lexer9.token);
      return {
        kind: Kind._ES5ProxyType ? Kind.get("ARGUMENT") : Kind.ARGUMENT,
        name: __callKey0(this, "parseName"),
        value: (__callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON), __callKey1$1(this, "parseValueLiteral", true)),
        loc: __callKey1$1(this, "loc", start)
      };
    }) // Implements the parsing rules in the Fragments section.

    /**
     * Corresponds to both FragmentSpread and InlineFragment in the spec.
     *
     * FragmentSpread : ... FragmentName Directives?
     *
     * InlineFragment : ... TypeCondition? Directives? SelectionSet
     */
    ;

    __setKey(_proto, "parseFragment", function parseFragment() {
      var _lexer10, _token10;

      var start = (_lexer10 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token10 = _lexer10._ES5ProxyType ? _lexer10.get("token") : _lexer10.token);

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("SPREAD") : TokenKind.SPREAD);

      var hasTypeCondition = __callKey1$1(this, "expectOptionalKeyword", 'on');

      if (!hasTypeCondition && __callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME)) {
        return {
          kind: Kind._ES5ProxyType ? Kind.get("FRAGMENT_SPREAD") : Kind.FRAGMENT_SPREAD,
          name: __callKey0(this, "parseFragmentName"),
          directives: __callKey1$1(this, "parseDirectives", false),
          loc: __callKey1$1(this, "loc", start)
        };
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("INLINE_FRAGMENT") : Kind.INLINE_FRAGMENT,
        typeCondition: hasTypeCondition ? __callKey0(this, "parseNamedType") : undefined,
        directives: __callKey1$1(this, "parseDirectives", false),
        selectionSet: __callKey0(this, "parseSelectionSet"),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * FragmentDefinition :
     *   - fragment FragmentName on TypeCondition Directives? SelectionSet
     *
     * TypeCondition : NamedType
     */
    ;

    __setKey(_proto, "parseFragmentDefinition", function parseFragmentDefinition() {
      var _lexer11, _token11;

      var _this$_options;

      var start = (_lexer11 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token11 = _lexer11._ES5ProxyType ? _lexer11.get("token") : _lexer11.token);

      __callKey1$1(this, "expectKeyword", 'fragment'); // Experimental support for defining variables within fragments changes
      // the grammar of FragmentDefinition:
      //   - fragment FragmentName VariableDefinitions? on TypeCondition Directives? SelectionSet


      if (((_this$_options = this._ES5ProxyType ? this.get("_options") : this._options) === null || _this$_options === void 0 ? void 0 : _this$_options._ES5ProxyType ? _this$_options.get("experimentalFragmentVariables") : _this$_options.experimentalFragmentVariables) === true) {
        return {
          kind: Kind._ES5ProxyType ? Kind.get("FRAGMENT_DEFINITION") : Kind.FRAGMENT_DEFINITION,
          name: __callKey0(this, "parseFragmentName"),
          variableDefinitions: __callKey0(this, "parseVariableDefinitions"),
          typeCondition: (__callKey1$1(this, "expectKeyword", 'on'), __callKey0(this, "parseNamedType")),
          directives: __callKey1$1(this, "parseDirectives", false),
          selectionSet: __callKey0(this, "parseSelectionSet"),
          loc: __callKey1$1(this, "loc", start)
        };
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("FRAGMENT_DEFINITION") : Kind.FRAGMENT_DEFINITION,
        name: __callKey0(this, "parseFragmentName"),
        typeCondition: (__callKey1$1(this, "expectKeyword", 'on'), __callKey0(this, "parseNamedType")),
        directives: __callKey1$1(this, "parseDirectives", false),
        selectionSet: __callKey0(this, "parseSelectionSet"),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * FragmentName : Name but not `on`
     */
    ;

    __setKey(_proto, "parseFragmentName", function parseFragmentName() {
      var _lexer12, _token12, _value2;

      if ((_lexer12 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token12 = _lexer12._ES5ProxyType ? _lexer12.get("token") : _lexer12.token, _value2 = _token12._ES5ProxyType ? _token12.get("value") : _token12.value) === 'on') {
        throw __callKey0(this, "unexpected");
      }

      return __callKey0(this, "parseName");
    }) // Implements the parsing rules in the Values section.

    /**
     * Value[Const] :
     *   - [~Const] Variable
     *   - IntValue
     *   - FloatValue
     *   - StringValue
     *   - BooleanValue
     *   - NullValue
     *   - EnumValue
     *   - ListValue[?Const]
     *   - ObjectValue[?Const]
     *
     * BooleanValue : one of `true` `false`
     *
     * NullValue : `null`
     *
     * EnumValue : Name but not `true`, `false` or `null`
     */
    ;

    __setKey(_proto, "parseValueLiteral", function parseValueLiteral(isConst) {
      var _lexer13, _token13;

      var token = (_lexer13 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token13 = _lexer13._ES5ProxyType ? _lexer13.get("token") : _lexer13.token);

      switch (token._ES5ProxyType ? token.get("kind") : token.kind) {
        case TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_L") : TokenKind.BRACKET_L:
          return __callKey1$1(this, "parseList", isConst);

        case TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L:
          return __callKey1$1(this, "parseObject", isConst);

        case TokenKind._ES5ProxyType ? TokenKind.get("INT") : TokenKind.INT:
          __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

          return {
            kind: Kind._ES5ProxyType ? Kind.get("INT") : Kind.INT,
            value: token._ES5ProxyType ? token.get("value") : token.value,
            loc: __callKey1$1(this, "loc", token)
          };

        case TokenKind._ES5ProxyType ? TokenKind.get("FLOAT") : TokenKind.FLOAT:
          __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

          return {
            kind: Kind._ES5ProxyType ? Kind.get("FLOAT") : Kind.FLOAT,
            value: token._ES5ProxyType ? token.get("value") : token.value,
            loc: __callKey1$1(this, "loc", token)
          };

        case TokenKind._ES5ProxyType ? TokenKind.get("STRING") : TokenKind.STRING:
        case TokenKind._ES5ProxyType ? TokenKind.get("BLOCK_STRING") : TokenKind.BLOCK_STRING:
          return __callKey0(this, "parseStringLiteral");

        case TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME:
          __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

          switch (token._ES5ProxyType ? token.get("value") : token.value) {
            case 'true':
              return {
                kind: Kind._ES5ProxyType ? Kind.get("BOOLEAN") : Kind.BOOLEAN,
                value: true,
                loc: __callKey1$1(this, "loc", token)
              };

            case 'false':
              return {
                kind: Kind._ES5ProxyType ? Kind.get("BOOLEAN") : Kind.BOOLEAN,
                value: false,
                loc: __callKey1$1(this, "loc", token)
              };

            case 'null':
              return {
                kind: Kind._ES5ProxyType ? Kind.get("NULL") : Kind.NULL,
                loc: __callKey1$1(this, "loc", token)
              };

            default:
              return {
                kind: Kind._ES5ProxyType ? Kind.get("ENUM") : Kind.ENUM,
                value: token._ES5ProxyType ? token.get("value") : token.value,
                loc: __callKey1$1(this, "loc", token)
              };
          }

        case TokenKind._ES5ProxyType ? TokenKind.get("DOLLAR") : TokenKind.DOLLAR:
          if (!isConst) {
            return __callKey0(this, "parseVariable");
          }

          break;
      }

      throw __callKey0(this, "unexpected");
    });

    __setKey(_proto, "parseStringLiteral", function parseStringLiteral() {
      var _lexer14, _token14;

      var token = (_lexer14 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token14 = _lexer14._ES5ProxyType ? _lexer14.get("token") : _lexer14.token);

      __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("STRING") : Kind.STRING,
        value: token._ES5ProxyType ? token.get("value") : token.value,
        block: (token._ES5ProxyType ? token.get("kind") : token.kind) === (TokenKind._ES5ProxyType ? TokenKind.get("BLOCK_STRING") : TokenKind.BLOCK_STRING),
        loc: __callKey1$1(this, "loc", token)
      };
    })
    /**
     * ListValue[Const] :
     *   - [ ]
     *   - [ Value[?Const]+ ]
     */
    ;

    __setKey(_proto, "parseList", function parseList(isConst) {
      var _lexer15, _token15;

      var _this = this;

      var start = (_lexer15 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token15 = _lexer15._ES5ProxyType ? _lexer15.get("token") : _lexer15.token);

      var item = function item() {
        return __callKey1$1(_this, "parseValueLiteral", isConst);
      };

      return {
        kind: Kind._ES5ProxyType ? Kind.get("LIST") : Kind.LIST,
        values: __callKey3(this, "any", TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_L") : TokenKind.BRACKET_L, item, TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_R") : TokenKind.BRACKET_R),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ObjectValue[Const] :
     *   - { }
     *   - { ObjectField[?Const]+ }
     */
    ;

    __setKey(_proto, "parseObject", function parseObject(isConst) {
      var _lexer16, _token16;

      var _this2 = this;

      var start = (_lexer16 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token16 = _lexer16._ES5ProxyType ? _lexer16.get("token") : _lexer16.token);

      var item = function item() {
        return __callKey1$1(_this2, "parseObjectField", isConst);
      };

      return {
        kind: Kind._ES5ProxyType ? Kind.get("OBJECT") : Kind.OBJECT,
        fields: __callKey3(this, "any", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, item, TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R),
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ObjectField[Const] : Name : Value[?Const]
     */
    ;

    __setKey(_proto, "parseObjectField", function parseObjectField(isConst) {
      var _lexer17, _token17;

      var start = (_lexer17 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token17 = _lexer17._ES5ProxyType ? _lexer17.get("token") : _lexer17.token);

      var name = __callKey0(this, "parseName");

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("OBJECT_FIELD") : Kind.OBJECT_FIELD,
        name: name,
        value: __callKey1$1(this, "parseValueLiteral", isConst),
        loc: __callKey1$1(this, "loc", start)
      };
    }) // Implements the parsing rules in the Directives section.

    /**
     * Directives[Const] : Directive[?Const]+
     */
    ;

    __setKey(_proto, "parseDirectives", function parseDirectives(isConst) {
      var directives = [];

      while (__callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("AT") : TokenKind.AT)) {
        directives.push(__callKey1$1(this, "parseDirective", isConst));
      }

      return directives;
    })
    /**
     * Directive[Const] : @ Name Arguments[?Const]?
     */
    ;

    __setKey(_proto, "parseDirective", function parseDirective(isConst) {
      var _lexer18, _token18;

      var start = (_lexer18 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token18 = _lexer18._ES5ProxyType ? _lexer18.get("token") : _lexer18.token);

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("AT") : TokenKind.AT);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("DIRECTIVE") : Kind.DIRECTIVE,
        name: __callKey0(this, "parseName"),
        arguments: __callKey1$1(this, "parseArguments", isConst),
        loc: __callKey1$1(this, "loc", start)
      };
    }) // Implements the parsing rules in the Types section.

    /**
     * Type :
     *   - NamedType
     *   - ListType
     *   - NonNullType
     */
    ;

    __setKey(_proto, "parseTypeReference", function parseTypeReference() {
      var _lexer19, _token19;

      var start = (_lexer19 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token19 = _lexer19._ES5ProxyType ? _lexer19.get("token") : _lexer19.token);
      var type;

      if (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_L") : TokenKind.BRACKET_L)) {
        type = __callKey0(this, "parseTypeReference");

        __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("BRACKET_R") : TokenKind.BRACKET_R);

        type = {
          kind: Kind._ES5ProxyType ? Kind.get("LIST_TYPE") : Kind.LIST_TYPE,
          type: type,
          loc: __callKey1$1(this, "loc", start)
        };
      } else {
        type = __callKey0(this, "parseNamedType");
      }

      if (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("BANG") : TokenKind.BANG)) {
        return {
          kind: Kind._ES5ProxyType ? Kind.get("NON_NULL_TYPE") : Kind.NON_NULL_TYPE,
          type: type,
          loc: __callKey1$1(this, "loc", start)
        };
      }

      return type;
    })
    /**
     * NamedType : Name
     */
    ;

    __setKey(_proto, "parseNamedType", function parseNamedType() {
      var _lexer20, _token20;

      var start = (_lexer20 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token20 = _lexer20._ES5ProxyType ? _lexer20.get("token") : _lexer20.token);
      return {
        kind: Kind._ES5ProxyType ? Kind.get("NAMED_TYPE") : Kind.NAMED_TYPE,
        name: __callKey0(this, "parseName"),
        loc: __callKey1$1(this, "loc", start)
      };
    }) // Implements the parsing rules in the Type Definition section.

    /**
     * TypeSystemDefinition :
     *   - SchemaDefinition
     *   - TypeDefinition
     *   - DirectiveDefinition
     *
     * TypeDefinition :
     *   - ScalarTypeDefinition
     *   - ObjectTypeDefinition
     *   - InterfaceTypeDefinition
     *   - UnionTypeDefinition
     *   - EnumTypeDefinition
     *   - InputObjectTypeDefinition
     */
    ;

    __setKey(_proto, "parseTypeSystemDefinition", function parseTypeSystemDefinition() {
      var _lexer21, _token21;

      // Many definitions begin with a description and require a lookahead.
      var keywordToken = __callKey0(this, "peekDescription") ? __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "lookahead") : (_lexer21 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token21 = _lexer21._ES5ProxyType ? _lexer21.get("token") : _lexer21.token);

      if ((keywordToken._ES5ProxyType ? keywordToken.get("kind") : keywordToken.kind) === (TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME)) {
        switch (keywordToken._ES5ProxyType ? keywordToken.get("value") : keywordToken.value) {
          case 'schema':
            return __callKey0(this, "parseSchemaDefinition");

          case 'scalar':
            return __callKey0(this, "parseScalarTypeDefinition");

          case 'type':
            return __callKey0(this, "parseObjectTypeDefinition");

          case 'interface':
            return __callKey0(this, "parseInterfaceTypeDefinition");

          case 'union':
            return __callKey0(this, "parseUnionTypeDefinition");

          case 'enum':
            return __callKey0(this, "parseEnumTypeDefinition");

          case 'input':
            return __callKey0(this, "parseInputObjectTypeDefinition");

          case 'directive':
            return __callKey0(this, "parseDirectiveDefinition");
        }
      }

      throw __callKey1$1(this, "unexpected", keywordToken);
    });

    __setKey(_proto, "peekDescription", function peekDescription() {
      return __callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("STRING") : TokenKind.STRING) || __callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("BLOCK_STRING") : TokenKind.BLOCK_STRING);
    })
    /**
     * Description : StringValue
     */
    ;

    __setKey(_proto, "parseDescription", function parseDescription() {
      if (__callKey0(this, "peekDescription")) {
        return __callKey0(this, "parseStringLiteral");
      }
    })
    /**
     * SchemaDefinition : Description? schema Directives[Const]? { OperationTypeDefinition+ }
     */
    ;

    __setKey(_proto, "parseSchemaDefinition", function parseSchemaDefinition() {
      var _lexer22, _token22;

      var start = (_lexer22 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token22 = _lexer22._ES5ProxyType ? _lexer22.get("token") : _lexer22.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'schema');

      var directives = __callKey1$1(this, "parseDirectives", true);

      var operationTypes = __callKey3(this, "many", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, this._ES5ProxyType ? this.get("parseOperationTypeDefinition") : this.parseOperationTypeDefinition, TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("SCHEMA_DEFINITION") : Kind.SCHEMA_DEFINITION,
        description: description,
        directives: directives,
        operationTypes: operationTypes,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * OperationTypeDefinition : OperationType : NamedType
     */
    ;

    __setKey(_proto, "parseOperationTypeDefinition", function parseOperationTypeDefinition() {
      var _lexer23, _token23;

      var start = (_lexer23 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token23 = _lexer23._ES5ProxyType ? _lexer23.get("token") : _lexer23.token);

      var operation = __callKey0(this, "parseOperationType");

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON);

      var type = __callKey0(this, "parseNamedType");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("OPERATION_TYPE_DEFINITION") : Kind.OPERATION_TYPE_DEFINITION,
        operation: operation,
        type: type,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ScalarTypeDefinition : Description? scalar Name Directives[Const]?
     */
    ;

    __setKey(_proto, "parseScalarTypeDefinition", function parseScalarTypeDefinition() {
      var _lexer24, _token24;

      var start = (_lexer24 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token24 = _lexer24._ES5ProxyType ? _lexer24.get("token") : _lexer24.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'scalar');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("SCALAR_TYPE_DEFINITION") : Kind.SCALAR_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ObjectTypeDefinition :
     *   Description?
     *   type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition?
     */
    ;

    __setKey(_proto, "parseObjectTypeDefinition", function parseObjectTypeDefinition() {
      var _lexer25, _token25;

      var start = (_lexer25 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token25 = _lexer25._ES5ProxyType ? _lexer25.get("token") : _lexer25.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'type');

      var name = __callKey0(this, "parseName");

      var interfaces = __callKey0(this, "parseImplementsInterfaces");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var fields = __callKey0(this, "parseFieldsDefinition");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("OBJECT_TYPE_DEFINITION") : Kind.OBJECT_TYPE_DEFINITION,
        description: description,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ImplementsInterfaces :
     *   - implements `&`? NamedType
     *   - ImplementsInterfaces & NamedType
     */
    ;

    __setKey(_proto, "parseImplementsInterfaces", function parseImplementsInterfaces() {
      var types = [];

      if (__callKey1$1(this, "expectOptionalKeyword", 'implements')) {
        // Optional leading ampersand
        __callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("AMP") : TokenKind.AMP);

        do {
          var _this$_options2;

          types.push(__callKey0(this, "parseNamedType"));
        } while (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("AMP") : TokenKind.AMP) || // Legacy support for the SDL?
        ((_this$_options2 = this._ES5ProxyType ? this.get("_options") : this._options) === null || _this$_options2 === void 0 ? void 0 : _this$_options2._ES5ProxyType ? _this$_options2.get("allowLegacySDLImplementsInterfaces") : _this$_options2.allowLegacySDLImplementsInterfaces) === true && __callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME));
      }

      return types;
    })
    /**
     * FieldsDefinition : { FieldDefinition+ }
     */
    ;

    __setKey(_proto, "parseFieldsDefinition", function parseFieldsDefinition() {
      var _this$_lexer$lookahea, _kind;

      var _this$_options3; // Legacy support for the SDL?


      if (((_this$_options3 = this._ES5ProxyType ? this.get("_options") : this._options) === null || _this$_options3 === void 0 ? void 0 : _this$_options3._ES5ProxyType ? _this$_options3.get("allowLegacySDLEmptyFields") : _this$_options3.allowLegacySDLEmptyFields) === true && __callKey1$1(this, "peek", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L) && (_this$_lexer$lookahea = __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "lookahead"), _kind = _this$_lexer$lookahea._ES5ProxyType ? _this$_lexer$lookahea.get("kind") : _this$_lexer$lookahea.kind) === (TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R)) {
        __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

        __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

        return [];
      }

      return __callKey3(this, "optionalMany", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, this._ES5ProxyType ? this.get("parseFieldDefinition") : this.parseFieldDefinition, TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R);
    })
    /**
     * FieldDefinition :
     *   - Description? Name ArgumentsDefinition? : Type Directives[Const]?
     */
    ;

    __setKey(_proto, "parseFieldDefinition", function parseFieldDefinition() {
      var _lexer26, _token26;

      var start = (_lexer26 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token26 = _lexer26._ES5ProxyType ? _lexer26.get("token") : _lexer26.token);

      var description = __callKey0(this, "parseDescription");

      var name = __callKey0(this, "parseName");

      var args = __callKey0(this, "parseArgumentDefs");

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON);

      var type = __callKey0(this, "parseTypeReference");

      var directives = __callKey1$1(this, "parseDirectives", true);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("FIELD_DEFINITION") : Kind.FIELD_DEFINITION,
        description: description,
        name: name,
        arguments: args,
        type: type,
        directives: directives,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ArgumentsDefinition : ( InputValueDefinition+ )
     */
    ;

    __setKey(_proto, "parseArgumentDefs", function parseArgumentDefs() {
      return __callKey3(this, "optionalMany", TokenKind._ES5ProxyType ? TokenKind.get("PAREN_L") : TokenKind.PAREN_L, this._ES5ProxyType ? this.get("parseInputValueDef") : this.parseInputValueDef, TokenKind._ES5ProxyType ? TokenKind.get("PAREN_R") : TokenKind.PAREN_R);
    })
    /**
     * InputValueDefinition :
     *   - Description? Name : Type DefaultValue? Directives[Const]?
     */
    ;

    __setKey(_proto, "parseInputValueDef", function parseInputValueDef() {
      var _lexer27, _token27;

      var start = (_lexer27 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token27 = _lexer27._ES5ProxyType ? _lexer27.get("token") : _lexer27.token);

      var description = __callKey0(this, "parseDescription");

      var name = __callKey0(this, "parseName");

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("COLON") : TokenKind.COLON);

      var type = __callKey0(this, "parseTypeReference");

      var defaultValue;

      if (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("EQUALS") : TokenKind.EQUALS)) {
        defaultValue = __callKey1$1(this, "parseValueLiteral", true);
      }

      var directives = __callKey1$1(this, "parseDirectives", true);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("INPUT_VALUE_DEFINITION") : Kind.INPUT_VALUE_DEFINITION,
        description: description,
        name: name,
        type: type,
        defaultValue: defaultValue,
        directives: directives,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * InterfaceTypeDefinition :
     *   - Description? interface Name Directives[Const]? FieldsDefinition?
     */
    ;

    __setKey(_proto, "parseInterfaceTypeDefinition", function parseInterfaceTypeDefinition() {
      var _lexer28, _token28;

      var start = (_lexer28 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token28 = _lexer28._ES5ProxyType ? _lexer28.get("token") : _lexer28.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'interface');

      var name = __callKey0(this, "parseName");

      var interfaces = __callKey0(this, "parseImplementsInterfaces");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var fields = __callKey0(this, "parseFieldsDefinition");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("INTERFACE_TYPE_DEFINITION") : Kind.INTERFACE_TYPE_DEFINITION,
        description: description,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * UnionTypeDefinition :
     *   - Description? union Name Directives[Const]? UnionMemberTypes?
     */
    ;

    __setKey(_proto, "parseUnionTypeDefinition", function parseUnionTypeDefinition() {
      var _lexer29, _token29;

      var start = (_lexer29 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token29 = _lexer29._ES5ProxyType ? _lexer29.get("token") : _lexer29.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'union');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var types = __callKey0(this, "parseUnionMemberTypes");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("UNION_TYPE_DEFINITION") : Kind.UNION_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        types: types,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * UnionMemberTypes :
     *   - = `|`? NamedType
     *   - UnionMemberTypes | NamedType
     */
    ;

    __setKey(_proto, "parseUnionMemberTypes", function parseUnionMemberTypes() {
      var types = [];

      if (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("EQUALS") : TokenKind.EQUALS)) {
        // Optional leading pipe
        __callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("PIPE") : TokenKind.PIPE);

        do {
          types.push(__callKey0(this, "parseNamedType"));
        } while (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("PIPE") : TokenKind.PIPE));
      }

      return types;
    })
    /**
     * EnumTypeDefinition :
     *   - Description? enum Name Directives[Const]? EnumValuesDefinition?
     */
    ;

    __setKey(_proto, "parseEnumTypeDefinition", function parseEnumTypeDefinition() {
      var _lexer30, _token30;

      var start = (_lexer30 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token30 = _lexer30._ES5ProxyType ? _lexer30.get("token") : _lexer30.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'enum');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var values = __callKey0(this, "parseEnumValuesDefinition");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("ENUM_TYPE_DEFINITION") : Kind.ENUM_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        values: values,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * EnumValuesDefinition : { EnumValueDefinition+ }
     */
    ;

    __setKey(_proto, "parseEnumValuesDefinition", function parseEnumValuesDefinition() {
      return __callKey3(this, "optionalMany", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, this._ES5ProxyType ? this.get("parseEnumValueDefinition") : this.parseEnumValueDefinition, TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R);
    })
    /**
     * EnumValueDefinition : Description? EnumValue Directives[Const]?
     *
     * EnumValue : Name
     */
    ;

    __setKey(_proto, "parseEnumValueDefinition", function parseEnumValueDefinition() {
      var _lexer31, _token31;

      var start = (_lexer31 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token31 = _lexer31._ES5ProxyType ? _lexer31.get("token") : _lexer31.token);

      var description = __callKey0(this, "parseDescription");

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      return {
        kind: Kind._ES5ProxyType ? Kind.get("ENUM_VALUE_DEFINITION") : Kind.ENUM_VALUE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * InputObjectTypeDefinition :
     *   - Description? input Name Directives[Const]? InputFieldsDefinition?
     */
    ;

    __setKey(_proto, "parseInputObjectTypeDefinition", function parseInputObjectTypeDefinition() {
      var _lexer32, _token32;

      var start = (_lexer32 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token32 = _lexer32._ES5ProxyType ? _lexer32.get("token") : _lexer32.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'input');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var fields = __callKey0(this, "parseInputFieldsDefinition");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("INPUT_OBJECT_TYPE_DEFINITION") : Kind.INPUT_OBJECT_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        fields: fields,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * InputFieldsDefinition : { InputValueDefinition+ }
     */
    ;

    __setKey(_proto, "parseInputFieldsDefinition", function parseInputFieldsDefinition() {
      return __callKey3(this, "optionalMany", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, this._ES5ProxyType ? this.get("parseInputValueDef") : this.parseInputValueDef, TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R);
    })
    /**
     * TypeSystemExtension :
     *   - SchemaExtension
     *   - TypeExtension
     *
     * TypeExtension :
     *   - ScalarTypeExtension
     *   - ObjectTypeExtension
     *   - InterfaceTypeExtension
     *   - UnionTypeExtension
     *   - EnumTypeExtension
     *   - InputObjectTypeDefinition
     */
    ;

    __setKey(_proto, "parseTypeSystemExtension", function parseTypeSystemExtension() {
      var keywordToken = __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "lookahead");

      if ((keywordToken._ES5ProxyType ? keywordToken.get("kind") : keywordToken.kind) === (TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME)) {
        switch (keywordToken._ES5ProxyType ? keywordToken.get("value") : keywordToken.value) {
          case 'schema':
            return __callKey0(this, "parseSchemaExtension");

          case 'scalar':
            return __callKey0(this, "parseScalarTypeExtension");

          case 'type':
            return __callKey0(this, "parseObjectTypeExtension");

          case 'interface':
            return __callKey0(this, "parseInterfaceTypeExtension");

          case 'union':
            return __callKey0(this, "parseUnionTypeExtension");

          case 'enum':
            return __callKey0(this, "parseEnumTypeExtension");

          case 'input':
            return __callKey0(this, "parseInputObjectTypeExtension");
        }
      }

      throw __callKey1$1(this, "unexpected", keywordToken);
    })
    /**
     * SchemaExtension :
     *  - extend schema Directives[Const]? { OperationTypeDefinition+ }
     *  - extend schema Directives[Const]
     */
    ;

    __setKey(_proto, "parseSchemaExtension", function parseSchemaExtension() {
      var _lexer33, _token33;

      var start = (_lexer33 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token33 = _lexer33._ES5ProxyType ? _lexer33.get("token") : _lexer33.token);

      __callKey1$1(this, "expectKeyword", 'extend');

      __callKey1$1(this, "expectKeyword", 'schema');

      var directives = __callKey1$1(this, "parseDirectives", true);

      var operationTypes = __callKey3(this, "optionalMany", TokenKind._ES5ProxyType ? TokenKind.get("BRACE_L") : TokenKind.BRACE_L, this._ES5ProxyType ? this.get("parseOperationTypeDefinition") : this.parseOperationTypeDefinition, TokenKind._ES5ProxyType ? TokenKind.get("BRACE_R") : TokenKind.BRACE_R);

      if ((directives._ES5ProxyType ? directives.get("length") : directives.length) === 0 && (operationTypes._ES5ProxyType ? operationTypes.get("length") : operationTypes.length) === 0) {
        throw __callKey0(this, "unexpected");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("SCHEMA_EXTENSION") : Kind.SCHEMA_EXTENSION,
        directives: directives,
        operationTypes: operationTypes,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ScalarTypeExtension :
     *   - extend scalar Name Directives[Const]
     */
    ;

    __setKey(_proto, "parseScalarTypeExtension", function parseScalarTypeExtension() {
      var _lexer34, _token34;

      var start = (_lexer34 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token34 = _lexer34._ES5ProxyType ? _lexer34.get("token") : _lexer34.token);

      __callKey1$1(this, "expectKeyword", 'extend');

      __callKey1$1(this, "expectKeyword", 'scalar');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      if ((directives._ES5ProxyType ? directives.get("length") : directives.length) === 0) {
        throw __callKey0(this, "unexpected");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("SCALAR_TYPE_EXTENSION") : Kind.SCALAR_TYPE_EXTENSION,
        name: name,
        directives: directives,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * ObjectTypeExtension :
     *  - extend type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
     *  - extend type Name ImplementsInterfaces? Directives[Const]
     *  - extend type Name ImplementsInterfaces
     */
    ;

    __setKey(_proto, "parseObjectTypeExtension", function parseObjectTypeExtension() {
      var _lexer35, _token35;

      var start = (_lexer35 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token35 = _lexer35._ES5ProxyType ? _lexer35.get("token") : _lexer35.token);

      __callKey1$1(this, "expectKeyword", 'extend');

      __callKey1$1(this, "expectKeyword", 'type');

      var name = __callKey0(this, "parseName");

      var interfaces = __callKey0(this, "parseImplementsInterfaces");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var fields = __callKey0(this, "parseFieldsDefinition");

      if ((interfaces._ES5ProxyType ? interfaces.get("length") : interfaces.length) === 0 && (directives._ES5ProxyType ? directives.get("length") : directives.length) === 0 && (fields._ES5ProxyType ? fields.get("length") : fields.length) === 0) {
        throw __callKey0(this, "unexpected");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("OBJECT_TYPE_EXTENSION") : Kind.OBJECT_TYPE_EXTENSION,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * InterfaceTypeExtension :
     *  - extend interface Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
     *  - extend interface Name ImplementsInterfaces? Directives[Const]
     *  - extend interface Name ImplementsInterfaces
     */
    ;

    __setKey(_proto, "parseInterfaceTypeExtension", function parseInterfaceTypeExtension() {
      var _lexer36, _token36;

      var start = (_lexer36 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token36 = _lexer36._ES5ProxyType ? _lexer36.get("token") : _lexer36.token);

      __callKey1$1(this, "expectKeyword", 'extend');

      __callKey1$1(this, "expectKeyword", 'interface');

      var name = __callKey0(this, "parseName");

      var interfaces = __callKey0(this, "parseImplementsInterfaces");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var fields = __callKey0(this, "parseFieldsDefinition");

      if ((interfaces._ES5ProxyType ? interfaces.get("length") : interfaces.length) === 0 && (directives._ES5ProxyType ? directives.get("length") : directives.length) === 0 && (fields._ES5ProxyType ? fields.get("length") : fields.length) === 0) {
        throw __callKey0(this, "unexpected");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("INTERFACE_TYPE_EXTENSION") : Kind.INTERFACE_TYPE_EXTENSION,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * UnionTypeExtension :
     *   - extend union Name Directives[Const]? UnionMemberTypes
     *   - extend union Name Directives[Const]
     */
    ;

    __setKey(_proto, "parseUnionTypeExtension", function parseUnionTypeExtension() {
      var _lexer37, _token37;

      var start = (_lexer37 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token37 = _lexer37._ES5ProxyType ? _lexer37.get("token") : _lexer37.token);

      __callKey1$1(this, "expectKeyword", 'extend');

      __callKey1$1(this, "expectKeyword", 'union');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var types = __callKey0(this, "parseUnionMemberTypes");

      if ((directives._ES5ProxyType ? directives.get("length") : directives.length) === 0 && (types._ES5ProxyType ? types.get("length") : types.length) === 0) {
        throw __callKey0(this, "unexpected");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("UNION_TYPE_EXTENSION") : Kind.UNION_TYPE_EXTENSION,
        name: name,
        directives: directives,
        types: types,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * EnumTypeExtension :
     *   - extend enum Name Directives[Const]? EnumValuesDefinition
     *   - extend enum Name Directives[Const]
     */
    ;

    __setKey(_proto, "parseEnumTypeExtension", function parseEnumTypeExtension() {
      var _lexer38, _token38;

      var start = (_lexer38 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token38 = _lexer38._ES5ProxyType ? _lexer38.get("token") : _lexer38.token);

      __callKey1$1(this, "expectKeyword", 'extend');

      __callKey1$1(this, "expectKeyword", 'enum');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var values = __callKey0(this, "parseEnumValuesDefinition");

      if ((directives._ES5ProxyType ? directives.get("length") : directives.length) === 0 && (values._ES5ProxyType ? values.get("length") : values.length) === 0) {
        throw __callKey0(this, "unexpected");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("ENUM_TYPE_EXTENSION") : Kind.ENUM_TYPE_EXTENSION,
        name: name,
        directives: directives,
        values: values,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * InputObjectTypeExtension :
     *   - extend input Name Directives[Const]? InputFieldsDefinition
     *   - extend input Name Directives[Const]
     */
    ;

    __setKey(_proto, "parseInputObjectTypeExtension", function parseInputObjectTypeExtension() {
      var _lexer39, _token39;

      var start = (_lexer39 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token39 = _lexer39._ES5ProxyType ? _lexer39.get("token") : _lexer39.token);

      __callKey1$1(this, "expectKeyword", 'extend');

      __callKey1$1(this, "expectKeyword", 'input');

      var name = __callKey0(this, "parseName");

      var directives = __callKey1$1(this, "parseDirectives", true);

      var fields = __callKey0(this, "parseInputFieldsDefinition");

      if ((directives._ES5ProxyType ? directives.get("length") : directives.length) === 0 && (fields._ES5ProxyType ? fields.get("length") : fields.length) === 0) {
        throw __callKey0(this, "unexpected");
      }

      return {
        kind: Kind._ES5ProxyType ? Kind.get("INPUT_OBJECT_TYPE_EXTENSION") : Kind.INPUT_OBJECT_TYPE_EXTENSION,
        name: name,
        directives: directives,
        fields: fields,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * DirectiveDefinition :
     *   - Description? directive @ Name ArgumentsDefinition? `repeatable`? on DirectiveLocations
     */
    ;

    __setKey(_proto, "parseDirectiveDefinition", function parseDirectiveDefinition() {
      var _lexer40, _token40;

      var start = (_lexer40 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token40 = _lexer40._ES5ProxyType ? _lexer40.get("token") : _lexer40.token);

      var description = __callKey0(this, "parseDescription");

      __callKey1$1(this, "expectKeyword", 'directive');

      __callKey1$1(this, "expectToken", TokenKind._ES5ProxyType ? TokenKind.get("AT") : TokenKind.AT);

      var name = __callKey0(this, "parseName");

      var args = __callKey0(this, "parseArgumentDefs");

      var repeatable = __callKey1$1(this, "expectOptionalKeyword", 'repeatable');

      __callKey1$1(this, "expectKeyword", 'on');

      var locations = __callKey0(this, "parseDirectiveLocations");

      return {
        kind: Kind._ES5ProxyType ? Kind.get("DIRECTIVE_DEFINITION") : Kind.DIRECTIVE_DEFINITION,
        description: description,
        name: name,
        arguments: args,
        repeatable: repeatable,
        locations: locations,
        loc: __callKey1$1(this, "loc", start)
      };
    })
    /**
     * DirectiveLocations :
     *   - `|`? DirectiveLocation
     *   - DirectiveLocations | DirectiveLocation
     */
    ;

    __setKey(_proto, "parseDirectiveLocations", function parseDirectiveLocations() {
      // Optional leading pipe
      __callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("PIPE") : TokenKind.PIPE);

      var locations = [];

      do {
        locations.push(__callKey0(this, "parseDirectiveLocation"));
      } while (__callKey1$1(this, "expectOptionalToken", TokenKind._ES5ProxyType ? TokenKind.get("PIPE") : TokenKind.PIPE));

      return locations;
    })
    /*
     * DirectiveLocation :
     *   - ExecutableDirectiveLocation
     *   - TypeSystemDirectiveLocation
     *
     * ExecutableDirectiveLocation : one of
     *   `QUERY`
     *   `MUTATION`
     *   `SUBSCRIPTION`
     *   `FIELD`
     *   `FRAGMENT_DEFINITION`
     *   `FRAGMENT_SPREAD`
     *   `INLINE_FRAGMENT`
     *
     * TypeSystemDirectiveLocation : one of
     *   `SCHEMA`
     *   `SCALAR`
     *   `OBJECT`
     *   `FIELD_DEFINITION`
     *   `ARGUMENT_DEFINITION`
     *   `INTERFACE`
     *   `UNION`
     *   `ENUM`
     *   `ENUM_VALUE`
     *   `INPUT_OBJECT`
     *   `INPUT_FIELD_DEFINITION`
     */
    ;

    __setKey(_proto, "parseDirectiveLocation", function parseDirectiveLocation() {
      var _lexer41, _token41, _name$value, _name$value2;

      var start = (_lexer41 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token41 = _lexer41._ES5ProxyType ? _lexer41.get("token") : _lexer41.token);

      var name = __callKey0(this, "parseName");

      if ((_name$value = name._ES5ProxyType ? name.get("value") : name.value, _name$value2 = DirectiveLocation._ES5ProxyType ? DirectiveLocation.get(_name$value) : DirectiveLocation[_name$value]) !== undefined) {
        return name;
      }

      throw __callKey1$1(this, "unexpected", start);
    }) // Core parsing utility functions

    /**
     * Returns a location object, used to identify the place in
     * the source that created a given parsed object.
     */
    ;

    __setKey(_proto, "loc", function loc(startToken) {
      var _this$_options4;

      if (((_this$_options4 = this._ES5ProxyType ? this.get("_options") : this._options) === null || _this$_options4 === void 0 ? void 0 : _this$_options4._ES5ProxyType ? _this$_options4.get("noLocation") : _this$_options4.noLocation) !== true) {
        var _lexer42, _lastToken, _lexer43, _source;

        return new Location(startToken, (_lexer42 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _lastToken = _lexer42._ES5ProxyType ? _lexer42.get("lastToken") : _lexer42.lastToken), (_lexer43 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _source = _lexer43._ES5ProxyType ? _lexer43.get("source") : _lexer43.source));
      }
    })
    /**
     * Determines if the next token is of a given kind
     */
    ;

    __setKey(_proto, "peek", function peek(kind) {
      var _lexer44, _token42, _kind2;

      return (_lexer44 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token42 = _lexer44._ES5ProxyType ? _lexer44.get("token") : _lexer44.token, _kind2 = _token42._ES5ProxyType ? _token42.get("kind") : _token42.kind) === kind;
    })
    /**
     * If the next token is of the given kind, return that token after advancing
     * the lexer. Otherwise, do not change the parser state and throw an error.
     */
    ;

    __setKey(_proto, "expectToken", function expectToken(kind) {
      var _lexer45, _token43, _lexer46, _source2;

      var token = (_lexer45 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token43 = _lexer45._ES5ProxyType ? _lexer45.get("token") : _lexer45.token);

      if ((token._ES5ProxyType ? token.get("kind") : token.kind) === kind) {
        __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

        return token;
      }

      throw syntaxError((_lexer46 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _source2 = _lexer46._ES5ProxyType ? _lexer46.get("source") : _lexer46.source), token._ES5ProxyType ? token.get("start") : token.start, __concat(__concat("Expected ", getTokenKindDesc(kind), ", found "), getTokenDesc(token), "."));
    })
    /**
     * If the next token is of the given kind, return that token after advancing
     * the lexer. Otherwise, do not change the parser state and return undefined.
     */
    ;

    __setKey(_proto, "expectOptionalToken", function expectOptionalToken(kind) {
      var _lexer47, _token44;

      var token = (_lexer47 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token44 = _lexer47._ES5ProxyType ? _lexer47.get("token") : _lexer47.token);

      if ((token._ES5ProxyType ? token.get("kind") : token.kind) === kind) {
        __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

        return token;
      }

      return undefined;
    })
    /**
     * If the next token is a given keyword, advance the lexer.
     * Otherwise, do not change the parser state and throw an error.
     */
    ;

    __setKey(_proto, "expectKeyword", function expectKeyword(value) {
      var _lexer48, _token45;

      var token = (_lexer48 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token45 = _lexer48._ES5ProxyType ? _lexer48.get("token") : _lexer48.token);

      if ((token._ES5ProxyType ? token.get("kind") : token.kind) === (TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME) && (token._ES5ProxyType ? token.get("value") : token.value) === value) {
        __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");
      } else {
        var _lexer49, _source3;

        throw syntaxError((_lexer49 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _source3 = _lexer49._ES5ProxyType ? _lexer49.get("source") : _lexer49.source), token._ES5ProxyType ? token.get("start") : token.start, __concat(__concat("Expected \"", value, "\", found "), getTokenDesc(token), "."));
      }
    })
    /**
     * If the next token is a given keyword, return "true" after advancing
     * the lexer. Otherwise, do not change the parser state and return "false".
     */
    ;

    __setKey(_proto, "expectOptionalKeyword", function expectOptionalKeyword(value) {
      var _lexer50, _token46;

      var token = (_lexer50 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token46 = _lexer50._ES5ProxyType ? _lexer50.get("token") : _lexer50.token);

      if ((token._ES5ProxyType ? token.get("kind") : token.kind) === (TokenKind._ES5ProxyType ? TokenKind.get("NAME") : TokenKind.NAME) && (token._ES5ProxyType ? token.get("value") : token.value) === value) {
        __callKey0(this._ES5ProxyType ? this.get("_lexer") : this._lexer, "advance");

        return true;
      }

      return false;
    })
    /**
     * Helper function for creating an error when an unexpected lexed token
     * is encountered.
     */
    ;

    __setKey(_proto, "unexpected", function unexpected(atToken) {
      var _lexer51, _token47, _lexer52, _source4;

      var token = atToken !== null && atToken !== void 0 ? atToken : (_lexer51 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _token47 = _lexer51._ES5ProxyType ? _lexer51.get("token") : _lexer51.token);
      return syntaxError((_lexer52 = this._ES5ProxyType ? this.get("_lexer") : this._lexer, _source4 = _lexer52._ES5ProxyType ? _lexer52.get("source") : _lexer52.source), token._ES5ProxyType ? token.get("start") : token.start, __concat("Unexpected ", getTokenDesc(token), "."));
    })
    /**
     * Returns a possibly empty list of parse nodes, determined by
     * the parseFn. This list begins with a lex token of openKind
     * and ends with a lex token of closeKind. Advances the parser
     * to the next lex token after the closing token.
     */
    ;

    __setKey(_proto, "any", function any(openKind, parseFn, closeKind) {
      __callKey1$1(this, "expectToken", openKind);

      var nodes = [];

      while (!__callKey1$1(this, "expectOptionalToken", closeKind)) {
        nodes.push(__callKey1$1(parseFn, "call", this));
      }

      return nodes;
    })
    /**
     * Returns a list of parse nodes, determined by the parseFn.
     * It can be empty only if open token is missing otherwise it will always
     * return non-empty list that begins with a lex token of openKind and ends
     * with a lex token of closeKind. Advances the parser to the next lex token
     * after the closing token.
     */
    ;

    __setKey(_proto, "optionalMany", function optionalMany(openKind, parseFn, closeKind) {
      if (__callKey1$1(this, "expectOptionalToken", openKind)) {
        var nodes = [];

        do {
          nodes.push(__callKey1$1(parseFn, "call", this));
        } while (!__callKey1$1(this, "expectOptionalToken", closeKind));

        return nodes;
      }

      return [];
    })
    /**
     * Returns a non-empty list of parse nodes, determined by
     * the parseFn. This list begins with a lex token of openKind
     * and ends with a lex token of closeKind. Advances the parser
     * to the next lex token after the closing token.
     */
    ;

    __setKey(_proto, "many", function many(openKind, parseFn, closeKind) {
      __callKey1$1(this, "expectToken", openKind);

      var nodes = [];

      do {
        nodes.push(__callKey1$1(parseFn, "call", this));
      } while (!__callKey1$1(this, "expectOptionalToken", closeKind));

      return nodes;
    });

    return Parser;
  }();
  /**
   * A helper function to describe a token as a string for debugging
   */


  function getTokenDesc(token) {
    var value = token._ES5ProxyType ? token.get("value") : token.value;
    return getTokenKindDesc(token._ES5ProxyType ? token.get("kind") : token.kind) + (value != null ? __concat(" \"", value, "\"") : '');
  }
  /**
   * A helper function to describe a token kind as a string for debugging
   */


  function getTokenKindDesc(kind) {
    return isPunctuatorTokenKind(kind) ? __concat("\"", kind, "\"") : kind;
  }

  var parser = /*#__PURE__*/Object.freeze({
    __proto__: null,
    parse: parse,
    parseValue: parseValue,
    parseType: parseType
  });

  var parser$1 = getCjsExportFromNamespace(parser);

  var parse$1 = parser$1._ES5ProxyType ? parser$1.get("parse") : parser$1.parse; // Strip insignificant whitespace
  // Note that this could do a lot more, such as reorder fields etc.

  function normalize(string) {
    return __callKey0(__callKey2(string, "replace", /[\s,]+/g, ' '), "trim");
  } // A map docString -> graphql document


  var docCache = {}; // A map fragmentName -> [normalized source]

  var fragmentSourceMap = {};

  function cacheKeyFromLoc(loc) {
    var _source, _body;

    return normalize(__callKey2((_source = loc._ES5ProxyType ? loc.get("source") : loc.source, _body = _source._ES5ProxyType ? _source.get("body") : _source.body), "substring", loc._ES5ProxyType ? loc.get("start") : loc.start, loc._ES5ProxyType ? loc.get("end") : loc.end));
  } // For testing.


  function resetCaches() {
    docCache = {};
    fragmentSourceMap = {};
  } // Take a unstripped parsed document (query/mutation or even fragment), and
  // check all fragment definitions, checking for name->source uniqueness.
  // We also want to make sure only unique fragments exist in the document.


  var printFragmentWarnings = true;

  function processFragments(ast) {
    var astFragmentMap = {};
    var definitions = [];

    for (var i = 0; i < (_definitions = ast._ES5ProxyType ? ast.get("definitions") : ast.definitions, _length = _definitions._ES5ProxyType ? _definitions.get("length") : _definitions.length); i++) {
      var _definitions, _length, _definitions2, _i;

      var fragmentDefinition = (_definitions2 = ast._ES5ProxyType ? ast.get("definitions") : ast.definitions, _i = _definitions2._ES5ProxyType ? _definitions2.get(i) : _definitions2[i]);

      if ((fragmentDefinition._ES5ProxyType ? fragmentDefinition.get("kind") : fragmentDefinition.kind) === 'FragmentDefinition') {
        var _name, _value, _fragmentName, _sourceKey;

        var fragmentName = (_name = fragmentDefinition._ES5ProxyType ? fragmentDefinition.get("name") : fragmentDefinition.name, _value = _name._ES5ProxyType ? _name.get("value") : _name.value);
        var sourceKey = cacheKeyFromLoc(fragmentDefinition._ES5ProxyType ? fragmentDefinition.get("loc") : fragmentDefinition.loc); // We know something about this fragment

        if (__hasOwnProperty(fragmentSourceMap, fragmentName) && !(_fragmentName = fragmentSourceMap._ES5ProxyType ? fragmentSourceMap.get(fragmentName) : fragmentSourceMap[fragmentName], _sourceKey = _fragmentName._ES5ProxyType ? _fragmentName.get(sourceKey) : _fragmentName[sourceKey])) {
          // this is a problem because the app developer is trying to register another fragment with
          // the same name as one previously registered. So, we tell them about it.
          if (printFragmentWarnings) {
            __callKey1$1(console, "warn", "Warning: fragment with name " + fragmentName + " already exists.\n" + "graphql-tag enforces all fragment names across your application to be unique; read more about\n" + "this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names");
          }

          __setKey(fragmentSourceMap._ES5ProxyType ? fragmentSourceMap.get(fragmentName) : fragmentSourceMap[fragmentName], sourceKey, true);
        } else if (!__hasOwnProperty(fragmentSourceMap, fragmentName)) {
          __setKey(fragmentSourceMap, fragmentName, {});

          __setKey(fragmentSourceMap._ES5ProxyType ? fragmentSourceMap.get(fragmentName) : fragmentSourceMap[fragmentName], sourceKey, true);
        }

        if (!(astFragmentMap._ES5ProxyType ? astFragmentMap.get(sourceKey) : astFragmentMap[sourceKey])) {
          __setKey(astFragmentMap, sourceKey, true);

          definitions.push(fragmentDefinition);
        }
      } else {
        definitions.push(fragmentDefinition);
      }
    }

    __setKey(ast, "definitions", definitions);

    return ast;
  }

  function disableFragmentWarnings() {
    printFragmentWarnings = false;
  }

  function stripLoc(doc, removeLocAtThisLevel) {
    var docType = __callKey1$1(Object.prototype._ES5ProxyType ? Object.prototype.get("toString") : Object.prototype.toString, "call", doc);

    if (docType === '[object Array]') {
      return __callKey1$1(doc, "map", function (d) {
        return stripLoc(d, removeLocAtThisLevel);
      });
    }

    if (docType !== '[object Object]') {
      throw new Error('Unexpected input.');
    } // We don't want to remove the root loc field so we can use it
    // for fragment substitution (see below)


    if (removeLocAtThisLevel && (doc._ES5ProxyType ? doc.get("loc") : doc.loc)) {
      __deleteKey(doc, "loc");
    } // https://github.com/apollographql/graphql-tag/issues/40


    if (doc._ES5ProxyType ? doc.get("loc") : doc.loc) {
      __deleteKey(doc._ES5ProxyType ? doc.get("loc") : doc.loc, "startToken");

      __deleteKey(doc._ES5ProxyType ? doc.get("loc") : doc.loc, "endToken");
    }

    var keys = Object.compatKeys(doc);
    var key;
    var value;
    var valueType;

    for (key in __iterableKey(keys)) {
      if (__hasOwnProperty(keys, key)) {
        var _keys$key, _keys$key2;

        value = (_keys$key = keys._ES5ProxyType ? keys.get(key) : keys[key], _keys$key2 = doc._ES5ProxyType ? doc.get(_keys$key) : doc[_keys$key]);
        valueType = __callKey1$1(Object.prototype._ES5ProxyType ? Object.prototype.get("toString") : Object.prototype.toString, "call", value);

        if (valueType === '[object Object]' || valueType === '[object Array]') {
          __setKey(doc, keys._ES5ProxyType ? keys.get(key) : keys[key], stripLoc(value, true));
        }
      }
    }

    return doc;
  }

  var experimentalFragmentVariables = false;

  function parseDocument(doc) {
    var cacheKey = normalize(doc);

    if (docCache._ES5ProxyType ? docCache.get(cacheKey) : docCache[cacheKey]) {
      return docCache._ES5ProxyType ? docCache.get(cacheKey) : docCache[cacheKey];
    }

    var parsed = parse$1(doc, {
      experimentalFragmentVariables: experimentalFragmentVariables
    });

    if (!parsed || (parsed._ES5ProxyType ? parsed.get("kind") : parsed.kind) !== 'Document') {
      throw new Error('Not a valid GraphQL document.');
    } // check that all "new" fragments inside the documents are consistent with
    // existing fragments of the same name


    parsed = processFragments(parsed);
    parsed = stripLoc(parsed, false);

    __setKey(docCache, cacheKey, parsed);

    return parsed;
  }

  function enableExperimentalFragmentVariables() {
    experimentalFragmentVariables = true;
  }

  function disableExperimentalFragmentVariables() {
    experimentalFragmentVariables = false;
  } // XXX This should eventually disallow arbitrary string interpolation, like Relay does


  function gql()
  /* arguments */
  {
    var args = __callKey1$1(Array.prototype._ES5ProxyType ? Array.prototype.get("slice") : Array.prototype.slice, "call", arguments);

    var literals = args._ES5ProxyType ? args.get(0) : args[0]; // We always get literals[0] and then matching post literals for each arg given

    var result = typeof literals === "string" ? literals : literals._ES5ProxyType ? literals.get(0) : literals[0];

    for (var i = 1; i < (args._ES5ProxyType ? args.get("length") : args.length); i++) {
      var _i2, _kind, _i3, _kind2;

      if ((args._ES5ProxyType ? args.get(i) : args[i]) && (_i2 = args._ES5ProxyType ? args.get(i) : args[i], _kind = _i2._ES5ProxyType ? _i2.get("kind") : _i2.kind) && (_i3 = args._ES5ProxyType ? args.get(i) : args[i], _kind2 = _i3._ES5ProxyType ? _i3.get("kind") : _i3.kind) === 'Document') {
        var _i4, _loc, _source2, _body2;

        result += (_i4 = args._ES5ProxyType ? args.get(i) : args[i], _loc = _i4._ES5ProxyType ? _i4.get("loc") : _i4.loc, _source2 = _loc._ES5ProxyType ? _loc.get("source") : _loc.source, _body2 = _source2._ES5ProxyType ? _source2.get("body") : _source2.body);
      } else {
        result += args._ES5ProxyType ? args.get(i) : args[i];
      }

      result += literals._ES5ProxyType ? literals.get(i) : literals[i];
    }

    return parseDocument(result);
  } // Support typescript, which isn't as nice as Babel about default exports


  __setKey(gql, "default", gql);

  __setKey(gql, "resetCaches", resetCaches);

  __setKey(gql, "disableFragmentWarnings", disableFragmentWarnings);

  __setKey(gql, "enableExperimentalFragmentVariables", enableExperimentalFragmentVariables);

  __setKey(gql, "disableExperimentalFragmentVariables", disableExperimentalFragmentVariables);

  var src = gql;

  var APOLLO_KEY = "__lwcapolloc_client__";
  function getClient() {
    return window._ES5ProxyType ? window.get(APOLLO_KEY) : window[APOLLO_KEY];
  }
  function setClient(client) {
    return __setKey(window, APOLLO_KEY, client);
  }

  function _objectSpread(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i] != null ? arguments[i] : {};
      var ownKeys = Object.compatKeys(source);

      if (typeof Object.getOwnPropertySymbols === 'function') {
        ownKeys = __concat(ownKeys, __callKey1$1(Object.getOwnPropertySymbols(source), "filter", function (sym) {
          var _Object$compatGetOwnP, _enumerable;

          return _Object$compatGetOwnP = Object.compatGetOwnPropertyDescriptor(source, sym), _enumerable = _Object$compatGetOwnP._ES5ProxyType ? _Object$compatGetOwnP.get("enumerable") : _Object$compatGetOwnP.enumerable;
        }));
      }

      __callKey1$1(ownKeys, "forEach", function (key) {
        _defineProperty$1(target, key, source._ES5ProxyType ? source.get(key) : source[key]);
      });
    }

    return target;
  }

  function _defineProperty$1(obj, key, value) {
    if (__inKey$1(obj, key)) {
      Object.compatDefineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      __setKey(obj, key, value);
    }

    return obj;
  }

  function _objectWithoutProperties(source, excluded) {
    if (source == null) return {};

    var target = _objectWithoutPropertiesLoose(source, excluded);

    var key, i;

    if (Object.getOwnPropertySymbols) {
      var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

      for (i = 0; i < (sourceSymbolKeys._ES5ProxyType ? sourceSymbolKeys.get("length") : sourceSymbolKeys.length); i++) {
        key = sourceSymbolKeys._ES5ProxyType ? sourceSymbolKeys.get(i) : sourceSymbolKeys[i];
        if (__callKey1$1(excluded, "indexOf", key) >= 0) continue;
        if (!__callKey2(Object.prototype._ES5ProxyType ? Object.prototype.get("propertyIsEnumerable") : Object.prototype.propertyIsEnumerable, "call", source, key)) continue;

        __setKey(target, key, source._ES5ProxyType ? source.get(key) : source[key]);
      }
    }

    return target;
  }

  function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.compatKeys(source);
    var key, i;

    for (i = 0; i < (sourceKeys._ES5ProxyType ? sourceKeys.get("length") : sourceKeys.length); i++) {
      key = sourceKeys._ES5ProxyType ? sourceKeys.get(i) : sourceKeys[i];
      if (__callKey1$1(excluded, "indexOf", key) >= 0) continue;

      __setKey(target, key, source._ES5ProxyType ? source.get(key) : source[key]);
    }

    return target;
  }
  var useQuery =
  /*#__PURE__*/
  function () {
    function useQuery(dataCallback) {
      classCallCheck(this, useQuery);

      __setKey(this, "connected", false);

      __setKey(this, "dataCallback", dataCallback);

      __setKey(this, "pendingResult", {
        client: undefined,
        loading: false,
        data: undefined,
        error: undefined,
        initialized: false,
        fetch: __callKey1$1(this._ES5ProxyType ? this.get("fetch") : this.fetch, "bind", this)
      });
    }

    createClass(useQuery, [{
      key: "update",
      value: function update(config) {
        var client = config._ES5ProxyType ? config.get("client") : config.client,
            lazy = config._ES5ProxyType ? config.get("lazy") : config.lazy,
            props = _objectWithoutProperties(config, ["client", "lazy"]);

        __setKey(this, "apolloOptions", props);

        __setKey(this._ES5ProxyType ? this.get("pendingResult") : this.pendingResult, "client", client || getClient());

        if (!lazy) {
          __callKey0(this, "fetch");
        } else {
          __callKey0(this, "sendUpdate");
        }
      }
    }, {
      key: "connect",
      value: function connect() {
        __setKey(this, "connected", true);

        __callKey0(this, "sendUpdate");
      }
    }, {
      key: "disconnect",
      value: function disconnect() {
        __setKey(this, "connected", false);

        if (this._ES5ProxyType ? this.get("subscription") : this.subscription) {
          __callKey0(this._ES5ProxyType ? this.get("subscription") : this.subscription, "unsubscribe");
        }
      }
    }, {
      key: "sendUpdate",
      value: function sendUpdate() {
        if (this._ES5ProxyType ? this.get("connected") : this.connected) {
          // Make a copy to make the notification effective and prevent changes (ex: client instance)
          var o = Object.compatAssign({}, this._ES5ProxyType ? this.get("pendingResult") : this.pendingResult);

          __callKey1$1(this, "dataCallback", o);
        }
      }
    }, {
      key: "fetch",
      value: function fetch(options) {
        var _this = this;

        var mergedOptions = _objectSpread({}, this._ES5ProxyType ? this.get("apolloOptions") : this.apolloOptions, options);

        __setKey(this._ES5ProxyType ? this.get("pendingResult") : this.pendingResult, "loading", true);

        __callKey0(this, "sendUpdate");

        try {
          var _pendingResult, _client;

          if (this._ES5ProxyType ? this.get("subscription") : this.subscription) {
            __callKey0(this._ES5ProxyType ? this.get("subscription") : this.subscription, "unsubscribe");
          }

          __setKey(this, "observableQuery", __callKey1$1((_pendingResult = this._ES5ProxyType ? this.get("pendingResult") : this.pendingResult, _client = _pendingResult._ES5ProxyType ? _pendingResult.get("client") : _pendingResult.client), "watchQuery", mergedOptions));

          __setKey(this, "subscription", __callKey1$1(this._ES5ProxyType ? this.get("observableQuery") : this.observableQuery, "subscribe", function (_ref) {
            var data = _ref._ES5ProxyType ? _ref.get("data") : _ref.data,
                loading = _ref._ES5ProxyType ? _ref.get("loading") : _ref.loading,
                errors = _ref._ES5ProxyType ? _ref.get("errors") : _ref.errors;
            Object.compatAssign(_this._ES5ProxyType ? _this.get("pendingResult") : _this.pendingResult, {
              loading: loading,
              data: data,
              error: errors,
              initialized: true
            });

            __callKey0(_this, "sendUpdate");
          }));
        } catch (error) {
          Object.compatAssign(this._ES5ProxyType ? this.get("pendingResult") : this.pendingResult, {
            loading: false,
            data: undefined,
            error: error,
            initialized: true
          });

          __callKey0(this, "sendUpdate");
        }
      }
    }]);

    return useQuery;
  }();

  var __callKey0$1 = Proxy.callKey0;

  var __deleteKey$1 = Proxy.deleteKey;

  var __iterableKey$1 = Proxy.iterableKey;

  var runtime_1 = __callKey1(commonjsHelpers, "createCommonjsModule", function (module) {
    /**
     * Copyright (c) 2014-present, Facebook, Inc.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var runtime = function (exports) {

      var Op = Object.prototype;
      var hasOwn = Op._ES5ProxyType ? Op.get("hasOwnProperty") : Op.hasOwnProperty;
      var undefined$1; // More compressible than void 0.

      var $Symbol = typeof Symbol === "function" ? Symbol : {};
      var iteratorSymbol = ($Symbol._ES5ProxyType ? $Symbol.get("iterator") : $Symbol.iterator) || "@@iterator";
      var asyncIteratorSymbol = ($Symbol._ES5ProxyType ? $Symbol.get("asyncIterator") : $Symbol.asyncIterator) || "@@asyncIterator";
      var toStringTagSymbol = ($Symbol._ES5ProxyType ? $Symbol.get("toStringTag") : $Symbol.toStringTag) || "@@toStringTag";

      function wrap(innerFn, outerFn, self, tryLocsList) {
        // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
        var protoGenerator = outerFn && _instanceof_1(outerFn._ES5ProxyType ? outerFn.get("prototype") : outerFn.prototype, Generator) ? outerFn : Generator;
        var generator = Object.create(protoGenerator._ES5ProxyType ? protoGenerator.get("prototype") : protoGenerator.prototype);
        var context = new Context(tryLocsList || []); // The ._invoke method unifies the implementations of the .next,
        // .throw, and .return methods.

        __setKey$1(generator, "_invoke", makeInvokeMethod(innerFn, self, context));

        return generator;
      }

      __setKey$1(exports, "wrap", wrap); // Try/catch helper to minimize deoptimizations. Returns a completion
      // record like context.tryEntries[i].completion. This interface could
      // have been (and was previously) designed to take a closure to be
      // invoked without arguments, but in all the cases we care about we
      // already have an existing method we want to call, so there's no need
      // to create a new function object. We can even get away with assuming
      // the method takes exactly one argument, since that happens to be true
      // in every case, so we don't have to touch the arguments object. The
      // only additional allocation required is the completion record, which
      // has a stable shape and so hopefully should be cheap to allocate.


      function tryCatch(fn, obj, arg) {
        try {
          return {
            type: "normal",
            arg: __callKey2$1(fn, "call", obj, arg)
          };
        } catch (err) {
          return {
            type: "throw",
            arg: err
          };
        }
      }

      var GenStateSuspendedStart = "suspendedStart";
      var GenStateSuspendedYield = "suspendedYield";
      var GenStateExecuting = "executing";
      var GenStateCompleted = "completed"; // Returning this object from the innerFn has the same effect as
      // breaking out of the dispatch switch statement.

      var ContinueSentinel = {}; // Dummy constructor functions that we use as the .constructor and
      // .constructor.prototype properties for functions that return Generator
      // objects. For full spec compliance, you may wish to configure your
      // minifier not to mangle the names of these two functions.

      function Generator() {}

      function GeneratorFunction() {}

      function GeneratorFunctionPrototype() {} // This is a polyfill for %IteratorPrototype% for environments that
      // don't natively support it.


      var IteratorPrototype = {};

      __setKey$1(IteratorPrototype, iteratorSymbol, function () {
        return this;
      });

      var getProto = Object.getPrototypeOf;
      var NativeIteratorPrototype = getProto && getProto(getProto(values([])));

      if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && __callKey2$1(hasOwn, "call", NativeIteratorPrototype, iteratorSymbol)) {
        // This environment has a native %IteratorPrototype%; use it instead
        // of the polyfill.
        IteratorPrototype = NativeIteratorPrototype;
      }

      var Gp = __setKey$1(GeneratorFunctionPrototype, "prototype", __setKey$1(Generator, "prototype", Object.create(IteratorPrototype)));

      __setKey$1(GeneratorFunction, "prototype", __setKey$1(Gp, "constructor", GeneratorFunctionPrototype));

      __setKey$1(GeneratorFunctionPrototype, "constructor", GeneratorFunction);

      __setKey$1(GeneratorFunctionPrototype, toStringTagSymbol, __setKey$1(GeneratorFunction, "displayName", "GeneratorFunction")); // Helper for defining the .next, .throw, and .return methods of the
      // Iterator interface in terms of a single ._invoke method.


      function defineIteratorMethods(prototype) {
        __callKey1(["next", "throw", "return"], "forEach", function (method) {
          __setKey$1(prototype, method, function (arg) {
            return __callKey2$1(this, "_invoke", method, arg);
          });
        });
      }

      __setKey$1(exports, "isGeneratorFunction", function (genFun) {
        var ctor = typeof genFun === "function" && (genFun._ES5ProxyType ? genFun.get("constructor") : genFun.constructor);
        return ctor ? ctor === GeneratorFunction || // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        ((ctor._ES5ProxyType ? ctor.get("displayName") : ctor.displayName) || (ctor._ES5ProxyType ? ctor.get("name") : ctor.name)) === "GeneratorFunction" : false;
      });

      __setKey$1(exports, "mark", function (genFun) {
        if (Object.setPrototypeOf) {
          Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
        } else {
          __setKey$1(genFun, "__proto__", GeneratorFunctionPrototype);

          if (!__inKey(genFun, toStringTagSymbol)) {
            __setKey$1(genFun, toStringTagSymbol, "GeneratorFunction");
          }
        }

        __setKey$1(genFun, "prototype", Object.create(Gp));

        return genFun;
      }); // Within the body of any async function, `await x` is transformed to
      // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
      // `hasOwn.call(value, "__await")` to determine if the yielded value is
      // meant to be awaited.


      __setKey$1(exports, "awrap", function (arg) {
        return {
          __await: arg
        };
      });

      function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
          var record = tryCatch(generator._ES5ProxyType ? generator.get(method) : generator[method], generator, arg);

          if ((record._ES5ProxyType ? record.get("type") : record.type) === "throw") {
            reject(record._ES5ProxyType ? record.get("arg") : record.arg);
          } else {
            var result = record._ES5ProxyType ? record.get("arg") : record.arg;
            var value = result._ES5ProxyType ? result.get("value") : result.value;

            if (value && _typeof_1(value) === "object" && __callKey2$1(hasOwn, "call", value, "__await")) {
              return __callKey2$1(__callKey1(PromiseImpl, "resolve", value._ES5ProxyType ? value.get("__await") : value.__await), "then", function (value) {
                invoke("next", value, resolve, reject);
              }, function (err) {
                invoke("throw", err, resolve, reject);
              });
            }

            return __callKey2$1(__callKey1(PromiseImpl, "resolve", value), "then", function (unwrapped) {
              // When a yielded Promise is resolved, its final value becomes
              // the .value of the Promise<{value,done}> result for the
              // current iteration.
              __setKey$1(result, "value", unwrapped);

              resolve(result);
            }, function (error) {
              // If a rejected Promise was yielded, throw the rejection back
              // into the async generator function so it can be handled there.
              return invoke("throw", error, resolve, reject);
            });
          }
        }

        var previousPromise;

        function enqueue(method, arg) {
          function callInvokeWithMethodAndArg() {
            return new PromiseImpl(function (resolve, reject) {
              invoke(method, arg, resolve, reject);
            });
          }

          return previousPromise = // If enqueue has been called before, then we want to wait until
          // all previous Promises have been resolved before calling invoke,
          // so that results are always delivered in the correct order. If
          // enqueue has not been called before, then it is important to
          // call invoke immediately, without waiting on a callback to fire,
          // so that the async generator function has the opportunity to do
          // any necessary setup in a predictable way. This predictability
          // is why the Promise constructor synchronously invokes its
          // executor callback, and why async functions synchronously
          // execute code before the first await. Since we implement simple
          // async functions in terms of async generators, it is especially
          // important to get this right, even though it requires care.
          previousPromise ? __callKey2$1(previousPromise, "then", callInvokeWithMethodAndArg, // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
        } // Define the unified helper method that is used to implement .next,
        // .throw, and .return (see defineIteratorMethods).


        __setKey$1(this, "_invoke", enqueue);
      }

      defineIteratorMethods(AsyncIterator._ES5ProxyType ? AsyncIterator.get("prototype") : AsyncIterator.prototype);

      __setKey$1(AsyncIterator._ES5ProxyType ? AsyncIterator.get("prototype") : AsyncIterator.prototype, asyncIteratorSymbol, function () {
        return this;
      });

      __setKey$1(exports, "AsyncIterator", AsyncIterator); // Note that simple async functions are implemented on top of
      // AsyncIterator objects; they just return a Promise for the value of
      // the final result produced by the iterator.


      __setKey$1(exports, "async", function (innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        if (PromiseImpl === void 0) PromiseImpl = Promise;
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return __callKey1(exports, "isGeneratorFunction", outerFn) ? iter // If outerFn is a generator, return the full iterator.
        : __callKey1(__callKey0$1(iter, "next"), "then", function (result) {
          return (result._ES5ProxyType ? result.get("done") : result.done) ? result._ES5ProxyType ? result.get("value") : result.value : __callKey0$1(iter, "next");
        });
      });

      function makeInvokeMethod(innerFn, self, context) {
        var state = GenStateSuspendedStart;
        return function invoke(method, arg) {
          if (state === GenStateExecuting) {
            throw new Error("Generator is already running");
          }

          if (state === GenStateCompleted) {
            if (method === "throw") {
              throw arg;
            } // Be forgiving, per 25.3.3.3.3 of the spec:
            // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume


            return doneResult();
          }

          __setKey$1(context, "method", method);

          __setKey$1(context, "arg", arg);

          while (true) {
            var delegate = context._ES5ProxyType ? context.get("delegate") : context.delegate;

            if (delegate) {
              var delegateResult = maybeInvokeDelegate(delegate, context);

              if (delegateResult) {
                if (delegateResult === ContinueSentinel) continue;
                return delegateResult;
              }
            }

            if ((context._ES5ProxyType ? context.get("method") : context.method) === "next") {
              // Setting context._sent for legacy support of Babel's
              // function.sent implementation.
              __setKey$1(context, "sent", __setKey$1(context, "_sent", context._ES5ProxyType ? context.get("arg") : context.arg));
            } else if ((context._ES5ProxyType ? context.get("method") : context.method) === "throw") {
              if (state === GenStateSuspendedStart) {
                state = GenStateCompleted;
                throw context._ES5ProxyType ? context.get("arg") : context.arg;
              }

              __callKey1(context, "dispatchException", context._ES5ProxyType ? context.get("arg") : context.arg);
            } else if ((context._ES5ProxyType ? context.get("method") : context.method) === "return") {
              __callKey2$1(context, "abrupt", "return", context._ES5ProxyType ? context.get("arg") : context.arg);
            }

            state = GenStateExecuting;
            var record = tryCatch(innerFn, self, context);

            if ((record._ES5ProxyType ? record.get("type") : record.type) === "normal") {
              // If an exception is thrown from innerFn, we leave state ===
              // GenStateExecuting and loop back for another invocation.
              state = (context._ES5ProxyType ? context.get("done") : context.done) ? GenStateCompleted : GenStateSuspendedYield;

              if ((record._ES5ProxyType ? record.get("arg") : record.arg) === ContinueSentinel) {
                continue;
              }

              return {
                value: record._ES5ProxyType ? record.get("arg") : record.arg,
                done: context._ES5ProxyType ? context.get("done") : context.done
              };
            } else if ((record._ES5ProxyType ? record.get("type") : record.type) === "throw") {
              state = GenStateCompleted; // Dispatch the exception by looping back around to the
              // context.dispatchException(context.arg) call above.

              __setKey$1(context, "method", "throw");

              __setKey$1(context, "arg", record._ES5ProxyType ? record.get("arg") : record.arg);
            }
          }
        };
      } // Call delegate.iterator[context.method](context.arg) and handle the
      // result, either by returning a { value, done } result from the
      // delegate iterator, or by modifying context.method and context.arg,
      // setting context.delegate to null, and returning the ContinueSentinel.


      function maybeInvokeDelegate(delegate, context) {
        var _iterator, _context$method, _context$method2;

        var method = (_iterator = delegate._ES5ProxyType ? delegate.get("iterator") : delegate.iterator, _context$method = context._ES5ProxyType ? context.get("method") : context.method, _context$method2 = _iterator._ES5ProxyType ? _iterator.get(_context$method) : _iterator[_context$method]);

        if (method === undefined$1) {
          // A .throw or .return when the delegate iterator has no .throw
          // method always terminates the yield* loop.
          __setKey$1(context, "delegate", null);

          if ((context._ES5ProxyType ? context.get("method") : context.method) === "throw") {
            var _iterator2, _return;

            // Note: ["return"] must be used for ES3 parsing compatibility.
            if (_iterator2 = delegate._ES5ProxyType ? delegate.get("iterator") : delegate.iterator, _return = _iterator2._ES5ProxyType ? _iterator2.get("return") : _iterator2["return"]) {
              // If the delegate iterator has a return method, give it a
              // chance to clean up.
              __setKey$1(context, "method", "return");

              __setKey$1(context, "arg", undefined$1);

              maybeInvokeDelegate(delegate, context);

              if ((context._ES5ProxyType ? context.get("method") : context.method) === "throw") {
                // If maybeInvokeDelegate(context) changed context.method from
                // "return" to "throw", let that override the TypeError below.
                return ContinueSentinel;
              }
            }

            __setKey$1(context, "method", "throw");

            __setKey$1(context, "arg", new TypeError("The iterator does not provide a 'throw' method"));
          }

          return ContinueSentinel;
        }

        var record = tryCatch(method, delegate._ES5ProxyType ? delegate.get("iterator") : delegate.iterator, context._ES5ProxyType ? context.get("arg") : context.arg);

        if ((record._ES5ProxyType ? record.get("type") : record.type) === "throw") {
          __setKey$1(context, "method", "throw");

          __setKey$1(context, "arg", record._ES5ProxyType ? record.get("arg") : record.arg);

          __setKey$1(context, "delegate", null);

          return ContinueSentinel;
        }

        var info = record._ES5ProxyType ? record.get("arg") : record.arg;

        if (!info) {
          __setKey$1(context, "method", "throw");

          __setKey$1(context, "arg", new TypeError("iterator result is not an object"));

          __setKey$1(context, "delegate", null);

          return ContinueSentinel;
        }

        if (info._ES5ProxyType ? info.get("done") : info.done) {
          // Assign the result of the finished delegate to the temporary
          // variable specified by delegate.resultName (see delegateYield).
          __setKey$1(context, delegate._ES5ProxyType ? delegate.get("resultName") : delegate.resultName, info._ES5ProxyType ? info.get("value") : info.value); // Resume execution at the desired location (see delegateYield).


          __setKey$1(context, "next", delegate._ES5ProxyType ? delegate.get("nextLoc") : delegate.nextLoc); // If context.method was "throw" but the delegate handled the
          // exception, let the outer generator proceed normally. If
          // context.method was "next", forget context.arg since it has been
          // "consumed" by the delegate iterator. If context.method was
          // "return", allow the original .return call to continue in the
          // outer generator.


          if ((context._ES5ProxyType ? context.get("method") : context.method) !== "return") {
            __setKey$1(context, "method", "next");

            __setKey$1(context, "arg", undefined$1);
          }
        } else {
          // Re-yield the result returned by the delegate method.
          return info;
        } // The delegate iterator is finished, so forget it and continue with
        // the outer generator.


        __setKey$1(context, "delegate", null);

        return ContinueSentinel;
      } // Define Generator.prototype.{next,throw,return} in terms of the
      // unified ._invoke helper method.


      defineIteratorMethods(Gp);

      __setKey$1(Gp, toStringTagSymbol, "Generator"); // A Generator should always return itself as the iterator object when the
      // @@iterator function is called on it. Some browsers' implementations of the
      // iterator prototype chain incorrectly implement this, causing the Generator
      // object to not be returned from this call. This ensures that doesn't happen.
      // See https://github.com/facebook/regenerator/issues/274 for more details.


      __setKey$1(Gp, iteratorSymbol, function () {
        return this;
      });

      __setKey$1(Gp, "toString", function () {
        return "[object Generator]";
      });

      function pushTryEntry(locs) {
        var entry = {
          tryLoc: locs._ES5ProxyType ? locs.get(0) : locs[0]
        };

        if (__inKey(locs, 1)) {
          __setKey$1(entry, "catchLoc", locs._ES5ProxyType ? locs.get(1) : locs[1]);
        }

        if (__inKey(locs, 2)) {
          __setKey$1(entry, "finallyLoc", locs._ES5ProxyType ? locs.get(2) : locs[2]);

          __setKey$1(entry, "afterLoc", locs._ES5ProxyType ? locs.get(3) : locs[3]);
        }

        (this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries).push(entry);
      }

      function resetTryEntry(entry) {
        var record = (entry._ES5ProxyType ? entry.get("completion") : entry.completion) || {};

        __setKey$1(record, "type", "normal");

        __deleteKey$1(record, "arg");

        __setKey$1(entry, "completion", record);
      }

      function Context(tryLocsList) {
        // The root entry object (effectively a try statement without a catch
        // or a finally block) gives us a place to store values thrown from
        // locations where there is no enclosing try statement.
        __setKey$1(this, "tryEntries", [{
          tryLoc: "root"
        }]);

        __callKey2$1(tryLocsList, "forEach", pushTryEntry, this);

        __callKey1(this, "reset", true);
      }

      __setKey$1(exports, "keys", function (object) {
        var keys = [];

        for (var key in __iterableKey$1(object)) {
          keys.push(key);
        }

        __callKey0$1(keys, "reverse"); // Rather than returning an object with a next method, we keep
        // things simple and return the next function itself.


        return function next() {
          while (keys._ES5ProxyType ? keys.get("length") : keys.length) {
            var key = keys.pop();

            if (__inKey(object, key)) {
              __setKey$1(next, "value", key);

              __setKey$1(next, "done", false);

              return next;
            }
          } // To avoid creating an additional object, we just hang the .value
          // and .done properties off the next function object itself. This
          // also ensures that the minifier will not anonymize the function.


          __setKey$1(next, "done", true);

          return next;
        };
      });

      function values(iterable) {
        if (iterable) {
          var iteratorMethod = iterable._ES5ProxyType ? iterable.get(iteratorSymbol) : iterable[iteratorSymbol];

          if (iteratorMethod) {
            return __callKey1(iteratorMethod, "call", iterable);
          }

          if (typeof (iterable._ES5ProxyType ? iterable.get("next") : iterable.next) === "function") {
            return iterable;
          }

          if (!isNaN(iterable._ES5ProxyType ? iterable.get("length") : iterable.length)) {
            var i = -1,
                next = function next() {
              while (++i < (iterable._ES5ProxyType ? iterable.get("length") : iterable.length)) {
                if (__callKey2$1(hasOwn, "call", iterable, i)) {
                  __setKey$1(next, "value", iterable._ES5ProxyType ? iterable.get(i) : iterable[i]);

                  __setKey$1(next, "done", false);

                  return next;
                }
              }

              __setKey$1(next, "value", undefined$1);

              __setKey$1(next, "done", true);

              return next;
            };

            return __setKey$1(next, "next", next);
          }
        } // Return an iterator with no values.


        return {
          next: doneResult
        };
      }

      __setKey$1(exports, "values", values);

      function doneResult() {
        return {
          value: undefined$1,
          done: true
        };
      }

      __setKey$1(Context, "prototype", {
        constructor: Context,
        reset: function reset(skipTempReset) {
          __setKey$1(this, "prev", 0);

          __setKey$1(this, "next", 0); // Resetting context._sent for legacy support of Babel's
          // function.sent implementation.


          __setKey$1(this, "sent", __setKey$1(this, "_sent", undefined$1));

          __setKey$1(this, "done", false);

          __setKey$1(this, "delegate", null);

          __setKey$1(this, "method", "next");

          __setKey$1(this, "arg", undefined$1);

          __callKey1(this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, "forEach", resetTryEntry);

          if (!skipTempReset) {
            for (var name in __iterableKey$1(this)) {
              // Not sure about the optimal order of these conditions:
              if (__callKey1(name, "charAt", 0) === "t" && __callKey2$1(hasOwn, "call", this, name) && !isNaN(+__callKey1(name, "slice", 1))) {
                __setKey$1(this, name, undefined$1);
              }
            }
          }
        },
        stop: function stop() {
          var _tryEntries, _;

          __setKey$1(this, "done", true);

          var rootEntry = (_tryEntries = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _ = _tryEntries._ES5ProxyType ? _tryEntries.get(0) : _tryEntries[0]);
          var rootRecord = rootEntry._ES5ProxyType ? rootEntry.get("completion") : rootEntry.completion;

          if ((rootRecord._ES5ProxyType ? rootRecord.get("type") : rootRecord.type) === "throw") {
            throw rootRecord._ES5ProxyType ? rootRecord.get("arg") : rootRecord.arg;
          }

          return this._ES5ProxyType ? this.get("rval") : this.rval;
        },
        dispatchException: function dispatchException(exception) {
          if (this._ES5ProxyType ? this.get("done") : this.done) {
            throw exception;
          }

          var context = this;

          function handle(loc, caught) {
            __setKey$1(record, "type", "throw");

            __setKey$1(record, "arg", exception);

            __setKey$1(context, "next", loc);

            if (caught) {
              // If the dispatched exception was caught by a catch block,
              // then let that catch block handle the exception normally.
              __setKey$1(context, "method", "next");

              __setKey$1(context, "arg", undefined$1);
            }

            return !!caught;
          }

          for (var i = (_tryEntries2 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _length = _tryEntries2._ES5ProxyType ? _tryEntries2.get("length") : _tryEntries2.length) - 1; i >= 0; --i) {
            var _tryEntries2, _length, _tryEntries3, _i;

            var entry = (_tryEntries3 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _i = _tryEntries3._ES5ProxyType ? _tryEntries3.get(i) : _tryEntries3[i]);
            var record = entry._ES5ProxyType ? entry.get("completion") : entry.completion;

            if ((entry._ES5ProxyType ? entry.get("tryLoc") : entry.tryLoc) === "root") {
              // Exception thrown outside of any try block that could handle
              // it, so set the completion value of the entire function to
              // throw the exception.
              return handle("end");
            }

            if ((entry._ES5ProxyType ? entry.get("tryLoc") : entry.tryLoc) <= (this._ES5ProxyType ? this.get("prev") : this.prev)) {
              var hasCatch = __callKey2$1(hasOwn, "call", entry, "catchLoc");

              var hasFinally = __callKey2$1(hasOwn, "call", entry, "finallyLoc");

              if (hasCatch && hasFinally) {
                if ((this._ES5ProxyType ? this.get("prev") : this.prev) < (entry._ES5ProxyType ? entry.get("catchLoc") : entry.catchLoc)) {
                  return handle(entry._ES5ProxyType ? entry.get("catchLoc") : entry.catchLoc, true);
                } else if ((this._ES5ProxyType ? this.get("prev") : this.prev) < (entry._ES5ProxyType ? entry.get("finallyLoc") : entry.finallyLoc)) {
                  return handle(entry._ES5ProxyType ? entry.get("finallyLoc") : entry.finallyLoc);
                }
              } else if (hasCatch) {
                if ((this._ES5ProxyType ? this.get("prev") : this.prev) < (entry._ES5ProxyType ? entry.get("catchLoc") : entry.catchLoc)) {
                  return handle(entry._ES5ProxyType ? entry.get("catchLoc") : entry.catchLoc, true);
                }
              } else if (hasFinally) {
                if ((this._ES5ProxyType ? this.get("prev") : this.prev) < (entry._ES5ProxyType ? entry.get("finallyLoc") : entry.finallyLoc)) {
                  return handle(entry._ES5ProxyType ? entry.get("finallyLoc") : entry.finallyLoc);
                }
              } else {
                throw new Error("try statement without catch or finally");
              }
            }
          }
        },
        abrupt: function abrupt(type, arg) {
          for (var i = (_tryEntries4 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _length2 = _tryEntries4._ES5ProxyType ? _tryEntries4.get("length") : _tryEntries4.length) - 1; i >= 0; --i) {
            var _tryEntries4, _length2, _tryEntries5, _i2;

            var entry = (_tryEntries5 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _i2 = _tryEntries5._ES5ProxyType ? _tryEntries5.get(i) : _tryEntries5[i]);

            if ((entry._ES5ProxyType ? entry.get("tryLoc") : entry.tryLoc) <= (this._ES5ProxyType ? this.get("prev") : this.prev) && __callKey2$1(hasOwn, "call", entry, "finallyLoc") && (this._ES5ProxyType ? this.get("prev") : this.prev) < (entry._ES5ProxyType ? entry.get("finallyLoc") : entry.finallyLoc)) {
              var finallyEntry = entry;
              break;
            }
          }

          if (finallyEntry && (type === "break" || type === "continue") && (finallyEntry._ES5ProxyType ? finallyEntry.get("tryLoc") : finallyEntry.tryLoc) <= arg && arg <= (finallyEntry._ES5ProxyType ? finallyEntry.get("finallyLoc") : finallyEntry.finallyLoc)) {
            // Ignore the finally entry if control is not jumping to a
            // location outside the try/catch block.
            finallyEntry = null;
          }

          var record = finallyEntry ? finallyEntry._ES5ProxyType ? finallyEntry.get("completion") : finallyEntry.completion : {};

          __setKey$1(record, "type", type);

          __setKey$1(record, "arg", arg);

          if (finallyEntry) {
            __setKey$1(this, "method", "next");

            __setKey$1(this, "next", finallyEntry._ES5ProxyType ? finallyEntry.get("finallyLoc") : finallyEntry.finallyLoc);

            return ContinueSentinel;
          }

          return __callKey1(this, "complete", record);
        },
        complete: function complete(record, afterLoc) {
          if ((record._ES5ProxyType ? record.get("type") : record.type) === "throw") {
            throw record._ES5ProxyType ? record.get("arg") : record.arg;
          }

          if ((record._ES5ProxyType ? record.get("type") : record.type) === "break" || (record._ES5ProxyType ? record.get("type") : record.type) === "continue") {
            __setKey$1(this, "next", record._ES5ProxyType ? record.get("arg") : record.arg);
          } else if ((record._ES5ProxyType ? record.get("type") : record.type) === "return") {
            __setKey$1(this, "rval", __setKey$1(this, "arg", record._ES5ProxyType ? record.get("arg") : record.arg));

            __setKey$1(this, "method", "return");

            __setKey$1(this, "next", "end");
          } else if ((record._ES5ProxyType ? record.get("type") : record.type) === "normal" && afterLoc) {
            __setKey$1(this, "next", afterLoc);
          }

          return ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
          for (var i = (_tryEntries6 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _length3 = _tryEntries6._ES5ProxyType ? _tryEntries6.get("length") : _tryEntries6.length) - 1; i >= 0; --i) {
            var _tryEntries6, _length3, _tryEntries7, _i3;

            var entry = (_tryEntries7 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _i3 = _tryEntries7._ES5ProxyType ? _tryEntries7.get(i) : _tryEntries7[i]);

            if ((entry._ES5ProxyType ? entry.get("finallyLoc") : entry.finallyLoc) === finallyLoc) {
              __callKey2$1(this, "complete", entry._ES5ProxyType ? entry.get("completion") : entry.completion, entry._ES5ProxyType ? entry.get("afterLoc") : entry.afterLoc);

              resetTryEntry(entry);
              return ContinueSentinel;
            }
          }
        },
        "catch": function _catch(tryLoc) {
          for (var i = (_tryEntries8 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _length4 = _tryEntries8._ES5ProxyType ? _tryEntries8.get("length") : _tryEntries8.length) - 1; i >= 0; --i) {
            var _tryEntries8, _length4, _tryEntries9, _i4;

            var entry = (_tryEntries9 = this._ES5ProxyType ? this.get("tryEntries") : this.tryEntries, _i4 = _tryEntries9._ES5ProxyType ? _tryEntries9.get(i) : _tryEntries9[i]);

            if ((entry._ES5ProxyType ? entry.get("tryLoc") : entry.tryLoc) === tryLoc) {
              var record = entry._ES5ProxyType ? entry.get("completion") : entry.completion;

              if ((record._ES5ProxyType ? record.get("type") : record.type) === "throw") {
                var thrown = record._ES5ProxyType ? record.get("arg") : record.arg;
                resetTryEntry(entry);
              }

              return thrown;
            }
          } // The context.catch method must only be called with a location
          // argument that corresponds to a known catch block.


          throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
          __setKey$1(this, "delegate", {
            iterator: values(iterable),
            resultName: resultName,
            nextLoc: nextLoc
          });

          if ((this._ES5ProxyType ? this.get("method") : this.method) === "next") {
            // Deliberately forget the last sent value so that we don't
            // accidentally pass it on to the delegate.
            __setKey$1(this, "arg", undefined$1);
          }

          return ContinueSentinel;
        }
      }); // Regardless of whether this script is executing as a CommonJS module
      // or not, return the runtime object so that we can declare the variable
      // regeneratorRuntime in the outer scope, which allows this module to be
      // injected easily by `bin/regenerator --include-runtime script.js`.


      return exports;
    }( // If this script is executing as a CommonJS module, use module.exports
    // as the regeneratorRuntime namespace. Otherwise create a new empty
    // object. Either way, the resulting object will be used to initialize
    // the regeneratorRuntime variable at the top of this file.
     module._ES5ProxyType ? module.get("exports") : module.exports );

    try {
      regeneratorRuntime = runtime;
    } catch (accidentalStrictMode) {
      // This module should not be running in strict mode, so the above
      // assignment should always work unless something is misconfigured. Just
      // in case runtime.js accidentally runs in strict mode, we can escape
      // strict mode using a global Function call. This could conceivably fail
      // if a Content Security Policy forbids using Function, but in that case
      // the proper solution is to fix the accidental strict mode problem. If
      // you've misconfigured your bundler to force strict mode and applied a
      // CSP to forbid Function, and you're not willing to fix either of those
      // problems, please detail your unique predicament in a GitHub issue.
      Function("r", "regeneratorRuntime = r")(runtime);
    }
  });

  var regenerator = runtime_1;

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
      var info = __callKey1(gen, key, arg);

      var value = info._ES5ProxyType ? info.get("value") : info.value;
    } catch (error) {
      reject(error);
      return;
    }

    if (info._ES5ProxyType ? info.get("done") : info.done) {
      resolve(value);
    } else {
      __callKey2$1(Promise.resolve(value), "then", _next, _throw);
    }
  }

  function _asyncToGenerator(fn) {
    return function () {
      var self = this,
          args = arguments;
      return new Promise(function (resolve, reject) {
        var gen = __callKey2$1(fn, "apply", self, args);

        function _next(value) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
        }

        function _throw(err) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
        }

        _next(undefined);
      });
    };
  }

  var asyncToGenerator = _asyncToGenerator;

  function stylesheet(hostSelector, shadowSelector, nativeShadow) {
    return ".greet" + shadowSelector + " {font-size: xx-large;}\n.fade-fast" + shadowSelector + " {opacity: 0;animation: fade-in 1s;}\n.fade-slow" + shadowSelector + " {opacity: 0;animation: fade-in 5s;}\n.fade-medium" + shadowSelector + " {opacity: 0;animation: fade-in 2s;}\n@keyframes fade-in {0% {opacity: 0;}\n35% {opacity: 1;}\n65% {opacity: 1;}\n100% {opacity: 0;}\n}.hide" + shadowSelector + " {opacity: 0;}\n.div1" + shadowSelector + "{margin:10px;font-size:1.25em;}\n.table" + shadowSelector + "{border-collapse:collapse;border: 2px solid black;}\n.td" + shadowSelector + "{border: 2px solid black;width:100px;height:100px;text-align:center;}\n";
  }

  var _implicitStylesheets = [stylesheet];

  function tmpl($api, $cmp, $slotset, $ctx) {
    var _results, _loading, _results2, _error, _results3, _error2, _results4, _error3, _results5, _data;

    var api_text = $api._ES5ProxyType ? $api.get("t") : $api.t,
        api_element = $api._ES5ProxyType ? $api.get("h") : $api.h,
        api_dynamic = $api._ES5ProxyType ? $api.get("d") : $api.d;
    return [api_element("div", {
      key: 2
    }, [!($cmp._ES5ProxyType ? $cmp.get("isBundle") : $cmp.isBundle) ? api_element("h1", {
      key: 0
    }, [api_text("Data below: ")]) : null, !($cmp._ES5ProxyType ? $cmp.get("isBundle") : $cmp.isBundle) ? (_results = $cmp._ES5ProxyType ? $cmp.get("results") : $cmp.results, _loading = _results._ES5ProxyType ? _results.get("loading") : _results.loading) ? api_text("Loading....") : null : null, !($cmp._ES5ProxyType ? $cmp.get("isBundle") : $cmp.isBundle) ? (_results2 = $cmp._ES5ProxyType ? $cmp.get("results") : $cmp.results, _error = _results2._ES5ProxyType ? _results2.get("error") : _results2.error) ? api_text("Man, there is an error ") : null : null, !($cmp._ES5ProxyType ? $cmp.get("isBundle") : $cmp.isBundle) ? (_results3 = $cmp._ES5ProxyType ? $cmp.get("results") : $cmp.results, _error2 = _results3._ES5ProxyType ? _results3.get("error") : _results3.error) ? api_dynamic((_results4 = $cmp._ES5ProxyType ? $cmp.get("results") : $cmp.results, _error3 = _results4._ES5ProxyType ? _results4.get("error") : _results4.error)) : null : null, !($cmp._ES5ProxyType ? $cmp.get("isBundle") : $cmp.isBundle) ? (_results5 = $cmp._ES5ProxyType ? $cmp.get("results") : $cmp.results, _data = _results5._ES5ProxyType ? _results5.get("data") : _results5.data) ? api_element("div", {
      key: 1
    }, [api_dynamic($cmp._ES5ProxyType ? $cmp.get("drawTable") : $cmp.drawTable)]) : null : null])];
  }

  var _tmpl$1 = registerTemplate(tmpl);

  __setKey(tmpl, "stylesheets", []);

  if (_implicitStylesheets) {
    __callKey2((tmpl._ES5ProxyType ? tmpl.get("stylesheets") : tmpl.stylesheets).push, "apply", tmpl._ES5ProxyType ? tmpl.get("stylesheets") : tmpl.stylesheets, _implicitStylesheets);
  }

  __setKey(tmpl, "stylesheetTokens", {
    hostAttribute: "my-greeting_greeting-host",
    shadowAttribute: "my-greeting_greeting"
  });

  function _taggedTemplateLiteral(strings, raw) {
    if (!raw) {
      raw = __callKey1(strings, "slice", 0);
    }

    return Object.freeze(Object.defineProperties(strings, {
      raw: {
        value: Object.freeze(raw)
      }
    }));
  }

  var taggedTemplateLiteral = _taggedTemplateLiteral;

  function _templateObject() {
    var data = taggedTemplateLiteral(["\nquery($pidList: [String]) {\n    multipleProducts(pidList: $pidList){\n        id\n        name\n        master{\n                    masterId\n                    orderable\n                    price\n                }\n                price\n                prices{\n                    sale\n                    list\n                }\n                currency\n                longDescription\n                shortDescription\n                variants{\n                productId\n                orderable\n                price\n                variationValues{\n                    color\n                    size\n                }\n                }\n                type{\n                bundle\n                item\n                master\n                option\n                set\n                }\n                productPromotions{\n                calloutMsg\n                promotionalPrice\n                promotionId\n                }\n                pageDescription\n                pageTitle\n                recommendations{\n                recommendedItemId\n                recommendedItemLink\n                }\n    }\n    }\n"]);

    _templateObject = function _templateObject() {
      return data;
    };

    return data;
  }
  var QUERY = src(_templateObject());
  var QUERY$1 = registerComponent(QUERY, {
    tmpl: _tmpl
  });

  function _objectSpread$1(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i] != null ? arguments[i] : {};
      var ownKeys = Object.compatKeys(source);

      if (typeof Object.getOwnPropertySymbols === 'function') {
        ownKeys = __concat(ownKeys, __callKey1$1(Object.getOwnPropertySymbols(source), "filter", function (sym) {
          var _Object$compatGetOwnP, _enumerable;

          return _Object$compatGetOwnP = Object.compatGetOwnPropertyDescriptor(source, sym), _enumerable = _Object$compatGetOwnP._ES5ProxyType ? _Object$compatGetOwnP.get("enumerable") : _Object$compatGetOwnP.enumerable;
        }));
      }

      __callKey1$1(ownKeys, "forEach", function (key) {
        _defineProperty$2(target, key, source._ES5ProxyType ? source.get(key) : source[key]);
      });
    }

    return target;
  }

  function _defineProperty$2(obj, key, value) {
    if (__inKey$1(obj, key)) {
      Object.compatDefineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      __setKey(obj, key, value);
    }

    return obj;
  }

  var Greeting =
  /*#__PURE__*/
  function (_LightningElement) {
    inherits(Greeting, _LightningElement);

    function Greeting() {
      var _getPrototypeOf2, _getPrototypeOf3, _call;

      var _this;

      classCallCheck(this, Greeting);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        __setKey(args, _key, arguments[_key]);
      }

      _this = possibleConstructorReturn(this, __callKey2((_getPrototypeOf3 = _getPrototypeOf2 = getPrototypeOf$1(Greeting), _call = _getPrototypeOf3._ES5ProxyType ? _getPrototypeOf3.get("call") : _getPrototypeOf3.call), "apply", _getPrototypeOf2, __concat([this], args)));

      __setKey(_this, "isBundle", false);

      __setKey(_this, "attributes", ["name", "price", "shortDescription", "variants"]);

      __setKey(_this, "variables", {
        pidList: ''
      });

      __setKey(_this, "results", void 0);

      return _this;
    }

    createClass(Greeting, [{
      key: "strToArr",
      value: function strToArr(val) {
        __callKey1$1(console, "log", "inside strToArr function");

        var pidStr = val;

        __callKey2(console, "log", "inside strToArr pid: ", pidStr);

        var pidSlice = __callKey2(pidStr, "slice", 1, (pidStr._ES5ProxyType ? pidStr.get("length") : pidStr.length) - 1);

        var pidList = __callKey1$1(pidSlice, "split", ",");

        for (var i = 0; i < (pidList._ES5ProxyType ? pidList.get("length") : pidList.length); i++) {
          __setKey(pidList, i, __callKey0(pidList._ES5ProxyType ? pidList.get(i) : pidList[i], "trim"));

          var tempStr = __callKey0(pidList._ES5ProxyType ? pidList.get(i) : pidList[i], "toString");

          if (__callKey1$1(tempStr, "includes", "bundle")) {
            __setKey(this, "isBundle", true);
          }
        }

        __callKey2(console, "log", "inside strToArr pidList: ", pidList._ES5ProxyType ? pidList.get(1) : pidList[1]);

        return pidList; //this.pidList( this.pidList);
      }
    }, {
      key: "connectedCallback",
      value: function () {
        var _connectedCallback = asyncToGenerator(
        /*#__PURE__*/
        __callKey1$1(regenerator, "mark", function _callee() {
          return __callKey3(regenerator, "wrap", function _callee$(_context) {
            while (1) {
              switch (__setKey(_context, "prev", _context._ES5ProxyType ? _context.get("next") : _context.next)) {
                case 0:
                  if ((this._ES5ProxyType ? this.get("isBundle") : this.isBundle) == false) {
                    __callKey1$1(this._ES5ProxyType ? this.get("results") : this.results, "fetch", {
                      variables: _objectSpread$1({}, this._ES5ProxyType ? this.get("variables") : this.variables)
                    });
                  }

                case 1:
                case "end":
                  return __callKey0(_context, "stop");
              }
            }
          }, _callee, this);
        }));

        function connectedCallback() {
          return __callKey2(_connectedCallback, "apply", this, arguments);
        }

        return connectedCallback;
      }()
    }, {
      key: "productArr",
      value: function productArr() {
        var _results, _data, _multipleProducts;

        var multiProd = (_results = this._ES5ProxyType ? this.get("results") : this.results, _data = _results._ES5ProxyType ? _results.get("data") : _results.data, _multipleProducts = _data._ES5ProxyType ? _data.get("multipleProducts") : _data.multipleProducts);

        for (var i = 0; i < (multiProd._ES5ProxyType ? multiProd.get("length") : multiProd.length); i++) {}
      }
    }, {
      key: "pid",
      set: function set(val) {
        var temp = __callKey1$1(this, "strToArr", val);

        __callKey2(console, "log", "inside set pid, pidList:", temp);

        __setKey(this, "variables", _objectSpread$1({}, this._ES5ProxyType ? this.get("variables") : this.variables, {
          pidList: temp
        }));
      },
      get: function get() {
        var _variables, _pidList;

        return _variables = this._ES5ProxyType ? this.get("variables") : this.variables, _pidList = _variables._ES5ProxyType ? _variables.get("pidList") : _variables.pidList;
      }
    }, {
      key: "firstResult",
      get: function get() {
        // console.log("value of pidList", this.pid());
        if ((this._ES5ProxyType ? this.get("isBundle") : this.isBundle) == false) {
          var _results2, _loading, _results3, _data2, _multipleProducts2;

          __callKey2(console, "log", "inside firstResult: ", this._ES5ProxyType ? this.get("results") : this.results);

          return (_results2 = this._ES5ProxyType ? this.get("results") : this.results, _loading = _results2._ES5ProxyType ? _results2.get("loading") : _results2.loading) ? "" : (_results3 = this._ES5ProxyType ? this.get("results") : this.results, _data2 = _results3._ES5ProxyType ? _results3.get("data") : _results3.data, _multipleProducts2 = _data2._ES5ProxyType ? _data2.get("multipleProducts") : _data2.multipleProducts);
        }
      }
    }, {
      key: "drawTable",
      get: function get() {
        var _this2 = this,
            _results4,
            _data3,
            _multipleProducts3,
            _attributes,
            _length;

        var multiProd = (_results4 = this._ES5ProxyType ? this.get("results") : this.results, _data3 = _results4._ES5ProxyType ? _results4.get("data") : _results4.data, _multipleProducts3 = _data3._ES5ProxyType ? _data3.get("multipleProducts") : _data3.multipleProducts);
        var totalRows = (_attributes = this._ES5ProxyType ? this.get("attributes") : this.attributes, _length = _attributes._ES5ProxyType ? _attributes.get("length") : _attributes.length);
        var cellsInRow = multiProd._ES5ProxyType ? multiProd.get("length") : multiProd.length;

        var div1 = __callKey1$1(document, "getElementById", "div1");

        __callKey2(console, "log", "div1", div1);

        var tbl = __callKey1$1(document, "createElement", "table");

        __setKey(tbl, "style", "width: 100%;border-collapse:collapse;border: 2px solid black;"); //tbl.setAttribute("class", "democlass");


        __callKey2(console, "log", "tbl", tbl);

        for (var r = 0; r < totalRows; r++) {
          var _attributes2, _r;

          var row = __callKey1$1(document, "createElement", "tr");

          __setKey(row, "style", "border: 1px solid black;");

          var cell = __callKey1$1(document, "createElement", "td");

          var cellText = __callKey1$1(document, "createTextNode", (_attributes2 = this._ES5ProxyType ? this.get("attributes") : this.attributes, _r = _attributes2._ES5ProxyType ? _attributes2.get(r) : _attributes2[r]));

          __setKey(cell, "style", "border: 1px solid black;width:100px;height:50px;text-align:center;");

          __callKey1$1(cell, "appendChild", cellText);

          __callKey1$1(row, "appendChild", cell);

          var _loop = function _loop() {
            var _attributes3, _r2;

            v = c - 1;
            map = new Map();
            var obj = multiProd._ES5ProxyType ? multiProd.get(v) : multiProd[v];

            __callKey1$1(Object.compatKeys(obj), "forEach", function (key) {
              __callKey2(map, "set", key, obj._ES5ProxyType ? obj.get(key) : obj[key]);
            });

            __callKey1$1(console, "log", "inside drawtable");

            cell = __callKey1$1(document, "createElement", "td");

            __setKey(cell, "style", "border: 1px solid black;width:100px;height:50px;text-align:center;");

            name = (_attributes3 = _this2._ES5ProxyType ? _this2.get("attributes") : _this2.attributes, _r2 = _attributes3._ES5ProxyType ? _attributes3.get(r) : _attributes3[r]);

            __callKey2(console, "log", "val of name: ", name);

            __callKey2(console, "log", "val of map.get(string): ", __callKey1$1(map, "get", name));

            cellText = __callKey1$1(document, "createTextNode", __callKey1$1(map, "get", name));

            __callKey1$1(cell, "appendChild", cellText);

            __callKey1$1(row, "appendChild", cell);
          };

          for (var c = 1; c <= cellsInRow; c++) {
            var v;
            var map;
            var cell;
            var name;
            var cellText;

            _loop();
          }

          __callKey1$1(tbl, "appendChild", row); // add the row to the end of the table body

        }

        __callKey1$1(div1, "appendChild", tbl); // appends <table> into <div1>

      }
    }]);

    return Greeting;
  }(BaseLightningElement);

  registerDecorators(Greeting, {
    publicProps: {
      pid: {
        config: 3
      }
    },
    wire: {
      results: {
        adapter: useQuery,
        params: {
          variables: "variables"
        },
        static: {
          query: QUERY$1,
          lazy: false
        },
        config: function config($cmp) {
          return {
            query: QUERY$1,
            lazy: false,
            variables: $cmp._ES5ProxyType ? $cmp.get("variables") : $cmp.variables
          };
        }
      }
    },
    fields: ["isBundle", "attributes", "variables"]
  });

  var Greeting$1 = registerComponent(Greeting, {
    tmpl: _tmpl$1
  });

  var httpLink = new HttpLink({
    uri: 'https://safe-brushlands-35946.herokuapp.com//'
  });
  var authLink = new ApolloLink(function (operation, forward) {
    // Call the next link in the middleware chain.
    return forward(operation);
  });
  var defaultOptions$1 = {
    watchQuery: {
      fetchPolicy: 'no-cache',
      errorPolicy: 'all'
    },
    query: {
      fetchPolicy: 'no-cache',
      errorPolicy: 'all'
    }
  };
  setClient(new ApolloClient({
    link: __concat(authLink, httpLink),
    // Chain it with the HttpLink
    cache: new InMemoryCache(),
    defaultOptions: defaultOptions$1
  })); // Components to export
  // This function can be removed if the components are not going to be used as custom elements

  if ( typeof customElements !== 'undefined') {
    __callKey2(customElements, "define", 'my-greeting', deprecatedBuildCustomElementConstructor(Greeting$1));
  } // Register a function to create the components dynamically
  // This function can be removed if the components are not going to be created that way


  {
    var delegate = window._ES5ProxyType ? window.get("createLwcComponent") : window.createLwcComponent;

    __setKey(window, "createLwcComponent", function createLwcComponent(name) {
      if (name === "my-greeting") {
        return createElement$1("my-greeting", {
          is: Greeting$1
        });
      }

      return delegate ? delegate(name) : null;
    });
  }

}());
//# sourceMappingURL=lwc-components-compat.js.map
