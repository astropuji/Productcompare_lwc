(function () {
  'use strict';

  /* proxy-compat-disable */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  function detect() {
    // Don't apply polyfill when ProxyCompat is enabled.
    if ('getKey' in Proxy) {
      return false;
    }

    const proxy = new Proxy([3, 4], {});
    const res = [1, 2].concat(proxy);
    return res.length !== 4;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const {
    isConcatSpreadable
  } = Symbol;
  const {
    isArray
  } = Array;
  const {
    slice: ArraySlice,
    unshift: ArrayUnshift,
    shift: ArrayShift
  } = Array.prototype;

  function isObject(O) {
    return typeof O === 'object' ? O !== null : typeof O === 'function';
  } // https://www.ecma-international.org/ecma-262/6.0/#sec-isconcatspreadable


  function isSpreadable(O) {
    if (!isObject(O)) {
      return false;
    }

    const spreadable = O[isConcatSpreadable];
    return spreadable !== undefined ? Boolean(spreadable) : isArray(O);
  } // https://www.ecma-international.org/ecma-262/6.0/#sec-array.prototype.concat


  function ArrayConcatPolyfill(..._args) {
    const O = Object(this);
    const A = [];
    let N = 0;
    const items = ArraySlice.call(arguments);
    ArrayUnshift.call(items, O);

    while (items.length) {
      const E = ArrayShift.call(items);

      if (isSpreadable(E)) {
        let k = 0;
        const length = E.length;

        for (k; k < length; k += 1, N += 1) {
          if (k in E) {
            const subElement = E[k];
            A[N] = subElement;
          }
        }
      } else {
        A[N] = E;
        N += 1;
      }
    }

    return A;
  }

  function apply() {
    Array.prototype.concat = ArrayConcatPolyfill;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  if (detect()) {
    apply();
  }
  /**
   * Copyright (C) 2018 salesforce.com, inc.
   */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function invariant(value, msg) {
    if (!value) {
      throw new Error(`Invariant Violation: ${msg}`);
    }
  }

  function isTrue(value, msg) {
    if (!value) {
      throw new Error(`Assert Violation: ${msg}`);
    }
  }

  function isFalse(value, msg) {
    if (value) {
      throw new Error(`Assert Violation: ${msg}`);
    }
  }

  function fail(msg) {
    throw new Error(msg);
  }

  var assert =
  /*#__PURE__*/
  Object.freeze({
    __proto__: null,
    invariant: invariant,
    isTrue: isTrue,
    isFalse: isFalse,
    fail: fail
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  const {
    assign,
    create,
    defineProperties,
    defineProperty,
    freeze,
    getOwnPropertyDescriptor,
    getOwnPropertyNames,
    getPrototypeOf,
    hasOwnProperty,
    keys,
    seal,
    setPrototypeOf
  } = Object;
  const {
    isArray: isArray$1
  } = Array;
  const {
    filter: ArrayFilter,
    find: ArrayFind,
    indexOf: ArrayIndexOf,
    join: ArrayJoin,
    map: ArrayMap,
    push: ArrayPush,
    reduce: ArrayReduce,
    reverse: ArrayReverse,
    slice: ArraySlice$1,
    splice: ArraySplice,
    unshift: ArrayUnshift$1,
    forEach
  } = Array.prototype;
  const {
    charCodeAt: StringCharCodeAt,
    replace: StringReplace,
    slice: StringSlice,
    toLowerCase: StringToLowerCase
  } = String.prototype;

  function isUndefined(obj) {
    return obj === undefined;
  }

  function isNull(obj) {
    return obj === null;
  }

  function isTrue$1(obj) {
    return obj === true;
  }

  function isFalse$1(obj) {
    return obj === false;
  }

  function isFunction(obj) {
    return typeof obj === 'function';
  }

  function isObject$1(obj) {
    return typeof obj === 'object';
  }

  function isString(obj) {
    return typeof obj === 'string';
  }

  function isNumber(obj) {
    return typeof obj === 'number';
  }

  const OtS = {}.toString;

  function toString(obj) {
    if (obj && obj.toString) {
      // Arrays might hold objects with "null" prototype So using
      // Array.prototype.toString directly will cause an error Iterate through
      // all the items and handle individually.
      if (isArray$1(obj)) {
        return ArrayJoin.call(ArrayMap.call(obj, toString), ',');
      }

      return obj.toString();
    } else if (typeof obj === 'object') {
      return OtS.call(obj);
    } else {
      return obj + emptyString;
    }
  }

  function getPropertyDescriptor(o, p) {
    do {
      const d = getOwnPropertyDescriptor(o, p);

      if (!isUndefined(d)) {
        return d;
      }

      o = getPrototypeOf(o);
    } while (o !== null);
  }

  const emptyString = '';
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * According to the following list, there are 48 aria attributes of which two (ariaDropEffect and
   * ariaGrabbed) are deprecated:
   * https://www.w3.org/TR/wai-aria-1.1/#x6-6-definitions-of-states-and-properties-all-aria-attributes
   *
   * The above list of 46 aria attributes is consistent with the following resources:
   * https://github.com/w3c/aria/pull/708/files#diff-eacf331f0ffc35d4b482f1d15a887d3bR11060
   * https://wicg.github.io/aom/spec/aria-reflection.html
   */

  const AriaPropertyNames = ['ariaActiveDescendant', 'ariaAtomic', 'ariaAutoComplete', 'ariaBusy', 'ariaChecked', 'ariaColCount', 'ariaColIndex', 'ariaColSpan', 'ariaControls', 'ariaCurrent', 'ariaDescribedBy', 'ariaDetails', 'ariaDisabled', 'ariaErrorMessage', 'ariaExpanded', 'ariaFlowTo', 'ariaHasPopup', 'ariaHidden', 'ariaInvalid', 'ariaKeyShortcuts', 'ariaLabel', 'ariaLabelledBy', 'ariaLevel', 'ariaLive', 'ariaModal', 'ariaMultiLine', 'ariaMultiSelectable', 'ariaOrientation', 'ariaOwns', 'ariaPlaceholder', 'ariaPosInSet', 'ariaPressed', 'ariaReadOnly', 'ariaRelevant', 'ariaRequired', 'ariaRoleDescription', 'ariaRowCount', 'ariaRowIndex', 'ariaRowSpan', 'ariaSelected', 'ariaSetSize', 'ariaSort', 'ariaValueMax', 'ariaValueMin', 'ariaValueNow', 'ariaValueText', 'role'];
  const AttrNameToPropNameMap = create(null);
  const PropNameToAttrNameMap = create(null); // Synthetic creation of all AOM property descriptors for Custom Elements

  forEach.call(AriaPropertyNames, propName => {
    // Typescript infers the wrong function type for this particular overloaded method:
    // https://github.com/Microsoft/TypeScript/issues/27972
    // @ts-ignore type-mismatch
    const attrName = StringToLowerCase.call(StringReplace.call(propName, /^aria/, 'aria-'));
    AttrNameToPropNameMap[attrName] = propName;
    PropNameToAttrNameMap[propName] = attrName;
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /*
   * In IE11, symbols are expensive.
   * Due to the nature of the symbol polyfill. This method abstract the
   * creation of symbols, so we can fallback to string when native symbols
   * are not supported. Note that we can't use typeof since it will fail when transpiling.
   */

  const hasNativeSymbolsSupport = Symbol('x').toString() === 'Symbol(x)';

  function createHiddenField(key, namespace) {
    return hasNativeSymbolsSupport ? Symbol(key) : `$$lwc-${namespace}-${key}$$`;
  }

  const hiddenFieldsMap = new WeakMap();

  function setHiddenField(o, field, value) {
    let valuesByField = hiddenFieldsMap.get(o);

    if (isUndefined(valuesByField)) {
      valuesByField = create(null);
      hiddenFieldsMap.set(o, valuesByField);
    }

    valuesByField[field] = value;
  }

  function getHiddenField(o, field) {
    const valuesByField = hiddenFieldsMap.get(o);

    if (!isUndefined(valuesByField)) {
      return valuesByField[field];
    }
  }
  /** version: 1.7.1 */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function detect$1(propName) {
    return Object.getOwnPropertyDescriptor(Element.prototype, propName) === undefined;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const {
    getAttribute,
    hasAttribute,
    removeAttribute,
    removeAttributeNS,
    setAttribute,
    setAttributeNS
  } = Element.prototype;
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  const nodeToAriaPropertyValuesMap = new WeakMap();

  function getAriaPropertyMap(elm) {
    let map = nodeToAriaPropertyValuesMap.get(elm);

    if (map === undefined) {
      map = {};
      nodeToAriaPropertyValuesMap.set(elm, map);
    }

    return map;
  }

  function getNormalizedAriaPropertyValue(value) {
    return value == null ? null : String(value);
  }

  function createAriaPropertyPropertyDescriptor(propName, attrName) {
    return {
      get() {
        const map = getAriaPropertyMap(this);

        if (hasOwnProperty.call(map, propName)) {
          return map[propName];
        } // otherwise just reflect what's in the attribute


        return hasAttribute.call(this, attrName) ? getAttribute.call(this, attrName) : null;
      },

      set(newValue) {
        const normalizedValue = getNormalizedAriaPropertyValue(newValue);
        const map = getAriaPropertyMap(this);
        map[propName] = normalizedValue; // reflect into the corresponding attribute

        if (newValue === null) {
          removeAttribute.call(this, attrName);
        } else {
          setAttribute.call(this, attrName, newValue);
        }
      },

      configurable: true,
      enumerable: true
    };
  }

  function patch(propName) {
    // Typescript is inferring the wrong function type for this particular
    // overloaded method: https://github.com/Microsoft/TypeScript/issues/27972
    // @ts-ignore type-mismatch
    const attrName = PropNameToAttrNameMap[propName];
    const descriptor = createAriaPropertyPropertyDescriptor(propName, attrName);
    Object.defineProperty(Element.prototype, propName, descriptor);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const ElementPrototypeAriaPropertyNames = keys(PropNameToAttrNameMap);

  for (let i = 0, len = ElementPrototypeAriaPropertyNames.length; i < len; i += 1) {
    const propName = ElementPrototypeAriaPropertyNames[i];

    if (detect$1(propName)) {
      patch(propName);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  let nextTickCallbackQueue = [];
  const SPACE_CHAR = 32;
  const EmptyObject = seal(create(null));
  const EmptyArray = seal([]);

  function flushCallbackQueue() {
    {
      if (nextTickCallbackQueue.length === 0) {
        throw new Error(`Internal Error: If callbackQueue is scheduled, it is because there must be at least one callback on this pending queue.`);
      }
    }

    const callbacks = nextTickCallbackQueue;
    nextTickCallbackQueue = []; // reset to a new queue

    for (let i = 0, len = callbacks.length; i < len; i += 1) {
      callbacks[i]();
    }
  }

  function addCallbackToNextTick(callback) {
    {
      if (!isFunction(callback)) {
        throw new Error(`Internal Error: addCallbackToNextTick() can only accept a function callback`);
      }
    }

    if (nextTickCallbackQueue.length === 0) {
      Promise.resolve().then(flushCallbackQueue);
    }

    ArrayPush.call(nextTickCallbackQueue, callback);
  }
  /*
   * Copyright (c) 2019, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const {
    create: create$1
  } = Object;
  const {
    splice: ArraySplice$1,
    indexOf: ArrayIndexOf$1,
    push: ArrayPush$1
  } = Array.prototype;
  const TargetToReactiveRecordMap = new WeakMap();

  function isUndefined$1(obj) {
    return obj === undefined;
  }

  function getReactiveRecord(target) {
    let reactiveRecord = TargetToReactiveRecordMap.get(target);

    if (isUndefined$1(reactiveRecord)) {
      const newRecord = create$1(null);
      reactiveRecord = newRecord;
      TargetToReactiveRecordMap.set(target, newRecord);
    }

    return reactiveRecord;
  }

  let currentReactiveObserver = null;

  function valueMutated(target, key) {
    const reactiveRecord = TargetToReactiveRecordMap.get(target);

    if (!isUndefined$1(reactiveRecord)) {
      const reactiveObservers = reactiveRecord[key];

      if (!isUndefined$1(reactiveObservers)) {
        for (let i = 0, len = reactiveObservers.length; i < len; i += 1) {
          const ro = reactiveObservers[i];
          ro.notify();
        }
      }
    }
  }

  function valueObserved(target, key) {
    // We should determine if an active Observing Record is present to track mutations.
    if (currentReactiveObserver === null) {
      return;
    }

    const ro = currentReactiveObserver;
    const reactiveRecord = getReactiveRecord(target);
    let reactiveObservers = reactiveRecord[key];

    if (isUndefined$1(reactiveObservers)) {
      reactiveObservers = [];
      reactiveRecord[key] = reactiveObservers;
    } else if (reactiveObservers[0] === ro) {
      return; // perf optimization considering that most subscriptions will come from the same record
    }

    if (ArrayIndexOf$1.call(reactiveObservers, ro) === -1) {
      ro.link(reactiveObservers);
    }
  }

  class ReactiveObserver {
    constructor(callback) {
      this.listeners = [];
      this.callback = callback;
    }

    observe(job) {
      const inceptionReactiveRecord = currentReactiveObserver;
      currentReactiveObserver = this;
      let error;

      try {
        job();
      } catch (e) {
        error = Object(e);
      } finally {
        currentReactiveObserver = inceptionReactiveRecord;

        if (error !== undefined) {
          throw error; // eslint-disable-line no-unsafe-finally
        }
      }
    }
    /**
     * This method is responsible for disconnecting the Reactive Observer
     * from any Reactive Record that has a reference to it, to prevent future
     * notifications about previously recorded access.
     */


    reset() {
      const {
        listeners
      } = this;
      const len = listeners.length;

      if (len > 0) {
        for (let i = 0; i < len; i += 1) {
          const set = listeners[i];
          const pos = ArrayIndexOf$1.call(listeners[i], this);
          ArraySplice$1.call(set, pos, 1);
        }

        listeners.length = 0;
      }
    } // friend methods


    notify() {
      this.callback.call(undefined, this);
    }

    link(reactiveObservers) {
      ArrayPush$1.call(reactiveObservers, this); // we keep track of observing records where the observing record was added to so we can do some clean up later on

      ArrayPush$1.call(this.listeners, reactiveObservers);
    }

  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function componentValueMutated(vm, key) {
    valueMutated(vm.component, key);
  }

  function componentValueObserved(vm, key) {
    valueObserved(vm.component, key);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function getComponentTag(vm) {
    return `<${StringToLowerCase.call(vm.tagName)}>`;
  } // TODO [#1695]: Unify getComponentStack and getErrorComponentStack


  function getComponentStack(vm) {
    const stack = [];
    let prefix = '';

    while (!isNull(vm.owner)) {
      ArrayPush.call(stack, prefix + getComponentTag(vm));
      vm = vm.owner;
      prefix += '\t';
    }

    return ArrayJoin.call(stack, '\n');
  }

  function getErrorComponentStack(vm) {
    const wcStack = [];
    let currentVm = vm;

    while (!isNull(currentVm)) {
      ArrayPush.call(wcStack, getComponentTag(currentVm));
      currentVm = currentVm.owner;
    }

    return wcStack.reverse().join('\n\t');
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function logError(message, vm) {
    let msg = `[LWC error]: ${message}`;

    if (!isUndefined(vm)) {
      msg = `${msg}\n${getComponentStack(vm)}`;
    }

    try {
      throw new Error(msg);
    } catch (e) {
      /* eslint-disable-next-line no-console */
      console.error(e);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function handleEvent(event, vnode) {
    const {
      type
    } = event;
    const {
      data: {
        on
      }
    } = vnode;
    const handler = on && on[type]; // call event handler if exists

    if (handler) {
      handler.call(undefined, event);
    }
  }

  function createListener() {
    return function handler(event) {
      handleEvent(event, handler.vnode);
    };
  }

  function updateAllEventListeners(oldVnode, vnode) {
    if (isUndefined(oldVnode.listener)) {
      createAllEventListeners(vnode);
    } else {
      vnode.listener = oldVnode.listener;
      vnode.listener.vnode = vnode;
    }
  }

  function createAllEventListeners(vnode) {
    const {
      data: {
        on
      }
    } = vnode;

    if (isUndefined(on)) {
      return;
    }

    const elm = vnode.elm;
    const listener = vnode.listener = createListener();
    listener.vnode = vnode;
    let name;

    for (name in on) {
      elm.addEventListener(name, listener);
    }
  }

  var modEvents = {
    update: updateAllEventListeners,
    create: createAllEventListeners
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  const defaultDefHTMLPropertyNames = ['accessKey', 'dir', 'draggable', 'hidden', 'id', 'lang', 'spellcheck', 'tabIndex', 'title']; // Few more exceptions that are using the attribute name to match the property in lowercase.
  // this list was compiled from https://msdn.microsoft.com/en-us/library/ms533062(v=vs.85).aspx
  // and https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes
  // Note: this list most be in sync with the compiler as well.

  const HTMLPropertyNamesWithLowercasedReflectiveAttributes = ['accessKey', 'readOnly', 'tabIndex', 'bgColor', 'colSpan', 'rowSpan', 'contentEditable', 'dateTime', 'formAction', 'isMap', 'maxLength', 'useMap'];

  function offsetPropertyErrorMessage(name) {
    return `Using the \`${name}\` property is an anti-pattern because it rounds the value to an integer. Instead, use the \`getBoundingClientRect\` method to obtain fractional values for the size of an element and its position relative to the viewport.`;
  } // Global HTML Attributes & Properties
  // https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes
  // https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement


  const globalHTMLProperties = assign(create(null), {
    accessKey: {
      attribute: 'accesskey'
    },
    accessKeyLabel: {
      readOnly: true
    },
    className: {
      attribute: 'class',
      error: 'Using the `className` property is an anti-pattern because of slow runtime behavior and potential conflicts with classes provided by the owner element. Use the `classList` API instead.'
    },
    contentEditable: {
      attribute: 'contenteditable'
    },
    dataset: {
      readOnly: true,
      error: "Using the `dataset` property is an anti-pattern because it can't be statically analyzed. Expose each property individually using the `@api` decorator instead."
    },
    dir: {
      attribute: 'dir'
    },
    draggable: {
      attribute: 'draggable'
    },
    dropzone: {
      attribute: 'dropzone',
      readOnly: true
    },
    hidden: {
      attribute: 'hidden'
    },
    id: {
      attribute: 'id'
    },
    inputMode: {
      attribute: 'inputmode'
    },
    lang: {
      attribute: 'lang'
    },
    slot: {
      attribute: 'slot',
      error: 'Using the `slot` property is an anti-pattern.'
    },
    spellcheck: {
      attribute: 'spellcheck'
    },
    style: {
      attribute: 'style'
    },
    tabIndex: {
      attribute: 'tabindex'
    },
    title: {
      attribute: 'title'
    },
    translate: {
      attribute: 'translate'
    },
    // additional "global attributes" that are not present in the link above.
    isContentEditable: {
      readOnly: true
    },
    offsetHeight: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetHeight')
    },
    offsetLeft: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetLeft')
    },
    offsetParent: {
      readOnly: true
    },
    offsetTop: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetTop')
    },
    offsetWidth: {
      readOnly: true,
      error: offsetPropertyErrorMessage('offsetWidth')
    },
    role: {
      attribute: 'role'
    }
  });
  const AttrNameToPropNameMap$1 = assign(create(null), AttrNameToPropNameMap);
  const PropNameToAttrNameMap$1 = assign(create(null), PropNameToAttrNameMap);
  forEach.call(defaultDefHTMLPropertyNames, propName => {
    const attrName = StringToLowerCase.call(propName);
    AttrNameToPropNameMap$1[attrName] = propName;
    PropNameToAttrNameMap$1[propName] = attrName;
  });
  forEach.call(HTMLPropertyNamesWithLowercasedReflectiveAttributes, propName => {
    const attrName = StringToLowerCase.call(propName);
    AttrNameToPropNameMap$1[attrName] = propName;
    PropNameToAttrNameMap$1[propName] = attrName;
  });
  const CAPS_REGEX = /[A-Z]/g;
  /**
   * This method maps between property names
   * and the corresponding attribute name.
   */

  function getAttrNameFromPropName(propName) {
    if (isUndefined(PropNameToAttrNameMap$1[propName])) {
      PropNameToAttrNameMap$1[propName] = StringReplace.call(propName, CAPS_REGEX, match => '-' + match.toLowerCase());
    }

    return PropNameToAttrNameMap$1[propName];
  }

  let controlledElement = null;
  let controlledAttributeName;

  function isAttributeLocked(elm, attrName) {
    return elm !== controlledElement || attrName !== controlledAttributeName;
  }

  function lockAttribute(_elm, _key) {
    controlledElement = null;
    controlledAttributeName = undefined;
  }

  function unlockAttribute(elm, key) {
    controlledElement = elm;
    controlledAttributeName = key;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const xlinkNS = 'http://www.w3.org/1999/xlink';
  const xmlNS = 'http://www.w3.org/XML/1998/namespace';
  const ColonCharCode = 58;

  function updateAttrs(oldVnode, vnode) {
    const {
      data: {
        attrs
      }
    } = vnode;

    if (isUndefined(attrs)) {
      return;
    }

    let {
      data: {
        attrs: oldAttrs
      }
    } = oldVnode;

    if (oldAttrs === attrs) {
      return;
    }

    {
      assert.invariant(isUndefined(oldAttrs) || keys(oldAttrs).join(',') === keys(attrs).join(','), `vnode.data.attrs cannot change shape.`);
    }

    const elm = vnode.elm;
    let key;
    oldAttrs = isUndefined(oldAttrs) ? EmptyObject : oldAttrs; // update modified attributes, add new attributes
    // this routine is only useful for data-* attributes in all kind of elements
    // and aria-* in standard elements (custom elements will use props for these)

    for (key in attrs) {
      const cur = attrs[key];
      const old = oldAttrs[key];

      if (old !== cur) {
        unlockAttribute(elm, key);

        if (StringCharCodeAt.call(key, 3) === ColonCharCode) {
          // Assume xml namespace
          elm.setAttributeNS(xmlNS, key, cur);
        } else if (StringCharCodeAt.call(key, 5) === ColonCharCode) {
          // Assume xlink namespace
          elm.setAttributeNS(xlinkNS, key, cur);
        } else if (isNull(cur)) {
          elm.removeAttribute(key);
        } else {
          elm.setAttribute(key, cur);
        }

        lockAttribute();
      }
    }
  }

  const emptyVNode = {
    data: {}
  };
  var modAttrs = {
    create: vnode => updateAttrs(emptyVNode, vnode),
    update: updateAttrs
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  function isLiveBindingProp(sel, key) {
    // For properties with live bindings, we read values from the DOM element
    // instead of relying on internally tracked values.
    return sel === 'input' && (key === 'value' || key === 'checked');
  }

  function update(oldVnode, vnode) {
    const props = vnode.data.props;

    if (isUndefined(props)) {
      return;
    }

    const oldProps = oldVnode.data.props;

    if (oldProps === props) {
      return;
    }

    {
      assert.invariant(isUndefined(oldProps) || keys(oldProps).join(',') === keys(props).join(','), 'vnode.data.props cannot change shape.');
    }

    const elm = vnode.elm;
    const isFirstPatch = isUndefined(oldProps);
    const {
      sel
    } = vnode;

    for (const key in props) {
      const cur = props[key];

      {
        if (!(key in elm)) {
          // TODO [#1297]: Move this validation to the compiler
          assert.fail(`Unknown public property "${key}" of element <${sel}>. This is likely a typo on the corresponding attribute "${getAttrNameFromPropName(key)}".`);
        }
      } // if it is the first time this element is patched, or the current value is different to the previous value...


      if (isFirstPatch || cur !== (isLiveBindingProp(sel, key) ? elm[key] : oldProps[key])) {
        elm[key] = cur;
      }
    }
  }

  const emptyVNode$1 = {
    data: {}
  };
  var modProps = {
    create: vnode => update(emptyVNode$1, vnode),
    update
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  const classNameToClassMap = create(null);

  function getMapFromClassName(className) {
    // Intentionally using == to match undefined and null values from computed style attribute
    if (className == null) {
      return EmptyObject;
    } // computed class names must be string


    className = isString(className) ? className : className + '';
    let map = classNameToClassMap[className];

    if (map) {
      return map;
    }

    map = create(null);
    let start = 0;
    let o;
    const len = className.length;

    for (o = 0; o < len; o++) {
      if (StringCharCodeAt.call(className, o) === SPACE_CHAR) {
        if (o > start) {
          map[StringSlice.call(className, start, o)] = true;
        }

        start = o + 1;
      }
    }

    if (o > start) {
      map[StringSlice.call(className, start, o)] = true;
    }

    classNameToClassMap[className] = map;

    {
      // just to make sure that this object never changes as part of the diffing algo
      freeze(map);
    }

    return map;
  }

  function updateClassAttribute(oldVnode, vnode) {
    const {
      elm,
      data: {
        className: newClass
      }
    } = vnode;
    const {
      data: {
        className: oldClass
      }
    } = oldVnode;

    if (oldClass === newClass) {
      return;
    }

    const {
      classList
    } = elm;
    const newClassMap = getMapFromClassName(newClass);
    const oldClassMap = getMapFromClassName(oldClass);
    let name;

    for (name in oldClassMap) {
      // remove only if it is not in the new class collection and it is not set from within the instance
      if (isUndefined(newClassMap[name])) {
        classList.remove(name);
      }
    }

    for (name in newClassMap) {
      if (isUndefined(oldClassMap[name])) {
        classList.add(name);
      }
    }
  }

  const emptyVNode$2 = {
    data: {}
  };
  var modComputedClassName = {
    create: vnode => updateClassAttribute(emptyVNode$2, vnode),
    update: updateClassAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  function updateStyleAttribute(oldVnode, vnode) {
    const {
      style: newStyle
    } = vnode.data;

    if (oldVnode.data.style === newStyle) {
      return;
    }

    const elm = vnode.elm;
    const {
      style
    } = elm;

    if (!isString(newStyle) || newStyle === '') {
      removeAttribute.call(elm, 'style');
    } else {
      style.cssText = newStyle;
    }
  }

  const emptyVNode$3 = {
    data: {}
  };
  var modComputedStyle = {
    create: vnode => updateStyleAttribute(emptyVNode$3, vnode),
    update: updateStyleAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // The compiler takes care of transforming the inline classnames into an object. It's faster to set the
  // different classnames properties individually instead of via a string.

  function createClassAttribute(vnode) {
    const {
      elm,
      data: {
        classMap
      }
    } = vnode;

    if (isUndefined(classMap)) {
      return;
    }

    const {
      classList
    } = elm;

    for (const name in classMap) {
      classList.add(name);
    }
  }

  var modStaticClassName = {
    create: createClassAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // The compiler takes care of transforming the inline style into an object. It's faster to set the
  // different style properties individually instead of via a string.

  function createStyleAttribute(vnode) {
    const {
      elm,
      data: {
        styleMap
      }
    } = vnode;

    if (isUndefined(styleMap)) {
      return;
    }

    const {
      style
    } = elm;

    for (const name in styleMap) {
      style[name] = styleMap[name];
    }
  }

  var modStaticStyle = {
    create: createStyleAttribute
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
  @license
  Copyright (c) 2015 Simon Friis Vindum.
  This code may only be used under the MIT License found at
  https://github.com/snabbdom/snabbdom/blob/master/LICENSE
  Code distributed by Snabbdom as part of the Snabbdom project at
  https://github.com/snabbdom/snabbdom/
  */

  function isUndef(s) {
    return s === undefined;
  }

  function sameVnode(vnode1, vnode2) {
    return vnode1.key === vnode2.key && vnode1.sel === vnode2.sel;
  }

  function isVNode(vnode) {
    return vnode != null;
  }

  function createKeyToOldIdx(children, beginIdx, endIdx) {
    const map = {};
    let j, key, ch; // TODO [#1637]: simplify this by assuming that all vnodes has keys

    for (j = beginIdx; j <= endIdx; ++j) {
      ch = children[j];

      if (isVNode(ch)) {
        key = ch.key;

        if (key !== undefined) {
          map[key] = j;
        }
      }
    }

    return map;
  }

  function addVnodes(parentElm, before, vnodes, startIdx, endIdx) {
    for (; startIdx <= endIdx; ++startIdx) {
      const ch = vnodes[startIdx];

      if (isVNode(ch)) {
        ch.hook.create(ch);
        ch.hook.insert(ch, parentElm, before);
      }
    }
  }

  function removeVnodes(parentElm, vnodes, startIdx, endIdx) {
    for (; startIdx <= endIdx; ++startIdx) {
      const ch = vnodes[startIdx]; // text nodes do not have logic associated to them

      if (isVNode(ch)) {
        ch.hook.remove(ch, parentElm);
      }
    }
  }

  function updateDynamicChildren(parentElm, oldCh, newCh) {
    let oldStartIdx = 0;
    let newStartIdx = 0;
    let oldEndIdx = oldCh.length - 1;
    let oldStartVnode = oldCh[0];
    let oldEndVnode = oldCh[oldEndIdx];
    let newEndIdx = newCh.length - 1;
    let newStartVnode = newCh[0];
    let newEndVnode = newCh[newEndIdx];
    let oldKeyToIdx;
    let idxInOld;
    let elmToMove;
    let before;

    while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
      if (!isVNode(oldStartVnode)) {
        oldStartVnode = oldCh[++oldStartIdx]; // Vnode might have been moved left
      } else if (!isVNode(oldEndVnode)) {
        oldEndVnode = oldCh[--oldEndIdx];
      } else if (!isVNode(newStartVnode)) {
        newStartVnode = newCh[++newStartIdx];
      } else if (!isVNode(newEndVnode)) {
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldStartVnode, newStartVnode)) {
        patchVnode(oldStartVnode, newStartVnode);
        oldStartVnode = oldCh[++oldStartIdx];
        newStartVnode = newCh[++newStartIdx];
      } else if (sameVnode(oldEndVnode, newEndVnode)) {
        patchVnode(oldEndVnode, newEndVnode);
        oldEndVnode = oldCh[--oldEndIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldStartVnode, newEndVnode)) {
        // Vnode moved right
        patchVnode(oldStartVnode, newEndVnode);
        newEndVnode.hook.move(oldStartVnode, parentElm, oldEndVnode.elm.nextSibling);
        oldStartVnode = oldCh[++oldStartIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldEndVnode, newStartVnode)) {
        // Vnode moved left
        patchVnode(oldEndVnode, newStartVnode);
        newStartVnode.hook.move(oldEndVnode, parentElm, oldStartVnode.elm);
        oldEndVnode = oldCh[--oldEndIdx];
        newStartVnode = newCh[++newStartIdx];
      } else {
        if (oldKeyToIdx === undefined) {
          oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx);
        }

        idxInOld = oldKeyToIdx[newStartVnode.key];

        if (isUndef(idxInOld)) {
          // New element
          newStartVnode.hook.create(newStartVnode);
          newStartVnode.hook.insert(newStartVnode, parentElm, oldStartVnode.elm);
          newStartVnode = newCh[++newStartIdx];
        } else {
          elmToMove = oldCh[idxInOld];

          if (isVNode(elmToMove)) {
            if (elmToMove.sel !== newStartVnode.sel) {
              // New element
              newStartVnode.hook.create(newStartVnode);
              newStartVnode.hook.insert(newStartVnode, parentElm, oldStartVnode.elm);
            } else {
              patchVnode(elmToMove, newStartVnode);
              oldCh[idxInOld] = undefined;
              newStartVnode.hook.move(elmToMove, parentElm, oldStartVnode.elm);
            }
          }

          newStartVnode = newCh[++newStartIdx];
        }
      }
    }

    if (oldStartIdx <= oldEndIdx || newStartIdx <= newEndIdx) {
      if (oldStartIdx > oldEndIdx) {
        const n = newCh[newEndIdx + 1];
        before = isVNode(n) ? n.elm : null;
        addVnodes(parentElm, before, newCh, newStartIdx, newEndIdx);
      } else {
        removeVnodes(parentElm, oldCh, oldStartIdx, oldEndIdx);
      }
    }
  }

  function updateStaticChildren(parentElm, oldCh, newCh) {
    const {
      length
    } = newCh;

    if (oldCh.length === 0) {
      // the old list is empty, we can directly insert anything new
      addVnodes(parentElm, null, newCh, 0, length);
      return;
    } // if the old list is not empty, the new list MUST have the same
    // amount of nodes, that's why we call this static children


    let referenceElm = null;

    for (let i = length - 1; i >= 0; i -= 1) {
      const vnode = newCh[i];
      const oldVNode = oldCh[i];

      if (vnode !== oldVNode) {
        if (isVNode(oldVNode)) {
          if (isVNode(vnode)) {
            // both vnodes must be equivalent, and se just need to patch them
            patchVnode(oldVNode, vnode);
            referenceElm = vnode.elm;
          } else {
            // removing the old vnode since the new one is null
            oldVNode.hook.remove(oldVNode, parentElm);
          }
        } else if (isVNode(vnode)) {
          // this condition is unnecessary
          vnode.hook.create(vnode); // insert the new node one since the old one is null

          vnode.hook.insert(vnode, parentElm, referenceElm);
          referenceElm = vnode.elm;
        }
      }
    }
  }

  function patchVnode(oldVnode, vnode) {
    if (oldVnode !== vnode) {
      vnode.elm = oldVnode.elm;
      vnode.hook.update(oldVnode, vnode);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function generateDataDescriptor(options) {
    return assign({
      configurable: true,
      enumerable: true,
      writable: true
    }, options);
  }

  function generateAccessorDescriptor(options) {
    return assign({
      configurable: true,
      enumerable: true
    }, options);
  }

  let isDomMutationAllowed = false;

  function unlockDomMutation() {

    isDomMutationAllowed = true;
  }

  function lockDomMutation() {

    isDomMutationAllowed = false;
  }

  function portalRestrictionErrorMessage(name, type) {
    return `The \`${name}\` ${type} is available only on elements that use the \`lwc:dom="manual"\` directive.`;
  }

  function getNodeRestrictionsDescriptors(node, options = {}) {

    const originalTextContentDescriptor = getPropertyDescriptor(node, 'textContent');
    const originalNodeValueDescriptor = getPropertyDescriptor(node, 'nodeValue');
    const {
      appendChild,
      insertBefore,
      removeChild,
      replaceChild
    } = node;
    return {
      appendChild: generateDataDescriptor({
        value(aChild) {
          if (this instanceof Element && isFalse$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('appendChild', 'method'));
          }

          return appendChild.call(this, aChild);
        }

      }),
      insertBefore: generateDataDescriptor({
        value(newNode, referenceNode) {
          if (!isDomMutationAllowed && this instanceof Element && isFalse$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('insertBefore', 'method'));
          }

          return insertBefore.call(this, newNode, referenceNode);
        }

      }),
      removeChild: generateDataDescriptor({
        value(aChild) {
          if (!isDomMutationAllowed && this instanceof Element && isFalse$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('removeChild', 'method'));
          }

          return removeChild.call(this, aChild);
        }

      }),
      replaceChild: generateDataDescriptor({
        value(newChild, oldChild) {
          if (this instanceof Element && isFalse$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('replaceChild', 'method'));
          }

          return replaceChild.call(this, newChild, oldChild);
        }

      }),
      nodeValue: generateAccessorDescriptor({
        get() {
          return originalNodeValueDescriptor.get.call(this);
        },

        set(value) {
          if (!isDomMutationAllowed && this instanceof Element && isFalse$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('nodeValue', 'property'));
          }

          originalNodeValueDescriptor.set.call(this, value);
        }

      }),
      textContent: generateAccessorDescriptor({
        get() {
          return originalTextContentDescriptor.get.call(this);
        },

        set(value) {
          if (this instanceof Element && isFalse$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('textContent', 'property'));
          }

          originalTextContentDescriptor.set.call(this, value);
        }

      })
    };
  }

  function getElementRestrictionsDescriptors(elm, options) {

    const descriptors = getNodeRestrictionsDescriptors(elm, options);
    const originalInnerHTMLDescriptor = getPropertyDescriptor(elm, 'innerHTML');
    const originalOuterHTMLDescriptor = getPropertyDescriptor(elm, 'outerHTML');
    assign(descriptors, {
      innerHTML: generateAccessorDescriptor({
        get() {
          return originalInnerHTMLDescriptor.get.call(this);
        },

        set(value) {
          if (isFalse$1(options.isPortal)) {
            logError(portalRestrictionErrorMessage('innerHTML', 'property'), getAssociatedVMIfPresent(this));
          }

          return originalInnerHTMLDescriptor.set.call(this, value);
        }

      }),
      outerHTML: generateAccessorDescriptor({
        get() {
          return originalOuterHTMLDescriptor.get.call(this);
        },

        set(_value) {
          throw new TypeError(`Invalid attempt to set outerHTML on Element.`);
        }

      })
    });
    return descriptors;
  }

  const BLOCKED_SHADOW_ROOT_METHODS = ['cloneNode', 'getElementById', 'getSelection', 'elementsFromPoint', 'dispatchEvent'];

  function getShadowRootRestrictionsDescriptors(sr) {
    // thing when using the real shadow root, because if that's the case,
    // the component will not work when running with synthetic shadow.


    const originalAddEventListener = sr.addEventListener;
    const descriptors = getNodeRestrictionsDescriptors(sr);
    const originalInnerHTMLDescriptor = getPropertyDescriptor(sr, 'innerHTML');
    const originalTextContentDescriptor = getPropertyDescriptor(sr, 'textContent');
    assign(descriptors, {
      innerHTML: generateAccessorDescriptor({
        get() {
          return originalInnerHTMLDescriptor.get.call(this);
        },

        set(_value) {
          throw new TypeError(`Invalid attempt to set innerHTML on ShadowRoot.`);
        }

      }),
      textContent: generateAccessorDescriptor({
        get() {
          return originalTextContentDescriptor.get.call(this);
        },

        set(_value) {
          throw new TypeError(`Invalid attempt to set textContent on ShadowRoot.`);
        }

      }),
      addEventListener: generateDataDescriptor({
        value(type, listener, options) {
          // TODO [#420]: this is triggered when the component author attempts to add a listener
          // programmatically into its Component's shadow root
          if (!isUndefined(options)) {
            logError('The `addEventListener` method in `LightningElement` does not support any options.', getAssociatedVMIfPresent(this));
          } // Typescript does not like it when you treat the `arguments` object as an array
          // @ts-ignore type-mismatch


          return originalAddEventListener.apply(this, arguments);
        }

      })
    });
    forEach.call(BLOCKED_SHADOW_ROOT_METHODS, methodName => {
      descriptors[methodName] = generateAccessorDescriptor({
        get() {
          throw new Error(`Disallowed method "${methodName}" in ShadowRoot.`);
        }

      });
    });
    return descriptors;
  } // Custom Elements Restrictions:
  // -----------------------------


  function getCustomElementRestrictionsDescriptors(elm) {

    const descriptors = getNodeRestrictionsDescriptors(elm);
    const originalAddEventListener = elm.addEventListener;
    const originalInnerHTMLDescriptor = getPropertyDescriptor(elm, 'innerHTML');
    const originalOuterHTMLDescriptor = getPropertyDescriptor(elm, 'outerHTML');
    const originalTextContentDescriptor = getPropertyDescriptor(elm, 'textContent');
    return assign(descriptors, {
      innerHTML: generateAccessorDescriptor({
        get() {
          return originalInnerHTMLDescriptor.get.call(this);
        },

        set(_value) {
          throw new TypeError(`Invalid attempt to set innerHTML on HTMLElement.`);
        }

      }),
      outerHTML: generateAccessorDescriptor({
        get() {
          return originalOuterHTMLDescriptor.get.call(this);
        },

        set(_value) {
          throw new TypeError(`Invalid attempt to set outerHTML on HTMLElement.`);
        }

      }),
      textContent: generateAccessorDescriptor({
        get() {
          return originalTextContentDescriptor.get.call(this);
        },

        set(_value) {
          throw new TypeError(`Invalid attempt to set textContent on HTMLElement.`);
        }

      }),
      addEventListener: generateDataDescriptor({
        value(type, listener, options) {
          // TODO [#420]: this is triggered when the component author attempts to add a listener
          // programmatically into a lighting element node
          if (!isUndefined(options)) {
            logError('The `addEventListener` method in `LightningElement` does not support any options.', getAssociatedVMIfPresent(this));
          } // Typescript does not like it when you treat the `arguments` object as an array
          // @ts-ignore type-mismatch


          return originalAddEventListener.apply(this, arguments);
        }

      })
    });
  }

  function getComponentRestrictionsDescriptors() {

    return {
      tagName: generateAccessorDescriptor({
        get() {
          throw new Error(`Usage of property \`tagName\` is disallowed because the component itself does` + ` not know which tagName will be used to create the element, therefore writing` + ` code that check for that value is error prone.`);
        },

        configurable: true,
        enumerable: false
      })
    };
  }

  function getLightningElementPrototypeRestrictionsDescriptors(proto) {

    const originalDispatchEvent = proto.dispatchEvent;
    const descriptors = {
      dispatchEvent: generateDataDescriptor({
        value(event) {
          const vm = getAssociatedVM(this);

          if (!isNull(event) && isObject$1(event)) {
            const {
              type
            } = event;

            if (!/^[a-z][a-z0-9_]*$/.test(type)) {
              logError(`Invalid event type "${type}" dispatched in element ${getComponentTag(vm)}.` + ` Event name must start with a lowercase letter and followed only lowercase` + ` letters, numbers, and underscores`, vm);
            }
          } // Typescript does not like it when you treat the `arguments` object as an array
          // @ts-ignore type-mismatch


          return originalDispatchEvent.apply(this, arguments);
        }

      })
    };
    forEach.call(getOwnPropertyNames(globalHTMLProperties), propName => {
      if (propName in proto) {
        return; // no need to redefine something that we are already exposing
      }

      descriptors[propName] = generateAccessorDescriptor({
        get() {
          const {
            error,
            attribute
          } = globalHTMLProperties[propName];
          const msg = [];
          msg.push(`Accessing the global HTML property "${propName}" is disabled.`);

          if (error) {
            msg.push(error);
          } else if (attribute) {
            msg.push(`Instead access it via \`this.getAttribute("${attribute}")\`.`);
          }

          logError(msg.join('\n'), getAssociatedVM(this));
        },

        set() {
          const {
            readOnly
          } = globalHTMLProperties[propName];

          if (readOnly) {
            logError(`The global HTML property \`${propName}\` is read-only.`, getAssociatedVM(this));
          }
        }

      });
    });
    return descriptors;
  }

  function patchElementWithRestrictions(elm, options) {
    defineProperties(elm, getElementRestrictionsDescriptors(elm, options));
  } // This routine will prevent access to certain properties on a shadow root instance to guarantee
  // that all components will work fine in IE11 and other browsers without shadow dom support.


  function patchShadowRootWithRestrictions(sr) {
    defineProperties(sr, getShadowRootRestrictionsDescriptors(sr));
  }

  function patchCustomElementWithRestrictions(elm) {
    const restrictionsDescriptors = getCustomElementRestrictionsDescriptors(elm);
    const elmProto = getPrototypeOf(elm);
    setPrototypeOf(elm, create(elmProto, restrictionsDescriptors));
  }

  function patchComponentWithRestrictions(cmp) {
    defineProperties(cmp, getComponentRestrictionsDescriptors());
  }

  function patchLightningElementPrototypeWithRestrictions(proto) {
    defineProperties(proto, getLightningElementPrototypeRestrictionsDescriptors(proto));
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * This is a descriptor map that contains
   * all standard properties that a Custom Element can support (including AOM properties), which
   * determines what kind of capabilities the Base HTML Element and
   * Base Lightning Element should support.
   */


  const HTMLElementOriginalDescriptors = create(null);
  forEach.call(keys(PropNameToAttrNameMap), propName => {
    // Note: intentionally using our in-house getPropertyDescriptor instead of getOwnPropertyDescriptor here because
    // in IE11, some properties are on Element.prototype instead of HTMLElement, just to be sure.
    const descriptor = getPropertyDescriptor(HTMLElement.prototype, propName);

    if (!isUndefined(descriptor)) {
      HTMLElementOriginalDescriptors[propName] = descriptor;
    }
  });
  forEach.call(defaultDefHTMLPropertyNames, propName => {
    // Note: intentionally using our in-house getPropertyDescriptor instead of getOwnPropertyDescriptor here because
    // in IE11, id property is on Element.prototype instead of HTMLElement, and we suspect that more will fall into
    // this category, so, better to be sure.
    const descriptor = getPropertyDescriptor(HTMLElement.prototype, propName);

    if (!isUndefined(descriptor)) {
      HTMLElementOriginalDescriptors[propName] = descriptor;
    }
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * This operation is called with a descriptor of an standard html property
   * that a Custom Element can support (including AOM properties), which
   * determines what kind of capabilities the Base Lightning Element should support. When producing the new descriptors
   * for the Base Lightning Element, it also include the reactivity bit, so the standard property is reactive.
   */

  function createBridgeToElementDescriptor(propName, descriptor) {
    const {
      get,
      set,
      enumerable,
      configurable
    } = descriptor;

    if (!isFunction(get)) {
      {
        assert.fail(`Detected invalid public property descriptor for HTMLElement.prototype.${propName} definition. Missing the standard getter.`);
      }

      throw new TypeError();
    }

    if (!isFunction(set)) {
      {
        assert.fail(`Detected invalid public property descriptor for HTMLElement.prototype.${propName} definition. Missing the standard setter.`);
      }

      throw new TypeError();
    }

    return {
      enumerable,
      configurable,

      get() {
        const vm = getAssociatedVM(this);

        if (isBeingConstructed(vm)) {
          {
            const name = vm.elm.constructor.name;
            logError(`\`${name}\` constructor can't read the value of property \`${propName}\` because the owner component hasn't set the value yet. Instead, use the \`${name}\` constructor to set a default value for the property.`, vm);
          }

          return;
        }

        componentValueObserved(vm, propName);
        return get.call(vm.elm);
      },

      set(newValue) {
        const vm = getAssociatedVM(this);

        {
          const vmBeingRendered = getVMBeingRendered();
          assert.invariant(!isInvokingRender, `${vmBeingRendered}.render() method has side effects on the state of ${vm}.${propName}`);
          assert.invariant(!isUpdatingTemplate, `When updating the template of ${vmBeingRendered}, one of the accessors used by the template has side effects on the state of ${vm}.${propName}`);
          assert.isFalse(isBeingConstructed(vm), `Failed to construct '${getComponentTag(vm)}': The result must not have attributes.`);
          assert.invariant(!isObject$1(newValue) || isNull(newValue), `Invalid value "${newValue}" for "${propName}" of ${vm}. Value cannot be an object, must be a primitive value.`);
        }

        if (newValue !== vm.cmpProps[propName]) {
          vm.cmpProps[propName] = newValue;
          componentValueMutated(vm, propName);
        }

        return set.call(vm.elm, newValue);
      }

    };
  }

  function getLinkedElement(cmp) {
    return getAssociatedVM(cmp).elm;
  }
  /**
   * This class is the base class for any LWC element.
   * Some elements directly extends this class, others implement it via inheritance.
   **/


  function BaseLightningElementConstructor() {
    // This should be as performant as possible, while any initialization should be done lazily
    if (isNull(vmBeingConstructed)) {
      throw new ReferenceError('Illegal constructor');
    }

    {
      assert.invariant(vmBeingConstructed.elm instanceof HTMLElement, `Component creation requires a DOM element to be associated to ${vmBeingConstructed}.`);
    }

    const vm = vmBeingConstructed;
    const {
      elm,
      mode,
      def: {
        ctor
      }
    } = vm;
    const component = this;
    const cmpRoot = elm.attachShadow({
      mode,
      delegatesFocus: !!ctor.delegatesFocus,
      '$$lwc-synthetic-mode$$': true
    });
    vm.component = this;
    vm.cmpRoot = cmpRoot; // Locker hooks assignment. When the LWC engine run with Locker, Locker intercepts all the new
    // component creation and passes hooks to instrument all the component interactions with the
    // engine. We are intentionally hiding this argument from the formal API of LightningElement
    // because we don't want folks to know about it just yet.

    if (arguments.length === 1) {
      const {
        callHook,
        setHook,
        getHook
      } = arguments[0];
      vm.callHook = callHook;
      vm.setHook = setHook;
      vm.getHook = getHook;
    } // Linking elm, shadow root and component with the VM.


    associateVM(component, vm);
    associateVM(cmpRoot, vm);
    associateVM(elm, vm); // Adding extra guard rails in DEV mode.

    {
      patchCustomElementWithRestrictions(elm);
      patchComponentWithRestrictions(component);
      patchShadowRootWithRestrictions(cmpRoot);
    }

    return this;
  }

  BaseLightningElementConstructor.prototype = {
    constructor: BaseLightningElementConstructor,

    dispatchEvent() {
      const elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch;

      return elm.dispatchEvent.apply(elm, arguments);
    },

    addEventListener(type, listener, options) {
      const vm = getAssociatedVM(this);

      {
        const vmBeingRendered = getVMBeingRendered();
        assert.invariant(!isInvokingRender, `${vmBeingRendered}.render() method has side effects on the state of ${vm} by adding an event listener for "${type}".`);
        assert.invariant(!isUpdatingTemplate, `Updating the template of ${vmBeingRendered} has side effects on the state of ${vm} by adding an event listener for "${type}".`);
        assert.invariant(isFunction(listener), `Invalid second argument for this.addEventListener() in ${vm} for event "${type}". Expected an EventListener but received ${listener}.`);
      }

      const wrappedListener = getWrappedComponentsListener(vm, listener);
      vm.elm.addEventListener(type, wrappedListener, options);
    },

    removeEventListener(type, listener, options) {
      const vm = getAssociatedVM(this);
      const wrappedListener = getWrappedComponentsListener(vm, listener);
      vm.elm.removeEventListener(type, wrappedListener, options);
    },

    hasAttribute() {
      const elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.hasAttribute.apply(elm, arguments);
    },

    hasAttributeNS() {
      const elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.hasAttributeNS.apply(elm, arguments);
    },

    removeAttribute(attrName) {
      const elm = getLinkedElement(this);
      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.removeAttribute.apply(elm, arguments);
      lockAttribute();
    },

    removeAttributeNS(_namespace, attrName) {
      const elm = getLinkedElement(this);
      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.removeAttributeNS.apply(elm, arguments);
      lockAttribute();
    },

    getAttribute() {
      const elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.getAttribute.apply(elm, arguments);
    },

    getAttributeNS() {
      const elm = getLinkedElement(this); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      return elm.getAttributeNS.apply(elm, arguments);
    },

    setAttribute(attrName) {
      const elm = getLinkedElement(this);

      {
        const vm = getAssociatedVM(this);
        assert.isFalse(isBeingConstructed(vm), `Failed to construct '${getComponentTag(vm)}': The result must not have attributes.`);
      }

      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.setAttribute.apply(elm, arguments);
      lockAttribute();
    },

    setAttributeNS(_namespace, attrName) {
      const elm = getLinkedElement(this);

      {
        const vm = getAssociatedVM(this);
        assert.isFalse(isBeingConstructed(vm), `Failed to construct '${getComponentTag(vm)}': The result must not have attributes.`);
      }

      unlockAttribute(elm, attrName); // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch

      elm.setAttributeNS.apply(elm, arguments);
      lockAttribute();
    },

    getBoundingClientRect() {
      const elm = getLinkedElement(this);

      {
        const vm = getAssociatedVM(this);
        assert.isFalse(isBeingConstructed(vm), `this.getBoundingClientRect() should not be called during the construction of the custom element for ${getComponentTag(vm)} because the element is not yet in the DOM, instead, you can use it in one of the available life-cycle hooks.`);
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.getBoundingClientRect.apply(elm, arguments);
    },

    /**
     * Returns the first element that is a descendant of node that
     * matches selectors.
     */
    // querySelector<K extends keyof HTMLElementTagNameMap>(selectors: K): HTMLElementTagNameMap[K] | null;
    // querySelector<K extends keyof SVGElementTagNameMap>(selectors: K): SVGElementTagNameMap[K] | null;
    querySelector() {
      const elm = getLinkedElement(this);

      {
        const vm = getAssociatedVM(this);
        assert.isFalse(isBeingConstructed(vm), `this.querySelector() cannot be called during the construction of the custom element for ${getComponentTag(vm)} because no children has been added to this element yet.`);
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.querySelector.apply(elm, arguments);
    },

    /**
     * Returns all element descendants of node that
     * match selectors.
     */
    // querySelectorAll<K extends keyof HTMLElementTagNameMap>(selectors: K): NodeListOf<HTMLElementTagNameMap[K]>,
    // querySelectorAll<K extends keyof SVGElementTagNameMap>(selectors: K): NodeListOf<SVGElementTagNameMap[K]>,
    querySelectorAll() {
      const elm = getLinkedElement(this);

      {
        const vm = getAssociatedVM(this);
        assert.isFalse(isBeingConstructed(vm), `this.querySelectorAll() cannot be called during the construction of the custom element for ${getComponentTag(vm)} because no children has been added to this element yet.`);
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.querySelectorAll.apply(elm, arguments);
    },

    /**
     * Returns all element descendants of node that
     * match the provided tagName.
     */
    getElementsByTagName() {
      const elm = getLinkedElement(this);

      {
        const vm = getAssociatedVM(this);
        assert.isFalse(isBeingConstructed(vm), `this.getElementsByTagName() cannot be called during the construction of the custom element for ${getComponentTag(vm)} because no children has been added to this element yet.`);
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.getElementsByTagName.apply(elm, arguments);
    },

    /**
     * Returns all element descendants of node that
     * match the provide classnames.
     */
    getElementsByClassName() {
      const elm = getLinkedElement(this);

      {
        const vm = getAssociatedVM(this);
        assert.isFalse(isBeingConstructed(vm), `this.getElementsByClassName() cannot be called during the construction of the custom element for ${getComponentTag(vm)} because no children has been added to this element yet.`);
      } // Typescript does not like it when you treat the `arguments` object as an array
      // @ts-ignore type-mismatch


      return elm.getElementsByClassName.apply(elm, arguments);
    },

    get isConnected() {
      return getLinkedElement(this).isConnected;
    },

    get classList() {
      {
        const vm = getAssociatedVM(this); // TODO [#1290]: this still fails in dev but works in production, eventually, we should just throw in all modes

        assert.isFalse(isBeingConstructed(vm), `Failed to construct ${vm}: The result must not have attributes. Adding or tampering with classname in constructor is not allowed in a web component, use connectedCallback() instead.`);
      }

      return getLinkedElement(this).classList;
    },

    get template() {
      const vm = getAssociatedVM(this);
      return vm.cmpRoot;
    },

    get shadowRoot() {
      // From within the component instance, the shadowRoot is always
      // reported as "closed". Authors should rely on this.template instead.
      return null;
    },

    render() {
      const vm = getAssociatedVM(this);
      return vm.def.template;
    },

    toString() {
      const vm = getAssociatedVM(this);
      return `[object ${vm.def.name}]`;
    }

  };
  const lightningBasedDescriptors = create(null);

  for (const propName in HTMLElementOriginalDescriptors) {
    lightningBasedDescriptors[propName] = createBridgeToElementDescriptor(propName, HTMLElementOriginalDescriptors[propName]);
  }

  defineProperties(BaseLightningElementConstructor.prototype, lightningBasedDescriptors);
  defineProperty(BaseLightningElementConstructor, 'CustomElementConstructor', {
    get() {
      // If required, a runtime-specific implementation must be defined.
      throw new ReferenceError('The current runtime does not support CustomElementConstructor.');
    },

    configurable: true
  });

  {
    patchLightningElementPrototypeWithRestrictions(BaseLightningElementConstructor.prototype);
  } // @ts-ignore


  const BaseLightningElement = BaseLightningElementConstructor;

  function internalWireFieldDecorator(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);
        componentValueObserved(vm, key);
        return vm.cmpFields[key];
      },

      set(value) {
        const vm = getAssociatedVM(this);
        /**
         * Reactivity for wired fields is provided in wiring.
         * We intentionally add reactivity here since this is just
         * letting the author to do the wrong thing, but it will keep our
         * system to be backward compatible.
         */

        if (value !== vm.cmpFields[key]) {
          vm.cmpFields[key] = value;
          componentValueMutated(vm, key);
        }
      },

      enumerable: true,
      configurable: true
    };
  }
  /**
   * Copyright (C) 2017 salesforce.com, inc.
   */


  const {
    isArray: isArray$2
  } = Array;
  const {
    getPrototypeOf: getPrototypeOf$1,
    create: ObjectCreate,
    defineProperty: ObjectDefineProperty,
    defineProperties: ObjectDefineProperties,
    isExtensible,
    getOwnPropertyDescriptor: getOwnPropertyDescriptor$1,
    getOwnPropertyNames: getOwnPropertyNames$1,
    getOwnPropertySymbols,
    preventExtensions,
    hasOwnProperty: hasOwnProperty$1
  } = Object;
  const {
    push: ArrayPush$2,
    concat: ArrayConcat,
    map: ArrayMap$1
  } = Array.prototype;
  const OtS$1 = {}.toString;

  function toString$1(obj) {
    if (obj && obj.toString) {
      return obj.toString();
    } else if (typeof obj === 'object') {
      return OtS$1.call(obj);
    } else {
      return obj + '';
    }
  }

  function isUndefined$2(obj) {
    return obj === undefined;
  }

  function isFunction$1(obj) {
    return typeof obj === 'function';
  }

  function isObject$2(obj) {
    return typeof obj === 'object';
  }

  const proxyToValueMap = new WeakMap();

  function registerProxy(proxy, value) {
    proxyToValueMap.set(proxy, value);
  }

  const unwrap = replicaOrAny => proxyToValueMap.get(replicaOrAny) || replicaOrAny;

  function wrapValue(membrane, value) {
    return membrane.valueIsObservable(value) ? membrane.getProxy(value) : value;
  }
  /**
   * Unwrap property descriptors will set value on original descriptor
   * We only need to unwrap if value is specified
   * @param descriptor external descrpitor provided to define new property on original value
   */


  function unwrapDescriptor(descriptor) {
    if (hasOwnProperty$1.call(descriptor, 'value')) {
      descriptor.value = unwrap(descriptor.value);
    }

    return descriptor;
  }

  function lockShadowTarget(membrane, shadowTarget, originalTarget) {
    const targetKeys = ArrayConcat.call(getOwnPropertyNames$1(originalTarget), getOwnPropertySymbols(originalTarget));
    targetKeys.forEach(key => {
      let descriptor = getOwnPropertyDescriptor$1(originalTarget, key); // We do not need to wrap the descriptor if configurable
      // Because we can deal with wrapping it when user goes through
      // Get own property descriptor. There is also a chance that this descriptor
      // could change sometime in the future, so we can defer wrapping
      // until we need to

      if (!descriptor.configurable) {
        descriptor = wrapDescriptor(membrane, descriptor, wrapValue);
      }

      ObjectDefineProperty(shadowTarget, key, descriptor);
    });
    preventExtensions(shadowTarget);
  }

  class ReactiveProxyHandler {
    constructor(membrane, value) {
      this.originalTarget = value;
      this.membrane = membrane;
    }

    get(shadowTarget, key) {
      const {
        originalTarget,
        membrane
      } = this;
      const value = originalTarget[key];
      const {
        valueObserved
      } = membrane;
      valueObserved(originalTarget, key);
      return membrane.getProxy(value);
    }

    set(shadowTarget, key, value) {
      const {
        originalTarget,
        membrane: {
          valueMutated
        }
      } = this;
      const oldValue = originalTarget[key];

      if (oldValue !== value) {
        originalTarget[key] = value;
        valueMutated(originalTarget, key);
      } else if (key === 'length' && isArray$2(originalTarget)) {
        // fix for issue #236: push will add the new index, and by the time length
        // is updated, the internal length is already equal to the new length value
        // therefore, the oldValue is equal to the value. This is the forking logic
        // to support this use case.
        valueMutated(originalTarget, key);
      }

      return true;
    }

    deleteProperty(shadowTarget, key) {
      const {
        originalTarget,
        membrane: {
          valueMutated
        }
      } = this;
      delete originalTarget[key];
      valueMutated(originalTarget, key);
      return true;
    }

    apply(shadowTarget, thisArg, argArray) {
      /* No op */
    }

    construct(target, argArray, newTarget) {
      /* No op */
    }

    has(shadowTarget, key) {
      const {
        originalTarget,
        membrane: {
          valueObserved
        }
      } = this;
      valueObserved(originalTarget, key);
      return key in originalTarget;
    }

    ownKeys(shadowTarget) {
      const {
        originalTarget
      } = this;
      return ArrayConcat.call(getOwnPropertyNames$1(originalTarget), getOwnPropertySymbols(originalTarget));
    }

    isExtensible(shadowTarget) {
      const shadowIsExtensible = isExtensible(shadowTarget);

      if (!shadowIsExtensible) {
        return shadowIsExtensible;
      }

      const {
        originalTarget,
        membrane
      } = this;
      const targetIsExtensible = isExtensible(originalTarget);

      if (!targetIsExtensible) {
        lockShadowTarget(membrane, shadowTarget, originalTarget);
      }

      return targetIsExtensible;
    }

    setPrototypeOf(shadowTarget, prototype) {
      {
        throw new Error(`Invalid setPrototypeOf invocation for reactive proxy ${toString$1(this.originalTarget)}. Prototype of reactive objects cannot be changed.`);
      }
    }

    getPrototypeOf(shadowTarget) {
      const {
        originalTarget
      } = this;
      return getPrototypeOf$1(originalTarget);
    }

    getOwnPropertyDescriptor(shadowTarget, key) {
      const {
        originalTarget,
        membrane
      } = this;
      const {
        valueObserved
      } = this.membrane; // keys looked up via hasOwnProperty need to be reactive

      valueObserved(originalTarget, key);
      let desc = getOwnPropertyDescriptor$1(originalTarget, key);

      if (isUndefined$2(desc)) {
        return desc;
      }

      const shadowDescriptor = getOwnPropertyDescriptor$1(shadowTarget, key);

      if (!isUndefined$2(shadowDescriptor)) {
        return shadowDescriptor;
      } // Note: by accessing the descriptor, the key is marked as observed
      // but access to the value, setter or getter (if available) cannot observe
      // mutations, just like regular methods, in which case we just do nothing.


      desc = wrapDescriptor(membrane, desc, wrapValue);

      if (!desc.configurable) {
        // If descriptor from original target is not configurable,
        // We must copy the wrapped descriptor over to the shadow target.
        // Otherwise, proxy will throw an invariant error.
        // This is our last chance to lock the value.
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy/handler/getOwnPropertyDescriptor#Invariants
        ObjectDefineProperty(shadowTarget, key, desc);
      }

      return desc;
    }

    preventExtensions(shadowTarget) {
      const {
        originalTarget,
        membrane
      } = this;
      lockShadowTarget(membrane, shadowTarget, originalTarget);
      preventExtensions(originalTarget);
      return true;
    }

    defineProperty(shadowTarget, key, descriptor) {
      const {
        originalTarget,
        membrane
      } = this;
      const {
        valueMutated
      } = membrane;
      const {
        configurable
      } = descriptor; // We have to check for value in descriptor
      // because Object.freeze(proxy) calls this method
      // with only { configurable: false, writeable: false }
      // Additionally, method will only be called with writeable:false
      // if the descriptor has a value, as opposed to getter/setter
      // So we can just check if writable is present and then see if
      // value is present. This eliminates getter and setter descriptors

      if (hasOwnProperty$1.call(descriptor, 'writable') && !hasOwnProperty$1.call(descriptor, 'value')) {
        const originalDescriptor = getOwnPropertyDescriptor$1(originalTarget, key);
        descriptor.value = originalDescriptor.value;
      }

      ObjectDefineProperty(originalTarget, key, unwrapDescriptor(descriptor));

      if (configurable === false) {
        ObjectDefineProperty(shadowTarget, key, wrapDescriptor(membrane, descriptor, wrapValue));
      }

      valueMutated(originalTarget, key);
      return true;
    }

  }

  function wrapReadOnlyValue(membrane, value) {
    return membrane.valueIsObservable(value) ? membrane.getReadOnlyProxy(value) : value;
  }

  class ReadOnlyHandler {
    constructor(membrane, value) {
      this.originalTarget = value;
      this.membrane = membrane;
    }

    get(shadowTarget, key) {
      const {
        membrane,
        originalTarget
      } = this;
      const value = originalTarget[key];
      const {
        valueObserved
      } = membrane;
      valueObserved(originalTarget, key);
      return membrane.getReadOnlyProxy(value);
    }

    set(shadowTarget, key, value) {
      {
        const {
          originalTarget
        } = this;
        throw new Error(`Invalid mutation: Cannot set "${key.toString()}" on "${originalTarget}". "${originalTarget}" is read-only.`);
      }
    }

    deleteProperty(shadowTarget, key) {
      {
        const {
          originalTarget
        } = this;
        throw new Error(`Invalid mutation: Cannot delete "${key.toString()}" on "${originalTarget}". "${originalTarget}" is read-only.`);
      }
    }

    apply(shadowTarget, thisArg, argArray) {
      /* No op */
    }

    construct(target, argArray, newTarget) {
      /* No op */
    }

    has(shadowTarget, key) {
      const {
        originalTarget,
        membrane: {
          valueObserved
        }
      } = this;
      valueObserved(originalTarget, key);
      return key in originalTarget;
    }

    ownKeys(shadowTarget) {
      const {
        originalTarget
      } = this;
      return ArrayConcat.call(getOwnPropertyNames$1(originalTarget), getOwnPropertySymbols(originalTarget));
    }

    setPrototypeOf(shadowTarget, prototype) {
      {
        const {
          originalTarget
        } = this;
        throw new Error(`Invalid prototype mutation: Cannot set prototype on "${originalTarget}". "${originalTarget}" prototype is read-only.`);
      }
    }

    getOwnPropertyDescriptor(shadowTarget, key) {
      const {
        originalTarget,
        membrane
      } = this;
      const {
        valueObserved
      } = membrane; // keys looked up via hasOwnProperty need to be reactive

      valueObserved(originalTarget, key);
      let desc = getOwnPropertyDescriptor$1(originalTarget, key);

      if (isUndefined$2(desc)) {
        return desc;
      }

      const shadowDescriptor = getOwnPropertyDescriptor$1(shadowTarget, key);

      if (!isUndefined$2(shadowDescriptor)) {
        return shadowDescriptor;
      } // Note: by accessing the descriptor, the key is marked as observed
      // but access to the value or getter (if available) cannot be observed,
      // just like regular methods, in which case we just do nothing.


      desc = wrapDescriptor(membrane, desc, wrapReadOnlyValue);

      if (hasOwnProperty$1.call(desc, 'set')) {
        desc.set = undefined; // readOnly membrane does not allow setters
      }

      if (!desc.configurable) {
        // If descriptor from original target is not configurable,
        // We must copy the wrapped descriptor over to the shadow target.
        // Otherwise, proxy will throw an invariant error.
        // This is our last chance to lock the value.
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy/handler/getOwnPropertyDescriptor#Invariants
        ObjectDefineProperty(shadowTarget, key, desc);
      }

      return desc;
    }

    preventExtensions(shadowTarget) {
      {
        const {
          originalTarget
        } = this;
        throw new Error(`Invalid mutation: Cannot preventExtensions on ${originalTarget}". "${originalTarget} is read-only.`);
      }
    }

    defineProperty(shadowTarget, key, descriptor) {
      {
        const {
          originalTarget
        } = this;
        throw new Error(`Invalid mutation: Cannot defineProperty "${key.toString()}" on "${originalTarget}". "${originalTarget}" is read-only.`);
      }
    }

  }

  function extract(objectOrArray) {
    if (isArray$2(objectOrArray)) {
      return objectOrArray.map(item => {
        const original = unwrap(item);

        if (original !== item) {
          return extract(original);
        }

        return item;
      });
    }

    const obj = ObjectCreate(getPrototypeOf$1(objectOrArray));
    const names = getOwnPropertyNames$1(objectOrArray);
    return ArrayConcat.call(names, getOwnPropertySymbols(objectOrArray)).reduce((seed, key) => {
      const item = objectOrArray[key];
      const original = unwrap(item);

      if (original !== item) {
        seed[key] = extract(original);
      } else {
        seed[key] = item;
      }

      return seed;
    }, obj);
  }

  const formatter = {
    header: plainOrProxy => {
      const originalTarget = unwrap(plainOrProxy); // if originalTarget is falsy or not unwrappable, exit

      if (!originalTarget || originalTarget === plainOrProxy) {
        return null;
      }

      const obj = extract(plainOrProxy);
      return ['object', {
        object: obj
      }];
    },
    hasBody: () => {
      return false;
    },
    body: () => {
      return null;
    }
  }; // Inspired from paulmillr/es6-shim
  // https://github.com/paulmillr/es6-shim/blob/master/es6-shim.js#L176-L185

  function getGlobal() {
    // the only reliable means to get the global object is `Function('return this')()`
    // However, this causes CSP violations in Chrome apps.
    if (typeof globalThis !== 'undefined') {
      return globalThis;
    }

    if (typeof self !== 'undefined') {
      return self;
    }

    if (typeof window !== 'undefined') {
      return window;
    }

    if (typeof global !== 'undefined') {
      return global;
    } // Gracefully degrade if not able to locate the global object


    return {};
  }

  function init() {

    const global = getGlobal(); // Custom Formatter for Dev Tools. To enable this, open Chrome Dev Tools
    //  - Go to Settings,
    //  - Under console, select "Enable custom formatters"
    // For more information, https://docs.google.com/document/d/1FTascZXT9cxfetuPRT2eXPQKXui4nWFivUnS_335T3U/preview

    const devtoolsFormatters = global.devtoolsFormatters || [];
    ArrayPush$2.call(devtoolsFormatters, formatter);
    global.devtoolsFormatters = devtoolsFormatters;
  }

  {
    init();
  }

  function createShadowTarget(value) {
    let shadowTarget = undefined;

    if (isArray$2(value)) {
      shadowTarget = [];
    } else if (isObject$2(value)) {
      shadowTarget = {};
    }

    return shadowTarget;
  }

  const ObjectDotPrototype = Object.prototype;

  function defaultValueIsObservable(value) {
    // intentionally checking for null
    if (value === null) {
      return false;
    } // treat all non-object types, including undefined, as non-observable values


    if (typeof value !== 'object') {
      return false;
    }

    if (isArray$2(value)) {
      return true;
    }

    const proto = getPrototypeOf$1(value);
    return proto === ObjectDotPrototype || proto === null || getPrototypeOf$1(proto) === null;
  }

  const defaultValueObserved = (obj, key) => {
    /* do nothing */
  };

  const defaultValueMutated = (obj, key) => {
    /* do nothing */
  };

  const defaultValueDistortion = value => value;

  function wrapDescriptor(membrane, descriptor, getValue) {
    const {
      set,
      get
    } = descriptor;

    if (hasOwnProperty$1.call(descriptor, 'value')) {
      descriptor.value = getValue(membrane, descriptor.value);
    } else {
      if (!isUndefined$2(get)) {
        descriptor.get = function () {
          // invoking the original getter with the original target
          return getValue(membrane, get.call(unwrap(this)));
        };
      }

      if (!isUndefined$2(set)) {
        descriptor.set = function (value) {
          // At this point we don't have a clear indication of whether
          // or not a valid mutation will occur, we don't have the key,
          // and we are not sure why and how they are invoking this setter.
          // Nevertheless we preserve the original semantics by invoking the
          // original setter with the original target and the unwrapped value
          set.call(unwrap(this), membrane.unwrapProxy(value));
        };
      }
    }

    return descriptor;
  }

  class ReactiveMembrane {
    constructor(options) {
      this.valueDistortion = defaultValueDistortion;
      this.valueMutated = defaultValueMutated;
      this.valueObserved = defaultValueObserved;
      this.valueIsObservable = defaultValueIsObservable;
      this.objectGraph = new WeakMap();

      if (!isUndefined$2(options)) {
        const {
          valueDistortion,
          valueMutated,
          valueObserved,
          valueIsObservable
        } = options;
        this.valueDistortion = isFunction$1(valueDistortion) ? valueDistortion : defaultValueDistortion;
        this.valueMutated = isFunction$1(valueMutated) ? valueMutated : defaultValueMutated;
        this.valueObserved = isFunction$1(valueObserved) ? valueObserved : defaultValueObserved;
        this.valueIsObservable = isFunction$1(valueIsObservable) ? valueIsObservable : defaultValueIsObservable;
      }
    }

    getProxy(value) {
      const unwrappedValue = unwrap(value);
      const distorted = this.valueDistortion(unwrappedValue);

      if (this.valueIsObservable(distorted)) {
        const o = this.getReactiveState(unwrappedValue, distorted); // when trying to extract the writable version of a readonly
        // we return the readonly.

        return o.readOnly === value ? value : o.reactive;
      }

      return distorted;
    }

    getReadOnlyProxy(value) {
      value = unwrap(value);
      const distorted = this.valueDistortion(value);

      if (this.valueIsObservable(distorted)) {
        return this.getReactiveState(value, distorted).readOnly;
      }

      return distorted;
    }

    unwrapProxy(p) {
      return unwrap(p);
    }

    getReactiveState(value, distortedValue) {
      const {
        objectGraph
      } = this;
      let reactiveState = objectGraph.get(distortedValue);

      if (reactiveState) {
        return reactiveState;
      }

      const membrane = this;
      reactiveState = {
        get reactive() {
          const reactiveHandler = new ReactiveProxyHandler(membrane, distortedValue); // caching the reactive proxy after the first time it is accessed

          const proxy = new Proxy(createShadowTarget(distortedValue), reactiveHandler);
          registerProxy(proxy, value);
          ObjectDefineProperty(this, 'reactive', {
            value: proxy
          });
          return proxy;
        },

        get readOnly() {
          const readOnlyHandler = new ReadOnlyHandler(membrane, distortedValue); // caching the readOnly proxy after the first time it is accessed

          const proxy = new Proxy(createShadowTarget(distortedValue), readOnlyHandler);
          registerProxy(proxy, value);
          ObjectDefineProperty(this, 'readOnly', {
            value: proxy
          });
          return proxy;
        }

      };
      objectGraph.set(distortedValue, reactiveState);
      return reactiveState;
    }

  }
  /** version: 0.26.0 */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  function valueDistortion(value) {
    return value;
  }

  const reactiveMembrane = new ReactiveMembrane({
    valueObserved,
    valueMutated,
    valueDistortion
  });

  function internalTrackDecorator(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);
        componentValueObserved(vm, key);
        return vm.cmpFields[key];
      },

      set(newValue) {
        const vm = getAssociatedVM(this);

        {
          const vmBeingRendered = getVMBeingRendered();
          assert.invariant(!isInvokingRender, `${vmBeingRendered}.render() method has side effects on the state of ${vm}.${toString(key)}`);
          assert.invariant(!isUpdatingTemplate, `Updating the template of ${vmBeingRendered} has side effects on the state of ${vm}.${toString(key)}`);
        }

        const reactiveOrAnyValue = reactiveMembrane.getProxy(newValue);

        if (reactiveOrAnyValue !== vm.cmpFields[key]) {
          vm.cmpFields[key] = reactiveOrAnyValue;
          componentValueMutated(vm, key);
        }
      },

      enumerable: true,
      configurable: true
    };
  }
  /**
   * Copyright (C) 2018 salesforce.com, inc.
   */

  /**
   * Copyright (C) 2018 salesforce.com, inc.
   */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const {
    assign: assign$1,
    create: create$2,
    defineProperties: defineProperties$1,
    defineProperty: defineProperty$1,
    freeze: freeze$1,
    getOwnPropertyDescriptor: getOwnPropertyDescriptor$2,
    getOwnPropertyNames: getOwnPropertyNames$2,
    getPrototypeOf: getPrototypeOf$2,
    hasOwnProperty: hasOwnProperty$2,
    keys: keys$1,
    seal: seal$1,
    setPrototypeOf: setPrototypeOf$1
  } = Object;
  const {
    filter: ArrayFilter$1,
    find: ArrayFind$1,
    indexOf: ArrayIndexOf$2,
    join: ArrayJoin$1,
    map: ArrayMap$2,
    push: ArrayPush$3,
    reduce: ArrayReduce$1,
    reverse: ArrayReverse$1,
    slice: ArraySlice$2,
    splice: ArraySplice$2,
    unshift: ArrayUnshift$2,
    forEach: forEach$1
  } = Array.prototype;
  const {
    charCodeAt: StringCharCodeAt$1,
    replace: StringReplace$1,
    slice: StringSlice$1,
    toLowerCase: StringToLowerCase$1
  } = String.prototype;
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * According to the following list, there are 48 aria attributes of which two (ariaDropEffect and
   * ariaGrabbed) are deprecated:
   * https://www.w3.org/TR/wai-aria-1.1/#x6-6-definitions-of-states-and-properties-all-aria-attributes
   *
   * The above list of 46 aria attributes is consistent with the following resources:
   * https://github.com/w3c/aria/pull/708/files#diff-eacf331f0ffc35d4b482f1d15a887d3bR11060
   * https://wicg.github.io/aom/spec/aria-reflection.html
   */


  const AriaPropertyNames$1 = ['ariaActiveDescendant', 'ariaAtomic', 'ariaAutoComplete', 'ariaBusy', 'ariaChecked', 'ariaColCount', 'ariaColIndex', 'ariaColSpan', 'ariaControls', 'ariaCurrent', 'ariaDescribedBy', 'ariaDetails', 'ariaDisabled', 'ariaErrorMessage', 'ariaExpanded', 'ariaFlowTo', 'ariaHasPopup', 'ariaHidden', 'ariaInvalid', 'ariaKeyShortcuts', 'ariaLabel', 'ariaLabelledBy', 'ariaLevel', 'ariaLive', 'ariaModal', 'ariaMultiLine', 'ariaMultiSelectable', 'ariaOrientation', 'ariaOwns', 'ariaPlaceholder', 'ariaPosInSet', 'ariaPressed', 'ariaReadOnly', 'ariaRelevant', 'ariaRequired', 'ariaRoleDescription', 'ariaRowCount', 'ariaRowIndex', 'ariaRowSpan', 'ariaSelected', 'ariaSetSize', 'ariaSort', 'ariaValueMax', 'ariaValueMin', 'ariaValueNow', 'ariaValueText', 'role'];
  const AttrNameToPropNameMap$2 = create$2(null);
  const PropNameToAttrNameMap$2 = create$2(null); // Synthetic creation of all AOM property descriptors for Custom Elements

  forEach$1.call(AriaPropertyNames$1, propName => {
    // Typescript infers the wrong function type for this particular overloaded method:
    // https://github.com/Microsoft/TypeScript/issues/27972
    // @ts-ignore type-mismatch
    const attrName = StringToLowerCase$1.call(StringReplace$1.call(propName, /^aria/, 'aria-'));
    AttrNameToPropNameMap$2[attrName] = propName;
    PropNameToAttrNameMap$2[propName] = attrName;
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /*
   * In IE11, symbols are expensive.
   * Due to the nature of the symbol polyfill. This method abstract the
   * creation of symbols, so we can fallback to string when native symbols
   * are not supported. Note that we can't use typeof since it will fail when transpiling.
   */

  const hasNativeSymbolsSupport$1 = Symbol('x').toString() === 'Symbol(x)';
  /** version: 1.7.1 */

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // Cached reference to globalThis

  let _globalThis;

  if (typeof globalThis === 'object') {
    _globalThis = globalThis;
  }

  function getGlobalThis() {
    if (typeof _globalThis === 'object') {
      return _globalThis;
    }

    try {
      // eslint-disable-next-line no-extend-native
      Object.defineProperty(Object.prototype, '__magic__', {
        get: function () {
          return this;
        },
        configurable: true
      }); // @ts-ignore
      // __magic__ is undefined in Safari 10 and IE10 and older.
      // eslint-disable-next-line no-undef

      _globalThis = __magic__; // @ts-ignore

      delete Object.prototype.__magic__;
    } catch (ex) {// In IE8, Object.defineProperty only works on DOM objects.
    } finally {
      // If the magic above fails for some reason we assume that we are in a
      // legacy browser. Assume `window` exists in this case.
      if (typeof _globalThis === 'undefined') {
        _globalThis = window;
      }
    }

    return _globalThis;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const _globalThis$1 = getGlobalThis();

  if (!_globalThis$1.lwcRuntimeFlags) {
    Object.defineProperty(_globalThis$1, 'lwcRuntimeFlags', {
      value: create$2(null)
    });
  }

  const runtimeFlags = _globalThis$1.lwcRuntimeFlags; // This function is not supported for use within components and is meant for

  function createPublicPropertyDescriptor(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);

        if (isBeingConstructed(vm)) {
          {
            const name = vm.elm.constructor.name;
            logError(`\`${name}\` constructor can’t read the value of property \`${toString(key)}\` because the owner component hasn’t set the value yet. Instead, use the \`${name}\` constructor to set a default value for the property.`, vm);
          }

          return;
        }

        componentValueObserved(vm, key);
        return vm.cmpProps[key];
      },

      set(newValue) {
        const vm = getAssociatedVM(this);

        {
          const vmBeingRendered = getVMBeingRendered();
          assert.invariant(!isInvokingRender, `${vmBeingRendered}.render() method has side effects on the state of ${vm}.${toString(key)}`);
          assert.invariant(!isUpdatingTemplate, `Updating the template of ${vmBeingRendered} has side effects on the state of ${vm}.${toString(key)}`);
        }

        vm.cmpProps[key] = newValue;
        componentValueMutated(vm, key);
      },

      enumerable: true,
      configurable: true
    };
  }

  class AccessorReactiveObserver extends ReactiveObserver {
    constructor(vm, set) {
      super(() => {
        if (isFalse$1(this.debouncing)) {
          this.debouncing = true;
          addCallbackToNextTick(() => {
            if (isTrue$1(this.debouncing)) {
              const {
                value
              } = this;
              const {
                isDirty: dirtyStateBeforeSetterCall,
                component,
                idx
              } = vm;
              set.call(component, value); // de-bouncing after the call to the original setter to prevent
              // infinity loop if the setter itself is mutating things that
              // were accessed during the previous invocation.

              this.debouncing = false;

              if (isTrue$1(vm.isDirty) && isFalse$1(dirtyStateBeforeSetterCall) && idx > 0) {
                // immediate rehydration due to a setter driven mutation, otherwise
                // the component will get rendered on the second tick, which it is not
                // desirable.
                rerenderVM(vm);
              }
            }
          });
        }
      });
      this.debouncing = false;
    }

    reset(value) {
      super.reset();
      this.debouncing = false;

      if (arguments.length > 0) {
        this.value = value;
      }
    }

  }

  function createPublicAccessorDescriptor(key, descriptor) {
    const {
      get,
      set,
      enumerable,
      configurable
    } = descriptor;

    if (!isFunction(get)) {
      {
        assert.invariant(isFunction(get), `Invalid compiler output for public accessor ${toString(key)} decorated with @api`);
      }

      throw new Error();
    }

    return {
      get() {
        {
          // Assert that the this value is an actual Component with an associated VM.
          getAssociatedVM(this);
        }

        return get.call(this);
      },

      set(newValue) {
        const vm = getAssociatedVM(this);

        {
          const vmBeingRendered = getVMBeingRendered();
          assert.invariant(!isInvokingRender, `${vmBeingRendered}.render() method has side effects on the state of ${vm}.${toString(key)}`);
          assert.invariant(!isUpdatingTemplate, `Updating the template of ${vmBeingRendered} has side effects on the state of ${vm}.${toString(key)}`);
        }

        if (set) {
          if (runtimeFlags.ENABLE_REACTIVE_SETTER) {
            let ro = vm.oar[key];

            if (isUndefined(ro)) {
              ro = vm.oar[key] = new AccessorReactiveObserver(vm, set);
            } // every time we invoke this setter from outside (through this wrapper setter)
            // we should reset the value and then debounce just in case there is a pending
            // invocation the next tick that is not longer relevant since the value is changing
            // from outside.


            ro.reset(newValue);
            ro.observe(() => {
              set.call(this, newValue);
            });
          } else {
            set.call(this, newValue);
          }
        } else {
          assert.fail(`Invalid attempt to set a new value for property ${toString(key)} of ${vm} that does not has a setter decorated with @api.`);
        }
      },

      enumerable,
      configurable
    };
  }

  function createObservedFieldPropertyDescriptor(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);
        componentValueObserved(vm, key);
        return vm.cmpFields[key];
      },

      set(newValue) {
        const vm = getAssociatedVM(this);

        if (newValue !== vm.cmpFields[key]) {
          vm.cmpFields[key] = newValue;
          componentValueMutated(vm, key);
        }
      },

      enumerable: true,
      configurable: true
    };
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var PropType;

  (function (PropType) {
    PropType[PropType["Field"] = 0] = "Field";
    PropType[PropType["Set"] = 1] = "Set";
    PropType[PropType["Get"] = 2] = "Get";
    PropType[PropType["GetSet"] = 3] = "GetSet";
  })(PropType || (PropType = {}));

  function validateObservedField(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined(descriptor)) {
        assert.fail(`Compiler Error: Invalid field ${fieldName} declaration.`);
      }
    }
  }

  function validateFieldDecoratedWithTrack(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined(descriptor)) {
        assert.fail(`Compiler Error: Invalid @track ${fieldName} declaration.`);
      }
    }
  }

  function validateFieldDecoratedWithWire(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined(descriptor)) {
        assert.fail(`Compiler Error: Invalid @wire(...) ${fieldName} field declaration.`);
      }
    }
  }

  function validateMethodDecoratedWithWire(Ctor, methodName, descriptor) {
    {
      if (isUndefined(descriptor) || !isFunction(descriptor.value) || isFalse$1(descriptor.writable)) {
        assert.fail(`Compiler Error: Invalid @wire(...) ${methodName} method declaration.`);
      }
    }
  }

  function validateFieldDecoratedWithApi(Ctor, fieldName, descriptor) {
    {
      if (!isUndefined(descriptor)) {
        assert.fail(`Compiler Error: Invalid @api ${fieldName} field declaration.`);
      }
    }
  }

  function validateAccessorDecoratedWithApi(Ctor, fieldName, descriptor) {
    {
      if (isUndefined(descriptor)) {
        assert.fail(`Compiler Error: Invalid @api get ${fieldName} accessor declaration.`);
      } else if (isFunction(descriptor.set)) {
        assert.isTrue(isFunction(descriptor.get), `Compiler Error: Missing getter for property ${toString(fieldName)} decorated with @api in ${Ctor}. You cannot have a setter without the corresponding getter.`);
      } else if (!isFunction(descriptor.get)) {
        assert.fail(`Compiler Error: Missing @api get ${fieldName} accessor declaration.`);
      }
    }
  }

  function validateMethodDecoratedWithApi(Ctor, methodName, descriptor) {
    {
      if (isUndefined(descriptor) || !isFunction(descriptor.value) || isFalse$1(descriptor.writable)) {
        assert.fail(`Compiler Error: Invalid @api ${methodName} method declaration.`);
      }
    }
  }
  /**
   * INTERNAL: This function can only be invoked by compiled code. The compiler
   * will prevent this function from being imported by user-land code.
   */


  function registerDecorators(Ctor, meta) {
    const proto = Ctor.prototype;
    const {
      publicProps,
      publicMethods,
      wire,
      track,
      fields
    } = meta;
    const apiMethods = create(null);
    const apiFields = create(null);
    const wiredMethods = create(null);
    const wiredFields = create(null);
    const observedFields = create(null);
    const apiFieldsConfig = create(null);
    let descriptor;

    if (!isUndefined(publicProps)) {
      for (const fieldName in publicProps) {
        const propConfig = publicProps[fieldName];
        apiFieldsConfig[fieldName] = propConfig.config;
        descriptor = getOwnPropertyDescriptor(proto, fieldName);

        if (propConfig.config > 0) {
          // accessor declaration
          {
            validateAccessorDecoratedWithApi(Ctor, fieldName, descriptor);
          }

          if (isUndefined(descriptor)) {
            throw new Error();
          }

          descriptor = createPublicAccessorDescriptor(fieldName, descriptor);
        } else {
          // field declaration
          {
            validateFieldDecoratedWithApi(Ctor, fieldName, descriptor);
          }

          descriptor = createPublicPropertyDescriptor(fieldName);
        }

        apiFields[fieldName] = descriptor;
        defineProperty(proto, fieldName, descriptor);
      }
    }

    if (!isUndefined(publicMethods)) {
      forEach.call(publicMethods, methodName => {
        descriptor = getOwnPropertyDescriptor(proto, methodName);

        {
          validateMethodDecoratedWithApi(Ctor, methodName, descriptor);
        }

        if (isUndefined(descriptor)) {
          throw new Error();
        }

        apiMethods[methodName] = descriptor;
      });
    }

    if (!isUndefined(wire)) {
      for (const fieldOrMethodName in wire) {
        const {
          adapter,
          method,
          config: configCallback,
          dynamic = []
        } = wire[fieldOrMethodName];
        descriptor = getOwnPropertyDescriptor(proto, fieldOrMethodName);

        if (method === 1) {
          {
            assert.isTrue(adapter, `@wire on method "${fieldOrMethodName}": adapter id must be truthy.`);
            validateMethodDecoratedWithWire(Ctor, fieldOrMethodName, descriptor);
          }

          if (isUndefined(descriptor)) {
            throw new Error();
          }

          wiredMethods[fieldOrMethodName] = descriptor;
          storeWiredMethodMeta(descriptor, adapter, configCallback, dynamic);
        } else {
          {
            assert.isTrue(adapter, `@wire on field "${fieldOrMethodName}": adapter id must be truthy.`);
            validateFieldDecoratedWithWire(Ctor, fieldOrMethodName, descriptor);
          }

          descriptor = internalWireFieldDecorator(fieldOrMethodName);
          wiredFields[fieldOrMethodName] = descriptor;
          storeWiredFieldMeta(descriptor, adapter, configCallback, dynamic);
          defineProperty(proto, fieldOrMethodName, descriptor);
        }
      }
    }

    if (!isUndefined(track)) {
      for (const fieldName in track) {
        descriptor = getOwnPropertyDescriptor(proto, fieldName);

        {
          validateFieldDecoratedWithTrack(Ctor, fieldName, descriptor);
        }

        descriptor = internalTrackDecorator(fieldName);
        defineProperty(proto, fieldName, descriptor);
      }
    }

    if (!isUndefined(fields)) {
      for (let i = 0, n = fields.length; i < n; i++) {
        const fieldName = fields[i];
        descriptor = getOwnPropertyDescriptor(proto, fieldName);

        {
          validateObservedField(Ctor, fieldName, descriptor);
        }

        observedFields[fieldName] = createObservedFieldPropertyDescriptor(fieldName);
      }
    }

    setDecoratorsMeta(Ctor, {
      apiMethods,
      apiFields,
      apiFieldsConfig,
      wiredMethods,
      wiredFields,
      observedFields
    });
    return Ctor;
  }

  const signedDecoratorToMetaMap = new Map();

  function setDecoratorsMeta(Ctor, meta) {
    signedDecoratorToMetaMap.set(Ctor, meta);
  }

  const defaultMeta = {
    apiMethods: EmptyObject,
    apiFields: EmptyObject,
    apiFieldsConfig: EmptyObject,
    wiredMethods: EmptyObject,
    wiredFields: EmptyObject,
    observedFields: EmptyObject
  };

  function getDecoratorsMeta(Ctor) {
    const meta = signedDecoratorToMetaMap.get(Ctor);
    return isUndefined(meta) ? defaultMeta : meta;
  }

  const signedTemplateSet = new Set();

  function defaultEmptyTemplate() {
    return [];
  }

  signedTemplateSet.add(defaultEmptyTemplate);

  function isTemplateRegistered(tpl) {
    return signedTemplateSet.has(tpl);
  }
  /**
   * INTERNAL: This function can only be invoked by compiled code. The compiler
   * will prevent this function from being imported by userland code.
   */


  function registerTemplate(tpl) {
    signedTemplateSet.add(tpl); // chaining this method as a way to wrap existing
    // assignment of templates easily, without too much transformation

    return tpl;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */
  // from the element instance, and get the value or set a new value on the component.
  // This means that across different elements, similar names can get the exact same
  // descriptor, so we can cache them:


  const cachedGetterByKey = create(null);
  const cachedSetterByKey = create(null);

  function createGetter(key) {
    let fn = cachedGetterByKey[key];

    if (isUndefined(fn)) {
      fn = cachedGetterByKey[key] = function () {
        const vm = getAssociatedVM(this);
        const {
          getHook
        } = vm;
        return getHook(vm.component, key);
      };
    }

    return fn;
  }

  function createSetter(key) {
    let fn = cachedSetterByKey[key];

    if (isUndefined(fn)) {
      fn = cachedSetterByKey[key] = function (newValue) {
        const vm = getAssociatedVM(this);
        const {
          setHook
        } = vm;
        newValue = reactiveMembrane.getReadOnlyProxy(newValue);
        setHook(vm.component, key, newValue);
      };
    }

    return fn;
  }

  function createMethodCaller(methodName) {
    return function () {
      const vm = getAssociatedVM(this);
      const {
        callHook,
        component
      } = vm;
      const fn = component[methodName];
      return callHook(vm.component, fn, ArraySlice$1.call(arguments));
    };
  }

  function HTMLBridgeElementFactory(SuperClass, props, methods) {
    let HTMLBridgeElement;
    /**
     * Modern browsers will have all Native Constructors as regular Classes
     * and must be instantiated with the new keyword. In older browsers,
     * specifically IE11, those are objects with a prototype property defined,
     * since they are not supposed to be extended or instantiated with the
     * new keyword. This forking logic supports both cases, specifically because
     * wc.ts relies on the construction path of the bridges to create new
     * fully qualifying web components.
     */

    if (isFunction(SuperClass)) {
      HTMLBridgeElement = class extends SuperClass {};
    } else {
      HTMLBridgeElement = function () {
        // Bridge classes are not supposed to be instantiated directly in
        // browsers that do not support web components.
        throw new TypeError('Illegal constructor');
      }; // prototype inheritance dance


      setPrototypeOf(HTMLBridgeElement, SuperClass);
      setPrototypeOf(HTMLBridgeElement.prototype, SuperClass.prototype);
      defineProperty(HTMLBridgeElement.prototype, 'constructor', {
        writable: true,
        configurable: true,
        value: HTMLBridgeElement
      });
    }

    const descriptors = create(null); // expose getters and setters for each public props on the new Element Bridge

    for (let i = 0, len = props.length; i < len; i += 1) {
      const propName = props[i];
      descriptors[propName] = {
        get: createGetter(propName),
        set: createSetter(propName),
        enumerable: true,
        configurable: true
      };
    } // expose public methods as props on the new Element Bridge


    for (let i = 0, len = methods.length; i < len; i += 1) {
      const methodName = methods[i];
      descriptors[methodName] = {
        value: createMethodCaller(methodName),
        writable: true,
        configurable: true
      };
    }

    defineProperties(HTMLBridgeElement.prototype, descriptors);
    return HTMLBridgeElement;
  }

  const BaseBridgeElement = HTMLBridgeElementFactory(HTMLElement, getOwnPropertyNames(HTMLElementOriginalDescriptors), []);
  freeze(BaseBridgeElement);
  seal(BaseBridgeElement.prototype);
  /*
   * Copyright (c) 2020, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  function resolveCircularModuleDependency(fn) {
    return fn();
  }

  function isCircularModuleDependency(obj) {
    return isFunction(obj) && hasOwnProperty.call(obj, '__circular__');
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const CtorToDefMap = new WeakMap();

  function getCtorProto(Ctor, subclassComponentName) {
    let proto = getPrototypeOf(Ctor);

    if (isNull(proto)) {
      throw new ReferenceError(`Invalid prototype chain for ${subclassComponentName}, you must extend LightningElement.`);
    } // covering the cases where the ref is circular in AMD


    if (isCircularModuleDependency(proto)) {
      const p = resolveCircularModuleDependency(proto);

      {
        if (isNull(p)) {
          throw new ReferenceError(`Circular module dependency for ${subclassComponentName}, must resolve to a constructor that extends LightningElement.`);
        }
      } // escape hatch for Locker and other abstractions to provide their own base class instead
      // of our Base class without having to leak it to user-land. If the circular function returns
      // itself, that's the signal that we have hit the end of the proto chain, which must always
      // be base.


      proto = p === proto ? BaseLightningElement : p;
    }

    return proto;
  }

  function createComponentDef(Ctor, meta, subclassComponentName) {
    {
      // local to dev block
      const ctorName = Ctor.name; // Removing the following assert until https://bugs.webkit.org/show_bug.cgi?id=190140 is fixed.
      // assert.isTrue(ctorName && isString(ctorName), `${toString(Ctor)} should have a "name" property with string value, but found ${ctorName}.`);

      assert.isTrue(Ctor.constructor, `Missing ${ctorName}.constructor, ${ctorName} should have a "constructor" property.`);
    }

    const {
      name
    } = meta;
    let {
      template
    } = meta;
    const decoratorsMeta = getDecoratorsMeta(Ctor);
    const {
      apiFields,
      apiFieldsConfig,
      apiMethods,
      wiredFields,
      wiredMethods,
      observedFields
    } = decoratorsMeta;
    const proto = Ctor.prototype;
    let {
      connectedCallback,
      disconnectedCallback,
      renderedCallback,
      errorCallback,
      render
    } = proto;
    const superProto = getCtorProto(Ctor, subclassComponentName);
    const superDef = superProto !== BaseLightningElement ? getComponentInternalDef(superProto, subclassComponentName) : lightingElementDef;
    const SuperBridge = isNull(superDef) ? BaseBridgeElement : superDef.bridge;
    const bridge = HTMLBridgeElementFactory(SuperBridge, keys(apiFields), keys(apiMethods));
    const props = assign(create(null), superDef.props, apiFields);
    const propsConfig = assign(create(null), superDef.propsConfig, apiFieldsConfig);
    const methods = assign(create(null), superDef.methods, apiMethods);
    const wire = assign(create(null), superDef.wire, wiredFields, wiredMethods);
    connectedCallback = connectedCallback || superDef.connectedCallback;
    disconnectedCallback = disconnectedCallback || superDef.disconnectedCallback;
    renderedCallback = renderedCallback || superDef.renderedCallback;
    errorCallback = errorCallback || superDef.errorCallback;
    render = render || superDef.render;
    template = template || superDef.template; // installing observed fields into the prototype.

    defineProperties(proto, observedFields);
    const def = {
      ctor: Ctor,
      name,
      wire,
      props,
      propsConfig,
      methods,
      bridge,
      template,
      connectedCallback,
      disconnectedCallback,
      renderedCallback,
      errorCallback,
      render
    };

    {
      freeze(Ctor.prototype);
    }

    return def;
  }
  /**
   * EXPERIMENTAL: This function allows for the identification of LWC constructors. This API is
   * subject to change or being removed.
   */


  function isComponentConstructor(ctor) {
    if (!isFunction(ctor)) {
      return false;
    } // Fast path: LightningElement is part of the prototype chain of the constructor.


    if (ctor.prototype instanceof BaseLightningElement) {
      return true;
    } // Slow path: LightningElement is not part of the prototype chain of the constructor, we need
    // climb up the constructor prototype chain to check in case there are circular dependencies
    // to resolve.


    let current = ctor;

    do {
      if (isCircularModuleDependency(current)) {
        const circularResolved = resolveCircularModuleDependency(current); // If the circular function returns itself, that's the signal that we have hit the end
        // of the proto chain, which must always be a valid base constructor.

        if (circularResolved === current) {
          return true;
        }

        current = circularResolved;
      }

      if (current === BaseLightningElement) {
        return true;
      }
    } while (!isNull(current) && (current = getPrototypeOf(current))); // Finally return false if the LightningElement is not part of the prototype chain.


    return false;
  }

  function getComponentInternalDef(Ctor, name) {
    let def = CtorToDefMap.get(Ctor);

    if (isUndefined(def)) {
      if (isCircularModuleDependency(Ctor)) {
        const resolvedCtor = resolveCircularModuleDependency(Ctor);
        def = getComponentInternalDef(resolvedCtor); // Cache the unresolved component ctor too. The next time if the same unresolved ctor is used,
        // look up the definition in cache instead of re-resolving and recreating the def.

        CtorToDefMap.set(Ctor, def);
        return def;
      }

      if (!isComponentConstructor(Ctor)) {
        throw new TypeError(`${Ctor} is not a valid component, or does not extends LightningElement from "lwc". You probably forgot to add the extend clause on the class declaration.`);
      }

      let meta = getComponentRegisteredMeta(Ctor);

      if (isUndefined(meta)) {
        // TODO [#1295]: remove this workaround after refactoring tests
        meta = {
          template: undefined,
          name: Ctor.name
        };
      }

      def = createComponentDef(Ctor, meta, name || Ctor.name);
      CtorToDefMap.set(Ctor, def);
    }

    return def;
  } // Only set prototype for public methods and properties
  // No DOM Patching occurs here


  function setElementProto(elm, def) {
    setPrototypeOf(elm, def.bridge.prototype);
  }

  const lightingElementDef = {
    ctor: BaseLightningElement,
    name: BaseLightningElement.name,
    props: lightningBasedDescriptors,
    propsConfig: EmptyObject,
    methods: EmptyObject,
    wire: EmptyObject,
    bridge: BaseBridgeElement,
    template: defaultEmptyTemplate,
    render: BaseLightningElement.prototype.render
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const useSyntheticShadow = hasOwnProperty.call(Element.prototype, '$shadowToken$');
  const dispatchEvent = 'EventTarget' in window ? EventTarget.prototype.dispatchEvent : Node.prototype.dispatchEvent; // IE11

  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  const noop = () => void 0;

  function observeElementChildNodes(elm) {
    elm.$domManual$ = true;
  }

  function setElementShadowToken(elm, token) {
    elm.$shadowToken$ = token;
  }

  function updateNodeHook(oldVnode, vnode) {
    const {
      text
    } = vnode;

    if (oldVnode.text !== text) {
      {
        unlockDomMutation();
      }
      /**
       * Compiler will never produce a text property that is not string
       */


      vnode.elm.nodeValue = text;

      {
        lockDomMutation();
      }
    }
  }

  function insertNodeHook(vnode, parentNode, referenceNode) {
    {
      unlockDomMutation();
    }

    parentNode.insertBefore(vnode.elm, referenceNode);

    {
      lockDomMutation();
    }
  }

  function removeNodeHook(vnode, parentNode) {
    {
      unlockDomMutation();
    }

    parentNode.removeChild(vnode.elm);

    {
      lockDomMutation();
    }
  }

  function createElmHook(vnode) {
    modEvents.create(vnode); // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.

    modAttrs.create(vnode);
    modProps.create(vnode);
    modStaticClassName.create(vnode);
    modStaticStyle.create(vnode);
    modComputedClassName.create(vnode);
    modComputedStyle.create(vnode);
  }

  var LWCDOMMode;

  (function (LWCDOMMode) {
    LWCDOMMode["manual"] = "manual";
  })(LWCDOMMode || (LWCDOMMode = {}));

  function fallbackElmHook(elm, vnode) {
    const {
      owner
    } = vnode;

    if (isTrue$1(useSyntheticShadow)) {
      const {
        data: {
          context
        }
      } = vnode;
      const {
        shadowAttribute
      } = owner.context;

      if (!isUndefined(context) && !isUndefined(context.lwc) && context.lwc.dom === LWCDOMMode.manual) {
        // this element will now accept any manual content inserted into it
        observeElementChildNodes(elm);
      } // when running in synthetic shadow mode, we need to set the shadowToken value
      // into each element from the template, so they can be styled accordingly.


      setElementShadowToken(elm, shadowAttribute);
    }

    {
      const {
        data: {
          context
        }
      } = vnode;
      const isPortal = !isUndefined(context) && !isUndefined(context.lwc) && context.lwc.dom === LWCDOMMode.manual;
      patchElementWithRestrictions(elm, {
        isPortal
      });
    }
  }

  function updateElmHook(oldVnode, vnode) {
    // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.
    modAttrs.update(oldVnode, vnode);
    modProps.update(oldVnode, vnode);
    modComputedClassName.update(oldVnode, vnode);
    modComputedStyle.update(oldVnode, vnode);
  }

  function insertCustomElmHook(vnode) {
    const vm = getAssociatedVM(vnode.elm);
    appendVM(vm);
  }

  function updateChildrenHook(oldVnode, vnode) {
    const {
      children,
      owner
    } = vnode;
    const fn = hasDynamicChildren(children) ? updateDynamicChildren : updateStaticChildren;
    runWithBoundaryProtection(owner, owner.owner, noop, () => {
      fn(vnode.elm, oldVnode.children, children);
    }, noop);
  }

  function allocateChildrenHook(vnode) {
    const vm = getAssociatedVM(vnode.elm); // A component with slots will re-render because:
    // 1- There is a change of the internal state.
    // 2- There is a change on the external api (ex: slots)
    //
    // In case #1, the vnodes in the cmpSlots will be reused since they didn't changed. This routine emptied the
    // slotted children when those VCustomElement were rendered and therefore in subsequent calls to allocate children
    // in a reused VCustomElement, there won't be any slotted children.
    // For those cases, we will use the reference for allocated children stored when rendering the fresh VCustomElement.
    //
    // In case #2, we will always get a fresh VCustomElement.

    const children = vnode.aChildren || vnode.children;
    vm.aChildren = children;

    if (isTrue$1(useSyntheticShadow)) {
      // slow path
      allocateInSlot(vm, children); // save the allocated children in case this vnode is reused.

      vnode.aChildren = children; // every child vnode is now allocated, and the host should receive none directly, it receives them via the shadow!

      vnode.children = EmptyArray;
    }
  }

  function createViewModelHook(elm, vnode) {
    if (!isUndefined(getAssociatedVMIfPresent(elm))) {
      // There is a possibility that a custom element is registered under tagName,
      // in which case, the initialization is already carry on, and there is nothing else
      // to do here since this hook is called right after invoking `document.createElement`.
      return;
    }

    const {
      sel,
      mode,
      ctor,
      owner
    } = vnode;
    const def = getComponentInternalDef(ctor);
    setElementProto(elm, def);

    if (isTrue$1(useSyntheticShadow)) {
      const {
        shadowAttribute
      } = owner.context; // when running in synthetic shadow mode, we need to set the shadowToken value
      // into each element from the template, so they can be styled accordingly.

      setElementShadowToken(elm, shadowAttribute);
    }

    createVM(elm, def, {
      mode,
      owner,
      tagName: sel
    });

    {
      assert.isTrue(isArray$1(vnode.children), `Invalid vnode for a custom element, it must have children defined.`);
    }
  }

  function createCustomElmHook(vnode) {
    modEvents.create(vnode); // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.

    modAttrs.create(vnode);
    modProps.create(vnode);
    modStaticClassName.create(vnode);
    modStaticStyle.create(vnode);
    modComputedClassName.create(vnode);
    modComputedStyle.create(vnode);
  }

  function createChildrenHook(vnode) {
    const {
      elm,
      children
    } = vnode;

    for (let j = 0; j < children.length; ++j) {
      const ch = children[j];

      if (ch != null) {
        ch.hook.create(ch);
        ch.hook.insert(ch, elm, null);
      }
    }
  }

  function rerenderCustomElmHook(vnode) {
    const vm = getAssociatedVM(vnode.elm);

    {
      assert.isTrue(isArray$1(vnode.children), `Invalid vnode for a custom element, it must have children defined.`);
    }

    rerenderVM(vm);
  }

  function updateCustomElmHook(oldVnode, vnode) {
    // Attrs need to be applied to element before props
    // IE11 will wipe out value on radio inputs if value
    // is set before type=radio.
    modAttrs.update(oldVnode, vnode);
    modProps.update(oldVnode, vnode);
    modComputedClassName.update(oldVnode, vnode);
    modComputedStyle.update(oldVnode, vnode);
  }

  function removeElmHook(vnode) {
    // this method only needs to search on child vnodes from template
    // to trigger the remove hook just in case some of those children
    // are custom elements.
    const {
      children,
      elm
    } = vnode;

    for (let j = 0, len = children.length; j < len; ++j) {
      const ch = children[j];

      if (!isNull(ch)) {
        ch.hook.remove(ch, elm);
      }
    }
  }

  function removeCustomElmHook(vnode) {
    // for custom elements we don't have to go recursively because the removeVM routine
    // will take care of disconnecting any child VM attached to its shadow as well.
    removeVM(getAssociatedVM(vnode.elm));
  } // Using a WeakMap instead of a WeakSet because this one works in IE11 :(


  const FromIteration = new WeakMap(); // dynamic children means it was generated by an iteration
  // in a template, and will require a more complex diffing algo.

  function markAsDynamicChildren(children) {
    FromIteration.set(children, 1);
  }

  function hasDynamicChildren(children) {
    return FromIteration.has(children);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const CHAR_S = 115;
  const CHAR_V = 118;
  const CHAR_G = 103;
  const NamespaceAttributeForSVG = 'http://www.w3.org/2000/svg';
  const SymbolIterator = Symbol.iterator;
  const TextHook = {
    create: vnode => {
      const elm = document.createTextNode(vnode.text);
      linkNodeToShadow(elm, vnode);
      vnode.elm = elm;
    },
    update: updateNodeHook,
    insert: insertNodeHook,
    move: insertNodeHook,
    remove: removeNodeHook
  }; // insert is called after update, which is used somewhere else (via a module)
  // to mark the vm as inserted, that means we cannot use update as the main channel
  // to rehydrate when dirty, because sometimes the element is not inserted just yet,
  // which breaks some invariants. For that reason, we have the following for any
  // Custom Element that is inserted via a template.

  const ElementHook = {
    create: vnode => {
      const {
        data,
        sel,
        clonedElement
      } = vnode;
      const {
        ns
      } = data; // TODO [#1364]: supporting the ability to inject a cloned StyleElement via a vnode this is
      // used for style tags for native shadow

      let elm;

      if (isUndefined(clonedElement)) {
        elm = isUndefined(ns) ? document.createElement(sel) : document.createElementNS(ns, sel);
      } else {
        elm = clonedElement;
      }

      linkNodeToShadow(elm, vnode);
      fallbackElmHook(elm, vnode);
      vnode.elm = elm;
      createElmHook(vnode);
    },
    update: (oldVnode, vnode) => {
      updateElmHook(oldVnode, vnode);
      updateChildrenHook(oldVnode, vnode);
    },
    insert: (vnode, parentNode, referenceNode) => {
      insertNodeHook(vnode, parentNode, referenceNode);
      createChildrenHook(vnode);
    },
    move: (vnode, parentNode, referenceNode) => {
      insertNodeHook(vnode, parentNode, referenceNode);
    },
    remove: (vnode, parentNode) => {
      removeNodeHook(vnode, parentNode);
      removeElmHook(vnode);
    }
  };
  const CustomElementHook = {
    create: vnode => {
      const {
        sel
      } = vnode;
      const elm = document.createElement(sel);
      linkNodeToShadow(elm, vnode);
      createViewModelHook(elm, vnode);
      vnode.elm = elm;
      allocateChildrenHook(vnode);
      createCustomElmHook(vnode);
    },
    update: (oldVnode, vnode) => {
      updateCustomElmHook(oldVnode, vnode); // in fallback mode, the allocation will always set children to
      // empty and delegate the real allocation to the slot elements

      allocateChildrenHook(vnode); // in fallback mode, the children will be always empty, so, nothing
      // will happen, but in native, it does allocate the light dom

      updateChildrenHook(oldVnode, vnode); // this will update the shadowRoot

      rerenderCustomElmHook(vnode);
    },
    insert: (vnode, parentNode, referenceNode) => {
      insertNodeHook(vnode, parentNode, referenceNode);
      const vm = getAssociatedVM(vnode.elm);

      {
        assert.isTrue(vm.state === VMState.created, `${vm} cannot be recycled.`);
      }

      runConnectedCallback(vm);
      createChildrenHook(vnode);
      insertCustomElmHook(vnode);
    },
    move: (vnode, parentNode, referenceNode) => {
      insertNodeHook(vnode, parentNode, referenceNode);
    },
    remove: (vnode, parentNode) => {
      removeNodeHook(vnode, parentNode);
      removeCustomElmHook(vnode);
    }
  };

  function linkNodeToShadow(elm, vnode) {
    // TODO [#1164]: this should eventually be done by the polyfill directly
    elm.$shadowResolver$ = vnode.owner.cmpRoot.$shadowResolver$;
  } // TODO [#1136]: this should be done by the compiler, adding ns to every sub-element


  function addNS(vnode) {
    const {
      data,
      children,
      sel
    } = vnode;
    data.ns = NamespaceAttributeForSVG; // TODO [#1275]: review why `sel` equal `foreignObject` should get this `ns`

    if (isArray$1(children) && sel !== 'foreignObject') {
      for (let j = 0, n = children.length; j < n; ++j) {
        const childNode = children[j];

        if (childNode != null && childNode.hook === ElementHook) {
          addNS(childNode);
        }
      }
    }
  }

  function addVNodeToChildLWC(vnode) {
    ArrayPush.call(getVMBeingRendered().velements, vnode);
  } // [h]tml node


  function h(sel, data, children) {
    const vmBeingRendered = getVMBeingRendered();

    {
      assert.isTrue(isString(sel), `h() 1st argument sel must be a string.`);
      assert.isTrue(isObject$1(data), `h() 2nd argument data must be an object.`);
      assert.isTrue(isArray$1(children), `h() 3rd argument children must be an array.`);
      assert.isTrue('key' in data, ` <${sel}> "key" attribute is invalid or missing for ${vmBeingRendered}. Key inside iterator is either undefined or null.`); // checking reserved internal data properties

      assert.isFalse(data.className && data.classMap, `vnode.data.className and vnode.data.classMap ambiguous declaration.`);
      assert.isFalse(data.styleMap && data.style, `vnode.data.styleMap and vnode.data.style ambiguous declaration.`);

      if (data.style && !isString(data.style)) {
        logError(`Invalid 'style' attribute passed to <${sel}> is ignored. This attribute must be a string value.`, vmBeingRendered);
      }

      forEach.call(children, childVnode => {
        if (childVnode != null) {
          assert.isTrue(childVnode && 'sel' in childVnode && 'data' in childVnode && 'children' in childVnode && 'text' in childVnode && 'elm' in childVnode && 'key' in childVnode, `${childVnode} is not a vnode.`);
        }
      });
    }

    const {
      key
    } = data;
    let text, elm;
    const vnode = {
      sel,
      data,
      children,
      text,
      elm,
      key,
      hook: ElementHook,
      owner: vmBeingRendered
    };

    if (sel.length === 3 && StringCharCodeAt.call(sel, 0) === CHAR_S && StringCharCodeAt.call(sel, 1) === CHAR_V && StringCharCodeAt.call(sel, 2) === CHAR_G) {
      addNS(vnode);
    }

    return vnode;
  } // [t]ab[i]ndex function


  function ti(value) {
    // if value is greater than 0, we normalize to 0
    // If value is an invalid tabIndex value (null, undefined, string, etc), we let that value pass through
    // If value is less than -1, we don't care
    const shouldNormalize = value > 0 && !(isTrue$1(value) || isFalse$1(value));

    {
      const vmBeingRendered = getVMBeingRendered();

      if (shouldNormalize) {
        logError(`Invalid tabindex value \`${toString(value)}\` in template for ${vmBeingRendered}. This attribute must be set to 0 or -1.`, vmBeingRendered);
      }
    }

    return shouldNormalize ? 0 : value;
  } // [s]lot element node


  function s(slotName, data, children, slotset) {
    {
      assert.isTrue(isString(slotName), `s() 1st argument slotName must be a string.`);
      assert.isTrue(isObject$1(data), `s() 2nd argument data must be an object.`);
      assert.isTrue(isArray$1(children), `h() 3rd argument children must be an array.`);
    }

    if (!isUndefined(slotset) && !isUndefined(slotset[slotName]) && slotset[slotName].length !== 0) {
      children = slotset[slotName];
    }

    const vnode = h('slot', data, children);

    if (useSyntheticShadow) {
      // TODO [#1276]: compiler should give us some sort of indicator when a vnodes collection is dynamic
      sc(children);
    }

    return vnode;
  } // [c]ustom element node


  function c(sel, Ctor, data, children = EmptyArray) {
    const vmBeingRendered = getVMBeingRendered();

    {
      assert.isTrue(isString(sel), `c() 1st argument sel must be a string.`);
      assert.isTrue(isFunction(Ctor), `c() 2nd argument Ctor must be a function.`);
      assert.isTrue(isObject$1(data), `c() 3nd argument data must be an object.`);
      assert.isTrue(arguments.length === 3 || isArray$1(children), `c() 4nd argument data must be an array.`); // checking reserved internal data properties

      assert.isFalse(data.className && data.classMap, `vnode.data.className and vnode.data.classMap ambiguous declaration.`);
      assert.isFalse(data.styleMap && data.style, `vnode.data.styleMap and vnode.data.style ambiguous declaration.`);

      if (data.style && !isString(data.style)) {
        logError(`Invalid 'style' attribute passed to <${sel}> is ignored. This attribute must be a string value.`, vmBeingRendered);
      }

      if (arguments.length === 4) {
        forEach.call(children, childVnode => {
          if (childVnode != null) {
            assert.isTrue(childVnode && 'sel' in childVnode && 'data' in childVnode && 'children' in childVnode && 'text' in childVnode && 'elm' in childVnode && 'key' in childVnode, `${childVnode} is not a vnode.`);
          }
        });
      }
    }

    const {
      key
    } = data;
    let text, elm;
    const vnode = {
      sel,
      data,
      children,
      text,
      elm,
      key,
      hook: CustomElementHook,
      ctor: Ctor,
      owner: vmBeingRendered,
      mode: 'open'
    };
    addVNodeToChildLWC(vnode);
    return vnode;
  } // [i]terable node


  function i(iterable, factory) {
    const list = []; // TODO [#1276]: compiler should give us some sort of indicator when a vnodes collection is dynamic

    sc(list);
    const vmBeingRendered = getVMBeingRendered();

    if (isUndefined(iterable) || iterable === null) {
      {
        logError(`Invalid template iteration for value "${toString(iterable)}" in ${vmBeingRendered}. It must be an Array or an iterable Object.`, vmBeingRendered);
      }

      return list;
    }

    {
      assert.isFalse(isUndefined(iterable[SymbolIterator]), `Invalid template iteration for value \`${toString(iterable)}\` in ${vmBeingRendered}. It must be an array-like object and not \`null\` nor \`undefined\`.`);
    }

    const iterator = iterable[SymbolIterator]();

    {
      assert.isTrue(iterator && isFunction(iterator.next), `Invalid iterator function for "${toString(iterable)}" in ${vmBeingRendered}.`);
    }

    let next = iterator.next();
    let j = 0;
    let {
      value,
      done: last
    } = next;
    let keyMap;
    let iterationError;

    {
      keyMap = create(null);
    }

    while (last === false) {
      // implementing a look-back-approach because we need to know if the element is the last
      next = iterator.next();
      last = next.done; // template factory logic based on the previous collected value

      const vnode = factory(value, j, j === 0, last);

      if (isArray$1(vnode)) {
        ArrayPush.apply(list, vnode);
      } else {
        ArrayPush.call(list, vnode);
      }

      {
        const vnodes = isArray$1(vnode) ? vnode : [vnode];
        forEach.call(vnodes, childVnode => {
          if (!isNull(childVnode) && isObject$1(childVnode) && !isUndefined(childVnode.sel)) {
            const {
              key
            } = childVnode;

            if (isString(key) || isNumber(key)) {
              if (keyMap[key] === 1 && isUndefined(iterationError)) {
                iterationError = `Duplicated "key" attribute value for "<${childVnode.sel}>" in ${vmBeingRendered} for item number ${j}. A key with value "${childVnode.key}" appears more than once in the iteration. Key values must be unique numbers or strings.`;
              }

              keyMap[key] = 1;
            } else if (isUndefined(iterationError)) {
              iterationError = `Invalid "key" attribute value in "<${childVnode.sel}>" in ${vmBeingRendered} for item number ${j}. Set a unique "key" value on all iterated child elements.`;
            }
          }
        });
      } // preparing next value


      j += 1;
      value = next.value;
    }

    {
      if (!isUndefined(iterationError)) {
        logError(iterationError, vmBeingRendered);
      }
    }

    return list;
  }
  /**
   * [f]lattening
   */


  function f(items) {
    {
      assert.isTrue(isArray$1(items), 'flattening api can only work with arrays.');
    }

    const len = items.length;
    const flattened = []; // TODO [#1276]: compiler should give us some sort of indicator when a vnodes collection is dynamic

    sc(flattened);

    for (let j = 0; j < len; j += 1) {
      const item = items[j];

      if (isArray$1(item)) {
        ArrayPush.apply(flattened, item);
      } else {
        ArrayPush.call(flattened, item);
      }
    }

    return flattened;
  } // [t]ext node


  function t(text) {
    const data = EmptyObject;
    let sel, children, key, elm;
    return {
      sel,
      data,
      children,
      text,
      elm,
      key,
      hook: TextHook,
      owner: getVMBeingRendered()
    };
  } // [d]ynamic value to produce a text vnode


  function d(value) {
    if (value == null) {
      return null;
    }

    return t(value);
  } // [b]ind function


  function b(fn) {
    const vmBeingRendered = getVMBeingRendered();

    if (isNull(vmBeingRendered)) {
      throw new Error();
    }

    const vm = vmBeingRendered;
    return function (event) {
      invokeEventListener(vm, fn, vm.component, event);
    };
  } // [k]ey function


  function k(compilerKey, obj) {
    switch (typeof obj) {
      case 'number':
      case 'string':
        return compilerKey + ':' + obj;

      case 'object':
        {
          assert.fail(`Invalid key value "${obj}" in ${getVMBeingRendered()}. Key must be a string or number.`);
        }

    }
  } // [g]lobal [id] function


  function gid(id) {
    const vmBeingRendered = getVMBeingRendered();

    if (isUndefined(id) || id === '') {
      {
        logError(`Invalid id value "${id}". The id attribute must contain a non-empty string.`, vmBeingRendered);
      }

      return id;
    } // We remove attributes when they are assigned a value of null


    if (isNull(id)) {
      return null;
    }

    return `${id}-${vmBeingRendered.idx}`;
  } // [f]ragment [id] function


  function fid(url) {
    const vmBeingRendered = getVMBeingRendered();

    if (isUndefined(url) || url === '') {
      {
        if (isUndefined(url)) {
          logError(`Undefined url value for "href" or "xlink:href" attribute. Expected a non-empty string.`, vmBeingRendered);
        }
      }

      return url;
    } // We remove attributes when they are assigned a value of null


    if (isNull(url)) {
      return null;
    } // Apply transformation only for fragment-only-urls


    if (/^#/.test(url)) {
      return `${url}-${vmBeingRendered.idx}`;
    }

    return url;
  }
  /**
   * Map to store an index value assigned to any dynamic component reference ingested
   * by dc() api. This allows us to generate a unique unique per template per dynamic
   * component reference to avoid diffing algo mismatches.
   */


  const DynamicImportedComponentMap = new Map();
  let dynamicImportedComponentCounter = 0;
  /**
   * create a dynamic component via `<x-foo lwc:dynamic={Ctor}>`
   */

  function dc(sel, Ctor, data, children) {
    {
      assert.isTrue(isString(sel), `dc() 1st argument sel must be a string.`);
      assert.isTrue(isObject$1(data), `dc() 3nd argument data must be an object.`);
      assert.isTrue(arguments.length === 3 || isArray$1(children), `dc() 4nd argument data must be an array.`);
    } // null or undefined values should produce a null value in the VNodes


    if (Ctor == null) {
      return null;
    }

    if (!isComponentConstructor(Ctor)) {
      throw new Error(`Invalid LWC Constructor ${toString(Ctor)} for custom element <${sel}>.`);
    }

    let idx = DynamicImportedComponentMap.get(Ctor);

    if (isUndefined(idx)) {
      idx = dynamicImportedComponentCounter++;
      DynamicImportedComponentMap.set(Ctor, idx);
    } // the new vnode key is a mix of idx and compiler key, this is required by the diffing algo
    // to identify different constructors as vnodes with different keys to avoid reusing the
    // element used for previous constructors.


    data.key = `dc:${idx}:${data.key}`;
    return c(sel, Ctor, data, children);
  }
  /**
   * slow children collection marking mechanism. this API allows the compiler to signal
   * to the engine that a particular collection of children must be diffed using the slow
   * algo based on keys due to the nature of the list. E.g.:
   *
   *   - slot element's children: the content of the slot has to be dynamic when in synthetic
   *                              shadow mode because the `vnode.children` might be the slotted
   *                              content vs default content, in which case the size and the
   *                              keys are not matching.
   *   - children that contain dynamic components
   *   - children that are produced by iteration
   *
   */


  function sc(vnodes) {
    {
      assert.isTrue(isArray$1(vnodes), 'sc() api can only work with arrays.');
    } // We have to mark the vnodes collection as dynamic so we can later on
    // choose to use the snabbdom virtual dom diffing algo instead of our
    // static dummy algo.


    markAsDynamicChildren(vnodes);
    return vnodes;
  }

  var api$1 =
  /*#__PURE__*/
  Object.freeze({
    __proto__: null,
    h: h,
    ti: ti,
    s: s,
    c: c,
    i: i,
    f: f,
    t: t,
    d: d,
    b: b,
    k: k,
    gid: gid,
    fid: fid,
    dc: dc,
    sc: sc
  });
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  const CachedStyleFragments = create(null);

  function createStyleElement(styleContent) {
    const elm = document.createElement('style');
    elm.type = 'text/css';
    elm.textContent = styleContent;
    return elm;
  }

  function getCachedStyleElement(styleContent) {
    let fragment = CachedStyleFragments[styleContent];

    if (isUndefined(fragment)) {
      fragment = document.createDocumentFragment();
      const styleElm = createStyleElement(styleContent);
      fragment.appendChild(styleElm);
      CachedStyleFragments[styleContent] = fragment;
    }

    return fragment.cloneNode(true).firstChild;
  }

  const globalStyleParent = document.head || document.body || document;
  const InsertedGlobalStyleContent = create(null);

  function insertGlobalStyle(styleContent) {
    // inserts the global style when needed, otherwise does nothing
    if (isUndefined(InsertedGlobalStyleContent[styleContent])) {
      InsertedGlobalStyleContent[styleContent] = true;
      const elm = createStyleElement(styleContent);
      globalStyleParent.appendChild(elm);
    }
  }

  function createStyleVNode(elm) {
    const vnode = h('style', {
      key: 'style'
    }, EmptyArray); // TODO [#1364]: supporting the ability to inject a cloned StyleElement
    // forcing the diffing algo to use the cloned style for native shadow

    vnode.clonedElement = elm;
    return vnode;
  }
  /**
   * Reset the styling token applied to the host element.
   */


  function resetStyleAttributes(vm) {
    const {
      context,
      elm
    } = vm; // Remove the style attribute currently applied to the host element.

    const oldHostAttribute = context.hostAttribute;

    if (!isUndefined(oldHostAttribute)) {
      removeAttribute.call(elm, oldHostAttribute);
    } // Reset the scoping attributes associated to the context.


    context.hostAttribute = context.shadowAttribute = undefined;
  }
  /**
   * Apply/Update the styling token applied to the host element.
   */


  function applyStyleAttributes(vm, hostAttribute, shadowAttribute) {
    const {
      context,
      elm
    } = vm; // Remove the style attribute currently applied to the host element.

    setAttribute.call(elm, hostAttribute, '');
    context.hostAttribute = hostAttribute;
    context.shadowAttribute = shadowAttribute;
  }

  function collectStylesheets(stylesheets, hostSelector, shadowSelector, isNative, aggregatorFn) {
    forEach.call(stylesheets, sheet => {
      if (isArray$1(sheet)) {
        collectStylesheets(sheet, hostSelector, shadowSelector, isNative, aggregatorFn);
      } else {
        aggregatorFn(sheet(hostSelector, shadowSelector, isNative));
      }
    });
  }

  function evaluateCSS(stylesheets, hostAttribute, shadowAttribute) {
    {
      assert.isTrue(isArray$1(stylesheets), `Invalid stylesheets.`);
    }

    if (useSyntheticShadow) {
      const hostSelector = `[${hostAttribute}]`;
      const shadowSelector = `[${shadowAttribute}]`;
      collectStylesheets(stylesheets, hostSelector, shadowSelector, false, textContent => {
        insertGlobalStyle(textContent);
      });
      return null;
    } else {
      // Native shadow in place, we need to act accordingly by using the `:host` selector, and an
      // empty shadow selector since it is not really needed.
      let buffer = '';
      collectStylesheets(stylesheets, emptyString, emptyString, true, textContent => {
        buffer += textContent;
      });
      return createStyleVNode(getCachedStyleElement(buffer));
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var GlobalMeasurementPhase;

  (function (GlobalMeasurementPhase) {
    GlobalMeasurementPhase["REHYDRATE"] = "lwc-rehydrate";
    GlobalMeasurementPhase["HYDRATE"] = "lwc-hydrate";
  })(GlobalMeasurementPhase || (GlobalMeasurementPhase = {})); // Even if all the browser the engine supports implements the UserTiming API, we need to guard the measure APIs.
  // JSDom (used in Jest) for example doesn't implement the UserTiming APIs.


  const isUserTimingSupported = typeof performance !== 'undefined' && typeof performance.mark === 'function' && typeof performance.clearMarks === 'function' && typeof performance.measure === 'function' && typeof performance.clearMeasures === 'function';

  function getMarkName(phase, vm) {
    // Adding the VM idx to the mark name creates a unique mark name component instance. This is necessary to produce
    // the right measures for components that are recursive.
    return `${getComponentTag(vm)} - ${phase} - ${vm.idx}`;
  }

  function getMeasureName(phase, vm) {
    return `${getComponentTag(vm)} - ${phase}`;
  }

  function start(markName) {
    performance.mark(markName);
  }

  function end(measureName, markName) {
    performance.measure(measureName, markName); // Clear the created marks and measure to avoid filling the performance entries buffer.
    // Note: Even if the entries get deleted, existing PerformanceObservers preserve a copy of those entries.

    performance.clearMarks(markName);
    performance.clearMarks(measureName);
  }

  function noop$1() {
    /* do nothing */
  }

  const startMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    const markName = getMarkName(phase, vm);
    start(markName);
  };
  const endMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    const markName = getMarkName(phase, vm);
    const measureName = getMeasureName(phase, vm);
    end(measureName, markName);
  };
  const startGlobalMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    const markName = isUndefined(vm) ? phase : getMarkName(phase, vm);
    start(markName);
  };
  const endGlobalMeasure = !isUserTimingSupported ? noop$1 : function (phase, vm) {
    const markName = isUndefined(vm) ? phase : getMarkName(phase, vm);
    end(phase, markName);
  };
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  let isUpdatingTemplate = false;
  let vmBeingRendered = null;

  function getVMBeingRendered() {
    return vmBeingRendered;
  }

  function setVMBeingRendered(vm) {
    vmBeingRendered = vm;
  }

  function validateSlots(vm, html) {

    const {
      cmpSlots
    } = vm;
    const {
      slots = EmptyArray
    } = html;

    for (const slotName in cmpSlots) {
      // eslint-disable-next-line lwc-internal/no-production-assert
      assert.isTrue(isArray$1(cmpSlots[slotName]), `Slots can only be set to an array, instead received ${toString(cmpSlots[slotName])} for slot "${slotName}" in ${vm}.`);

      if (slotName !== '' && ArrayIndexOf.call(slots, slotName) === -1) {
        // TODO [#1297]: this should never really happen because the compiler should always validate
        // eslint-disable-next-line lwc-internal/no-production-assert
        logError(`Ignoring unknown provided slot name "${slotName}" in ${vm}. Check for a typo on the slot attribute.`, vm);
      }
    }
  }

  function evaluateTemplate(vm, html) {
    {
      assert.isTrue(isFunction(html), `evaluateTemplate() second argument must be an imported template instead of ${toString(html)}`);
    }

    const isUpdatingTemplateInception = isUpdatingTemplate;
    const vmOfTemplateBeingUpdatedInception = vmBeingRendered;
    let vnodes = [];
    runWithBoundaryProtection(vm, vm.owner, () => {
      // pre
      vmBeingRendered = vm;

      {
        startMeasure('render', vm);
      }
    }, () => {
      // job
      const {
        component,
        context,
        cmpSlots,
        cmpTemplate,
        tro
      } = vm;
      tro.observe(() => {
        // Reset the cache memoizer for template when needed.
        if (html !== cmpTemplate) {
          // Perf opt: do not reset the shadow root during the first rendering (there is
          // nothing to reset).
          if (!isNull(cmpTemplate)) {
            // It is important to reset the content to avoid reusing similar elements
            // generated from a different template, because they could have similar IDs,
            // and snabbdom just rely on the IDs.
            resetShadowRoot(vm);
          } // Check that the template was built by the compiler.


          if (!isTemplateRegistered(html)) {
            throw new TypeError(`Invalid template returned by the render() method on ${vm}. It must return an imported template (e.g.: \`import html from "./${vm.def.name}.html"\`), instead, it has returned: ${toString(html)}.`);
          }

          vm.cmpTemplate = html; // Populate context with template information

          context.tplCache = create(null);
          resetStyleAttributes(vm);
          const {
            stylesheets,
            stylesheetTokens
          } = html;

          if (isUndefined(stylesheets) || stylesheets.length === 0) {
            context.styleVNode = null;
          } else if (!isUndefined(stylesheetTokens)) {
            const {
              hostAttribute,
              shadowAttribute
            } = stylesheetTokens;
            applyStyleAttributes(vm, hostAttribute, shadowAttribute); // Caching style vnode so it can be reused on every render

            context.styleVNode = evaluateCSS(stylesheets, hostAttribute, shadowAttribute);
          }
        }

        if ("development" !== 'production') {
          // validating slots in every rendering since the allocated content might change over time
          validateSlots(vm, html);
        } // right before producing the vnodes, we clear up all internal references
        // to custom elements from the template.


        vm.velements = []; // Set the global flag that template is being updated

        isUpdatingTemplate = true;
        vnodes = html.call(undefined, api$1, component, cmpSlots, context.tplCache);
        const {
          styleVNode
        } = context;

        if (!isNull(styleVNode)) {
          ArrayUnshift$1.call(vnodes, styleVNode);
        }
      });
    }, () => {
      // post
      isUpdatingTemplate = isUpdatingTemplateInception;
      vmBeingRendered = vmOfTemplateBeingUpdatedInception;

      {
        endMeasure('render', vm);
      }
    });

    {
      assert.invariant(isArray$1(vnodes), `Compiler should produce html functions that always return an array.`);
    }

    return vnodes;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  let isInvokingRender = false;
  let vmBeingConstructed = null;

  function isBeingConstructed(vm) {
    return vmBeingConstructed === vm;
  }

  const noop$2 = () => void 0;

  function invokeComponentCallback(vm, fn, args) {
    const {
      component,
      callHook,
      owner
    } = vm;
    let result;
    runWithBoundaryProtection(vm, owner, noop$2, () => {
      // job
      result = callHook(component, fn, args);
    }, noop$2);
    return result;
  }

  function invokeComponentConstructor(vm, Ctor) {
    const vmBeingConstructedInception = vmBeingConstructed;
    let error;

    {
      startMeasure('constructor', vm);
    }

    vmBeingConstructed = vm;
    /**
     * Constructors don't need to be wrapped with a boundary because for root elements
     * it should throw, while elements from template are already wrapped by a boundary
     * associated to the diffing algo.
     */

    try {
      // job
      const result = new Ctor(); // Check indirectly if the constructor result is an instance of LightningElement. Using
      // the "instanceof" operator would not work here since Locker Service provides its own
      // implementation of LightningElement, so we indirectly check if the base constructor is
      // invoked by accessing the component on the vm.

      if (vmBeingConstructed.component !== result) {
        throw new TypeError('Invalid component constructor, the class should extend LightningElement.');
      }
    } catch (e) {
      error = Object(e);
    } finally {
      {
        endMeasure('constructor', vm);
      }

      vmBeingConstructed = vmBeingConstructedInception;

      if (!isUndefined(error)) {
        error.wcStack = getErrorComponentStack(vm); // re-throwing the original error annotated after restoring the context

        throw error; // eslint-disable-line no-unsafe-finally
      }
    }
  }

  function invokeComponentRenderMethod(vm) {
    const {
      def: {
        render
      },
      callHook,
      component,
      owner
    } = vm;
    const isRenderBeingInvokedInception = isInvokingRender;
    const vmBeingRenderedInception = getVMBeingRendered();
    let html;
    let renderInvocationSuccessful = false;
    runWithBoundaryProtection(vm, owner, () => {
      // pre
      isInvokingRender = true;
      setVMBeingRendered(vm);
    }, () => {
      // job
      vm.tro.observe(() => {
        html = callHook(component, render);
        renderInvocationSuccessful = true;
      });
    }, () => {
      // post
      isInvokingRender = isRenderBeingInvokedInception;
      setVMBeingRendered(vmBeingRenderedInception);
    }); // If render() invocation failed, process errorCallback in boundary and return an empty template

    return renderInvocationSuccessful ? evaluateTemplate(vm, html) : [];
  }

  function invokeComponentRenderedCallback(vm) {
    const {
      def: {
        renderedCallback
      },
      component,
      callHook,
      owner
    } = vm;

    if (!isUndefined(renderedCallback)) {
      runWithBoundaryProtection(vm, owner, () => {
        {
          startMeasure('renderedCallback', vm);
        }
      }, () => {
        // job
        callHook(component, renderedCallback);
      }, () => {
        // post
        {
          endMeasure('renderedCallback', vm);
        }
      });
    }
  }

  function invokeEventListener(vm, fn, thisValue, event) {
    const {
      callHook,
      owner
    } = vm;
    runWithBoundaryProtection(vm, owner, noop$2, () => {
      // job
      if ("development" !== 'production') {
        assert.isTrue(isFunction(fn), `Invalid event handler for event '${event.type}' on ${vm}.`);
      }

      callHook(thisValue, fn, [event]);
    }, noop$2);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const signedComponentToMetaMap = new Map();
  /**
   * INTERNAL: This function can only be invoked by compiled code. The compiler
   * will prevent this function from being imported by userland code.
   */

  function registerComponent(Ctor, {
    name,
    tmpl: template
  }) {
    signedComponentToMetaMap.set(Ctor, {
      name,
      template
    }); // chaining this method as a way to wrap existing
    // assignment of component constructor easily, without too much transformation

    return Ctor;
  }

  function getComponentRegisteredMeta(Ctor) {
    return signedComponentToMetaMap.get(Ctor);
  }

  function createComponent(vm, Ctor) {
    // create the component instance
    invokeComponentConstructor(vm, Ctor);

    if (isUndefined(vm.component)) {
      throw new ReferenceError(`Invalid construction for ${Ctor}, you must extend LightningElement.`);
    }
  }

  function getTemplateReactiveObserver(vm) {
    return new ReactiveObserver(() => {
      const {
        isDirty
      } = vm;

      if (isFalse$1(isDirty)) {
        markComponentAsDirty(vm);
        scheduleRehydration(vm);
      }
    });
  }

  function renderComponent(vm) {
    {
      assert.invariant(vm.isDirty, `${vm} is not dirty.`);
    }

    vm.tro.reset();
    const vnodes = invokeComponentRenderMethod(vm);
    vm.isDirty = false;
    vm.isScheduled = false;

    {
      assert.invariant(isArray$1(vnodes), `${vm}.render() should always return an array of vnodes instead of ${vnodes}`);
    }

    return vnodes;
  }

  function markComponentAsDirty(vm) {
    {
      const vmBeingRendered = getVMBeingRendered();
      assert.isFalse(vm.isDirty, `markComponentAsDirty() for ${vm} should not be called when the component is already dirty.`);
      assert.isFalse(isInvokingRender, `markComponentAsDirty() for ${vm} cannot be called during rendering of ${vmBeingRendered}.`);
      assert.isFalse(isUpdatingTemplate, `markComponentAsDirty() for ${vm} cannot be called while updating template of ${vmBeingRendered}.`);
    }

    vm.isDirty = true;
  }

  const cmpEventListenerMap = new WeakMap();

  function getWrappedComponentsListener(vm, listener) {
    if (!isFunction(listener)) {
      throw new TypeError(); // avoiding problems with non-valid listeners
    }

    let wrappedListener = cmpEventListenerMap.get(listener);

    if (isUndefined(wrappedListener)) {
      wrappedListener = function (event) {
        invokeEventListener(vm, listener, undefined, event);
      };

      cmpEventListenerMap.set(listener, wrappedListener);
    }

    return wrappedListener;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const Services = create(null);

  function invokeServiceHook(vm, cbs) {
    {
      assert.isTrue(isArray$1(cbs) && cbs.length > 0, `Optimize invokeServiceHook() to be invoked only when needed`);
    }

    const {
      component,
      def,
      context
    } = vm;

    for (let i = 0, len = cbs.length; i < len; ++i) {
      cbs[i].call(undefined, component, {}, def, context);
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  var VMState;

  (function (VMState) {
    VMState[VMState["created"] = 0] = "created";
    VMState[VMState["connected"] = 1] = "connected";
    VMState[VMState["disconnected"] = 2] = "disconnected";
  })(VMState || (VMState = {}));

  let idx = 0;
  /** The internal slot used to associate different objects the engine manipulates with the VM */

  const ViewModelReflection = createHiddenField('ViewModel', 'engine');

  function callHook(cmp, fn, args = []) {
    return fn.apply(cmp, args);
  }

  function setHook(cmp, prop, newValue) {
    cmp[prop] = newValue;
  }

  function getHook(cmp, prop) {
    return cmp[prop];
  }

  function rerenderVM(vm) {
    rehydrate(vm);
  }

  function connectRootElement(elm) {
    const vm = getAssociatedVM(elm);
    startGlobalMeasure(GlobalMeasurementPhase.HYDRATE, vm); // Usually means moving the element from one place to another, which is observable via
    // life-cycle hooks.

    if (vm.state === VMState.connected) {
      disconnectRootElement(elm);
    }

    runConnectedCallback(vm);
    rehydrate(vm);
    endGlobalMeasure(GlobalMeasurementPhase.HYDRATE, vm);
  }

  function disconnectRootElement(elm) {
    const vm = getAssociatedVM(elm);
    resetComponentStateWhenRemoved(vm);
  }

  function appendVM(vm) {
    rehydrate(vm);
  } // just in case the component comes back, with this we guarantee re-rendering it
  // while preventing any attempt to rehydration until after reinsertion.


  function resetComponentStateWhenRemoved(vm) {
    const {
      state
    } = vm;

    if (state !== VMState.disconnected) {
      const {
        oar,
        tro
      } = vm; // Making sure that any observing record will not trigger the rehydrated on this vm

      tro.reset(); // Making sure that any observing accessor record will not trigger the setter to be reinvoked

      for (const key in oar) {
        oar[key].reset();
      }

      runDisconnectedCallback(vm); // Spec: https://dom.spec.whatwg.org/#concept-node-remove (step 14-15)

      runShadowChildNodesDisconnectedCallback(vm);
      runLightChildNodesDisconnectedCallback(vm);
    }
  } // this method is triggered by the diffing algo only when a vnode from the
  // old vnode.children is removed from the DOM.


  function removeVM(vm) {
    {
      assert.isTrue(vm.state === VMState.connected || vm.state === VMState.disconnected, `${vm} must have been connected.`);
    }

    resetComponentStateWhenRemoved(vm);
  }

  function createVM(elm, def, options) {
    {
      assert.invariant(elm instanceof HTMLElement, `VM creation requires a DOM element instead of ${elm}.`);
    }

    const vm = {
      elm,
      def,
      idx: idx++,
      state: VMState.created,
      isScheduled: false,
      isDirty: true,
      tagName: options.tagName,
      mode: options.mode,
      owner: options.owner,
      children: EmptyArray,
      aChildren: EmptyArray,
      velements: EmptyArray,
      cmpProps: create(null),
      cmpFields: create(null),
      cmpSlots: create(null),
      oar: create(null),
      cmpTemplate: null,
      context: {
        hostAttribute: undefined,
        shadowAttribute: undefined,
        styleVNode: null,
        tplCache: EmptyObject,
        wiredConnecting: EmptyArray,
        wiredDisconnecting: EmptyArray
      },
      tro: null,
      component: null,
      cmpRoot: null,
      callHook,
      setHook,
      getHook
    };
    vm.tro = getTemplateReactiveObserver(vm);

    {
      vm.toString = () => {
        return `[object:vm ${def.name} (${vm.idx})]`;
      };
    } // Create component instance associated to the vm and the element.


    createComponent(vm, def.ctor); // Initializing the wire decorator per instance only when really needed

    if (hasWireAdapters(vm)) {
      installWireAdapters(vm);
    }

    return vm;
  }

  function assertIsVM(obj) {
    if (isNull(obj) || !isObject$1(obj) || !('cmpRoot' in obj)) {
      throw new TypeError(`${obj} is not a VM.`);
    }
  }

  function associateVM(obj, vm) {
    setHiddenField(obj, ViewModelReflection, vm);
  }

  function getAssociatedVM(obj) {
    const vm = getHiddenField(obj, ViewModelReflection);

    {
      assertIsVM(vm);
    }

    return vm;
  }

  function getAssociatedVMIfPresent(obj) {
    const maybeVm = getHiddenField(obj, ViewModelReflection);

    {
      if (!isUndefined(maybeVm)) {
        assertIsVM(maybeVm);
      }
    }

    return maybeVm;
  }

  function rehydrate(vm) {
    {
      assert.isTrue(vm.elm instanceof HTMLElement, `rehydration can only happen after ${vm} was patched the first time.`);
    }

    if (isTrue$1(vm.isDirty)) {
      const children = renderComponent(vm);
      patchShadowRoot(vm, children);
    }
  }

  function patchShadowRoot(vm, newCh) {
    const {
      cmpRoot,
      children: oldCh
    } = vm;
    vm.children = newCh; // caching the new children collection

    if (newCh.length > 0 || oldCh.length > 0) {
      // patch function mutates vnodes by adding the element reference,
      // however, if patching fails it contains partial changes.
      if (oldCh !== newCh) {
        const fn = hasDynamicChildren(newCh) ? updateDynamicChildren : updateStaticChildren;
        runWithBoundaryProtection(vm, vm, () => {
          // pre
          {
            startMeasure('patch', vm);
          }
        }, () => {
          // job
          fn(cmpRoot, oldCh, newCh);
        }, () => {
          // post
          {
            endMeasure('patch', vm);
          }
        });
      }
    }

    if (vm.state === VMState.connected) {
      // If the element is connected, that means connectedCallback was already issued, and
      // any successive rendering should finish with the call to renderedCallback, otherwise
      // the connectedCallback will take care of calling it in the right order at the end of
      // the current rehydration process.
      runRenderedCallback(vm);
    }
  }

  function runRenderedCallback(vm) {
    const {
      rendered
    } = Services;

    if (rendered) {
      invokeServiceHook(vm, rendered);
    }

    invokeComponentRenderedCallback(vm);
  }

  let rehydrateQueue = [];

  function flushRehydrationQueue() {
    startGlobalMeasure(GlobalMeasurementPhase.REHYDRATE);

    {
      assert.invariant(rehydrateQueue.length, `If rehydrateQueue was scheduled, it is because there must be at least one VM on this pending queue instead of ${rehydrateQueue}.`);
    }

    const vms = rehydrateQueue.sort((a, b) => a.idx - b.idx);
    rehydrateQueue = []; // reset to a new queue

    for (let i = 0, len = vms.length; i < len; i += 1) {
      const vm = vms[i];

      try {
        rehydrate(vm);
      } catch (error) {
        if (i + 1 < len) {
          // pieces of the queue are still pending to be rehydrated, those should have priority
          if (rehydrateQueue.length === 0) {
            addCallbackToNextTick(flushRehydrationQueue);
          }

          ArrayUnshift$1.apply(rehydrateQueue, ArraySlice$1.call(vms, i + 1));
        } // we need to end the measure before throwing.


        endGlobalMeasure(GlobalMeasurementPhase.REHYDRATE); // re-throwing the original error will break the current tick, but since the next tick is
        // already scheduled, it should continue patching the rest.

        throw error; // eslint-disable-line no-unsafe-finally
      }
    }

    endGlobalMeasure(GlobalMeasurementPhase.REHYDRATE);
  }

  function runConnectedCallback(vm) {
    const {
      state
    } = vm;

    if (state === VMState.connected) {
      return; // nothing to do since it was already connected
    }

    vm.state = VMState.connected; // reporting connection

    const {
      connected
    } = Services;

    if (connected) {
      invokeServiceHook(vm, connected);
    }

    if (hasWireAdapters(vm)) {
      connectWireAdapters(vm);
    }

    const {
      connectedCallback
    } = vm.def;

    if (!isUndefined(connectedCallback)) {
      {
        startMeasure('connectedCallback', vm);
      }

      invokeComponentCallback(vm, connectedCallback);

      {
        endMeasure('connectedCallback', vm);
      }
    }
  }

  function hasWireAdapters(vm) {
    return getOwnPropertyNames(vm.def.wire).length > 0;
  }

  function runDisconnectedCallback(vm) {
    {
      assert.isTrue(vm.state !== VMState.disconnected, `${vm} must be inserted.`);
    }

    if (isFalse$1(vm.isDirty)) {
      // this guarantees that if the component is reused/reinserted,
      // it will be re-rendered because we are disconnecting the reactivity
      // linking, so mutations are not automatically reflected on the state
      // of disconnected components.
      vm.isDirty = true;
    }

    vm.state = VMState.disconnected; // reporting disconnection

    const {
      disconnected
    } = Services;

    if (disconnected) {
      invokeServiceHook(vm, disconnected);
    }

    if (hasWireAdapters(vm)) {
      disconnectWireAdapters(vm);
    }

    const {
      disconnectedCallback
    } = vm.def;

    if (!isUndefined(disconnectedCallback)) {
      {
        startMeasure('disconnectedCallback', vm);
      }

      invokeComponentCallback(vm, disconnectedCallback);

      {
        endMeasure('disconnectedCallback', vm);
      }
    }
  }

  function runShadowChildNodesDisconnectedCallback(vm) {
    const {
      velements: vCustomElementCollection
    } = vm; // Reporting disconnection for every child in inverse order since they are
    // inserted in reserved order.

    for (let i = vCustomElementCollection.length - 1; i >= 0; i -= 1) {
      const {
        elm
      } = vCustomElementCollection[i]; // There are two cases where the element could be undefined:
      // * when there is an error during the construction phase, and an error
      //   boundary picks it, there is a possibility that the VCustomElement
      //   is not properly initialized, and therefore is should be ignored.
      // * when slotted custom element is not used by the element where it is
      //   slotted into it, as  a result, the custom element was never
      //   initialized.

      if (!isUndefined(elm)) {
        const childVM = getAssociatedVMIfPresent(elm); // The VM associated with the element might be associated undefined
        // in the case where the VM failed in the middle of its creation,
        // eg: constructor throwing before invoking super().

        if (!isUndefined(childVM)) {
          resetComponentStateWhenRemoved(childVM);
        }
      }
    }
  }

  function runLightChildNodesDisconnectedCallback(vm) {
    const {
      aChildren: adoptedChildren
    } = vm;
    recursivelyDisconnectChildren(adoptedChildren);
  }
  /**
   * The recursion doesn't need to be a complete traversal of the vnode graph,
   * instead it can be partial, when a custom element vnode is found, we don't
   * need to continue into its children because by attempting to disconnect the
   * custom element itself will trigger the removal of anything slotted or anything
   * defined on its shadow.
   */


  function recursivelyDisconnectChildren(vnodes) {
    for (let i = 0, len = vnodes.length; i < len; i += 1) {
      const vnode = vnodes[i];

      if (!isNull(vnode) && isArray$1(vnode.children) && !isUndefined(vnode.elm)) {
        // vnode is a VElement with children
        if (isUndefined(vnode.ctor)) {
          // it is a VElement, just keep looking (recursively)
          recursivelyDisconnectChildren(vnode.children);
        } else {
          // it is a VCustomElement, disconnect it and ignore its children
          resetComponentStateWhenRemoved(getAssociatedVM(vnode.elm));
        }
      }
    }
  } // This is a super optimized mechanism to remove the content of the shadowRoot without having to go
  // into snabbdom. Especially useful when the reset is a consequence of an error, in which case the
  // children VNodes might not be representing the current state of the DOM


  function resetShadowRoot(vm) {
    const {
      children,
      cmpRoot
    } = vm;

    for (let i = 0, len = children.length; i < len; i++) {
      const child = children[i];

      if (!isNull(child) && !isUndefined(child.elm)) {
        cmpRoot.removeChild(child.elm);
      }
    }

    vm.children = EmptyArray;
    runShadowChildNodesDisconnectedCallback(vm);
    vm.velements = EmptyArray;
  }

  function scheduleRehydration(vm) {
    if (!vm.isScheduled) {
      vm.isScheduled = true;

      if (rehydrateQueue.length === 0) {
        addCallbackToNextTick(flushRehydrationQueue);
      }

      ArrayPush.call(rehydrateQueue, vm);
    }
  }

  function getErrorBoundaryVM(vm) {
    let currentVm = vm;

    while (!isNull(currentVm)) {
      if (!isUndefined(currentVm.def.errorCallback)) {
        return currentVm;
      }

      currentVm = currentVm.owner;
    }
  } // slow path routine
  // NOTE: we should probably more this routine to the synthetic shadow folder
  // and get the allocation to be cached by in the elm instead of in the VM


  function allocateInSlot(vm, children) {
    {
      assert.invariant(isObject$1(vm.cmpSlots), `When doing manual allocation, there must be a cmpSlots object available.`);
    }

    const {
      cmpSlots: oldSlots
    } = vm;
    const cmpSlots = vm.cmpSlots = create(null);

    for (let i = 0, len = children.length; i < len; i += 1) {
      const vnode = children[i];

      if (isNull(vnode)) {
        continue;
      }

      const {
        data
      } = vnode;
      const slotName = data.attrs && data.attrs.slot || '';
      const vnodes = cmpSlots[slotName] = cmpSlots[slotName] || []; // re-keying the vnodes is necessary to avoid conflicts with default content for the slot
      // which might have similar keys. Each vnode will always have a key that
      // starts with a numeric character from compiler. In this case, we add a unique
      // notation for slotted vnodes keys, e.g.: `@foo:1:1`

      vnode.key = `@${slotName}:${vnode.key}`;
      ArrayPush.call(vnodes, vnode);
    }

    if (isFalse$1(vm.isDirty)) {
      // We need to determine if the old allocation is really different from the new one
      // and mark the vm as dirty
      const oldKeys = keys(oldSlots);

      if (oldKeys.length !== keys(cmpSlots).length) {
        markComponentAsDirty(vm);
        return;
      }

      for (let i = 0, len = oldKeys.length; i < len; i += 1) {
        const key = oldKeys[i];

        if (isUndefined(cmpSlots[key]) || oldSlots[key].length !== cmpSlots[key].length) {
          markComponentAsDirty(vm);
          return;
        }

        const oldVNodes = oldSlots[key];
        const vnodes = cmpSlots[key];

        for (let j = 0, a = cmpSlots[key].length; j < a; j += 1) {
          if (oldVNodes[j] !== vnodes[j]) {
            markComponentAsDirty(vm);
            return;
          }
        }
      }
    }
  }

  function runWithBoundaryProtection(vm, owner, pre, job, post) {
    let error;
    pre();

    try {
      job();
    } catch (e) {
      error = Object(e);
    } finally {
      post();

      if (!isUndefined(error)) {
        error.wcStack = error.wcStack || getErrorComponentStack(vm);
        const errorBoundaryVm = isNull(owner) ? undefined : getErrorBoundaryVM(owner);

        if (isUndefined(errorBoundaryVm)) {
          throw error; // eslint-disable-line no-unsafe-finally
        }

        resetShadowRoot(vm); // remove offenders

        {
          startMeasure('errorCallback', errorBoundaryVm);
        } // error boundaries must have an ErrorCallback


        const errorCallback = errorBoundaryVm.def.errorCallback;
        invokeComponentCallback(errorBoundaryVm, errorCallback, [error, error.wcStack]);

        {
          endMeasure('errorCallback', errorBoundaryVm);
        }
      }
    }
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const DeprecatedWiredElementHost = '$$DeprecatedWiredElementHostKey$$';
  const DeprecatedWiredParamsMeta = '$$DeprecatedWiredParamsMetaKey$$';
  const WireMetaMap = new Map();

  function noop$3() {}

  function createFieldDataCallback(vm, name) {
    const {
      cmpFields
    } = vm;
    return value => {
      if (value !== vm.cmpFields[name]) {
        // storing the value in the underlying storage
        cmpFields[name] = value;
        componentValueMutated(vm, name);
      }
    };
  }

  function createMethodDataCallback(vm, method) {
    return value => {
      // dispatching new value into the wired method
      invokeComponentCallback(vm, method, [value]);
    };
  }

  function createConfigWatcher(vm, wireDef, callbackWhenConfigIsReady) {
    const {
      component
    } = vm;
    const {
      configCallback
    } = wireDef;
    let hasPendingConfig = false; // creating the reactive observer for reactive params when needed

    const ro = new ReactiveObserver(() => {
      if (hasPendingConfig === false) {
        hasPendingConfig = true; // collect new config in the micro-task

        Promise.resolve().then(() => {
          hasPendingConfig = false; // resetting current reactive params

          ro.reset(); // dispatching a new config due to a change in the configuration

          callback();
        });
      }
    });

    const callback = () => {
      let config;
      ro.observe(() => config = configCallback(component)); // eslint-disable-next-line lwc-internal/no-invalid-todo
      // TODO: dev-mode validation of config based on the adapter.configSchema
      // @ts-ignore it is assigned in the observe() callback

      callbackWhenConfigIsReady(config);
    };

    return callback;
  }

  function createContextWatcher(vm, wireDef, callbackWhenContextIsReady) {
    const {
      adapter
    } = wireDef;
    const adapterContextToken = getAdapterToken(adapter);

    if (isUndefined(adapterContextToken)) {
      return; // no provider found, nothing to be done
    }

    const {
      elm,
      context: {
        wiredConnecting,
        wiredDisconnecting
      }
    } = vm; // waiting for the component to be connected to formally request the context via the token

    ArrayPush.call(wiredConnecting, () => {
      // This event is responsible for connecting the host element with another
      // element in the composed path that is providing contextual data. The provider
      // must be listening for a special dom event with the name corresponding to the value of
      // `adapterContextToken`, which will remain secret and internal to this file only to
      // guarantee that the linkage can be forged.
      const internalDomEvent = new CustomEvent(adapterContextToken, {
        bubbles: true,
        composed: true,

        detail(newContext, disconnectCallback) {
          // adds this callback into the disconnect bucket so it gets disconnected from parent
          // the the element hosting the wire is disconnected
          ArrayPush.call(wiredDisconnecting, disconnectCallback); // eslint-disable-next-line lwc-internal/no-invalid-todo
          // TODO: dev-mode validation of config based on the adapter.contextSchema

          callbackWhenContextIsReady(newContext);
        }

      });
      dispatchEvent.call(elm, internalDomEvent);
    });
  }

  function createConnector(vm, name, wireDef) {
    const {
      method,
      adapter,
      configCallback,
      dynamic
    } = wireDef;
    const hasDynamicParams = dynamic.length > 0;
    const {
      component
    } = vm;
    const dataCallback = isUndefined(method) ? createFieldDataCallback(vm, name) : createMethodDataCallback(vm, method);
    let context;
    let connector; // Workaround to pass the component element associated to this wire adapter instance.

    defineProperty(dataCallback, DeprecatedWiredElementHost, {
      value: vm.elm
    });
    defineProperty(dataCallback, DeprecatedWiredParamsMeta, {
      value: dynamic
    });
    runWithBoundaryProtection(vm, vm, noop$3, () => {
      // job
      connector = new adapter(dataCallback);
    }, noop$3);

    const updateConnectorConfig = config => {
      // every time the config is recomputed due to tracking,
      // this callback will be invoked with the new computed config
      runWithBoundaryProtection(vm, vm, noop$3, () => {
        // job
        connector.update(config, context);
      }, noop$3);
    }; // Computes the current wire config and calls the update method on the wire adapter.
    // This initial implementation may change depending on the specific wire instance, if it has params, we will need
    // to observe changes in the next tick.


    let computeConfigAndUpdate = () => {
      updateConnectorConfig(configCallback(component));
    };

    if (hasDynamicParams) {
      // This wire has dynamic parameters: we wait for the component instance is created and its values set
      // in order to call the update(config) method.
      Promise.resolve().then(() => {
        computeConfigAndUpdate = createConfigWatcher(vm, wireDef, updateConnectorConfig);
        computeConfigAndUpdate();
      });
    } else {
      computeConfigAndUpdate();
    } // if the adapter needs contextualization, we need to watch for new context and push it alongside the config


    if (!isUndefined(adapter.contextSchema)) {
      createContextWatcher(vm, wireDef, newContext => {
        // every time the context is pushed into this component,
        // this callback will be invoked with the new computed context
        if (context !== newContext) {
          context = newContext; // Note: when new context arrives, the config will be recomputed and pushed along side the new
          // context, this is to preserve the identity characteristics, config should not have identity
          // (ever), while context can have identity

          computeConfigAndUpdate();
        }
      });
    } // @ts-ignore the boundary protection executes sync, connector is always defined


    return connector;
  }

  const AdapterToTokenMap = new Map();

  function getAdapterToken(adapter) {
    return AdapterToTokenMap.get(adapter);
  }

  function storeWiredMethodMeta(descriptor, adapter, configCallback, dynamic) {
    // support for callable adapters
    if (adapter.adapter) {
      adapter = adapter.adapter;
    }

    const method = descriptor.value;
    const def = {
      adapter,
      method,
      configCallback,
      dynamic
    };
    WireMetaMap.set(descriptor, def);
  }

  function storeWiredFieldMeta(descriptor, adapter, configCallback, dynamic) {
    // support for callable adapters
    if (adapter.adapter) {
      adapter = adapter.adapter;
    }

    const def = {
      adapter,
      configCallback,
      dynamic
    };
    WireMetaMap.set(descriptor, def);
  }

  function installWireAdapters(vm) {
    const {
      context,
      def: {
        wire
      }
    } = vm;
    const wiredConnecting = context.wiredConnecting = [];
    const wiredDisconnecting = context.wiredDisconnecting = [];

    for (const fieldNameOrMethod in wire) {
      const descriptor = wire[fieldNameOrMethod];
      const wireDef = WireMetaMap.get(descriptor);

      {
        assert.invariant(wireDef, `Internal Error: invalid wire definition found.`);
      }

      if (!isUndefined(wireDef)) {
        const adapterInstance = createConnector(vm, fieldNameOrMethod, wireDef);
        ArrayPush.call(wiredConnecting, () => adapterInstance.connect());
        ArrayPush.call(wiredDisconnecting, () => adapterInstance.disconnect());
      }
    }
  }

  function connectWireAdapters(vm) {
    const {
      wiredConnecting
    } = vm.context;

    for (let i = 0, len = wiredConnecting.length; i < len; i += 1) {
      wiredConnecting[i]();
    }
  }

  function disconnectWireAdapters(vm) {
    const {
      wiredDisconnecting
    } = vm.context;
    runWithBoundaryProtection(vm, vm, noop$3, () => {
      // job
      for (let i = 0, len = wiredDisconnecting.length; i < len; i += 1) {
        wiredDisconnecting[i]();
      }
    }, noop$3);
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */

  /**
   * This function builds a Web Component class from a LWC constructor so it can be
   * registered as a new element via customElements.define() at any given time.
   *
   * @deprecated since version 1.3.11
   *
   * @example
   * ```
   * import { buildCustomElementConstructor } from 'lwc';
   * import Foo from 'ns/foo';
   * const WC = buildCustomElementConstructor(Foo);
   * customElements.define('x-foo', WC);
   * const elm = document.createElement('x-foo');
   * ```
   */


  function deprecatedBuildCustomElementConstructor(Ctor) {
    {
      /* eslint-disable-next-line no-console */
      console.warn('Deprecated function called: "buildCustomElementConstructor" function is deprecated and it will be removed.' + `Use "${Ctor.name}.CustomElementConstructor" static property of the component constructor to access the corresponding custom element constructor instead.`);
    }

    return Ctor.CustomElementConstructor;
  }

  function buildCustomElementConstructor(Ctor) {
    var _a;

    const def = getComponentInternalDef(Ctor); // generating the hash table for attributes to avoid duplicate fields and facilitate validation
    // and false positives in case of inheritance.

    const attributeToPropMap = create(null);

    for (const propName in def.props) {
      attributeToPropMap[getAttrNameFromPropName(propName)] = propName;
    }

    return _a = class extends def.bridge {
      constructor() {
        super();
        createVM(this, def, {
          mode: 'open',
          owner: null,
          tagName: this.tagName
        });
      }

      connectedCallback() {
        connectRootElement(this);
      }

      disconnectedCallback() {
        disconnectRootElement(this);
      }

      attributeChangedCallback(attrName, oldValue, newValue) {
        if (oldValue === newValue) {
          // Ignore same values.
          return;
        }

        const propName = attributeToPropMap[attrName];

        if (isUndefined(propName)) {
          // Ignore unknown attributes.
          return;
        }

        if (!isAttributeLocked(this, attrName)) {
          // Ignore changes triggered by the engine itself during:
          // * diffing when public props are attempting to reflect to the DOM
          // * component via `this.setAttribute()`, should never update the prop
          // Both cases, the setAttribute call is always wrapped by the unlocking of the
          // attribute to be changed
          return;
        } // Reflect attribute change to the corresponding property when changed from outside.


        this[propName] = newValue;
      }

    }, // Specify attributes for which we want to reflect changes back to their corresponding
    // properties via attributeChangedCallback.
    _a.observedAttributes = keys(attributeToPropMap), _a;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const ConnectingSlot = createHiddenField('connecting', 'engine');
  const DisconnectingSlot = createHiddenField('disconnecting', 'engine');

  function callNodeSlot(node, slot) {
    {
      assert.isTrue(node, `callNodeSlot() should not be called for a non-object`);
    }

    const fn = getHiddenField(node, slot);

    if (!isUndefined(fn)) {
      fn(node);
    }

    return node; // for convenience
  } // Monkey patching Node methods to be able to detect the insertions and removal of root elements
  // created via createElement.


  const {
    appendChild,
    insertBefore,
    removeChild,
    replaceChild
  } = Node.prototype;
  assign(Node.prototype, {
    appendChild(newChild) {
      const appendedNode = appendChild.call(this, newChild);
      return callNodeSlot(appendedNode, ConnectingSlot);
    },

    insertBefore(newChild, referenceNode) {
      const insertedNode = insertBefore.call(this, newChild, referenceNode);
      return callNodeSlot(insertedNode, ConnectingSlot);
    },

    removeChild(oldChild) {
      const removedNode = removeChild.call(this, oldChild);
      return callNodeSlot(removedNode, DisconnectingSlot);
    },

    replaceChild(newChild, oldChild) {
      const replacedNode = replaceChild.call(this, newChild, oldChild);
      callNodeSlot(replacedNode, DisconnectingSlot);
      callNodeSlot(newChild, ConnectingSlot);
      return replacedNode;
    }

  });
  /**
   * EXPERIMENTAL: This function is almost identical to document.createElement with the slightly
   * difference that in the options, you can pass the `is` property set to a Constructor instead of
   * just a string value. The intent is to allow the creation of an element controlled by LWC without
   * having to register the element as a custom element.
   *
   * @example
   * ```
   * const el = createElement('x-foo', { is: FooCtor });
   * ```
   */

  function createElement(sel, options) {
    if (!isObject$1(options) || isNull(options)) {
      throw new TypeError(`"createElement" function expects an object as second parameter but received "${toString(options)}".`);
    }

    const Ctor = options.is;

    if (!isFunction(Ctor)) {
      throw new TypeError(`"createElement" function expects an "is" option with a valid component constructor.`);
    }

    const element = document.createElement(sel); // There is a possibility that a custom element is registered under tagName, in which case, the
    // initialization is already carry on, and there is nothing else to do here.

    if (!isUndefined(getAssociatedVMIfPresent(element))) {
      return element;
    }

    const def = getComponentInternalDef(Ctor);
    setElementProto(element, def);
    createVM(element, def, {
      tagName: sel,
      mode: options.mode !== 'closed' ? 'open' : 'closed',
      owner: null
    });
    setHiddenField(element, ConnectingSlot, connectRootElement);
    setHiddenField(element, DisconnectingSlot, disconnectRootElement);
    return element;
  }
  /*
   * Copyright (c) 2018, salesforce.com, inc.
   * All rights reserved.
   * SPDX-License-Identifier: MIT
   * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
   */


  const ComponentConstructorToCustomElementConstructorMap = new Map();

  function getCustomElementConstructor(Ctor) {
    if (Ctor === BaseLightningElement) {
      throw new TypeError(`Invalid Constructor. LightningElement base class can't be claimed as a custom element.`);
    }

    let ce = ComponentConstructorToCustomElementConstructorMap.get(Ctor);

    if (isUndefined(ce)) {
      ce = buildCustomElementConstructor(Ctor);
      ComponentConstructorToCustomElementConstructorMap.set(Ctor, ce);
    }

    return ce;
  }
  /**
   * This static getter builds a Web Component class from a LWC constructor so it can be registered
   * as a new element via customElements.define() at any given time. E.g.:
   *
   *      import Foo from 'ns/foo';
   *      customElements.define('x-foo', Foo.CustomElementConstructor);
   *      const elm = document.createElement('x-foo');
   *
   */


  defineProperty(BaseLightningElement, 'CustomElementConstructor', {
    get() {
      return getCustomElementConstructor(this);
    }

  });
  freeze(BaseLightningElement);
  seal(BaseLightningElement.prototype);

  var _tmpl = void 0;

  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */

  /* global Reflect, Promise */
  var extendStatics = function (d, b) {
    extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    };

    return extendStatics(d, b);
  };

  function __extends(d, b) {
    extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }
  var __assign = function () {
    __assign = Object.assign || function __assign(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];

        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }

      return t;
    };

    return __assign.apply(this, arguments);
  };
  function __rest(s, e) {
    var t = {};

    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

    if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
  }
  function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function (resolve) {
        resolve(value);
      });
    }

    return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      }

      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e) {
          reject(e);
        }
      }

      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }

      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  }
  function __generator(thisArg, body) {
    var _ = {
      label: 0,
      sent: function () {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
        f,
        y,
        t,
        g;
    return g = {
      next: verb(0),
      "throw": verb(1),
      "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
      return this;
    }), g;

    function verb(n) {
      return function (v) {
        return step([n, v]);
      };
    }

    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");

      while (_) try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }

      if (op[0] & 5) throw op[1];
      return {
        value: op[0] ? op[1] : void 0,
        done: true
      };
    }
  }
  function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;

    for (var r = Array(s), k = 0, i = 0; i < il; i++) for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) r[k] = a[j];

    return r;
  }

  // istanbul ignore next (See: 'https://github.com/graphql/graphql-js/issues/2317')
  var nodejsCustomInspectSymbol = typeof Symbol === 'function' && typeof Symbol.for === 'function' ? Symbol.for('nodejs.util.inspect.custom') : undefined;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }
  var MAX_ARRAY_LENGTH = 10;
  var MAX_RECURSIVE_DEPTH = 2;
  /**
   * Used to print values in error messages.
   */

  function inspect(value) {
    return formatValue(value, []);
  }

  function formatValue(value, seenValues) {
    switch (_typeof(value)) {
      case 'string':
        return JSON.stringify(value);

      case 'function':
        return value.name ? "[function ".concat(value.name, "]") : '[function]';

      case 'object':
        if (value === null) {
          return 'null';
        }

        return formatObjectValue(value, seenValues);

      default:
        return String(value);
    }
  }

  function formatObjectValue(value, previouslySeenValues) {
    if (previouslySeenValues.indexOf(value) !== -1) {
      return '[Circular]';
    }

    var seenValues = [].concat(previouslySeenValues, [value]);
    var customInspectFn = getCustomFn(value);

    if (customInspectFn !== undefined) {
      // $FlowFixMe(>=0.90.0)
      var customValue = customInspectFn.call(value); // check for infinite recursion

      if (customValue !== value) {
        return typeof customValue === 'string' ? customValue : formatValue(customValue, seenValues);
      }
    } else if (Array.isArray(value)) {
      return formatArray(value, seenValues);
    }

    return formatObject(value, seenValues);
  }

  function formatObject(object, seenValues) {
    var keys = Object.keys(object);

    if (keys.length === 0) {
      return '{}';
    }

    if (seenValues.length > MAX_RECURSIVE_DEPTH) {
      return '[' + getObjectTag(object) + ']';
    }

    var properties = keys.map(function (key) {
      var value = formatValue(object[key], seenValues);
      return key + ': ' + value;
    });
    return '{ ' + properties.join(', ') + ' }';
  }

  function formatArray(array, seenValues) {
    if (array.length === 0) {
      return '[]';
    }

    if (seenValues.length > MAX_RECURSIVE_DEPTH) {
      return '[Array]';
    }

    var len = Math.min(MAX_ARRAY_LENGTH, array.length);
    var remaining = array.length - len;
    var items = [];

    for (var i = 0; i < len; ++i) {
      items.push(formatValue(array[i], seenValues));
    }

    if (remaining === 1) {
      items.push('... 1 more item');
    } else if (remaining > 1) {
      items.push("... ".concat(remaining, " more items"));
    }

    return '[' + items.join(', ') + ']';
  }

  function getCustomFn(object) {
    var customInspectFn = object[String(nodejsCustomInspectSymbol)];

    if (typeof customInspectFn === 'function') {
      return customInspectFn;
    }

    if (typeof object.inspect === 'function') {
      return object.inspect;
    }
  }

  function getObjectTag(object) {
    var tag = Object.prototype.toString.call(object).replace(/^\[object /, '').replace(/]$/, '');

    if (tag === 'Object' && typeof object.constructor === 'function') {
      var name = object.constructor.name;

      if (typeof name === 'string' && name !== '') {
        return name;
      }
    }

    return tag;
  }

  function invariant$1(condition, message) {
    var booleanCondition = Boolean(condition); // istanbul ignore else (See transformation done in './resources/inlineInvariant.js')

    if (!booleanCondition) {
      throw new Error(message != null ? message : 'Unexpected invariant triggered.');
    }
  }

  /**
   * The `defineInspect()` function defines `inspect()` prototype method as alias of `toJSON`
   */

  function defineInspect(classObject) {
    var fn = classObject.prototype.toJSON;
    typeof fn === 'function' || invariant$1(0);
    classObject.prototype.inspect = fn; // istanbul ignore else (See: 'https://github.com/graphql/graphql-js/issues/2317')

    if (nodejsCustomInspectSymbol) {
      classObject.prototype[nodejsCustomInspectSymbol] = fn;
    }
  }

  /**
   * Contains a range of UTF-8 character offsets and token references that
   * identify the region of the source from which the AST derived.
   */
  var Location = /*#__PURE__*/function () {
    /**
     * The character offset at which this Node begins.
     */

    /**
     * The character offset at which this Node ends.
     */

    /**
     * The Token at which this Node begins.
     */

    /**
     * The Token at which this Node ends.
     */

    /**
     * The Source document the AST represents.
     */
    function Location(startToken, endToken, source) {
      this.start = startToken.start;
      this.end = endToken.end;
      this.startToken = startToken;
      this.endToken = endToken;
      this.source = source;
    }

    var _proto = Location.prototype;

    _proto.toJSON = function toJSON() {
      return {
        start: this.start,
        end: this.end
      };
    };

    return Location;
  }(); // Print a simplified form when appearing in `inspect` and `util.inspect`.

  defineInspect(Location);
  /**
   * Represents a range of characters represented by a lexical token
   * within a Source.
   */

  var Token = /*#__PURE__*/function () {
    /**
     * The kind of Token.
     */

    /**
     * The character offset at which this Node begins.
     */

    /**
     * The character offset at which this Node ends.
     */

    /**
     * The 1-indexed line number on which this Token appears.
     */

    /**
     * The 1-indexed column number at which this Token begins.
     */

    /**
     * For non-punctuation tokens, represents the interpreted value of the token.
     */

    /**
     * Tokens exist as nodes in a double-linked-list amongst all tokens
     * including ignored tokens. <SOF> is always the first node and <EOF>
     * the last.
     */
    function Token(kind, start, end, line, column, prev, value) {
      this.kind = kind;
      this.start = start;
      this.end = end;
      this.line = line;
      this.column = column;
      this.value = value;
      this.prev = prev;
      this.next = null;
    }

    var _proto2 = Token.prototype;

    _proto2.toJSON = function toJSON() {
      return {
        kind: this.kind,
        value: this.value,
        line: this.line,
        column: this.column
      };
    };

    return Token;
  }(); // Print a simplified form when appearing in `inspect` and `util.inspect`.

  defineInspect(Token);
  /**
   * @internal
   */

  function isNode(maybeNode) {
    return maybeNode != null && typeof maybeNode.kind === 'string';
  }
  /**
   * The list of all possible AST node types.
   */

  /**
   * A visitor is provided to visit, it contains the collection of
   * relevant functions to be called during the visitor's traversal.
   */

  var QueryDocumentKeys = {
    Name: [],
    Document: ['definitions'],
    OperationDefinition: ['name', 'variableDefinitions', 'directives', 'selectionSet'],
    VariableDefinition: ['variable', 'type', 'defaultValue', 'directives'],
    Variable: ['name'],
    SelectionSet: ['selections'],
    Field: ['alias', 'name', 'arguments', 'directives', 'selectionSet'],
    Argument: ['name', 'value'],
    FragmentSpread: ['name', 'directives'],
    InlineFragment: ['typeCondition', 'directives', 'selectionSet'],
    FragmentDefinition: ['name', // Note: fragment variable definitions are experimental and may be changed
    // or removed in the future.
    'variableDefinitions', 'typeCondition', 'directives', 'selectionSet'],
    IntValue: [],
    FloatValue: [],
    StringValue: [],
    BooleanValue: [],
    NullValue: [],
    EnumValue: [],
    ListValue: ['values'],
    ObjectValue: ['fields'],
    ObjectField: ['name', 'value'],
    Directive: ['name', 'arguments'],
    NamedType: ['name'],
    ListType: ['type'],
    NonNullType: ['type'],
    SchemaDefinition: ['description', 'directives', 'operationTypes'],
    OperationTypeDefinition: ['type'],
    ScalarTypeDefinition: ['description', 'name', 'directives'],
    ObjectTypeDefinition: ['description', 'name', 'interfaces', 'directives', 'fields'],
    FieldDefinition: ['description', 'name', 'arguments', 'type', 'directives'],
    InputValueDefinition: ['description', 'name', 'type', 'defaultValue', 'directives'],
    InterfaceTypeDefinition: ['description', 'name', 'interfaces', 'directives', 'fields'],
    UnionTypeDefinition: ['description', 'name', 'directives', 'types'],
    EnumTypeDefinition: ['description', 'name', 'directives', 'values'],
    EnumValueDefinition: ['description', 'name', 'directives'],
    InputObjectTypeDefinition: ['description', 'name', 'directives', 'fields'],
    DirectiveDefinition: ['description', 'name', 'arguments', 'locations'],
    SchemaExtension: ['directives', 'operationTypes'],
    ScalarTypeExtension: ['name', 'directives'],
    ObjectTypeExtension: ['name', 'interfaces', 'directives', 'fields'],
    InterfaceTypeExtension: ['name', 'interfaces', 'directives', 'fields'],
    UnionTypeExtension: ['name', 'directives', 'types'],
    EnumTypeExtension: ['name', 'directives', 'values'],
    InputObjectTypeExtension: ['name', 'directives', 'fields']
  };
  var BREAK = Object.freeze({});
  /**
   * visit() will walk through an AST using a depth first traversal, calling
   * the visitor's enter function at each node in the traversal, and calling the
   * leave function after visiting that node and all of its child nodes.
   *
   * By returning different values from the enter and leave functions, the
   * behavior of the visitor can be altered, including skipping over a sub-tree of
   * the AST (by returning false), editing the AST by returning a value or null
   * to remove the value, or to stop the whole traversal by returning BREAK.
   *
   * When using visit() to edit an AST, the original AST will not be modified, and
   * a new version of the AST with the changes applied will be returned from the
   * visit function.
   *
   *     const editedAST = visit(ast, {
   *       enter(node, key, parent, path, ancestors) {
   *         // @return
   *         //   undefined: no action
   *         //   false: skip visiting this node
   *         //   visitor.BREAK: stop visiting altogether
   *         //   null: delete this node
   *         //   any value: replace this node with the returned value
   *       },
   *       leave(node, key, parent, path, ancestors) {
   *         // @return
   *         //   undefined: no action
   *         //   false: no action
   *         //   visitor.BREAK: stop visiting altogether
   *         //   null: delete this node
   *         //   any value: replace this node with the returned value
   *       }
   *     });
   *
   * Alternatively to providing enter() and leave() functions, a visitor can
   * instead provide functions named the same as the kinds of AST nodes, or
   * enter/leave visitors at a named key, leading to four permutations of
   * visitor API:
   *
   * 1) Named visitors triggered when entering a node a specific kind.
   *
   *     visit(ast, {
   *       Kind(node) {
   *         // enter the "Kind" node
   *       }
   *     })
   *
   * 2) Named visitors that trigger upon entering and leaving a node of
   *    a specific kind.
   *
   *     visit(ast, {
   *       Kind: {
   *         enter(node) {
   *           // enter the "Kind" node
   *         }
   *         leave(node) {
   *           // leave the "Kind" node
   *         }
   *       }
   *     })
   *
   * 3) Generic visitors that trigger upon entering and leaving any node.
   *
   *     visit(ast, {
   *       enter(node) {
   *         // enter any node
   *       },
   *       leave(node) {
   *         // leave any node
   *       }
   *     })
   *
   * 4) Parallel visitors for entering and leaving nodes of a specific kind.
   *
   *     visit(ast, {
   *       enter: {
   *         Kind(node) {
   *           // enter the "Kind" node
   *         }
   *       },
   *       leave: {
   *         Kind(node) {
   *           // leave the "Kind" node
   *         }
   *       }
   *     })
   */

  function visit(root, visitor) {
    var visitorKeys = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : QueryDocumentKeys;

    /* eslint-disable no-undef-init */
    var stack = undefined;
    var inArray = Array.isArray(root);
    var keys = [root];
    var index = -1;
    var edits = [];
    var node = undefined;
    var key = undefined;
    var parent = undefined;
    var path = [];
    var ancestors = [];
    var newRoot = root;
    /* eslint-enable no-undef-init */

    do {
      index++;
      var isLeaving = index === keys.length;
      var isEdited = isLeaving && edits.length !== 0;

      if (isLeaving) {
        key = ancestors.length === 0 ? undefined : path[path.length - 1];
        node = parent;
        parent = ancestors.pop();

        if (isEdited) {
          if (inArray) {
            node = node.slice();
          } else {
            var clone = {};

            for (var _i2 = 0, _Object$keys2 = Object.keys(node); _i2 < _Object$keys2.length; _i2++) {
              var k = _Object$keys2[_i2];
              clone[k] = node[k];
            }

            node = clone;
          }

          var editOffset = 0;

          for (var ii = 0; ii < edits.length; ii++) {
            var editKey = edits[ii][0];
            var editValue = edits[ii][1];

            if (inArray) {
              editKey -= editOffset;
            }

            if (inArray && editValue === null) {
              node.splice(editKey, 1);
              editOffset++;
            } else {
              node[editKey] = editValue;
            }
          }
        }

        index = stack.index;
        keys = stack.keys;
        edits = stack.edits;
        inArray = stack.inArray;
        stack = stack.prev;
      } else {
        key = parent ? inArray ? index : keys[index] : undefined;
        node = parent ? parent[key] : newRoot;

        if (node === null || node === undefined) {
          continue;
        }

        if (parent) {
          path.push(key);
        }
      }

      var result = void 0;

      if (!Array.isArray(node)) {
        if (!isNode(node)) {
          throw new Error("Invalid AST Node: ".concat(inspect(node), "."));
        }

        var visitFn = getVisitFn(visitor, node.kind, isLeaving);

        if (visitFn) {
          result = visitFn.call(visitor, node, key, parent, path, ancestors);

          if (result === BREAK) {
            break;
          }

          if (result === false) {
            if (!isLeaving) {
              path.pop();
              continue;
            }
          } else if (result !== undefined) {
            edits.push([key, result]);

            if (!isLeaving) {
              if (isNode(result)) {
                node = result;
              } else {
                path.pop();
                continue;
              }
            }
          }
        }
      }

      if (result === undefined && isEdited) {
        edits.push([key, node]);
      }

      if (isLeaving) {
        path.pop();
      } else {
        var _visitorKeys$node$kin;

        stack = {
          inArray: inArray,
          index: index,
          keys: keys,
          edits: edits,
          prev: stack
        };
        inArray = Array.isArray(node);
        keys = inArray ? node : (_visitorKeys$node$kin = visitorKeys[node.kind]) !== null && _visitorKeys$node$kin !== void 0 ? _visitorKeys$node$kin : [];
        index = -1;
        edits = [];

        if (parent) {
          ancestors.push(parent);
        }

        parent = node;
      }
    } while (stack !== undefined);

    if (edits.length !== 0) {
      newRoot = edits[edits.length - 1][1];
    }

    return newRoot;
  }
  /**
   * Given a visitor instance, if it is leaving or not, and a node kind, return
   * the function the visitor runtime should call.
   */

  function getVisitFn(visitor, kind, isLeaving) {
    var kindVisitor = visitor[kind];

    if (kindVisitor) {
      if (!isLeaving && typeof kindVisitor === 'function') {
        // { Kind() {} }
        return kindVisitor;
      }

      var kindSpecificVisitor = isLeaving ? kindVisitor.leave : kindVisitor.enter;

      if (typeof kindSpecificVisitor === 'function') {
        // { Kind: { enter() {}, leave() {} } }
        return kindSpecificVisitor;
      }
    } else {
      var specificVisitor = isLeaving ? visitor.leave : visitor.enter;

      if (specificVisitor) {
        if (typeof specificVisitor === 'function') {
          // { enter() {}, leave() {} }
          return specificVisitor;
        }

        var specificKindVisitor = specificVisitor[kind];

        if (typeof specificKindVisitor === 'function') {
          // { enter: { Kind() {} }, leave: { Kind() {} } }
          return specificKindVisitor;
        }
      }
    }
  }

  var genericMessage = "Invariant Violation";
  var _a = Object.setPrototypeOf,
      setPrototypeOf$2 = _a === void 0 ? function (obj, proto) {
    obj.__proto__ = proto;
    return obj;
  } : _a;

  var InvariantError =
  /** @class */
  function (_super) {
    __extends(InvariantError, _super);

    function InvariantError(message) {
      if (message === void 0) {
        message = genericMessage;
      }

      var _this = _super.call(this, typeof message === "number" ? genericMessage + ": " + message + " (see https://github.com/apollographql/invariant-packages)" : message) || this;

      _this.framesToPop = 1;
      _this.name = genericMessage;
      setPrototypeOf$2(_this, InvariantError.prototype);
      return _this;
    }

    return InvariantError;
  }(Error);

  function invariant$2(condition, message) {
    if (!condition) {
      throw new InvariantError(message);
    }
  }

  function wrapConsoleMethod(method) {
    return function () {
      return console[method].apply(console, arguments);
    };
  }

  (function (invariant) {
    invariant.warn = wrapConsoleMethod("warn");
    invariant.error = wrapConsoleMethod("error");
  })(invariant$2 || (invariant$2 = {})); // Code that uses ts-invariant with rollup-plugin-invariant may want to
  // import this process stub to avoid errors evaluating "development".
  // However, because most ESM-to-CJS compilers will rewrite the process import
  // as tsInvariant.process, which prevents proper replacement by minifiers, we
  // also attempt to define the stub globally when it is not already defined.


  var processStub = {
    env: {}
  };

  if (typeof process === "object") {
    processStub = process;
  } else try {
    // Using Function to evaluate this assignment in global scope also escapes
    // the strict mode of the current module, thereby allowing the assignment.
    // Inspired by https://github.com/facebook/regenerator/pull/369.
    Function("stub", "process = stub")(processStub);
  } catch (atLeastWeTried) {// The assignment can fail if a Content Security Policy heavy-handedly
    // forbids Function usage. In those environments, developers should take
    // extra care to replace "development" in their production builds,
    // or define an appropriate global.process polyfill.
  }

  var invariant$1$1 = invariant$2;
  registerComponent(invariant$1$1, {
    tmpl: _tmpl
  });

  var fastJsonStableStringify = function (data, opts) {
    if (!opts) opts = {};
    if (typeof opts === 'function') opts = {
      cmp: opts
    };
    var cycles = typeof opts.cycles === 'boolean' ? opts.cycles : false;

    var cmp = opts.cmp && function (f) {
      return function (node) {
        return function (a, b) {
          var aobj = {
            key: a,
            value: node[a]
          };
          var bobj = {
            key: b,
            value: node[b]
          };
          return f(aobj, bobj);
        };
      };
    }(opts.cmp);

    var seen = [];
    return function stringify(node) {
      if (node && node.toJSON && typeof node.toJSON === 'function') {
        node = node.toJSON();
      }

      if (node === undefined) return;
      if (typeof node == 'number') return isFinite(node) ? '' + node : 'null';
      if (typeof node !== 'object') return JSON.stringify(node);
      var i, out;

      if (Array.isArray(node)) {
        out = '[';

        for (i = 0; i < node.length; i++) {
          if (i) out += ',';
          out += stringify(node[i]) || 'null';
        }

        return out + ']';
      }

      if (node === null) return 'null';

      if (seen.indexOf(node) !== -1) {
        if (cycles) return JSON.stringify('__cycle__');
        throw new TypeError('Converting circular structure to JSON');
      }

      var seenIndex = seen.push(node) - 1;
      var keys = Object.keys(node).sort(cmp && cmp(node));
      out = '';

      for (i = 0; i < keys.length; i++) {
        var key = keys[i];
        var value = stringify(node[key]);
        if (!value) continue;
        if (out) out += ',';
        out += JSON.stringify(key) + ':' + value;
      }

      seen.splice(seenIndex, 1);
      return '{' + out + '}';
    }(data);
  };

  var _a$1 = Object.prototype,
      toString$2 = _a$1.toString,
      hasOwnProperty$3 = _a$1.hasOwnProperty;
  var previousComparisons = new Map();
  /**
   * Performs a deep equality check on two JavaScript values, tolerating cycles.
   */

  function equal(a, b) {
    try {
      return check(a, b);
    } finally {
      previousComparisons.clear();
    }
  }

  function check(a, b) {
    // If the two values are strictly equal, our job is easy.
    if (a === b) {
      return true;
    } // Object.prototype.toString returns a representation of the runtime type of
    // the given value that is considerably more precise than typeof.


    var aTag = toString$2.call(a);
    var bTag = toString$2.call(b); // If the runtime types of a and b are different, they could maybe be equal
    // under some interpretation of equality, but for simplicity and performance
    // we just return false instead.

    if (aTag !== bTag) {
      return false;
    }

    switch (aTag) {
      case '[object Array]':
        // Arrays are a lot like other objects, but we can cheaply compare their
        // lengths as a short-cut before comparing their elements.
        if (a.length !== b.length) return false;
      // Fall through to object case...

      case '[object Object]':
        {
          if (previouslyCompared(a, b)) return true;
          var aKeys = Object.keys(a);
          var bKeys = Object.keys(b); // If `a` and `b` have a different number of enumerable keys, they
          // must be different.

          var keyCount = aKeys.length;
          if (keyCount !== bKeys.length) return false; // Now make sure they have the same keys.

          for (var k = 0; k < keyCount; ++k) {
            if (!hasOwnProperty$3.call(b, aKeys[k])) {
              return false;
            }
          } // Finally, check deep equality of all child properties.


          for (var k = 0; k < keyCount; ++k) {
            var key = aKeys[k];

            if (!check(a[key], b[key])) {
              return false;
            }
          }

          return true;
        }

      case '[object Error]':
        return a.name === b.name && a.message === b.message;

      case '[object Number]':
        // Handle NaN, which is !== itself.
        if (a !== a) return b !== b;
      // Fall through to shared +a === +b case...

      case '[object Boolean]':
      case '[object Date]':
        return +a === +b;

      case '[object RegExp]':
      case '[object String]':
        return a == "" + b;

      case '[object Map]':
      case '[object Set]':
        {
          if (a.size !== b.size) return false;
          if (previouslyCompared(a, b)) return true;
          var aIterator = a.entries();
          var isMap = aTag === '[object Map]';

          while (true) {
            var info = aIterator.next();
            if (info.done) break; // If a instanceof Set, aValue === aKey.

            var _a = info.value,
                aKey = _a[0],
                aValue = _a[1]; // So this works the same way for both Set and Map.

            if (!b.has(aKey)) {
              return false;
            } // However, we care about deep equality of values only when dealing
            // with Map structures.


            if (isMap && !check(aValue, b.get(aKey))) {
              return false;
            }
          }

          return true;
        }
    } // Otherwise the values are not equal.


    return false;
  }

  function previouslyCompared(a, b) {
    // Though cyclic references can make an object graph appear infinite from the
    // perspective of a depth-first traversal, the graph still contains a finite
    // number of distinct object references. We use the previousComparisons cache
    // to avoid comparing the same pair of object references more than once, which
    // guarantees termination (even if we end up comparing every object in one
    // graph to every object in the other graph, which is extremely unlikely),
    // while still allowing weird isomorphic structures (like rings with different
    // lengths) a chance to pass the equality test.
    var bSet = previousComparisons.get(a);

    if (bSet) {
      // Return true here because we can be sure false will be returned somewhere
      // else if the objects are not equivalent.
      if (bSet.has(b)) return true;
    } else {
      previousComparisons.set(a, bSet = new Set());
    }

    bSet.add(b);
    return false;
  }

  registerComponent(equal, {
    tmpl: _tmpl
  });

  function isStringValue(value) {
    return value.kind === 'StringValue';
  }

  function isBooleanValue(value) {
    return value.kind === 'BooleanValue';
  }

  function isIntValue(value) {
    return value.kind === 'IntValue';
  }

  function isFloatValue(value) {
    return value.kind === 'FloatValue';
  }

  function isVariable(value) {
    return value.kind === 'Variable';
  }

  function isObjectValue(value) {
    return value.kind === 'ObjectValue';
  }

  function isListValue(value) {
    return value.kind === 'ListValue';
  }

  function isEnumValue(value) {
    return value.kind === 'EnumValue';
  }

  function isNullValue(value) {
    return value.kind === 'NullValue';
  }

  function valueToObjectRepresentation(argObj, name, value, variables) {
    if (isIntValue(value) || isFloatValue(value)) {
      argObj[name.value] = Number(value.value);
    } else if (isBooleanValue(value) || isStringValue(value)) {
      argObj[name.value] = value.value;
    } else if (isObjectValue(value)) {
      var nestedArgObj_1 = {};
      value.fields.map(function (obj) {
        return valueToObjectRepresentation(nestedArgObj_1, obj.name, obj.value, variables);
      });
      argObj[name.value] = nestedArgObj_1;
    } else if (isVariable(value)) {
      var variableValue = (variables || {})[value.name.value];
      argObj[name.value] = variableValue;
    } else if (isListValue(value)) {
      argObj[name.value] = value.values.map(function (listValue) {
        var nestedArgArrayObj = {};
        valueToObjectRepresentation(nestedArgArrayObj, name, listValue, variables);
        return nestedArgArrayObj[name.value];
      });
    } else if (isEnumValue(value)) {
      argObj[name.value] = value.value;
    } else if (isNullValue(value)) {
      argObj[name.value] = null;
    } else {
      throw  new InvariantError("The inline argument \"" + name.value + "\" of kind \"" + value.kind + "\"" + 'is not supported. Use variables instead of inline arguments to ' + 'overcome this limitation.');
    }
  }

  function storeKeyNameFromField(field, variables) {
    var directivesObj = null;

    if (field.directives) {
      directivesObj = {};
      field.directives.forEach(function (directive) {
        directivesObj[directive.name.value] = {};

        if (directive.arguments) {
          directive.arguments.forEach(function (_a) {
            var name = _a.name,
                value = _a.value;
            return valueToObjectRepresentation(directivesObj[directive.name.value], name, value, variables);
          });
        }
      });
    }

    var argObj = null;

    if (field.arguments && field.arguments.length) {
      argObj = {};
      field.arguments.forEach(function (_a) {
        var name = _a.name,
            value = _a.value;
        return valueToObjectRepresentation(argObj, name, value, variables);
      });
    }

    return getStoreKeyName(field.name.value, argObj, directivesObj);
  }

  var KNOWN_DIRECTIVES = ['connection', 'include', 'skip', 'client', 'rest', 'export'];

  function getStoreKeyName(fieldName, args, directives) {
    if (directives && directives['connection'] && directives['connection']['key']) {
      if (directives['connection']['filter'] && directives['connection']['filter'].length > 0) {
        var filterKeys = directives['connection']['filter'] ? directives['connection']['filter'] : [];
        filterKeys.sort();
        var queryArgs_1 = args;
        var filteredArgs_1 = {};
        filterKeys.forEach(function (key) {
          filteredArgs_1[key] = queryArgs_1[key];
        });
        return directives['connection']['key'] + "(" + JSON.stringify(filteredArgs_1) + ")";
      } else {
        return directives['connection']['key'];
      }
    }

    var completeFieldName = fieldName;

    if (args) {
      var stringifiedArgs = fastJsonStableStringify(args);
      completeFieldName += "(" + stringifiedArgs + ")";
    }

    if (directives) {
      Object.keys(directives).forEach(function (key) {
        if (KNOWN_DIRECTIVES.indexOf(key) !== -1) return;

        if (directives[key] && Object.keys(directives[key]).length) {
          completeFieldName += "@" + key + "(" + JSON.stringify(directives[key]) + ")";
        } else {
          completeFieldName += "@" + key;
        }
      });
    }

    return completeFieldName;
  }

  function argumentsObjectFromField(field, variables) {
    if (field.arguments && field.arguments.length) {
      var argObj_1 = {};
      field.arguments.forEach(function (_a) {
        var name = _a.name,
            value = _a.value;
        return valueToObjectRepresentation(argObj_1, name, value, variables);
      });
      return argObj_1;
    }

    return null;
  }

  function resultKeyNameFromField(field) {
    return field.alias ? field.alias.value : field.name.value;
  }

  function isField(selection) {
    return selection.kind === 'Field';
  }

  function isInlineFragment(selection) {
    return selection.kind === 'InlineFragment';
  }

  function isIdValue(idObject) {
    return idObject && idObject.type === 'id' && typeof idObject.generated === 'boolean';
  }

  function toIdValue(idConfig, generated) {
    if (generated === void 0) {
      generated = false;
    }

    return __assign({
      type: 'id',
      generated: generated
    }, typeof idConfig === 'string' ? {
      id: idConfig,
      typename: undefined
    } : idConfig);
  }

  function isJsonValue(jsonObject) {
    return jsonObject != null && typeof jsonObject === 'object' && jsonObject.type === 'json';
  }

  function getDirectiveInfoFromField(field, variables) {
    if (field.directives && field.directives.length) {
      var directiveObj_1 = {};
      field.directives.forEach(function (directive) {
        directiveObj_1[directive.name.value] = argumentsObjectFromField(directive, variables);
      });
      return directiveObj_1;
    }

    return null;
  }

  function shouldInclude(selection, variables) {
    if (variables === void 0) {
      variables = {};
    }

    return getInclusionDirectives(selection.directives).every(function (_a) {
      var directive = _a.directive,
          ifArgument = _a.ifArgument;
      var evaledValue = false;

      if (ifArgument.value.kind === 'Variable') {
        evaledValue = variables[ifArgument.value.name.value];
         invariant$2(evaledValue !== void 0, "Invalid variable referenced in @" + directive.name.value + " directive.");
      } else {
        evaledValue = ifArgument.value.value;
      }

      return directive.name.value === 'skip' ? !evaledValue : evaledValue;
    });
  }

  function getDirectiveNames(doc) {
    var names = [];
    visit(doc, {
      Directive: function (node) {
        names.push(node.name.value);
      }
    });
    return names;
  }

  function hasDirectives(names, doc) {
    return getDirectiveNames(doc).some(function (name) {
      return names.indexOf(name) > -1;
    });
  }

  function hasClientExports(document) {
    return document && hasDirectives(['client'], document) && hasDirectives(['export'], document);
  }

  function isInclusionDirective(_a) {
    var value = _a.name.value;
    return value === 'skip' || value === 'include';
  }

  function getInclusionDirectives(directives) {
    return directives ? directives.filter(isInclusionDirective).map(function (directive) {
      var directiveArguments = directive.arguments;
      var directiveName = directive.name.value;
       invariant$2(directiveArguments && directiveArguments.length === 1, "Incorrect number of arguments for the @" + directiveName + " directive.");
      var ifArgument = directiveArguments[0];
       invariant$2(ifArgument.name && ifArgument.name.value === 'if', "Invalid argument for the @" + directiveName + " directive.");
      var ifValue = ifArgument.value;
       invariant$2(ifValue && (ifValue.kind === 'Variable' || ifValue.kind === 'BooleanValue'), "Argument for the @" + directiveName + " directive must be a variable or a boolean value.");
      return {
        directive: directive,
        ifArgument: ifArgument
      };
    }) : [];
  }

  function getFragmentQueryDocument(document, fragmentName) {
    var actualFragmentName = fragmentName;
    var fragments = [];
    document.definitions.forEach(function (definition) {
      if (definition.kind === 'OperationDefinition') {
        throw  new InvariantError("Found a " + definition.operation + " operation" + (definition.name ? " named '" + definition.name.value + "'" : '') + ". " + 'No operations are allowed when using a fragment as a query. Only fragments are allowed.');
      }

      if (definition.kind === 'FragmentDefinition') {
        fragments.push(definition);
      }
    });

    if (typeof actualFragmentName === 'undefined') {
       invariant$2(fragments.length === 1, "Found " + fragments.length + " fragments. `fragmentName` must be provided when there is not exactly 1 fragment.");
      actualFragmentName = fragments[0].name.value;
    }

    var query = __assign(__assign({}, document), {
      definitions: __spreadArrays([{
        kind: 'OperationDefinition',
        operation: 'query',
        selectionSet: {
          kind: 'SelectionSet',
          selections: [{
            kind: 'FragmentSpread',
            name: {
              kind: 'Name',
              value: actualFragmentName
            }
          }]
        }
      }], document.definitions)
    });

    return query;
  }

  function assign$2(target) {
    var sources = [];

    for (var _i = 1; _i < arguments.length; _i++) {
      sources[_i - 1] = arguments[_i];
    }

    sources.forEach(function (source) {
      if (typeof source === 'undefined' || source === null) {
        return;
      }

      Object.keys(source).forEach(function (key) {
        target[key] = source[key];
      });
    });
    return target;
  }

  function checkDocument(doc) {
     invariant$2(doc && doc.kind === 'Document', "Expecting a parsed GraphQL document. Perhaps you need to wrap the query string in a \"gql\" tag? http://docs.apollostack.com/apollo-client/core.html#gql");
    var operations = doc.definitions.filter(function (d) {
      return d.kind !== 'FragmentDefinition';
    }).map(function (definition) {
      if (definition.kind !== 'OperationDefinition') {
        throw  new InvariantError("Schema type definitions not allowed in queries. Found: \"" + definition.kind + "\"");
      }

      return definition;
    });
     invariant$2(operations.length <= 1, "Ambiguous GraphQL document: contains " + operations.length + " operations");
    return doc;
  }

  function getOperationDefinition(doc) {
    checkDocument(doc);
    return doc.definitions.filter(function (definition) {
      return definition.kind === 'OperationDefinition';
    })[0];
  }

  function getOperationName(doc) {
    return doc.definitions.filter(function (definition) {
      return definition.kind === 'OperationDefinition' && definition.name;
    }).map(function (x) {
      return x.name.value;
    })[0] || null;
  }

  function getFragmentDefinitions(doc) {
    return doc.definitions.filter(function (definition) {
      return definition.kind === 'FragmentDefinition';
    });
  }

  function getQueryDefinition(doc) {
    var queryDef = getOperationDefinition(doc);
     invariant$2(queryDef && queryDef.operation === 'query', 'Must contain a query definition.');
    return queryDef;
  }

  function getFragmentDefinition(doc) {
     invariant$2(doc.kind === 'Document', "Expecting a parsed GraphQL document. Perhaps you need to wrap the query string in a \"gql\" tag? http://docs.apollostack.com/apollo-client/core.html#gql");
     invariant$2(doc.definitions.length <= 1, 'Fragment must have exactly one definition.');
    var fragmentDef = doc.definitions[0];
     invariant$2(fragmentDef.kind === 'FragmentDefinition', 'Must be a fragment definition.');
    return fragmentDef;
  }

  function getMainDefinition(queryDoc) {
    checkDocument(queryDoc);
    var fragmentDefinition;

    for (var _i = 0, _a = queryDoc.definitions; _i < _a.length; _i++) {
      var definition = _a[_i];

      if (definition.kind === 'OperationDefinition') {
        var operation = definition.operation;

        if (operation === 'query' || operation === 'mutation' || operation === 'subscription') {
          return definition;
        }
      }

      if (definition.kind === 'FragmentDefinition' && !fragmentDefinition) {
        fragmentDefinition = definition;
      }
    }

    if (fragmentDefinition) {
      return fragmentDefinition;
    }

    throw  new InvariantError('Expected a parsed GraphQL query with a query, mutation, subscription, or a fragment.');
  }

  function createFragmentMap(fragments) {
    if (fragments === void 0) {
      fragments = [];
    }

    var symTable = {};
    fragments.forEach(function (fragment) {
      symTable[fragment.name.value] = fragment;
    });
    return symTable;
  }

  function getDefaultValues(definition) {
    if (definition && definition.variableDefinitions && definition.variableDefinitions.length) {
      var defaultValues = definition.variableDefinitions.filter(function (_a) {
        var defaultValue = _a.defaultValue;
        return defaultValue;
      }).map(function (_a) {
        var variable = _a.variable,
            defaultValue = _a.defaultValue;
        var defaultValueObj = {};
        valueToObjectRepresentation(defaultValueObj, variable.name, defaultValue);
        return defaultValueObj;
      });
      return assign$2.apply(void 0, __spreadArrays([{}], defaultValues));
    }

    return {};
  }

  function filterInPlace(array, test, context) {
    var target = 0;
    array.forEach(function (elem, i) {
      if (test.call(this, elem, i, array)) {
        array[target++] = elem;
      }
    }, context);
    array.length = target;
    return array;
  }

  var TYPENAME_FIELD = {
    kind: 'Field',
    name: {
      kind: 'Name',
      value: '__typename'
    }
  };

  function isEmpty(op, fragments) {
    return op.selectionSet.selections.every(function (selection) {
      return selection.kind === 'FragmentSpread' && isEmpty(fragments[selection.name.value], fragments);
    });
  }

  function nullIfDocIsEmpty(doc) {
    return isEmpty(getOperationDefinition(doc) || getFragmentDefinition(doc), createFragmentMap(getFragmentDefinitions(doc))) ? null : doc;
  }

  function getDirectiveMatcher(directives) {
    return function directiveMatcher(directive) {
      return directives.some(function (dir) {
        return dir.name && dir.name === directive.name.value || dir.test && dir.test(directive);
      });
    };
  }

  function removeDirectivesFromDocument(directives, doc) {
    var variablesInUse = Object.create(null);
    var variablesToRemove = [];
    var fragmentSpreadsInUse = Object.create(null);
    var fragmentSpreadsToRemove = [];
    var modifiedDoc = nullIfDocIsEmpty(visit(doc, {
      Variable: {
        enter: function (node, _key, parent) {
          if (parent.kind !== 'VariableDefinition') {
            variablesInUse[node.name.value] = true;
          }
        }
      },
      Field: {
        enter: function (node) {
          if (directives && node.directives) {
            var shouldRemoveField = directives.some(function (directive) {
              return directive.remove;
            });

            if (shouldRemoveField && node.directives && node.directives.some(getDirectiveMatcher(directives))) {
              if (node.arguments) {
                node.arguments.forEach(function (arg) {
                  if (arg.value.kind === 'Variable') {
                    variablesToRemove.push({
                      name: arg.value.name.value
                    });
                  }
                });
              }

              if (node.selectionSet) {
                getAllFragmentSpreadsFromSelectionSet(node.selectionSet).forEach(function (frag) {
                  fragmentSpreadsToRemove.push({
                    name: frag.name.value
                  });
                });
              }

              return null;
            }
          }
        }
      },
      FragmentSpread: {
        enter: function (node) {
          fragmentSpreadsInUse[node.name.value] = true;
        }
      },
      Directive: {
        enter: function (node) {
          if (getDirectiveMatcher(directives)(node)) {
            return null;
          }
        }
      }
    }));

    if (modifiedDoc && filterInPlace(variablesToRemove, function (v) {
      return !variablesInUse[v.name];
    }).length) {
      modifiedDoc = removeArgumentsFromDocument(variablesToRemove, modifiedDoc);
    }

    if (modifiedDoc && filterInPlace(fragmentSpreadsToRemove, function (fs) {
      return !fragmentSpreadsInUse[fs.name];
    }).length) {
      modifiedDoc = removeFragmentSpreadFromDocument(fragmentSpreadsToRemove, modifiedDoc);
    }

    return modifiedDoc;
  }

  function addTypenameToDocument(doc) {
    return visit(checkDocument(doc), {
      SelectionSet: {
        enter: function (node, _key, parent) {
          if (parent && parent.kind === 'OperationDefinition') {
            return;
          }

          var selections = node.selections;

          if (!selections) {
            return;
          }

          var skip = selections.some(function (selection) {
            return isField(selection) && (selection.name.value === '__typename' || selection.name.value.lastIndexOf('__', 0) === 0);
          });

          if (skip) {
            return;
          }

          var field = parent;

          if (isField(field) && field.directives && field.directives.some(function (d) {
            return d.name.value === 'export';
          })) {
            return;
          }

          return __assign(__assign({}, node), {
            selections: __spreadArrays(selections, [TYPENAME_FIELD])
          });
        }
      }
    });
  }

  var connectionRemoveConfig = {
    test: function (directive) {
      var willRemove = directive.name.value === 'connection';

      if (willRemove) {
        if (!directive.arguments || !directive.arguments.some(function (arg) {
          return arg.name.value === 'key';
        })) {
           invariant$2.warn('Removing an @connection directive even though it does not have a key. ' + 'You may want to use the key parameter to specify a store key.');
        }
      }

      return willRemove;
    }
  };

  function removeConnectionDirectiveFromDocument(doc) {
    return removeDirectivesFromDocument([connectionRemoveConfig], checkDocument(doc));
  }

  function getArgumentMatcher(config) {
    return function argumentMatcher(argument) {
      return config.some(function (aConfig) {
        return argument.value && argument.value.kind === 'Variable' && argument.value.name && (aConfig.name === argument.value.name.value || aConfig.test && aConfig.test(argument));
      });
    };
  }

  function removeArgumentsFromDocument(config, doc) {
    var argMatcher = getArgumentMatcher(config);
    return nullIfDocIsEmpty(visit(doc, {
      OperationDefinition: {
        enter: function (node) {
          return __assign(__assign({}, node), {
            variableDefinitions: node.variableDefinitions.filter(function (varDef) {
              return !config.some(function (arg) {
                return arg.name === varDef.variable.name.value;
              });
            })
          });
        }
      },
      Field: {
        enter: function (node) {
          var shouldRemoveField = config.some(function (argConfig) {
            return argConfig.remove;
          });

          if (shouldRemoveField) {
            var argMatchCount_1 = 0;
            node.arguments.forEach(function (arg) {
              if (argMatcher(arg)) {
                argMatchCount_1 += 1;
              }
            });

            if (argMatchCount_1 === 1) {
              return null;
            }
          }
        }
      },
      Argument: {
        enter: function (node) {
          if (argMatcher(node)) {
            return null;
          }
        }
      }
    }));
  }

  function removeFragmentSpreadFromDocument(config, doc) {
    function enter(node) {
      if (config.some(function (def) {
        return def.name === node.name.value;
      })) {
        return null;
      }
    }

    return nullIfDocIsEmpty(visit(doc, {
      FragmentSpread: {
        enter: enter
      },
      FragmentDefinition: {
        enter: enter
      }
    }));
  }

  function getAllFragmentSpreadsFromSelectionSet(selectionSet) {
    var allFragments = [];
    selectionSet.selections.forEach(function (selection) {
      if ((isField(selection) || isInlineFragment(selection)) && selection.selectionSet) {
        getAllFragmentSpreadsFromSelectionSet(selection.selectionSet).forEach(function (frag) {
          return allFragments.push(frag);
        });
      } else if (selection.kind === 'FragmentSpread') {
        allFragments.push(selection);
      }
    });
    return allFragments;
  }

  function buildQueryFromSelectionSet(document) {
    var definition = getMainDefinition(document);
    var definitionOperation = definition.operation;

    if (definitionOperation === 'query') {
      return document;
    }

    var modifiedDoc = visit(document, {
      OperationDefinition: {
        enter: function (node) {
          return __assign(__assign({}, node), {
            operation: 'query'
          });
        }
      }
    });
    return modifiedDoc;
  }

  function removeClientSetsFromDocument(document) {
    checkDocument(document);
    var modifiedDoc = removeDirectivesFromDocument([{
      test: function (directive) {
        return directive.name.value === 'client';
      },
      remove: true
    }], document);

    if (modifiedDoc) {
      modifiedDoc = visit(modifiedDoc, {
        FragmentDefinition: {
          enter: function (node) {
            if (node.selectionSet) {
              var isTypenameOnly = node.selectionSet.selections.every(function (selection) {
                return isField(selection) && selection.name.value === '__typename';
              });

              if (isTypenameOnly) {
                return null;
              }
            }
          }
        }
      });
    }

    return modifiedDoc;
  }

  var canUseWeakMap = typeof WeakMap === 'function' && !(typeof navigator === 'object' && navigator.product === 'ReactNative');
  var toString$3 = Object.prototype.toString;

  function cloneDeep(value) {
    return cloneDeepHelper(value, new Map());
  }

  function cloneDeepHelper(val, seen) {
    switch (toString$3.call(val)) {
      case "[object Array]":
        {
          if (seen.has(val)) return seen.get(val);
          var copy_1 = val.slice(0);
          seen.set(val, copy_1);
          copy_1.forEach(function (child, i) {
            copy_1[i] = cloneDeepHelper(child, seen);
          });
          return copy_1;
        }

      case "[object Object]":
        {
          if (seen.has(val)) return seen.get(val);
          var copy_2 = Object.create(Object.getPrototypeOf(val));
          seen.set(val, copy_2);
          Object.keys(val).forEach(function (key) {
            copy_2[key] = cloneDeepHelper(val[key], seen);
          });
          return copy_2;
        }

      default:
        return val;
    }
  }

  function getEnv() {
    if (typeof process !== 'undefined' && "development") {
      return "development";
    }

    return 'development';
  }

  function isEnv(env) {
    return getEnv() === env;
  }

  function isProduction() {
    return isEnv('production') === true;
  }

  function isDevelopment() {
    return isEnv('development') === true;
  }

  function isTest() {
    return isEnv('test') === true;
  }

  function tryFunctionOrLogError(f) {
    try {
      return f();
    } catch (e) {
      if (console.error) {
        console.error(e);
      }
    }
  }

  function graphQLResultHasError(result) {
    return result.errors && result.errors.length;
  }

  function deepFreeze(o) {
    Object.freeze(o);
    Object.getOwnPropertyNames(o).forEach(function (prop) {
      if (o[prop] !== null && (typeof o[prop] === 'object' || typeof o[prop] === 'function') && !Object.isFrozen(o[prop])) {
        deepFreeze(o[prop]);
      }
    });
    return o;
  }

  function maybeDeepFreeze(obj) {
    if (isDevelopment() || isTest()) {
      var symbolIsPolyfilled = typeof Symbol === 'function' && typeof Symbol('') === 'string';

      if (!symbolIsPolyfilled) {
        return deepFreeze(obj);
      }
    }

    return obj;
  }

  var hasOwnProperty$4 = Object.prototype.hasOwnProperty;

  function mergeDeep() {
    var sources = [];

    for (var _i = 0; _i < arguments.length; _i++) {
      sources[_i] = arguments[_i];
    }

    return mergeDeepArray(sources);
  }

  function mergeDeepArray(sources) {
    var target = sources[0] || {};
    var count = sources.length;

    if (count > 1) {
      var pastCopies = [];
      target = shallowCopyForMerge(target, pastCopies);

      for (var i = 1; i < count; ++i) {
        target = mergeHelper(target, sources[i], pastCopies);
      }
    }

    return target;
  }

  function isObject$3(obj) {
    return obj !== null && typeof obj === 'object';
  }

  function mergeHelper(target, source, pastCopies) {
    if (isObject$3(source) && isObject$3(target)) {
      if (Object.isExtensible && !Object.isExtensible(target)) {
        target = shallowCopyForMerge(target, pastCopies);
      }

      Object.keys(source).forEach(function (sourceKey) {
        var sourceValue = source[sourceKey];

        if (hasOwnProperty$4.call(target, sourceKey)) {
          var targetValue = target[sourceKey];

          if (sourceValue !== targetValue) {
            target[sourceKey] = mergeHelper(shallowCopyForMerge(targetValue, pastCopies), sourceValue, pastCopies);
          }
        } else {
          target[sourceKey] = sourceValue;
        }
      });
      return target;
    }

    return source;
  }

  function shallowCopyForMerge(value, pastCopies) {
    if (value !== null && typeof value === 'object' && pastCopies.indexOf(value) < 0) {
      if (Array.isArray(value)) {
        value = value.slice(0);
      } else {
        value = __assign({
          __proto__: Object.getPrototypeOf(value)
        }, value);
      }

      pastCopies.push(value);
    }

    return value;
  }

  function unwrapExports (x) {
  	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
  }

  function createCommonjsModule(fn, module) {
  	return module = { exports: {} }, fn(module, module.exports), module.exports;
  }

  function getCjsExportFromNamespace (n) {
  	return n && n['default'] || n;
  }

  var Observable_1 = createCommonjsModule(function (module, exports) {

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Observable = void 0;

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  } // === Symbol Support ===


  var hasSymbols = function () {
    return typeof Symbol === 'function';
  };

  var hasSymbol = function (name) {
    return hasSymbols() && Boolean(Symbol[name]);
  };

  var getSymbol = function (name) {
    return hasSymbol(name) ? Symbol[name] : '@@' + name;
  };

  if (hasSymbols() && !hasSymbol('observable')) {
    Symbol.observable = Symbol('observable');
  }

  var SymbolIterator = getSymbol('iterator');
  var SymbolObservable = getSymbol('observable');
  var SymbolSpecies = getSymbol('species'); // === Abstract Operations ===

  function getMethod(obj, key) {
    var value = obj[key];
    if (value == null) return undefined;
    if (typeof value !== 'function') throw new TypeError(value + ' is not a function');
    return value;
  }

  function getSpecies(obj) {
    var ctor = obj.constructor;

    if (ctor !== undefined) {
      ctor = ctor[SymbolSpecies];

      if (ctor === null) {
        ctor = undefined;
      }
    }

    return ctor !== undefined ? ctor : Observable;
  }

  function isObservable(x) {
    return x instanceof Observable; // SPEC: Brand check
  }

  function hostReportError(e) {
    if (hostReportError.log) {
      hostReportError.log(e);
    } else {
      setTimeout(function () {
        throw e;
      });
    }
  }

  function enqueue(fn) {
    Promise.resolve().then(function () {
      try {
        fn();
      } catch (e) {
        hostReportError(e);
      }
    });
  }

  function cleanupSubscription(subscription) {
    var cleanup = subscription._cleanup;
    if (cleanup === undefined) return;
    subscription._cleanup = undefined;

    if (!cleanup) {
      return;
    }

    try {
      if (typeof cleanup === 'function') {
        cleanup();
      } else {
        var unsubscribe = getMethod(cleanup, 'unsubscribe');

        if (unsubscribe) {
          unsubscribe.call(cleanup);
        }
      }
    } catch (e) {
      hostReportError(e);
    }
  }

  function closeSubscription(subscription) {
    subscription._observer = undefined;
    subscription._queue = undefined;
    subscription._state = 'closed';
  }

  function flushSubscription(subscription) {
    var queue = subscription._queue;

    if (!queue) {
      return;
    }

    subscription._queue = undefined;
    subscription._state = 'ready';

    for (var i = 0; i < queue.length; ++i) {
      notifySubscription(subscription, queue[i].type, queue[i].value);
      if (subscription._state === 'closed') break;
    }
  }

  function notifySubscription(subscription, type, value) {
    subscription._state = 'running';
    var observer = subscription._observer;

    try {
      var m = getMethod(observer, type);

      switch (type) {
        case 'next':
          if (m) m.call(observer, value);
          break;

        case 'error':
          closeSubscription(subscription);
          if (m) m.call(observer, value);else throw value;
          break;

        case 'complete':
          closeSubscription(subscription);
          if (m) m.call(observer);
          break;
      }
    } catch (e) {
      hostReportError(e);
    }

    if (subscription._state === 'closed') cleanupSubscription(subscription);else if (subscription._state === 'running') subscription._state = 'ready';
  }

  function onNotify(subscription, type, value) {
    if (subscription._state === 'closed') return;

    if (subscription._state === 'buffering') {
      subscription._queue.push({
        type: type,
        value: value
      });

      return;
    }

    if (subscription._state !== 'ready') {
      subscription._state = 'buffering';
      subscription._queue = [{
        type: type,
        value: value
      }];
      enqueue(function () {
        return flushSubscription(subscription);
      });
      return;
    }

    notifySubscription(subscription, type, value);
  }

  var Subscription =
  /*#__PURE__*/
  function () {
    function Subscription(observer, subscriber) {
      _classCallCheck(this, Subscription); // ASSERT: observer is an object
      // ASSERT: subscriber is callable


      this._cleanup = undefined;
      this._observer = observer;
      this._queue = undefined;
      this._state = 'initializing';
      var subscriptionObserver = new SubscriptionObserver(this);

      try {
        this._cleanup = subscriber.call(undefined, subscriptionObserver);
      } catch (e) {
        subscriptionObserver.error(e);
      }

      if (this._state === 'initializing') this._state = 'ready';
    }

    _createClass(Subscription, [{
      key: "unsubscribe",
      value: function unsubscribe() {
        if (this._state !== 'closed') {
          closeSubscription(this);
          cleanupSubscription(this);
        }
      }
    }, {
      key: "closed",
      get: function () {
        return this._state === 'closed';
      }
    }]);

    return Subscription;
  }();

  var SubscriptionObserver =
  /*#__PURE__*/
  function () {
    function SubscriptionObserver(subscription) {
      _classCallCheck(this, SubscriptionObserver);

      this._subscription = subscription;
    }

    _createClass(SubscriptionObserver, [{
      key: "next",
      value: function next(value) {
        onNotify(this._subscription, 'next', value);
      }
    }, {
      key: "error",
      value: function error(value) {
        onNotify(this._subscription, 'error', value);
      }
    }, {
      key: "complete",
      value: function complete() {
        onNotify(this._subscription, 'complete');
      }
    }, {
      key: "closed",
      get: function () {
        return this._subscription._state === 'closed';
      }
    }]);

    return SubscriptionObserver;
  }();

  var Observable =
  /*#__PURE__*/
  function () {
    function Observable(subscriber) {
      _classCallCheck(this, Observable);

      if (!(this instanceof Observable)) throw new TypeError('Observable cannot be called as a function');
      if (typeof subscriber !== 'function') throw new TypeError('Observable initializer must be a function');
      this._subscriber = subscriber;
    }

    _createClass(Observable, [{
      key: "subscribe",
      value: function subscribe(observer) {
        if (typeof observer !== 'object' || observer === null) {
          observer = {
            next: observer,
            error: arguments[1],
            complete: arguments[2]
          };
        }

        return new Subscription(observer, this._subscriber);
      }
    }, {
      key: "forEach",
      value: function forEach(fn) {
        var _this = this;

        return new Promise(function (resolve, reject) {
          if (typeof fn !== 'function') {
            reject(new TypeError(fn + ' is not a function'));
            return;
          }

          function done() {
            subscription.unsubscribe();
            resolve();
          }

          var subscription = _this.subscribe({
            next: function (value) {
              try {
                fn(value, done);
              } catch (e) {
                reject(e);
                subscription.unsubscribe();
              }
            },
            error: reject,
            complete: resolve
          });
        });
      }
    }, {
      key: "map",
      value: function map(fn) {
        var _this2 = this;

        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        return new C(function (observer) {
          return _this2.subscribe({
            next: function (value) {
              try {
                value = fn(value);
              } catch (e) {
                return observer.error(e);
              }

              observer.next(value);
            },
            error: function (e) {
              observer.error(e);
            },
            complete: function () {
              observer.complete();
            }
          });
        });
      }
    }, {
      key: "filter",
      value: function filter(fn) {
        var _this3 = this;

        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        return new C(function (observer) {
          return _this3.subscribe({
            next: function (value) {
              try {
                if (!fn(value)) return;
              } catch (e) {
                return observer.error(e);
              }

              observer.next(value);
            },
            error: function (e) {
              observer.error(e);
            },
            complete: function () {
              observer.complete();
            }
          });
        });
      }
    }, {
      key: "reduce",
      value: function reduce(fn) {
        var _this4 = this;

        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        var hasSeed = arguments.length > 1;
        var hasValue = false;
        var seed = arguments[1];
        var acc = seed;
        return new C(function (observer) {
          return _this4.subscribe({
            next: function (value) {
              var first = !hasValue;
              hasValue = true;

              if (!first || hasSeed) {
                try {
                  acc = fn(acc, value);
                } catch (e) {
                  return observer.error(e);
                }
              } else {
                acc = value;
              }
            },
            error: function (e) {
              observer.error(e);
            },
            complete: function () {
              if (!hasValue && !hasSeed) return observer.error(new TypeError('Cannot reduce an empty sequence'));
              observer.next(acc);
              observer.complete();
            }
          });
        });
      }
    }, {
      key: "concat",
      value: function concat() {
        var _this5 = this;

        for (var _len = arguments.length, sources = new Array(_len), _key = 0; _key < _len; _key++) {
          sources[_key] = arguments[_key];
        }

        var C = getSpecies(this);
        return new C(function (observer) {
          var subscription;
          var index = 0;

          function startNext(next) {
            subscription = next.subscribe({
              next: function (v) {
                observer.next(v);
              },
              error: function (e) {
                observer.error(e);
              },
              complete: function () {
                if (index === sources.length) {
                  subscription = undefined;
                  observer.complete();
                } else {
                  startNext(C.from(sources[index++]));
                }
              }
            });
          }

          startNext(_this5);
          return function () {
            if (subscription) {
              subscription.unsubscribe();
              subscription = undefined;
            }
          };
        });
      }
    }, {
      key: "flatMap",
      value: function flatMap(fn) {
        var _this6 = this;

        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        return new C(function (observer) {
          var subscriptions = [];

          var outer = _this6.subscribe({
            next: function (value) {
              if (fn) {
                try {
                  value = fn(value);
                } catch (e) {
                  return observer.error(e);
                }
              }

              var inner = C.from(value).subscribe({
                next: function (value) {
                  observer.next(value);
                },
                error: function (e) {
                  observer.error(e);
                },
                complete: function () {
                  var i = subscriptions.indexOf(inner);
                  if (i >= 0) subscriptions.splice(i, 1);
                  completeIfDone();
                }
              });
              subscriptions.push(inner);
            },
            error: function (e) {
              observer.error(e);
            },
            complete: function () {
              completeIfDone();
            }
          });

          function completeIfDone() {
            if (outer.closed && subscriptions.length === 0) observer.complete();
          }

          return function () {
            subscriptions.forEach(function (s) {
              return s.unsubscribe();
            });
            outer.unsubscribe();
          };
        });
      }
    }, {
      key: SymbolObservable,
      value: function () {
        return this;
      }
    }], [{
      key: "from",
      value: function from(x) {
        var C = typeof this === 'function' ? this : Observable;
        if (x == null) throw new TypeError(x + ' is not an object');
        var method = getMethod(x, SymbolObservable);

        if (method) {
          var observable = method.call(x);
          if (Object(observable) !== observable) throw new TypeError(observable + ' is not an object');
          if (isObservable(observable) && observable.constructor === C) return observable;
          return new C(function (observer) {
            return observable.subscribe(observer);
          });
        }

        if (hasSymbol('iterator')) {
          method = getMethod(x, SymbolIterator);

          if (method) {
            return new C(function (observer) {
              enqueue(function () {
                if (observer.closed) return;
                var _iteratorNormalCompletion = true;
                var _didIteratorError = false;
                var _iteratorError = undefined;

                try {
                  for (var _iterator = method.call(x)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var _item = _step.value;
                    observer.next(_item);
                    if (observer.closed) return;
                  }
                } catch (err) {
                  _didIteratorError = true;
                  _iteratorError = err;
                } finally {
                  try {
                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                      _iterator.return();
                    }
                  } finally {
                    if (_didIteratorError) {
                      throw _iteratorError;
                    }
                  }
                }

                observer.complete();
              });
            });
          }
        }

        if (Array.isArray(x)) {
          return new C(function (observer) {
            enqueue(function () {
              if (observer.closed) return;

              for (var i = 0; i < x.length; ++i) {
                observer.next(x[i]);
                if (observer.closed) return;
              }

              observer.complete();
            });
          });
        }

        throw new TypeError(x + ' is not observable');
      }
    }, {
      key: "of",
      value: function of() {
        for (var _len2 = arguments.length, items = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          items[_key2] = arguments[_key2];
        }

        var C = typeof this === 'function' ? this : Observable;
        return new C(function (observer) {
          enqueue(function () {
            if (observer.closed) return;

            for (var i = 0; i < items.length; ++i) {
              observer.next(items[i]);
              if (observer.closed) return;
            }

            observer.complete();
          });
        });
      }
    }, {
      key: SymbolSpecies,
      get: function () {
        return this;
      }
    }]);

    return Observable;
  }();

  exports.Observable = Observable;

  if (hasSymbols()) {
    Object.defineProperty(Observable, Symbol('extensions'), {
      value: {
        symbol: SymbolObservable,
        hostReportError: hostReportError
      },
      configurable: true
    });
  }
  });

  unwrapExports(Observable_1);
  var Observable_2 = Observable_1.Observable;

  var zenObservable = Observable_1.Observable;

  var Observable = zenObservable;
  var Observable$1 = registerComponent(Observable, {
    tmpl: _tmpl
  });

  function validateOperation(operation) {
    var OPERATION_FIELDS = ['query', 'operationName', 'variables', 'extensions', 'context'];

    for (var _i = 0, _a = Object.keys(operation); _i < _a.length; _i++) {
      var key = _a[_i];

      if (OPERATION_FIELDS.indexOf(key) < 0) {
        throw  new InvariantError("illegal argument: " + key);
      }
    }

    return operation;
  }

  var LinkError = function (_super) {
    __extends(LinkError, _super);

    function LinkError(message, link) {
      var _this = _super.call(this, message) || this;

      _this.link = link;
      return _this;
    }

    return LinkError;
  }(Error);

  function isTerminating(link) {
    return link.request.length <= 1;
  }

  function fromError(errorValue) {
    return new Observable$1(function (observer) {
      observer.error(errorValue);
    });
  }

  function transformOperation(operation) {
    var transformedOperation = {
      variables: operation.variables || {},
      extensions: operation.extensions || {},
      operationName: operation.operationName,
      query: operation.query
    };

    if (!transformedOperation.operationName) {
      transformedOperation.operationName = typeof transformedOperation.query !== 'string' ? getOperationName(transformedOperation.query) : '';
    }

    return transformedOperation;
  }

  function createOperation(starting, operation) {
    var context = __assign({}, starting);

    var setContext = function (next) {
      if (typeof next === 'function') {
        context = __assign({}, context, next(context));
      } else {
        context = __assign({}, context, next);
      }
    };

    var getContext = function () {
      return __assign({}, context);
    };

    Object.defineProperty(operation, 'setContext', {
      enumerable: false,
      value: setContext
    });
    Object.defineProperty(operation, 'getContext', {
      enumerable: false,
      value: getContext
    });
    Object.defineProperty(operation, 'toKey', {
      enumerable: false,
      value: function () {
        return getKey(operation);
      }
    });
    return operation;
  }

  function getKey(operation) {
    var query = operation.query,
        variables = operation.variables,
        operationName = operation.operationName;
    return JSON.stringify([operationName, query, variables]);
  }

  function passthrough(op, forward) {
    return forward ? forward(op) : Observable$1.of();
  }

  function toLink(handler) {
    return typeof handler === 'function' ? new ApolloLink(handler) : handler;
  }

  function empty() {
    return new ApolloLink(function () {
      return Observable$1.of();
    });
  }

  function from(links) {
    if (links.length === 0) return empty();
    return links.map(toLink).reduce(function (x, y) {
      return x.concat(y);
    });
  }

  function split(test, left, right) {
    var leftLink = toLink(left);
    var rightLink = toLink(right || new ApolloLink(passthrough));

    if (isTerminating(leftLink) && isTerminating(rightLink)) {
      return new ApolloLink(function (operation) {
        return test(operation) ? leftLink.request(operation) || Observable$1.of() : rightLink.request(operation) || Observable$1.of();
      });
    } else {
      return new ApolloLink(function (operation, forward) {
        return test(operation) ? leftLink.request(operation, forward) || Observable$1.of() : rightLink.request(operation, forward) || Observable$1.of();
      });
    }
  }

  var concat = function (first, second) {
    var firstLink = toLink(first);

    if (isTerminating(firstLink)) {
       invariant$2.warn(new LinkError("You are calling concat on a terminating link, which will have no effect", firstLink));
      return firstLink;
    }

    var nextLink = toLink(second);

    if (isTerminating(nextLink)) {
      return new ApolloLink(function (operation) {
        return firstLink.request(operation, function (op) {
          return nextLink.request(op) || Observable$1.of();
        }) || Observable$1.of();
      });
    } else {
      return new ApolloLink(function (operation, forward) {
        return firstLink.request(operation, function (op) {
          return nextLink.request(op, forward) || Observable$1.of();
        }) || Observable$1.of();
      });
    }
  };

  var ApolloLink = function () {
    function ApolloLink(request) {
      if (request) this.request = request;
    }

    ApolloLink.prototype.split = function (test, left, right) {
      return this.concat(split(test, left, right || new ApolloLink(passthrough)));
    };

    ApolloLink.prototype.concat = function (next) {
      return concat(this, next);
    };

    ApolloLink.prototype.request = function (operation, forward) {
      throw  new InvariantError('request is not implemented');
    };

    ApolloLink.empty = empty;
    ApolloLink.from = from;
    ApolloLink.split = split;
    ApolloLink.execute = execute;
    return ApolloLink;
  }();

  function execute(link, operation) {
    return link.request(createOperation(operation.context, transformOperation(validateOperation(operation)))) || Observable$1.of();
  }

  function symbolObservablePonyfill(root) {
    var result;
    var Symbol = root.Symbol;

    if (typeof Symbol === 'function') {
      if (Symbol.observable) {
        result = Symbol.observable;
      } else {
        result = Symbol('observable');
        Symbol.observable = result;
      }
    } else {
      result = '@@observable';
    }

    return result;
  }

  var root;

  if (typeof self !== 'undefined') {
    root = self;
  } else if (typeof window !== 'undefined') {
    root = window;
  } else if (typeof global !== 'undefined') {
    root = global;
  } else if (typeof module !== 'undefined') {
    root = module;
  } else {
    root = Function('return this')();
  }

  var result = symbolObservablePonyfill(root);
  var $$observable = registerComponent(result, {
    tmpl: _tmpl
  });

  var NetworkStatus;

  (function (NetworkStatus) {
    NetworkStatus[NetworkStatus["loading"] = 1] = "loading";
    NetworkStatus[NetworkStatus["setVariables"] = 2] = "setVariables";
    NetworkStatus[NetworkStatus["fetchMore"] = 3] = "fetchMore";
    NetworkStatus[NetworkStatus["refetch"] = 4] = "refetch";
    NetworkStatus[NetworkStatus["poll"] = 6] = "poll";
    NetworkStatus[NetworkStatus["ready"] = 7] = "ready";
    NetworkStatus[NetworkStatus["error"] = 8] = "error";
  })(NetworkStatus || (NetworkStatus = {}));

  function isNetworkRequestInFlight(networkStatus) {
    return networkStatus < 7;
  }

  var Observable$2 = function (_super) {
    __extends(Observable, _super);

    function Observable() {
      return _super !== null && _super.apply(this, arguments) || this;
    }

    Observable.prototype[$$observable] = function () {
      return this;
    };

    Observable.prototype['@@observable'] = function () {
      return this;
    };

    return Observable;
  }(Observable$1);

  function isNonEmptyArray(value) {
    return Array.isArray(value) && value.length > 0;
  }

  function isApolloError(err) {
    return err.hasOwnProperty('graphQLErrors');
  }

  var generateErrorMessage = function (err) {
    var message = '';

    if (isNonEmptyArray(err.graphQLErrors)) {
      err.graphQLErrors.forEach(function (graphQLError) {
        var errorMessage = graphQLError ? graphQLError.message : 'Error message not found.';
        message += "GraphQL error: " + errorMessage + "\n";
      });
    }

    if (err.networkError) {
      message += 'Network error: ' + err.networkError.message + '\n';
    }

    message = message.replace(/\n$/, '');
    return message;
  };

  var ApolloError = function (_super) {
    __extends(ApolloError, _super);

    function ApolloError(_a) {
      var graphQLErrors = _a.graphQLErrors,
          networkError = _a.networkError,
          errorMessage = _a.errorMessage,
          extraInfo = _a.extraInfo;

      var _this = _super.call(this, errorMessage) || this;

      _this.graphQLErrors = graphQLErrors || [];
      _this.networkError = networkError || null;

      if (!errorMessage) {
        _this.message = generateErrorMessage(_this);
      } else {
        _this.message = errorMessage;
      }

      _this.extraInfo = extraInfo;
      _this.__proto__ = ApolloError.prototype;
      return _this;
    }

    return ApolloError;
  }(Error);

  var FetchType;

  (function (FetchType) {
    FetchType[FetchType["normal"] = 1] = "normal";
    FetchType[FetchType["refetch"] = 2] = "refetch";
    FetchType[FetchType["poll"] = 3] = "poll";
  })(FetchType || (FetchType = {}));

  var hasError = function (storeValue, policy) {
    if (policy === void 0) {
      policy = 'none';
    }

    return storeValue && (storeValue.networkError || policy === 'none' && isNonEmptyArray(storeValue.graphQLErrors));
  };

  var ObservableQuery = function (_super) {
    __extends(ObservableQuery, _super);

    function ObservableQuery(_a) {
      var queryManager = _a.queryManager,
          options = _a.options,
          _b = _a.shouldSubscribe,
          shouldSubscribe = _b === void 0 ? true : _b;

      var _this = _super.call(this, function (observer) {
        return _this.onSubscribe(observer);
      }) || this;

      _this.observers = new Set();
      _this.subscriptions = new Set();
      _this.isTornDown = false;
      _this.options = options;
      _this.variables = options.variables || {};
      _this.queryId = queryManager.generateQueryId();
      _this.shouldSubscribe = shouldSubscribe;
      var opDef = getOperationDefinition(options.query);
      _this.queryName = opDef && opDef.name && opDef.name.value;
      _this.queryManager = queryManager;
      return _this;
    }

    ObservableQuery.prototype.result = function () {
      var _this = this;

      return new Promise(function (resolve, reject) {
        var observer = {
          next: function (result) {
            resolve(result);

            _this.observers.delete(observer);

            if (!_this.observers.size) {
              _this.queryManager.removeQuery(_this.queryId);
            }

            setTimeout(function () {
              subscription.unsubscribe();
            }, 0);
          },
          error: reject
        };

        var subscription = _this.subscribe(observer);
      });
    };

    ObservableQuery.prototype.currentResult = function () {
      var result = this.getCurrentResult();

      if (result.data === undefined) {
        result.data = {};
      }

      return result;
    };

    ObservableQuery.prototype.getCurrentResult = function () {
      if (this.isTornDown) {
        var lastResult = this.lastResult;
        return {
          data: !this.lastError && lastResult && lastResult.data || void 0,
          error: this.lastError,
          loading: false,
          networkStatus: NetworkStatus.error
        };
      }

      var _a = this.queryManager.getCurrentQueryResult(this),
          data = _a.data,
          partial = _a.partial;

      var queryStoreValue = this.queryManager.queryStore.get(this.queryId);
      var result;
      var fetchPolicy = this.options.fetchPolicy;
      var isNetworkFetchPolicy = fetchPolicy === 'network-only' || fetchPolicy === 'no-cache';

      if (queryStoreValue) {
        var networkStatus = queryStoreValue.networkStatus;

        if (hasError(queryStoreValue, this.options.errorPolicy)) {
          return {
            data: void 0,
            loading: false,
            networkStatus: networkStatus,
            error: new ApolloError({
              graphQLErrors: queryStoreValue.graphQLErrors,
              networkError: queryStoreValue.networkError
            })
          };
        }

        if (queryStoreValue.variables) {
          this.options.variables = __assign(__assign({}, this.options.variables), queryStoreValue.variables);
          this.variables = this.options.variables;
        }

        result = {
          data: data,
          loading: isNetworkRequestInFlight(networkStatus),
          networkStatus: networkStatus
        };

        if (queryStoreValue.graphQLErrors && this.options.errorPolicy === 'all') {
          result.errors = queryStoreValue.graphQLErrors;
        }
      } else {
        var loading = isNetworkFetchPolicy || partial && fetchPolicy !== 'cache-only';
        result = {
          data: data,
          loading: loading,
          networkStatus: loading ? NetworkStatus.loading : NetworkStatus.ready
        };
      }

      if (!partial) {
        this.updateLastResult(__assign(__assign({}, result), {
          stale: false
        }));
      }

      return __assign(__assign({}, result), {
        partial: partial
      });
    };

    ObservableQuery.prototype.isDifferentFromLastResult = function (newResult) {
      var snapshot = this.lastResultSnapshot;
      return !(snapshot && newResult && snapshot.networkStatus === newResult.networkStatus && snapshot.stale === newResult.stale && equal(snapshot.data, newResult.data));
    };

    ObservableQuery.prototype.getLastResult = function () {
      return this.lastResult;
    };

    ObservableQuery.prototype.getLastError = function () {
      return this.lastError;
    };

    ObservableQuery.prototype.resetLastResults = function () {
      delete this.lastResult;
      delete this.lastResultSnapshot;
      delete this.lastError;
      this.isTornDown = false;
    };

    ObservableQuery.prototype.resetQueryStoreErrors = function () {
      var queryStore = this.queryManager.queryStore.get(this.queryId);

      if (queryStore) {
        queryStore.networkError = null;
        queryStore.graphQLErrors = [];
      }
    };

    ObservableQuery.prototype.refetch = function (variables) {
      var fetchPolicy = this.options.fetchPolicy;

      if (fetchPolicy === 'cache-only') {
        return Promise.reject( new InvariantError('cache-only fetchPolicy option should not be used together with query refetch.'));
      }

      if (fetchPolicy !== 'no-cache' && fetchPolicy !== 'cache-and-network') {
        fetchPolicy = 'network-only';
      }

      if (!equal(this.variables, variables)) {
        this.variables = __assign(__assign({}, this.variables), variables);
      }

      if (!equal(this.options.variables, this.variables)) {
        this.options.variables = __assign(__assign({}, this.options.variables), this.variables);
      }

      return this.queryManager.fetchQuery(this.queryId, __assign(__assign({}, this.options), {
        fetchPolicy: fetchPolicy
      }), FetchType.refetch);
    };

    ObservableQuery.prototype.fetchMore = function (fetchMoreOptions) {
      var _this = this;

       invariant$2(fetchMoreOptions.updateQuery, 'updateQuery option is required. This function defines how to update the query data with the new results.');

      var combinedOptions = __assign(__assign({}, fetchMoreOptions.query ? fetchMoreOptions : __assign(__assign(__assign({}, this.options), fetchMoreOptions), {
        variables: __assign(__assign({}, this.variables), fetchMoreOptions.variables)
      })), {
        fetchPolicy: 'network-only'
      });

      var qid = this.queryManager.generateQueryId();
      return this.queryManager.fetchQuery(qid, combinedOptions, FetchType.normal, this.queryId).then(function (fetchMoreResult) {
        _this.updateQuery(function (previousResult) {
          return fetchMoreOptions.updateQuery(previousResult, {
            fetchMoreResult: fetchMoreResult.data,
            variables: combinedOptions.variables
          });
        });

        _this.queryManager.stopQuery(qid);

        return fetchMoreResult;
      }, function (error) {
        _this.queryManager.stopQuery(qid);

        throw error;
      });
    };

    ObservableQuery.prototype.subscribeToMore = function (options) {
      var _this = this;

      var subscription = this.queryManager.startGraphQLSubscription({
        query: options.document,
        variables: options.variables
      }).subscribe({
        next: function (subscriptionData) {
          var updateQuery = options.updateQuery;

          if (updateQuery) {
            _this.updateQuery(function (previous, _a) {
              var variables = _a.variables;
              return updateQuery(previous, {
                subscriptionData: subscriptionData,
                variables: variables
              });
            });
          }
        },
        error: function (err) {
          if (options.onError) {
            options.onError(err);
            return;
          }

           invariant$2.error('Unhandled GraphQL subscription error', err);
        }
      });
      this.subscriptions.add(subscription);
      return function () {
        if (_this.subscriptions.delete(subscription)) {
          subscription.unsubscribe();
        }
      };
    };

    ObservableQuery.prototype.setOptions = function (opts) {
      var oldFetchPolicy = this.options.fetchPolicy;
      this.options = __assign(__assign({}, this.options), opts);

      if (opts.pollInterval) {
        this.startPolling(opts.pollInterval);
      } else if (opts.pollInterval === 0) {
        this.stopPolling();
      }

      var fetchPolicy = opts.fetchPolicy;
      return this.setVariables(this.options.variables, oldFetchPolicy !== fetchPolicy && (oldFetchPolicy === 'cache-only' || oldFetchPolicy === 'standby' || fetchPolicy === 'network-only'), opts.fetchResults);
    };

    ObservableQuery.prototype.setVariables = function (variables, tryFetch, fetchResults) {
      if (tryFetch === void 0) {
        tryFetch = false;
      }

      if (fetchResults === void 0) {
        fetchResults = true;
      }

      this.isTornDown = false;
      variables = variables || this.variables;

      if (!tryFetch && equal(variables, this.variables)) {
        return this.observers.size && fetchResults ? this.result() : Promise.resolve();
      }

      this.variables = this.options.variables = variables;

      if (!this.observers.size) {
        return Promise.resolve();
      }

      return this.queryManager.fetchQuery(this.queryId, this.options);
    };

    ObservableQuery.prototype.updateQuery = function (mapFn) {
      var queryManager = this.queryManager;

      var _a = queryManager.getQueryWithPreviousResult(this.queryId),
          previousResult = _a.previousResult,
          variables = _a.variables,
          document = _a.document;

      var newResult = tryFunctionOrLogError(function () {
        return mapFn(previousResult, {
          variables: variables
        });
      });

      if (newResult) {
        queryManager.dataStore.markUpdateQueryResult(document, variables, newResult);
        queryManager.broadcastQueries();
      }
    };

    ObservableQuery.prototype.stopPolling = function () {
      this.queryManager.stopPollingQuery(this.queryId);
      this.options.pollInterval = undefined;
    };

    ObservableQuery.prototype.startPolling = function (pollInterval) {
      assertNotCacheFirstOrOnly(this);
      this.options.pollInterval = pollInterval;
      this.queryManager.startPollingQuery(this.options, this.queryId);
    };

    ObservableQuery.prototype.updateLastResult = function (newResult) {
      var previousResult = this.lastResult;
      this.lastResult = newResult;
      this.lastResultSnapshot = this.queryManager.assumeImmutableResults ? newResult : cloneDeep(newResult);
      return previousResult;
    };

    ObservableQuery.prototype.onSubscribe = function (observer) {
      var _this = this;

      try {
        var subObserver = observer._subscription._observer;

        if (subObserver && !subObserver.error) {
          subObserver.error = defaultSubscriptionObserverErrorCallback;
        }
      } catch (_a) {}

      var first = !this.observers.size;
      this.observers.add(observer);
      if (observer.next && this.lastResult) observer.next(this.lastResult);
      if (observer.error && this.lastError) observer.error(this.lastError);

      if (first) {
        this.setUpQuery();
      }

      return function () {
        if (_this.observers.delete(observer) && !_this.observers.size) {
          _this.tearDownQuery();
        }
      };
    };

    ObservableQuery.prototype.setUpQuery = function () {
      var _this = this;

      var _a = this,
          queryManager = _a.queryManager,
          queryId = _a.queryId;

      if (this.shouldSubscribe) {
        queryManager.addObservableQuery(queryId, this);
      }

      if (this.options.pollInterval) {
        assertNotCacheFirstOrOnly(this);
        queryManager.startPollingQuery(this.options, queryId);
      }

      var onError = function (error) {
        _this.updateLastResult(__assign(__assign({}, _this.lastResult), {
          errors: error.graphQLErrors,
          networkStatus: NetworkStatus.error,
          loading: false
        }));

        iterateObserversSafely(_this.observers, 'error', _this.lastError = error);
      };

      queryManager.observeQuery(queryId, this.options, {
        next: function (result) {
          if (_this.lastError || _this.isDifferentFromLastResult(result)) {
            var previousResult_1 = _this.updateLastResult(result);

            var _a = _this.options,
                query_1 = _a.query,
                variables = _a.variables,
                fetchPolicy_1 = _a.fetchPolicy;

            if (queryManager.transform(query_1).hasClientExports) {
              queryManager.getLocalState().addExportedVariables(query_1, variables).then(function (variables) {
                var previousVariables = _this.variables;
                _this.variables = _this.options.variables = variables;

                if (!result.loading && previousResult_1 && fetchPolicy_1 !== 'cache-only' && queryManager.transform(query_1).serverQuery && !equal(previousVariables, variables)) {
                  _this.refetch();
                } else {
                  iterateObserversSafely(_this.observers, 'next', result);
                }
              });
            } else {
              iterateObserversSafely(_this.observers, 'next', result);
            }
          }
        },
        error: onError
      }).catch(onError);
    };

    ObservableQuery.prototype.tearDownQuery = function () {
      var queryManager = this.queryManager;
      this.isTornDown = true;
      queryManager.stopPollingQuery(this.queryId);
      this.subscriptions.forEach(function (sub) {
        return sub.unsubscribe();
      });
      this.subscriptions.clear();
      queryManager.removeObservableQuery(this.queryId);
      queryManager.stopQuery(this.queryId);
      this.observers.clear();
    };

    return ObservableQuery;
  }(Observable$2);

  function defaultSubscriptionObserverErrorCallback(error) {
     invariant$2.error('Unhandled error', error.message, error.stack);
  }

  function iterateObserversSafely(observers, method, argument) {
    var observersWithMethod = [];
    observers.forEach(function (obs) {
      return obs[method] && observersWithMethod.push(obs);
    });
    observersWithMethod.forEach(function (obs) {
      return obs[method](argument);
    });
  }

  function assertNotCacheFirstOrOnly(obsQuery) {
    var fetchPolicy = obsQuery.options.fetchPolicy;
     invariant$2(fetchPolicy !== 'cache-first' && fetchPolicy !== 'cache-only', 'Queries that specify the cache-first and cache-only fetchPolicies cannot also be polling queries.');
  }

  var MutationStore = function () {
    function MutationStore() {
      this.store = {};
    }

    MutationStore.prototype.getStore = function () {
      return this.store;
    };

    MutationStore.prototype.get = function (mutationId) {
      return this.store[mutationId];
    };

    MutationStore.prototype.initMutation = function (mutationId, mutation, variables) {
      this.store[mutationId] = {
        mutation: mutation,
        variables: variables || {},
        loading: true,
        error: null
      };
    };

    MutationStore.prototype.markMutationError = function (mutationId, error) {
      var mutation = this.store[mutationId];

      if (mutation) {
        mutation.loading = false;
        mutation.error = error;
      }
    };

    MutationStore.prototype.markMutationResult = function (mutationId) {
      var mutation = this.store[mutationId];

      if (mutation) {
        mutation.loading = false;
        mutation.error = null;
      }
    };

    MutationStore.prototype.reset = function () {
      this.store = {};
    };

    return MutationStore;
  }();

  var QueryStore = function () {
    function QueryStore() {
      this.store = {};
    }

    QueryStore.prototype.getStore = function () {
      return this.store;
    };

    QueryStore.prototype.get = function (queryId) {
      return this.store[queryId];
    };

    QueryStore.prototype.initQuery = function (query) {
      var previousQuery = this.store[query.queryId];
       invariant$2(!previousQuery || previousQuery.document === query.document || equal(previousQuery.document, query.document), 'Internal Error: may not update existing query string in store');
      var isSetVariables = false;
      var previousVariables = null;

      if (query.storePreviousVariables && previousQuery && previousQuery.networkStatus !== NetworkStatus.loading) {
        if (!equal(previousQuery.variables, query.variables)) {
          isSetVariables = true;
          previousVariables = previousQuery.variables;
        }
      }

      var networkStatus;

      if (isSetVariables) {
        networkStatus = NetworkStatus.setVariables;
      } else if (query.isPoll) {
        networkStatus = NetworkStatus.poll;
      } else if (query.isRefetch) {
        networkStatus = NetworkStatus.refetch;
      } else {
        networkStatus = NetworkStatus.loading;
      }

      var graphQLErrors = [];

      if (previousQuery && previousQuery.graphQLErrors) {
        graphQLErrors = previousQuery.graphQLErrors;
      }

      this.store[query.queryId] = {
        document: query.document,
        variables: query.variables,
        previousVariables: previousVariables,
        networkError: null,
        graphQLErrors: graphQLErrors,
        networkStatus: networkStatus,
        metadata: query.metadata
      };

      if (typeof query.fetchMoreForQueryId === 'string' && this.store[query.fetchMoreForQueryId]) {
        this.store[query.fetchMoreForQueryId].networkStatus = NetworkStatus.fetchMore;
      }
    };

    QueryStore.prototype.markQueryResult = function (queryId, result, fetchMoreForQueryId) {
      if (!this.store || !this.store[queryId]) return;
      this.store[queryId].networkError = null;
      this.store[queryId].graphQLErrors = isNonEmptyArray(result.errors) ? result.errors : [];
      this.store[queryId].previousVariables = null;
      this.store[queryId].networkStatus = NetworkStatus.ready;

      if (typeof fetchMoreForQueryId === 'string' && this.store[fetchMoreForQueryId]) {
        this.store[fetchMoreForQueryId].networkStatus = NetworkStatus.ready;
      }
    };

    QueryStore.prototype.markQueryError = function (queryId, error, fetchMoreForQueryId) {
      if (!this.store || !this.store[queryId]) return;
      this.store[queryId].networkError = error;
      this.store[queryId].networkStatus = NetworkStatus.error;

      if (typeof fetchMoreForQueryId === 'string') {
        this.markQueryResultClient(fetchMoreForQueryId, true);
      }
    };

    QueryStore.prototype.markQueryResultClient = function (queryId, complete) {
      var storeValue = this.store && this.store[queryId];

      if (storeValue) {
        storeValue.networkError = null;
        storeValue.previousVariables = null;

        if (complete) {
          storeValue.networkStatus = NetworkStatus.ready;
        }
      }
    };

    QueryStore.prototype.stopQuery = function (queryId) {
      delete this.store[queryId];
    };

    QueryStore.prototype.reset = function (observableQueryIds) {
      var _this = this;

      Object.keys(this.store).forEach(function (queryId) {
        if (observableQueryIds.indexOf(queryId) < 0) {
          _this.stopQuery(queryId);
        } else {
          _this.store[queryId].networkStatus = NetworkStatus.loading;
        }
      });
    };

    return QueryStore;
  }();

  function capitalizeFirstLetter(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  var LocalState = function () {
    function LocalState(_a) {
      var cache = _a.cache,
          client = _a.client,
          resolvers = _a.resolvers,
          fragmentMatcher = _a.fragmentMatcher;
      this.cache = cache;

      if (client) {
        this.client = client;
      }

      if (resolvers) {
        this.addResolvers(resolvers);
      }

      if (fragmentMatcher) {
        this.setFragmentMatcher(fragmentMatcher);
      }
    }

    LocalState.prototype.addResolvers = function (resolvers) {
      var _this = this;

      this.resolvers = this.resolvers || {};

      if (Array.isArray(resolvers)) {
        resolvers.forEach(function (resolverGroup) {
          _this.resolvers = mergeDeep(_this.resolvers, resolverGroup);
        });
      } else {
        this.resolvers = mergeDeep(this.resolvers, resolvers);
      }
    };

    LocalState.prototype.setResolvers = function (resolvers) {
      this.resolvers = {};
      this.addResolvers(resolvers);
    };

    LocalState.prototype.getResolvers = function () {
      return this.resolvers || {};
    };

    LocalState.prototype.runResolvers = function (_a) {
      var document = _a.document,
          remoteResult = _a.remoteResult,
          context = _a.context,
          variables = _a.variables,
          _b = _a.onlyRunForcedResolvers,
          onlyRunForcedResolvers = _b === void 0 ? false : _b;
      return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_c) {
          if (document) {
            return [2, this.resolveDocument(document, remoteResult.data, context, variables, this.fragmentMatcher, onlyRunForcedResolvers).then(function (localResult) {
              return __assign(__assign({}, remoteResult), {
                data: localResult.result
              });
            })];
          }

          return [2, remoteResult];
        });
      });
    };

    LocalState.prototype.setFragmentMatcher = function (fragmentMatcher) {
      this.fragmentMatcher = fragmentMatcher;
    };

    LocalState.prototype.getFragmentMatcher = function () {
      return this.fragmentMatcher;
    };

    LocalState.prototype.clientQuery = function (document) {
      if (hasDirectives(['client'], document)) {
        if (this.resolvers) {
          return document;
        }

         invariant$2.warn('Found @client directives in a query but no ApolloClient resolvers ' + 'were specified. This means ApolloClient local resolver handling ' + 'has been disabled, and @client directives will be passed through ' + 'to your link chain.');
      }

      return null;
    };

    LocalState.prototype.serverQuery = function (document) {
      return this.resolvers ? removeClientSetsFromDocument(document) : document;
    };

    LocalState.prototype.prepareContext = function (context) {
      if (context === void 0) {
        context = {};
      }

      var cache = this.cache;

      var newContext = __assign(__assign({}, context), {
        cache: cache,
        getCacheKey: function (obj) {
          if (cache.config) {
            return cache.config.dataIdFromObject(obj);
          } else {
             invariant$2(false, 'To use context.getCacheKey, you need to use a cache that has ' + 'a configurable dataIdFromObject, like apollo-cache-inmemory.');
          }
        }
      });

      return newContext;
    };

    LocalState.prototype.addExportedVariables = function (document, variables, context) {
      if (variables === void 0) {
        variables = {};
      }

      if (context === void 0) {
        context = {};
      }

      return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
          if (document) {
            return [2, this.resolveDocument(document, this.buildRootValueFromCache(document, variables) || {}, this.prepareContext(context), variables).then(function (data) {
              return __assign(__assign({}, variables), data.exportedVariables);
            })];
          }

          return [2, __assign({}, variables)];
        });
      });
    };

    LocalState.prototype.shouldForceResolvers = function (document) {
      var forceResolvers = false;
      visit(document, {
        Directive: {
          enter: function (node) {
            if (node.name.value === 'client' && node.arguments) {
              forceResolvers = node.arguments.some(function (arg) {
                return arg.name.value === 'always' && arg.value.kind === 'BooleanValue' && arg.value.value === true;
              });

              if (forceResolvers) {
                return BREAK;
              }
            }
          }
        }
      });
      return forceResolvers;
    };

    LocalState.prototype.buildRootValueFromCache = function (document, variables) {
      return this.cache.diff({
        query: buildQueryFromSelectionSet(document),
        variables: variables,
        returnPartialData: true,
        optimistic: false
      }).result;
    };

    LocalState.prototype.resolveDocument = function (document, rootValue, context, variables, fragmentMatcher, onlyRunForcedResolvers) {
      if (context === void 0) {
        context = {};
      }

      if (variables === void 0) {
        variables = {};
      }

      if (fragmentMatcher === void 0) {
        fragmentMatcher = function () {
          return true;
        };
      }

      if (onlyRunForcedResolvers === void 0) {
        onlyRunForcedResolvers = false;
      }

      return __awaiter(this, void 0, void 0, function () {
        var mainDefinition, fragments, fragmentMap, definitionOperation, defaultOperationType, _a, cache, client, execContext;

        return __generator(this, function (_b) {
          mainDefinition = getMainDefinition(document);
          fragments = getFragmentDefinitions(document);
          fragmentMap = createFragmentMap(fragments);
          definitionOperation = mainDefinition.operation;
          defaultOperationType = definitionOperation ? capitalizeFirstLetter(definitionOperation) : 'Query';
          _a = this, cache = _a.cache, client = _a.client;
          execContext = {
            fragmentMap: fragmentMap,
            context: __assign(__assign({}, context), {
              cache: cache,
              client: client
            }),
            variables: variables,
            fragmentMatcher: fragmentMatcher,
            defaultOperationType: defaultOperationType,
            exportedVariables: {},
            onlyRunForcedResolvers: onlyRunForcedResolvers
          };
          return [2, this.resolveSelectionSet(mainDefinition.selectionSet, rootValue, execContext).then(function (result) {
            return {
              result: result,
              exportedVariables: execContext.exportedVariables
            };
          })];
        });
      });
    };

    LocalState.prototype.resolveSelectionSet = function (selectionSet, rootValue, execContext) {
      return __awaiter(this, void 0, void 0, function () {
        var fragmentMap, context, variables, resultsToMerge, execute;

        var _this = this;

        return __generator(this, function (_a) {
          fragmentMap = execContext.fragmentMap, context = execContext.context, variables = execContext.variables;
          resultsToMerge = [rootValue];

          execute = function (selection) {
            return __awaiter(_this, void 0, void 0, function () {
              var fragment, typeCondition;
              return __generator(this, function (_a) {
                if (!shouldInclude(selection, variables)) {
                  return [2];
                }

                if (isField(selection)) {
                  return [2, this.resolveField(selection, rootValue, execContext).then(function (fieldResult) {
                    var _a;

                    if (typeof fieldResult !== 'undefined') {
                      resultsToMerge.push((_a = {}, _a[resultKeyNameFromField(selection)] = fieldResult, _a));
                    }
                  })];
                }

                if (isInlineFragment(selection)) {
                  fragment = selection;
                } else {
                  fragment = fragmentMap[selection.name.value];
                   invariant$2(fragment, "No fragment named " + selection.name.value);
                }

                if (fragment && fragment.typeCondition) {
                  typeCondition = fragment.typeCondition.name.value;

                  if (execContext.fragmentMatcher(rootValue, typeCondition, context)) {
                    return [2, this.resolveSelectionSet(fragment.selectionSet, rootValue, execContext).then(function (fragmentResult) {
                      resultsToMerge.push(fragmentResult);
                    })];
                  }
                }

                return [2];
              });
            });
          };

          return [2, Promise.all(selectionSet.selections.map(execute)).then(function () {
            return mergeDeepArray(resultsToMerge);
          })];
        });
      });
    };

    LocalState.prototype.resolveField = function (field, rootValue, execContext) {
      return __awaiter(this, void 0, void 0, function () {
        var variables, fieldName, aliasedFieldName, aliasUsed, defaultResult, resultPromise, resolverType, resolverMap, resolve;

        var _this = this;

        return __generator(this, function (_a) {
          variables = execContext.variables;
          fieldName = field.name.value;
          aliasedFieldName = resultKeyNameFromField(field);
          aliasUsed = fieldName !== aliasedFieldName;
          defaultResult = rootValue[aliasedFieldName] || rootValue[fieldName];
          resultPromise = Promise.resolve(defaultResult);

          if (!execContext.onlyRunForcedResolvers || this.shouldForceResolvers(field)) {
            resolverType = rootValue.__typename || execContext.defaultOperationType;
            resolverMap = this.resolvers && this.resolvers[resolverType];

            if (resolverMap) {
              resolve = resolverMap[aliasUsed ? fieldName : aliasedFieldName];

              if (resolve) {
                resultPromise = Promise.resolve(resolve(rootValue, argumentsObjectFromField(field, variables), execContext.context, {
                  field: field,
                  fragmentMap: execContext.fragmentMap
                }));
              }
            }
          }

          return [2, resultPromise.then(function (result) {
            if (result === void 0) {
              result = defaultResult;
            }

            if (field.directives) {
              field.directives.forEach(function (directive) {
                if (directive.name.value === 'export' && directive.arguments) {
                  directive.arguments.forEach(function (arg) {
                    if (arg.name.value === 'as' && arg.value.kind === 'StringValue') {
                      execContext.exportedVariables[arg.value.value] = result;
                    }
                  });
                }
              });
            }

            if (!field.selectionSet) {
              return result;
            }

            if (result == null) {
              return result;
            }

            if (Array.isArray(result)) {
              return _this.resolveSubSelectedArray(field, result, execContext);
            }

            if (field.selectionSet) {
              return _this.resolveSelectionSet(field.selectionSet, result, execContext);
            }
          })];
        });
      });
    };

    LocalState.prototype.resolveSubSelectedArray = function (field, result, execContext) {
      var _this = this;

      return Promise.all(result.map(function (item) {
        if (item === null) {
          return null;
        }

        if (Array.isArray(item)) {
          return _this.resolveSubSelectedArray(field, item, execContext);
        }

        if (field.selectionSet) {
          return _this.resolveSelectionSet(field.selectionSet, item, execContext);
        }
      }));
    };

    return LocalState;
  }();

  function multiplex(inner) {
    var observers = new Set();
    var sub = null;
    return new Observable$2(function (observer) {
      observers.add(observer);
      sub = sub || inner.subscribe({
        next: function (value) {
          observers.forEach(function (obs) {
            return obs.next && obs.next(value);
          });
        },
        error: function (error) {
          observers.forEach(function (obs) {
            return obs.error && obs.error(error);
          });
        },
        complete: function () {
          observers.forEach(function (obs) {
            return obs.complete && obs.complete();
          });
        }
      });
      return function () {
        if (observers.delete(observer) && !observers.size && sub) {
          sub.unsubscribe();
          sub = null;
        }
      };
    });
  }

  function asyncMap(observable, mapFn) {
    return new Observable$2(function (observer) {
      var next = observer.next,
          error = observer.error,
          complete = observer.complete;
      var activeNextCount = 0;
      var completed = false;
      var handler = {
        next: function (value) {
          ++activeNextCount;
          new Promise(function (resolve) {
            resolve(mapFn(value));
          }).then(function (result) {
            --activeNextCount;
            next && next.call(observer, result);
            completed && handler.complete();
          }, function (e) {
            --activeNextCount;
            error && error.call(observer, e);
          });
        },
        error: function (e) {
          error && error.call(observer, e);
        },
        complete: function () {
          completed = true;

          if (!activeNextCount) {
            complete && complete.call(observer);
          }
        }
      };
      var sub = observable.subscribe(handler);
      return function () {
        return sub.unsubscribe();
      };
    });
  }

  var hasOwnProperty$5 = Object.prototype.hasOwnProperty;

  var QueryManager = function () {
    function QueryManager(_a) {
      var link = _a.link,
          _b = _a.queryDeduplication,
          queryDeduplication = _b === void 0 ? false : _b,
          store = _a.store,
          _c = _a.onBroadcast,
          onBroadcast = _c === void 0 ? function () {
        return undefined;
      } : _c,
          _d = _a.ssrMode,
          ssrMode = _d === void 0 ? false : _d,
          _e = _a.clientAwareness,
          clientAwareness = _e === void 0 ? {} : _e,
          localState = _a.localState,
          assumeImmutableResults = _a.assumeImmutableResults;
      this.mutationStore = new MutationStore();
      this.queryStore = new QueryStore();
      this.clientAwareness = {};
      this.idCounter = 1;
      this.queries = new Map();
      this.fetchQueryRejectFns = new Map();
      this.transformCache = new (canUseWeakMap ? WeakMap : Map)();
      this.inFlightLinkObservables = new Map();
      this.pollingInfoByQueryId = new Map();
      this.link = link;
      this.queryDeduplication = queryDeduplication;
      this.dataStore = store;
      this.onBroadcast = onBroadcast;
      this.clientAwareness = clientAwareness;
      this.localState = localState || new LocalState({
        cache: store.getCache()
      });
      this.ssrMode = ssrMode;
      this.assumeImmutableResults = !!assumeImmutableResults;
    }

    QueryManager.prototype.stop = function () {
      var _this = this;

      this.queries.forEach(function (_info, queryId) {
        _this.stopQueryNoBroadcast(queryId);
      });
      this.fetchQueryRejectFns.forEach(function (reject) {
        reject( new InvariantError('QueryManager stopped while query was in flight'));
      });
    };

    QueryManager.prototype.mutate = function (_a) {
      var mutation = _a.mutation,
          variables = _a.variables,
          optimisticResponse = _a.optimisticResponse,
          updateQueriesByName = _a.updateQueries,
          _b = _a.refetchQueries,
          refetchQueries = _b === void 0 ? [] : _b,
          _c = _a.awaitRefetchQueries,
          awaitRefetchQueries = _c === void 0 ? false : _c,
          updateWithProxyFn = _a.update,
          _d = _a.errorPolicy,
          errorPolicy = _d === void 0 ? 'none' : _d,
          fetchPolicy = _a.fetchPolicy,
          _e = _a.context,
          context = _e === void 0 ? {} : _e;
      return __awaiter(this, void 0, void 0, function () {
        var mutationId, generateUpdateQueriesInfo, self;

        var _this = this;

        return __generator(this, function (_f) {
          switch (_f.label) {
            case 0:
               invariant$2(mutation, 'mutation option is required. You must specify your GraphQL document in the mutation option.');
               invariant$2(!fetchPolicy || fetchPolicy === 'no-cache', "Mutations only support a 'no-cache' fetchPolicy. If you don't want to disable the cache, remove your fetchPolicy setting to proceed with the default mutation behavior.");
              mutationId = this.generateQueryId();
              mutation = this.transform(mutation).document;
              this.setQuery(mutationId, function () {
                return {
                  document: mutation
                };
              });
              variables = this.getVariables(mutation, variables);
              if (!this.transform(mutation).hasClientExports) return [3, 2];
              return [4, this.localState.addExportedVariables(mutation, variables, context)];

            case 1:
              variables = _f.sent();
              _f.label = 2;

            case 2:
              generateUpdateQueriesInfo = function () {
                var ret = {};

                if (updateQueriesByName) {
                  _this.queries.forEach(function (_a, queryId) {
                    var observableQuery = _a.observableQuery;

                    if (observableQuery) {
                      var queryName = observableQuery.queryName;

                      if (queryName && hasOwnProperty$5.call(updateQueriesByName, queryName)) {
                        ret[queryId] = {
                          updater: updateQueriesByName[queryName],
                          query: _this.queryStore.get(queryId)
                        };
                      }
                    }
                  });
                }

                return ret;
              };

              this.mutationStore.initMutation(mutationId, mutation, variables);
              this.dataStore.markMutationInit({
                mutationId: mutationId,
                document: mutation,
                variables: variables,
                updateQueries: generateUpdateQueriesInfo(),
                update: updateWithProxyFn,
                optimisticResponse: optimisticResponse
              });
              this.broadcastQueries();
              self = this;
              return [2, new Promise(function (resolve, reject) {
                var storeResult;
                var error;
                self.getObservableFromLink(mutation, __assign(__assign({}, context), {
                  optimisticResponse: optimisticResponse
                }), variables, false).subscribe({
                  next: function (result) {
                    if (graphQLResultHasError(result) && errorPolicy === 'none') {
                      error = new ApolloError({
                        graphQLErrors: result.errors
                      });
                      return;
                    }

                    self.mutationStore.markMutationResult(mutationId);

                    if (fetchPolicy !== 'no-cache') {
                      self.dataStore.markMutationResult({
                        mutationId: mutationId,
                        result: result,
                        document: mutation,
                        variables: variables,
                        updateQueries: generateUpdateQueriesInfo(),
                        update: updateWithProxyFn
                      });
                    }

                    storeResult = result;
                  },
                  error: function (err) {
                    self.mutationStore.markMutationError(mutationId, err);
                    self.dataStore.markMutationComplete({
                      mutationId: mutationId,
                      optimisticResponse: optimisticResponse
                    });
                    self.broadcastQueries();
                    self.setQuery(mutationId, function () {
                      return {
                        document: null
                      };
                    });
                    reject(new ApolloError({
                      networkError: err
                    }));
                  },
                  complete: function () {
                    if (error) {
                      self.mutationStore.markMutationError(mutationId, error);
                    }

                    self.dataStore.markMutationComplete({
                      mutationId: mutationId,
                      optimisticResponse: optimisticResponse
                    });
                    self.broadcastQueries();

                    if (error) {
                      reject(error);
                      return;
                    }

                    if (typeof refetchQueries === 'function') {
                      refetchQueries = refetchQueries(storeResult);
                    }

                    var refetchQueryPromises = [];

                    if (isNonEmptyArray(refetchQueries)) {
                      refetchQueries.forEach(function (refetchQuery) {
                        if (typeof refetchQuery === 'string') {
                          self.queries.forEach(function (_a) {
                            var observableQuery = _a.observableQuery;

                            if (observableQuery && observableQuery.queryName === refetchQuery) {
                              refetchQueryPromises.push(observableQuery.refetch());
                            }
                          });
                        } else {
                          var queryOptions = {
                            query: refetchQuery.query,
                            variables: refetchQuery.variables,
                            fetchPolicy: 'network-only'
                          };

                          if (refetchQuery.context) {
                            queryOptions.context = refetchQuery.context;
                          }

                          refetchQueryPromises.push(self.query(queryOptions));
                        }
                      });
                    }

                    Promise.all(awaitRefetchQueries ? refetchQueryPromises : []).then(function () {
                      self.setQuery(mutationId, function () {
                        return {
                          document: null
                        };
                      });

                      if (errorPolicy === 'ignore' && storeResult && graphQLResultHasError(storeResult)) {
                        delete storeResult.errors;
                      }

                      resolve(storeResult);
                    });
                  }
                });
              })];
          }
        });
      });
    };

    QueryManager.prototype.fetchQuery = function (queryId, options, fetchType, fetchMoreForQueryId) {
      return __awaiter(this, void 0, void 0, function () {
        var _a, metadata, _b, fetchPolicy, _c, context, query, variables, storeResult, isNetworkOnly, needToFetch, _d, complete, result, shouldFetch, requestId, cancel, networkResult;

        var _this = this;

        return __generator(this, function (_e) {
          switch (_e.label) {
            case 0:
              _a = options.metadata, metadata = _a === void 0 ? null : _a, _b = options.fetchPolicy, fetchPolicy = _b === void 0 ? 'cache-first' : _b, _c = options.context, context = _c === void 0 ? {} : _c;
              query = this.transform(options.query).document;
              variables = this.getVariables(query, options.variables);
              if (!this.transform(query).hasClientExports) return [3, 2];
              return [4, this.localState.addExportedVariables(query, variables, context)];

            case 1:
              variables = _e.sent();
              _e.label = 2;

            case 2:
              options = __assign(__assign({}, options), {
                variables: variables
              });
              isNetworkOnly = fetchPolicy === 'network-only' || fetchPolicy === 'no-cache';
              needToFetch = isNetworkOnly;

              if (!isNetworkOnly) {
                _d = this.dataStore.getCache().diff({
                  query: query,
                  variables: variables,
                  returnPartialData: true,
                  optimistic: false
                }), complete = _d.complete, result = _d.result;
                needToFetch = !complete || fetchPolicy === 'cache-and-network';
                storeResult = result;
              }

              shouldFetch = needToFetch && fetchPolicy !== 'cache-only' && fetchPolicy !== 'standby';
              if (hasDirectives(['live'], query)) shouldFetch = true;
              requestId = this.idCounter++;
              cancel = fetchPolicy !== 'no-cache' ? this.updateQueryWatch(queryId, query, options) : undefined;
              this.setQuery(queryId, function () {
                return {
                  document: query,
                  lastRequestId: requestId,
                  invalidated: true,
                  cancel: cancel
                };
              });
              this.invalidate(fetchMoreForQueryId);
              this.queryStore.initQuery({
                queryId: queryId,
                document: query,
                storePreviousVariables: shouldFetch,
                variables: variables,
                isPoll: fetchType === FetchType.poll,
                isRefetch: fetchType === FetchType.refetch,
                metadata: metadata,
                fetchMoreForQueryId: fetchMoreForQueryId
              });
              this.broadcastQueries();

              if (shouldFetch) {
                networkResult = this.fetchRequest({
                  requestId: requestId,
                  queryId: queryId,
                  document: query,
                  options: options,
                  fetchMoreForQueryId: fetchMoreForQueryId
                }).catch(function (error) {
                  if (isApolloError(error)) {
                    throw error;
                  } else {
                    if (requestId >= _this.getQuery(queryId).lastRequestId) {
                      _this.queryStore.markQueryError(queryId, error, fetchMoreForQueryId);

                      _this.invalidate(queryId);

                      _this.invalidate(fetchMoreForQueryId);

                      _this.broadcastQueries();
                    }

                    throw new ApolloError({
                      networkError: error
                    });
                  }
                });

                if (fetchPolicy !== 'cache-and-network') {
                  return [2, networkResult];
                }

                networkResult.catch(function () {});
              }

              this.queryStore.markQueryResultClient(queryId, !shouldFetch);
              this.invalidate(queryId);
              this.invalidate(fetchMoreForQueryId);

              if (this.transform(query).hasForcedResolvers) {
                return [2, this.localState.runResolvers({
                  document: query,
                  remoteResult: {
                    data: storeResult
                  },
                  context: context,
                  variables: variables,
                  onlyRunForcedResolvers: true
                }).then(function (result) {
                  _this.markQueryResult(queryId, result, options, fetchMoreForQueryId);

                  _this.broadcastQueries();

                  return result;
                })];
              }

              this.broadcastQueries();
              return [2, {
                data: storeResult
              }];
          }
        });
      });
    };

    QueryManager.prototype.markQueryResult = function (queryId, result, _a, fetchMoreForQueryId) {
      var fetchPolicy = _a.fetchPolicy,
          variables = _a.variables,
          errorPolicy = _a.errorPolicy;

      if (fetchPolicy === 'no-cache') {
        this.setQuery(queryId, function () {
          return {
            newData: {
              result: result.data,
              complete: true
            }
          };
        });
      } else {
        this.dataStore.markQueryResult(result, this.getQuery(queryId).document, variables, fetchMoreForQueryId, errorPolicy === 'ignore' || errorPolicy === 'all');
      }
    };

    QueryManager.prototype.queryListenerForObserver = function (queryId, options, observer) {
      var _this = this;

      function invoke(method, argument) {
        if (observer[method]) {
          try {
            observer[method](argument);
          } catch (e) {
             invariant$2.error(e);
          }
        } else if (method === 'error') {
           invariant$2.error(argument);
        }
      }

      return function (queryStoreValue, newData) {
        _this.invalidate(queryId, false);

        if (!queryStoreValue) return;

        var _a = _this.getQuery(queryId),
            observableQuery = _a.observableQuery,
            document = _a.document;

        var fetchPolicy = observableQuery ? observableQuery.options.fetchPolicy : options.fetchPolicy;
        if (fetchPolicy === 'standby') return;
        var loading = isNetworkRequestInFlight(queryStoreValue.networkStatus);
        var lastResult = observableQuery && observableQuery.getLastResult();
        var networkStatusChanged = !!(lastResult && lastResult.networkStatus !== queryStoreValue.networkStatus);
        var shouldNotifyIfLoading = options.returnPartialData || !newData && queryStoreValue.previousVariables || networkStatusChanged && options.notifyOnNetworkStatusChange || fetchPolicy === 'cache-only' || fetchPolicy === 'cache-and-network';

        if (loading && !shouldNotifyIfLoading) {
          return;
        }

        var hasGraphQLErrors = isNonEmptyArray(queryStoreValue.graphQLErrors);
        var errorPolicy = observableQuery && observableQuery.options.errorPolicy || options.errorPolicy || 'none';

        if (errorPolicy === 'none' && hasGraphQLErrors || queryStoreValue.networkError) {
          return invoke('error', new ApolloError({
            graphQLErrors: queryStoreValue.graphQLErrors,
            networkError: queryStoreValue.networkError
          }));
        }

        try {
          var data = void 0;
          var isMissing = void 0;

          if (newData) {
            if (fetchPolicy !== 'no-cache' && fetchPolicy !== 'network-only') {
              _this.setQuery(queryId, function () {
                return {
                  newData: null
                };
              });
            }

            data = newData.result;
            isMissing = !newData.complete;
          } else {
            var lastError = observableQuery && observableQuery.getLastError();
            var errorStatusChanged = errorPolicy !== 'none' && (lastError && lastError.graphQLErrors) !== queryStoreValue.graphQLErrors;

            if (lastResult && lastResult.data && !errorStatusChanged) {
              data = lastResult.data;
              isMissing = false;
            } else {
              var diffResult = _this.dataStore.getCache().diff({
                query: document,
                variables: queryStoreValue.previousVariables || queryStoreValue.variables,
                returnPartialData: true,
                optimistic: true
              });

              data = diffResult.result;
              isMissing = !diffResult.complete;
            }
          }

          var stale = isMissing && !(options.returnPartialData || fetchPolicy === 'cache-only');
          var resultFromStore = {
            data: stale ? lastResult && lastResult.data : data,
            loading: loading,
            networkStatus: queryStoreValue.networkStatus,
            stale: stale
          };

          if (errorPolicy === 'all' && hasGraphQLErrors) {
            resultFromStore.errors = queryStoreValue.graphQLErrors;
          }

          invoke('next', resultFromStore);
        } catch (networkError) {
          invoke('error', new ApolloError({
            networkError: networkError
          }));
        }
      };
    };

    QueryManager.prototype.transform = function (document) {
      var transformCache = this.transformCache;

      if (!transformCache.has(document)) {
        var cache = this.dataStore.getCache();
        var transformed = cache.transformDocument(document);
        var forLink = removeConnectionDirectiveFromDocument(cache.transformForLink(transformed));
        var clientQuery = this.localState.clientQuery(transformed);
        var serverQuery = this.localState.serverQuery(forLink);
        var cacheEntry_1 = {
          document: transformed,
          hasClientExports: hasClientExports(transformed),
          hasForcedResolvers: this.localState.shouldForceResolvers(transformed),
          clientQuery: clientQuery,
          serverQuery: serverQuery,
          defaultVars: getDefaultValues(getOperationDefinition(transformed))
        };

        var add = function (doc) {
          if (doc && !transformCache.has(doc)) {
            transformCache.set(doc, cacheEntry_1);
          }
        };

        add(document);
        add(transformed);
        add(clientQuery);
        add(serverQuery);
      }

      return transformCache.get(document);
    };

    QueryManager.prototype.getVariables = function (document, variables) {
      return __assign(__assign({}, this.transform(document).defaultVars), variables);
    };

    QueryManager.prototype.watchQuery = function (options, shouldSubscribe) {
      if (shouldSubscribe === void 0) {
        shouldSubscribe = true;
      }

       invariant$2(options.fetchPolicy !== 'standby', 'client.watchQuery cannot be called with fetchPolicy set to "standby"');
      options.variables = this.getVariables(options.query, options.variables);

      if (typeof options.notifyOnNetworkStatusChange === 'undefined') {
        options.notifyOnNetworkStatusChange = false;
      }

      var transformedOptions = __assign({}, options);

      return new ObservableQuery({
        queryManager: this,
        options: transformedOptions,
        shouldSubscribe: shouldSubscribe
      });
    };

    QueryManager.prototype.query = function (options) {
      var _this = this;

       invariant$2(options.query, 'query option is required. You must specify your GraphQL document ' + 'in the query option.');
       invariant$2(options.query.kind === 'Document', 'You must wrap the query string in a "gql" tag.');
       invariant$2(!options.returnPartialData, 'returnPartialData option only supported on watchQuery.');
       invariant$2(!options.pollInterval, 'pollInterval option only supported on watchQuery.');
      return new Promise(function (resolve, reject) {
        var watchedQuery = _this.watchQuery(options, false);

        _this.fetchQueryRejectFns.set("query:" + watchedQuery.queryId, reject);

        watchedQuery.result().then(resolve, reject).then(function () {
          return _this.fetchQueryRejectFns.delete("query:" + watchedQuery.queryId);
        });
      });
    };

    QueryManager.prototype.generateQueryId = function () {
      return String(this.idCounter++);
    };

    QueryManager.prototype.stopQueryInStore = function (queryId) {
      this.stopQueryInStoreNoBroadcast(queryId);
      this.broadcastQueries();
    };

    QueryManager.prototype.stopQueryInStoreNoBroadcast = function (queryId) {
      this.stopPollingQuery(queryId);
      this.queryStore.stopQuery(queryId);
      this.invalidate(queryId);
    };

    QueryManager.prototype.addQueryListener = function (queryId, listener) {
      this.setQuery(queryId, function (_a) {
        var listeners = _a.listeners;
        listeners.add(listener);
        return {
          invalidated: false
        };
      });
    };

    QueryManager.prototype.updateQueryWatch = function (queryId, document, options) {
      var _this = this;

      var cancel = this.getQuery(queryId).cancel;
      if (cancel) cancel();

      var previousResult = function () {
        var previousResult = null;

        var observableQuery = _this.getQuery(queryId).observableQuery;

        if (observableQuery) {
          var lastResult = observableQuery.getLastResult();

          if (lastResult) {
            previousResult = lastResult.data;
          }
        }

        return previousResult;
      };

      return this.dataStore.getCache().watch({
        query: document,
        variables: options.variables,
        optimistic: true,
        previousResult: previousResult,
        callback: function (newData) {
          _this.setQuery(queryId, function () {
            return {
              invalidated: true,
              newData: newData
            };
          });
        }
      });
    };

    QueryManager.prototype.addObservableQuery = function (queryId, observableQuery) {
      this.setQuery(queryId, function () {
        return {
          observableQuery: observableQuery
        };
      });
    };

    QueryManager.prototype.removeObservableQuery = function (queryId) {
      var cancel = this.getQuery(queryId).cancel;
      this.setQuery(queryId, function () {
        return {
          observableQuery: null
        };
      });
      if (cancel) cancel();
    };

    QueryManager.prototype.clearStore = function () {
      this.fetchQueryRejectFns.forEach(function (reject) {
        reject( new InvariantError('Store reset while query was in flight (not completed in link chain)'));
      });
      var resetIds = [];
      this.queries.forEach(function (_a, queryId) {
        var observableQuery = _a.observableQuery;
        if (observableQuery) resetIds.push(queryId);
      });
      this.queryStore.reset(resetIds);
      this.mutationStore.reset();
      return this.dataStore.reset();
    };

    QueryManager.prototype.resetStore = function () {
      var _this = this;

      return this.clearStore().then(function () {
        return _this.reFetchObservableQueries();
      });
    };

    QueryManager.prototype.reFetchObservableQueries = function (includeStandby) {
      var _this = this;

      if (includeStandby === void 0) {
        includeStandby = false;
      }

      var observableQueryPromises = [];
      this.queries.forEach(function (_a, queryId) {
        var observableQuery = _a.observableQuery;

        if (observableQuery) {
          var fetchPolicy = observableQuery.options.fetchPolicy;
          observableQuery.resetLastResults();

          if (fetchPolicy !== 'cache-only' && (includeStandby || fetchPolicy !== 'standby')) {
            observableQueryPromises.push(observableQuery.refetch());
          }

          _this.setQuery(queryId, function () {
            return {
              newData: null
            };
          });

          _this.invalidate(queryId);
        }
      });
      this.broadcastQueries();
      return Promise.all(observableQueryPromises);
    };

    QueryManager.prototype.observeQuery = function (queryId, options, observer) {
      this.addQueryListener(queryId, this.queryListenerForObserver(queryId, options, observer));
      return this.fetchQuery(queryId, options);
    };

    QueryManager.prototype.startQuery = function (queryId, options, listener) {
       invariant$2.warn("The QueryManager.startQuery method has been deprecated");
      this.addQueryListener(queryId, listener);
      this.fetchQuery(queryId, options).catch(function () {
        return undefined;
      });
      return queryId;
    };

    QueryManager.prototype.startGraphQLSubscription = function (_a) {
      var _this = this;

      var query = _a.query,
          fetchPolicy = _a.fetchPolicy,
          variables = _a.variables;
      query = this.transform(query).document;
      variables = this.getVariables(query, variables);

      var makeObservable = function (variables) {
        return _this.getObservableFromLink(query, {}, variables, false).map(function (result) {
          if (!fetchPolicy || fetchPolicy !== 'no-cache') {
            _this.dataStore.markSubscriptionResult(result, query, variables);

            _this.broadcastQueries();
          }

          if (graphQLResultHasError(result)) {
            throw new ApolloError({
              graphQLErrors: result.errors
            });
          }

          return result;
        });
      };

      if (this.transform(query).hasClientExports) {
        var observablePromise_1 = this.localState.addExportedVariables(query, variables).then(makeObservable);
        return new Observable$2(function (observer) {
          var sub = null;
          observablePromise_1.then(function (observable) {
            return sub = observable.subscribe(observer);
          }, observer.error);
          return function () {
            return sub && sub.unsubscribe();
          };
        });
      }

      return makeObservable(variables);
    };

    QueryManager.prototype.stopQuery = function (queryId) {
      this.stopQueryNoBroadcast(queryId);
      this.broadcastQueries();
    };

    QueryManager.prototype.stopQueryNoBroadcast = function (queryId) {
      this.stopQueryInStoreNoBroadcast(queryId);
      this.removeQuery(queryId);
    };

    QueryManager.prototype.removeQuery = function (queryId) {
      this.fetchQueryRejectFns.delete("query:" + queryId);
      this.fetchQueryRejectFns.delete("fetchRequest:" + queryId);
      this.getQuery(queryId).subscriptions.forEach(function (x) {
        return x.unsubscribe();
      });
      this.queries.delete(queryId);
    };

    QueryManager.prototype.getCurrentQueryResult = function (observableQuery, optimistic) {
      if (optimistic === void 0) {
        optimistic = true;
      }

      var _a = observableQuery.options,
          variables = _a.variables,
          query = _a.query,
          fetchPolicy = _a.fetchPolicy,
          returnPartialData = _a.returnPartialData;
      var lastResult = observableQuery.getLastResult();
      var newData = this.getQuery(observableQuery.queryId).newData;

      if (newData && newData.complete) {
        return {
          data: newData.result,
          partial: false
        };
      }

      if (fetchPolicy === 'no-cache' || fetchPolicy === 'network-only') {
        return {
          data: undefined,
          partial: false
        };
      }

      var _b = this.dataStore.getCache().diff({
        query: query,
        variables: variables,
        previousResult: lastResult ? lastResult.data : undefined,
        returnPartialData: true,
        optimistic: optimistic
      }),
          result = _b.result,
          complete = _b.complete;

      return {
        data: complete || returnPartialData ? result : void 0,
        partial: !complete
      };
    };

    QueryManager.prototype.getQueryWithPreviousResult = function (queryIdOrObservable) {
      var observableQuery;

      if (typeof queryIdOrObservable === 'string') {
        var foundObserveableQuery = this.getQuery(queryIdOrObservable).observableQuery;
         invariant$2(foundObserveableQuery, "ObservableQuery with this id doesn't exist: " + queryIdOrObservable);
        observableQuery = foundObserveableQuery;
      } else {
        observableQuery = queryIdOrObservable;
      }

      var _a = observableQuery.options,
          variables = _a.variables,
          query = _a.query;
      return {
        previousResult: this.getCurrentQueryResult(observableQuery, false).data,
        variables: variables,
        document: query
      };
    };

    QueryManager.prototype.broadcastQueries = function () {
      var _this = this;

      this.onBroadcast();
      this.queries.forEach(function (info, id) {
        if (info.invalidated) {
          info.listeners.forEach(function (listener) {
            if (listener) {
              listener(_this.queryStore.get(id), info.newData);
            }
          });
        }
      });
    };

    QueryManager.prototype.getLocalState = function () {
      return this.localState;
    };

    QueryManager.prototype.getObservableFromLink = function (query, context, variables, deduplication) {
      var _this = this;

      if (deduplication === void 0) {
        deduplication = this.queryDeduplication;
      }

      var observable;
      var serverQuery = this.transform(query).serverQuery;

      if (serverQuery) {
        var _a = this,
            inFlightLinkObservables_1 = _a.inFlightLinkObservables,
            link = _a.link;

        var operation = {
          query: serverQuery,
          variables: variables,
          operationName: getOperationName(serverQuery) || void 0,
          context: this.prepareContext(__assign(__assign({}, context), {
            forceFetch: !deduplication
          }))
        };
        context = operation.context;

        if (deduplication) {
          var byVariables_1 = inFlightLinkObservables_1.get(serverQuery) || new Map();
          inFlightLinkObservables_1.set(serverQuery, byVariables_1);
          var varJson_1 = JSON.stringify(variables);
          observable = byVariables_1.get(varJson_1);

          if (!observable) {
            byVariables_1.set(varJson_1, observable = multiplex(execute(link, operation)));

            var cleanup = function () {
              byVariables_1.delete(varJson_1);
              if (!byVariables_1.size) inFlightLinkObservables_1.delete(serverQuery);
              cleanupSub_1.unsubscribe();
            };

            var cleanupSub_1 = observable.subscribe({
              next: cleanup,
              error: cleanup,
              complete: cleanup
            });
          }
        } else {
          observable = multiplex(execute(link, operation));
        }
      } else {
        observable = Observable$2.of({
          data: {}
        });
        context = this.prepareContext(context);
      }

      var clientQuery = this.transform(query).clientQuery;

      if (clientQuery) {
        observable = asyncMap(observable, function (result) {
          return _this.localState.runResolvers({
            document: clientQuery,
            remoteResult: result,
            context: context,
            variables: variables
          });
        });
      }

      return observable;
    };

    QueryManager.prototype.fetchRequest = function (_a) {
      var _this = this;

      var requestId = _a.requestId,
          queryId = _a.queryId,
          document = _a.document,
          options = _a.options,
          fetchMoreForQueryId = _a.fetchMoreForQueryId;
      var variables = options.variables,
          _b = options.errorPolicy,
          errorPolicy = _b === void 0 ? 'none' : _b,
          fetchPolicy = options.fetchPolicy;
      var resultFromStore;
      var errorsFromStore;
      return new Promise(function (resolve, reject) {
        var observable = _this.getObservableFromLink(document, options.context, variables);

        var fqrfId = "fetchRequest:" + queryId;

        _this.fetchQueryRejectFns.set(fqrfId, reject);

        var cleanup = function () {
          _this.fetchQueryRejectFns.delete(fqrfId);

          _this.setQuery(queryId, function (_a) {
            var subscriptions = _a.subscriptions;
            subscriptions.delete(subscription);
          });
        };

        var subscription = observable.map(function (result) {
          if (requestId >= _this.getQuery(queryId).lastRequestId) {
            _this.markQueryResult(queryId, result, options, fetchMoreForQueryId);

            _this.queryStore.markQueryResult(queryId, result, fetchMoreForQueryId);

            _this.invalidate(queryId);

            _this.invalidate(fetchMoreForQueryId);

            _this.broadcastQueries();
          }

          if (errorPolicy === 'none' && isNonEmptyArray(result.errors)) {
            return reject(new ApolloError({
              graphQLErrors: result.errors
            }));
          }

          if (errorPolicy === 'all') {
            errorsFromStore = result.errors;
          }

          if (fetchMoreForQueryId || fetchPolicy === 'no-cache') {
            resultFromStore = result.data;
          } else {
            var _a = _this.dataStore.getCache().diff({
              variables: variables,
              query: document,
              optimistic: false,
              returnPartialData: true
            }),
                result_1 = _a.result,
                complete = _a.complete;

            if (complete || options.returnPartialData) {
              resultFromStore = result_1;
            }
          }
        }).subscribe({
          error: function (error) {
            cleanup();
            reject(error);
          },
          complete: function () {
            cleanup();
            resolve({
              data: resultFromStore,
              errors: errorsFromStore,
              loading: false,
              networkStatus: NetworkStatus.ready,
              stale: false
            });
          }
        });

        _this.setQuery(queryId, function (_a) {
          var subscriptions = _a.subscriptions;
          subscriptions.add(subscription);
        });
      });
    };

    QueryManager.prototype.getQuery = function (queryId) {
      return this.queries.get(queryId) || {
        listeners: new Set(),
        invalidated: false,
        document: null,
        newData: null,
        lastRequestId: 1,
        observableQuery: null,
        subscriptions: new Set()
      };
    };

    QueryManager.prototype.setQuery = function (queryId, updater) {
      var prev = this.getQuery(queryId);

      var newInfo = __assign(__assign({}, prev), updater(prev));

      this.queries.set(queryId, newInfo);
    };

    QueryManager.prototype.invalidate = function (queryId, invalidated) {
      if (invalidated === void 0) {
        invalidated = true;
      }

      if (queryId) {
        this.setQuery(queryId, function () {
          return {
            invalidated: invalidated
          };
        });
      }
    };

    QueryManager.prototype.prepareContext = function (context) {
      if (context === void 0) {
        context = {};
      }

      var newContext = this.localState.prepareContext(context);
      return __assign(__assign({}, newContext), {
        clientAwareness: this.clientAwareness
      });
    };

    QueryManager.prototype.checkInFlight = function (queryId) {
      var query = this.queryStore.get(queryId);
      return query && query.networkStatus !== NetworkStatus.ready && query.networkStatus !== NetworkStatus.error;
    };

    QueryManager.prototype.startPollingQuery = function (options, queryId, listener) {
      var _this = this;

      var pollInterval = options.pollInterval;
       invariant$2(pollInterval, 'Attempted to start a polling query without a polling interval.');

      if (!this.ssrMode) {
        var info = this.pollingInfoByQueryId.get(queryId);

        if (!info) {
          this.pollingInfoByQueryId.set(queryId, info = {});
        }

        info.interval = pollInterval;
        info.options = __assign(__assign({}, options), {
          fetchPolicy: 'network-only'
        });

        var maybeFetch_1 = function () {
          var info = _this.pollingInfoByQueryId.get(queryId);

          if (info) {
            if (_this.checkInFlight(queryId)) {
              poll_1();
            } else {
              _this.fetchQuery(queryId, info.options, FetchType.poll).then(poll_1, poll_1);
            }
          }
        };

        var poll_1 = function () {
          var info = _this.pollingInfoByQueryId.get(queryId);

          if (info) {
            clearTimeout(info.timeout);
            info.timeout = setTimeout(maybeFetch_1, info.interval);
          }
        };

        if (listener) {
          this.addQueryListener(queryId, listener);
        }

        poll_1();
      }

      return queryId;
    };

    QueryManager.prototype.stopPollingQuery = function (queryId) {
      this.pollingInfoByQueryId.delete(queryId);
    };

    return QueryManager;
  }();

  var DataStore = function () {
    function DataStore(initialCache) {
      this.cache = initialCache;
    }

    DataStore.prototype.getCache = function () {
      return this.cache;
    };

    DataStore.prototype.markQueryResult = function (result, document, variables, fetchMoreForQueryId, ignoreErrors) {
      if (ignoreErrors === void 0) {
        ignoreErrors = false;
      }

      var writeWithErrors = !graphQLResultHasError(result);

      if (ignoreErrors && graphQLResultHasError(result) && result.data) {
        writeWithErrors = true;
      }

      if (!fetchMoreForQueryId && writeWithErrors) {
        this.cache.write({
          result: result.data,
          dataId: 'ROOT_QUERY',
          query: document,
          variables: variables
        });
      }
    };

    DataStore.prototype.markSubscriptionResult = function (result, document, variables) {
      if (!graphQLResultHasError(result)) {
        this.cache.write({
          result: result.data,
          dataId: 'ROOT_SUBSCRIPTION',
          query: document,
          variables: variables
        });
      }
    };

    DataStore.prototype.markMutationInit = function (mutation) {
      var _this = this;

      if (mutation.optimisticResponse) {
        var optimistic_1;

        if (typeof mutation.optimisticResponse === 'function') {
          optimistic_1 = mutation.optimisticResponse(mutation.variables);
        } else {
          optimistic_1 = mutation.optimisticResponse;
        }

        this.cache.recordOptimisticTransaction(function (c) {
          var orig = _this.cache;
          _this.cache = c;

          try {
            _this.markMutationResult({
              mutationId: mutation.mutationId,
              result: {
                data: optimistic_1
              },
              document: mutation.document,
              variables: mutation.variables,
              updateQueries: mutation.updateQueries,
              update: mutation.update
            });
          } finally {
            _this.cache = orig;
          }
        }, mutation.mutationId);
      }
    };

    DataStore.prototype.markMutationResult = function (mutation) {
      var _this = this;

      if (!graphQLResultHasError(mutation.result)) {
        var cacheWrites_1 = [{
          result: mutation.result.data,
          dataId: 'ROOT_MUTATION',
          query: mutation.document,
          variables: mutation.variables
        }];
        var updateQueries_1 = mutation.updateQueries;

        if (updateQueries_1) {
          Object.keys(updateQueries_1).forEach(function (id) {
            var _a = updateQueries_1[id],
                query = _a.query,
                updater = _a.updater;

            var _b = _this.cache.diff({
              query: query.document,
              variables: query.variables,
              returnPartialData: true,
              optimistic: false
            }),
                currentQueryResult = _b.result,
                complete = _b.complete;

            if (complete) {
              var nextQueryResult = tryFunctionOrLogError(function () {
                return updater(currentQueryResult, {
                  mutationResult: mutation.result,
                  queryName: getOperationName(query.document) || undefined,
                  queryVariables: query.variables
                });
              });

              if (nextQueryResult) {
                cacheWrites_1.push({
                  result: nextQueryResult,
                  dataId: 'ROOT_QUERY',
                  query: query.document,
                  variables: query.variables
                });
              }
            }
          });
        }

        this.cache.performTransaction(function (c) {
          cacheWrites_1.forEach(function (write) {
            return c.write(write);
          });
          var update = mutation.update;

          if (update) {
            tryFunctionOrLogError(function () {
              return update(c, mutation.result);
            });
          }
        });
      }
    };

    DataStore.prototype.markMutationComplete = function (_a) {
      var mutationId = _a.mutationId,
          optimisticResponse = _a.optimisticResponse;

      if (optimisticResponse) {
        this.cache.removeOptimistic(mutationId);
      }
    };

    DataStore.prototype.markUpdateQueryResult = function (document, variables, newResult) {
      this.cache.write({
        result: newResult,
        dataId: 'ROOT_QUERY',
        variables: variables,
        query: document
      });
    };

    DataStore.prototype.reset = function () {
      return this.cache.reset();
    };

    return DataStore;
  }();

  var version = "2.6.10";
  var hasSuggestedDevtools = false;

  var ApolloClient = function () {
    function ApolloClient(options) {
      var _this = this;

      this.defaultOptions = {};
      this.resetStoreCallbacks = [];
      this.clearStoreCallbacks = [];
      var cache = options.cache,
          _a = options.ssrMode,
          ssrMode = _a === void 0 ? false : _a,
          _b = options.ssrForceFetchDelay,
          ssrForceFetchDelay = _b === void 0 ? 0 : _b,
          connectToDevTools = options.connectToDevTools,
          _c = options.queryDeduplication,
          queryDeduplication = _c === void 0 ? true : _c,
          defaultOptions = options.defaultOptions,
          _d = options.assumeImmutableResults,
          assumeImmutableResults = _d === void 0 ? false : _d,
          resolvers = options.resolvers,
          typeDefs = options.typeDefs,
          fragmentMatcher = options.fragmentMatcher,
          clientAwarenessName = options.name,
          clientAwarenessVersion = options.version;
      var link = options.link;

      if (!link && resolvers) {
        link = ApolloLink.empty();
      }

      if (!link || !cache) {
        throw  new InvariantError("In order to initialize Apollo Client, you must specify 'link' and 'cache' properties in the options object.\n" + "These options are part of the upgrade requirements when migrating from Apollo Client 1.x to Apollo Client 2.x.\n" + "For more information, please visit: https://www.apollographql.com/docs/tutorial/client.html#apollo-client-setup");
      }

      this.link = link;
      this.cache = cache;
      this.store = new DataStore(cache);
      this.disableNetworkFetches = ssrMode || ssrForceFetchDelay > 0;
      this.queryDeduplication = queryDeduplication;
      this.defaultOptions = defaultOptions || {};
      this.typeDefs = typeDefs;

      if (ssrForceFetchDelay) {
        setTimeout(function () {
          return _this.disableNetworkFetches = false;
        }, ssrForceFetchDelay);
      }

      this.watchQuery = this.watchQuery.bind(this);
      this.query = this.query.bind(this);
      this.mutate = this.mutate.bind(this);
      this.resetStore = this.resetStore.bind(this);
      this.reFetchObservableQueries = this.reFetchObservableQueries.bind(this);
      var defaultConnectToDevTools =  typeof window !== 'undefined' && !window.__APOLLO_CLIENT__;

      if (typeof connectToDevTools === 'undefined' ? defaultConnectToDevTools : connectToDevTools && typeof window !== 'undefined') {
        window.__APOLLO_CLIENT__ = this;
      }

      if (!hasSuggestedDevtools && "development" !== 'production') {
        hasSuggestedDevtools = true;

        if (typeof window !== 'undefined' && window.document && window.top === window.self) {
          if (typeof window.__APOLLO_DEVTOOLS_GLOBAL_HOOK__ === 'undefined') {
            if (window.navigator && window.navigator.userAgent && window.navigator.userAgent.indexOf('Chrome') > -1) {
              console.debug('Download the Apollo DevTools ' + 'for a better development experience: ' + 'https://chrome.google.com/webstore/detail/apollo-client-developer-t/jdkknkkbebbapilgoeccciglkfbmbnfm');
            }
          }
        }
      }

      this.version = version;
      this.localState = new LocalState({
        cache: cache,
        client: this,
        resolvers: resolvers,
        fragmentMatcher: fragmentMatcher
      });
      this.queryManager = new QueryManager({
        link: this.link,
        store: this.store,
        queryDeduplication: queryDeduplication,
        ssrMode: ssrMode,
        clientAwareness: {
          name: clientAwarenessName,
          version: clientAwarenessVersion
        },
        localState: this.localState,
        assumeImmutableResults: assumeImmutableResults,
        onBroadcast: function () {
          if (_this.devToolsHookCb) {
            _this.devToolsHookCb({
              action: {},
              state: {
                queries: _this.queryManager.queryStore.getStore(),
                mutations: _this.queryManager.mutationStore.getStore()
              },
              dataWithOptimisticResults: _this.cache.extract(true)
            });
          }
        }
      });
    }

    ApolloClient.prototype.stop = function () {
      this.queryManager.stop();
    };

    ApolloClient.prototype.watchQuery = function (options) {
      if (this.defaultOptions.watchQuery) {
        options = __assign(__assign({}, this.defaultOptions.watchQuery), options);
      }

      if (this.disableNetworkFetches && (options.fetchPolicy === 'network-only' || options.fetchPolicy === 'cache-and-network')) {
        options = __assign(__assign({}, options), {
          fetchPolicy: 'cache-first'
        });
      }

      return this.queryManager.watchQuery(options);
    };

    ApolloClient.prototype.query = function (options) {
      if (this.defaultOptions.query) {
        options = __assign(__assign({}, this.defaultOptions.query), options);
      }

       invariant$2(options.fetchPolicy !== 'cache-and-network', 'The cache-and-network fetchPolicy does not work with client.query, because ' + 'client.query can only return a single result. Please use client.watchQuery ' + 'to receive multiple results from the cache and the network, or consider ' + 'using a different fetchPolicy, such as cache-first or network-only.');

      if (this.disableNetworkFetches && options.fetchPolicy === 'network-only') {
        options = __assign(__assign({}, options), {
          fetchPolicy: 'cache-first'
        });
      }

      return this.queryManager.query(options);
    };

    ApolloClient.prototype.mutate = function (options) {
      if (this.defaultOptions.mutate) {
        options = __assign(__assign({}, this.defaultOptions.mutate), options);
      }

      return this.queryManager.mutate(options);
    };

    ApolloClient.prototype.subscribe = function (options) {
      return this.queryManager.startGraphQLSubscription(options);
    };

    ApolloClient.prototype.readQuery = function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return this.cache.readQuery(options, optimistic);
    };

    ApolloClient.prototype.readFragment = function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return this.cache.readFragment(options, optimistic);
    };

    ApolloClient.prototype.writeQuery = function (options) {
      var result = this.cache.writeQuery(options);
      this.queryManager.broadcastQueries();
      return result;
    };

    ApolloClient.prototype.writeFragment = function (options) {
      var result = this.cache.writeFragment(options);
      this.queryManager.broadcastQueries();
      return result;
    };

    ApolloClient.prototype.writeData = function (options) {
      var result = this.cache.writeData(options);
      this.queryManager.broadcastQueries();
      return result;
    };

    ApolloClient.prototype.__actionHookForDevTools = function (cb) {
      this.devToolsHookCb = cb;
    };

    ApolloClient.prototype.__requestRaw = function (payload) {
      return execute(this.link, payload);
    };

    ApolloClient.prototype.initQueryManager = function () {
       invariant$2.warn('Calling the initQueryManager method is no longer necessary, ' + 'and it will be removed from ApolloClient in version 3.0.');
      return this.queryManager;
    };

    ApolloClient.prototype.resetStore = function () {
      var _this = this;

      return Promise.resolve().then(function () {
        return _this.queryManager.clearStore();
      }).then(function () {
        return Promise.all(_this.resetStoreCallbacks.map(function (fn) {
          return fn();
        }));
      }).then(function () {
        return _this.reFetchObservableQueries();
      });
    };

    ApolloClient.prototype.clearStore = function () {
      var _this = this;

      return Promise.resolve().then(function () {
        return _this.queryManager.clearStore();
      }).then(function () {
        return Promise.all(_this.clearStoreCallbacks.map(function (fn) {
          return fn();
        }));
      });
    };

    ApolloClient.prototype.onResetStore = function (cb) {
      var _this = this;

      this.resetStoreCallbacks.push(cb);
      return function () {
        _this.resetStoreCallbacks = _this.resetStoreCallbacks.filter(function (c) {
          return c !== cb;
        });
      };
    };

    ApolloClient.prototype.onClearStore = function (cb) {
      var _this = this;

      this.clearStoreCallbacks.push(cb);
      return function () {
        _this.clearStoreCallbacks = _this.clearStoreCallbacks.filter(function (c) {
          return c !== cb;
        });
      };
    };

    ApolloClient.prototype.reFetchObservableQueries = function (includeStandby) {
      return this.queryManager.reFetchObservableQueries(includeStandby);
    };

    ApolloClient.prototype.extract = function (optimistic) {
      return this.cache.extract(optimistic);
    };

    ApolloClient.prototype.restore = function (serializedState) {
      return this.cache.restore(serializedState);
    };

    ApolloClient.prototype.addResolvers = function (resolvers) {
      this.localState.addResolvers(resolvers);
    };

    ApolloClient.prototype.setResolvers = function (resolvers) {
      this.localState.setResolvers(resolvers);
    };

    ApolloClient.prototype.getResolvers = function () {
      return this.localState.getResolvers();
    };

    ApolloClient.prototype.setLocalStateFragmentMatcher = function (fragmentMatcher) {
      this.localState.setFragmentMatcher(fragmentMatcher);
    };

    return ApolloClient;
  }();

  registerComponent(ApolloClient, {
    tmpl: _tmpl
  });

  function queryFromPojo(obj) {
    var op = {
      kind: 'OperationDefinition',
      operation: 'query',
      name: {
        kind: 'Name',
        value: 'GeneratedClientQuery'
      },
      selectionSet: selectionSetFromObj(obj)
    };
    var out = {
      kind: 'Document',
      definitions: [op]
    };
    return out;
  }

  function fragmentFromPojo(obj, typename) {
    var frag = {
      kind: 'FragmentDefinition',
      typeCondition: {
        kind: 'NamedType',
        name: {
          kind: 'Name',
          value: typename || '__FakeType'
        }
      },
      name: {
        kind: 'Name',
        value: 'GeneratedClientQuery'
      },
      selectionSet: selectionSetFromObj(obj)
    };
    var out = {
      kind: 'Document',
      definitions: [frag]
    };
    return out;
  }

  function selectionSetFromObj(obj) {
    if (typeof obj === 'number' || typeof obj === 'boolean' || typeof obj === 'string' || typeof obj === 'undefined' || obj === null) {
      return null;
    }

    if (Array.isArray(obj)) {
      return selectionSetFromObj(obj[0]);
    }

    var selections = [];
    Object.keys(obj).forEach(function (key) {
      var nestedSelSet = selectionSetFromObj(obj[key]);
      var field = {
        kind: 'Field',
        name: {
          kind: 'Name',
          value: key
        },
        selectionSet: nestedSelSet || undefined
      };
      selections.push(field);
    });
    var selectionSet = {
      kind: 'SelectionSet',
      selections: selections
    };
    return selectionSet;
  }

  var justTypenameQuery = {
    kind: 'Document',
    definitions: [{
      kind: 'OperationDefinition',
      operation: 'query',
      name: null,
      variableDefinitions: null,
      directives: [],
      selectionSet: {
        kind: 'SelectionSet',
        selections: [{
          kind: 'Field',
          alias: null,
          name: {
            kind: 'Name',
            value: '__typename'
          },
          arguments: [],
          directives: [],
          selectionSet: null
        }]
      }
    }]
  };

  var ApolloCache = function () {
    function ApolloCache() {}

    ApolloCache.prototype.transformDocument = function (document) {
      return document;
    };

    ApolloCache.prototype.transformForLink = function (document) {
      return document;
    };

    ApolloCache.prototype.readQuery = function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return this.read({
        query: options.query,
        variables: options.variables,
        optimistic: optimistic
      });
    };

    ApolloCache.prototype.readFragment = function (options, optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return this.read({
        query: getFragmentQueryDocument(options.fragment, options.fragmentName),
        variables: options.variables,
        rootId: options.id,
        optimistic: optimistic
      });
    };

    ApolloCache.prototype.writeQuery = function (options) {
      this.write({
        dataId: 'ROOT_QUERY',
        result: options.data,
        query: options.query,
        variables: options.variables
      });
    };

    ApolloCache.prototype.writeFragment = function (options) {
      this.write({
        dataId: options.id,
        result: options.data,
        variables: options.variables,
        query: getFragmentQueryDocument(options.fragment, options.fragmentName)
      });
    };

    ApolloCache.prototype.writeData = function (_a) {
      var id = _a.id,
          data = _a.data;

      if (typeof id !== 'undefined') {
        var typenameResult = null;

        try {
          typenameResult = this.read({
            rootId: id,
            optimistic: false,
            query: justTypenameQuery
          });
        } catch (e) {}

        var __typename = typenameResult && typenameResult.__typename || '__ClientData';

        var dataToWrite = Object.assign({
          __typename: __typename
        }, data);
        this.writeFragment({
          id: id,
          fragment: fragmentFromPojo(dataToWrite, __typename),
          data: dataToWrite
        });
      } else {
        this.writeQuery({
          query: queryFromPojo(data),
          data: data
        });
      }
    };

    return ApolloCache;
  }();

  // This currentContext variable will only be used if the makeSlotClass
  // function is called, which happens only if this is the first copy of the
  // @wry/context package to be imported.
  var currentContext = null; // This unique internal object is used to denote the absence of a value
  // for a given Slot, and is never exposed to outside code.

  var MISSING_VALUE = {};
  var idCounter = 1; // Although we can't do anything about the cost of duplicated code from
  // accidentally bundling multiple copies of the @wry/context package, we can
  // avoid creating the Slot class more than once using makeSlotClass.

  var makeSlotClass = function () {
    return (
      /** @class */
      function () {
        function Slot() {
          // If you have a Slot object, you can find out its slot.id, but you cannot
          // guess the slot.id of a Slot you don't have access to, thanks to the
          // randomized suffix.
          this.id = ["slot", idCounter++, Date.now(), Math.random().toString(36).slice(2)].join(":");
        }

        Slot.prototype.hasValue = function () {
          for (var context_1 = currentContext; context_1; context_1 = context_1.parent) {
            // We use the Slot object iself as a key to its value, which means the
            // value cannot be obtained without a reference to the Slot object.
            if (this.id in context_1.slots) {
              var value = context_1.slots[this.id];
              if (value === MISSING_VALUE) break;

              if (context_1 !== currentContext) {
                // Cache the value in currentContext.slots so the next lookup will
                // be faster. This caching is safe because the tree of contexts and
                // the values of the slots are logically immutable.
                currentContext.slots[this.id] = value;
              }

              return true;
            }
          }

          if (currentContext) {
            // If a value was not found for this Slot, it's never going to be found
            // no matter how many times we look it up, so we might as well cache
            // the absence of the value, too.
            currentContext.slots[this.id] = MISSING_VALUE;
          }

          return false;
        };

        Slot.prototype.getValue = function () {
          if (this.hasValue()) {
            return currentContext.slots[this.id];
          }
        };

        Slot.prototype.withValue = function (value, callback, // Given the prevalence of arrow functions, specifying arguments is likely
        // to be much more common than specifying `this`, hence this ordering:
        args, thisArg) {
          var _a;

          var slots = (_a = {
            __proto__: null
          }, _a[this.id] = value, _a);
          var parent = currentContext;
          currentContext = {
            parent: parent,
            slots: slots
          };

          try {
            // Function.prototype.apply allows the arguments array argument to be
            // omitted or undefined, so args! is fine here.
            return callback.apply(thisArg, args);
          } finally {
            currentContext = parent;
          }
        }; // Capture the current context and wrap a callback function so that it
        // reestablishes the captured context when called.


        Slot.bind = function (callback) {
          var context = currentContext;
          return function () {
            var saved = currentContext;

            try {
              currentContext = context;
              return callback.apply(this, arguments);
            } finally {
              currentContext = saved;
            }
          };
        }; // Immediately run a callback function without any captured context.


        Slot.noContext = function (callback, // Given the prevalence of arrow functions, specifying arguments is likely
        // to be much more common than specifying `this`, hence this ordering:
        args, thisArg) {
          if (currentContext) {
            var saved = currentContext;

            try {
              currentContext = null; // Function.prototype.apply allows the arguments array argument to be
              // omitted or undefined, so args! is fine here.

              return callback.apply(thisArg, args);
            } finally {
              currentContext = saved;
            }
          } else {
            return callback.apply(thisArg, args);
          }
        };

        return Slot;
      }()
    );
  }; // We store a single global implementation of the Slot class as a permanent
  // non-enumerable symbol property of the Array constructor. This obfuscation
  // does nothing to prevent access to the Slot class, but at least it ensures
  // the implementation (i.e. currentContext) cannot be tampered with, and all
  // copies of the @wry/context package (hopefully just one) will share the
  // same Slot implementation. Since the first copy of the @wry/context package
  // to be imported wins, this technique imposes a very high cost for any
  // future breaking changes to the Slot class.


  var globalKey = "@wry/context:Slot";
  var host = Array;

  var Slot = host[globalKey] || function () {
    var Slot = makeSlotClass();

    try {
      Object.defineProperty(host, globalKey, {
        value: host[globalKey] = Slot,
        enumerable: false,
        writable: false,
        configurable: false
      });
    } finally {
      return Slot;
    }
  }();

  var bind = Slot.bind,
      noContext = Slot.noContext;

  function defaultDispose() {}

  var Cache =
  /** @class */
  function () {
    function Cache(max, dispose) {
      if (max === void 0) {
        max = Infinity;
      }

      if (dispose === void 0) {
        dispose = defaultDispose;
      }

      this.max = max;
      this.dispose = dispose;
      this.map = new Map();
      this.newest = null;
      this.oldest = null;
    }

    Cache.prototype.has = function (key) {
      return this.map.has(key);
    };

    Cache.prototype.get = function (key) {
      var entry = this.getEntry(key);
      return entry && entry.value;
    };

    Cache.prototype.getEntry = function (key) {
      var entry = this.map.get(key);

      if (entry && entry !== this.newest) {
        var older = entry.older,
            newer = entry.newer;

        if (newer) {
          newer.older = older;
        }

        if (older) {
          older.newer = newer;
        }

        entry.older = this.newest;
        entry.older.newer = entry;
        entry.newer = null;
        this.newest = entry;

        if (entry === this.oldest) {
          this.oldest = newer;
        }
      }

      return entry;
    };

    Cache.prototype.set = function (key, value) {
      var entry = this.getEntry(key);

      if (entry) {
        return entry.value = value;
      }

      entry = {
        key: key,
        value: value,
        newer: null,
        older: this.newest
      };

      if (this.newest) {
        this.newest.newer = entry;
      }

      this.newest = entry;
      this.oldest = this.oldest || entry;
      this.map.set(key, entry);
      return entry.value;
    };

    Cache.prototype.clean = function () {
      while (this.oldest && this.map.size > this.max) {
        this.delete(this.oldest.key);
      }
    };

    Cache.prototype.delete = function (key) {
      var entry = this.map.get(key);

      if (entry) {
        if (entry === this.newest) {
          this.newest = entry.older;
        }

        if (entry === this.oldest) {
          this.oldest = entry.newer;
        }

        if (entry.newer) {
          entry.newer.older = entry.older;
        }

        if (entry.older) {
          entry.older.newer = entry.newer;
        }

        this.map.delete(key);
        this.dispose(entry.value, key);
        return true;
      }

      return false;
    };

    return Cache;
  }();

  var parentEntrySlot = new Slot();
  var reusableEmptyArray = [];
  var emptySetPool = [];
  var POOL_TARGET_SIZE = 100; // Since this package might be used browsers, we should avoid using the
  // Node built-in assert module.

  function assert$1(condition, optionalMessage) {
    if (!condition) {
      throw new Error(optionalMessage || "assertion failure");
    }
  }

  function valueIs(a, b) {
    var len = a.length;
    return (// Unknown values are not equal to each other.
      len > 0 && // Both values must be ordinary (or both exceptional) to be equal.
      len === b.length && // The underlying value or exception must be the same.
      a[len - 1] === b[len - 1]
    );
  }

  function valueGet(value) {
    switch (value.length) {
      case 0:
        throw new Error("unknown value");

      case 1:
        return value[0];

      case 2:
        throw value[1];
    }
  }

  function valueCopy(value) {
    return value.slice(0);
  }

  var Entry =
  /** @class */
  function () {
    function Entry(fn, args) {
      this.fn = fn;
      this.args = args;
      this.parents = new Set();
      this.childValues = new Map(); // When this Entry has children that are dirty, this property becomes
      // a Set containing other Entry objects, borrowed from emptySetPool.
      // When the set becomes empty, it gets recycled back to emptySetPool.

      this.dirtyChildren = null;
      this.dirty = true;
      this.recomputing = false;
      this.value = [];
      ++Entry.count;
    } // This is the most important method of the Entry API, because it
    // determines whether the cached this.value can be returned immediately,
    // or must be recomputed. The overall performance of the caching system
    // depends on the truth of the following observations: (1) this.dirty is
    // usually false, (2) this.dirtyChildren is usually null/empty, and thus
    // (3) valueGet(this.value) is usually returned without recomputation.


    Entry.prototype.recompute = function () {
      assert$1(!this.recomputing, "already recomputing");

      if (!rememberParent(this) && maybeReportOrphan(this)) {
        // The recipient of the entry.reportOrphan callback decided to dispose
        // of this orphan entry by calling entry.dispose(), so we don't need to
        // (and should not) proceed with the recomputation.
        return void 0;
      }

      return mightBeDirty(this) ? reallyRecompute(this) : valueGet(this.value);
    };

    Entry.prototype.setDirty = function () {
      if (this.dirty) return;
      this.dirty = true;
      this.value.length = 0;
      reportDirty(this); // We can go ahead and unsubscribe here, since any further dirty
      // notifications we receive will be redundant, and unsubscribing may
      // free up some resources, e.g. file watchers.

      maybeUnsubscribe(this);
    };

    Entry.prototype.dispose = function () {
      var _this = this;

      forgetChildren(this).forEach(maybeReportOrphan);
      maybeUnsubscribe(this); // Because this entry has been kicked out of the cache (in index.js),
      // we've lost the ability to find out if/when this entry becomes dirty,
      // whether that happens through a subscription, because of a direct call
      // to entry.setDirty(), or because one of its children becomes dirty.
      // Because of this loss of future information, we have to assume the
      // worst (that this entry might have become dirty very soon), so we must
      // immediately mark this entry's parents as dirty. Normally we could
      // just call entry.setDirty() rather than calling parent.setDirty() for
      // each parent, but that would leave this entry in parent.childValues
      // and parent.dirtyChildren, which would prevent the child from being
      // truly forgotten.

      this.parents.forEach(function (parent) {
        parent.setDirty();
        forgetChild(parent, _this);
      });
    };

    Entry.count = 0;
    return Entry;
  }();

  function rememberParent(child) {
    var parent = parentEntrySlot.getValue();

    if (parent) {
      child.parents.add(parent);

      if (!parent.childValues.has(child)) {
        parent.childValues.set(child, []);
      }

      if (mightBeDirty(child)) {
        reportDirtyChild(parent, child);
      } else {
        reportCleanChild(parent, child);
      }

      return parent;
    }
  }

  function reallyRecompute(entry) {
    // Since this recomputation is likely to re-remember some of this
    // entry's children, we forget our children here but do not call
    // maybeReportOrphan until after the recomputation finishes.
    var originalChildren = forgetChildren(entry); // Set entry as the parent entry while calling recomputeNewValue(entry).

    parentEntrySlot.withValue(entry, recomputeNewValue, [entry]);

    if (maybeSubscribe(entry)) {
      // If we successfully recomputed entry.value and did not fail to
      // (re)subscribe, then this Entry is no longer explicitly dirty.
      setClean(entry);
    } // Now that we've had a chance to re-remember any children that were
    // involved in the recomputation, we can safely report any orphan
    // children that remain.


    originalChildren.forEach(maybeReportOrphan);
    return valueGet(entry.value);
  }

  function recomputeNewValue(entry) {
    entry.recomputing = true; // Set entry.value as unknown.

    entry.value.length = 0;

    try {
      // If entry.fn succeeds, entry.value will become a normal Value.
      entry.value[0] = entry.fn.apply(null, entry.args);
    } catch (e) {
      // If entry.fn throws, entry.value will become exceptional.
      entry.value[1] = e;
    } // Either way, this line is always reached.


    entry.recomputing = false;
  }

  function mightBeDirty(entry) {
    return entry.dirty || !!(entry.dirtyChildren && entry.dirtyChildren.size);
  }

  function setClean(entry) {
    entry.dirty = false;

    if (mightBeDirty(entry)) {
      // This Entry may still have dirty children, in which case we can't
      // let our parents know we're clean just yet.
      return;
    }

    reportClean(entry);
  }

  function reportDirty(child) {
    child.parents.forEach(function (parent) {
      return reportDirtyChild(parent, child);
    });
  }

  function reportClean(child) {
    child.parents.forEach(function (parent) {
      return reportCleanChild(parent, child);
    });
  } // Let a parent Entry know that one of its children may be dirty.


  function reportDirtyChild(parent, child) {
    // Must have called rememberParent(child) before calling
    // reportDirtyChild(parent, child).
    assert$1(parent.childValues.has(child));
    assert$1(mightBeDirty(child));

    if (!parent.dirtyChildren) {
      parent.dirtyChildren = emptySetPool.pop() || new Set();
    } else if (parent.dirtyChildren.has(child)) {
      // If we already know this child is dirty, then we must have already
      // informed our own parents that we are dirty, so we can terminate
      // the recursion early.
      return;
    }

    parent.dirtyChildren.add(child);
    reportDirty(parent);
  } // Let a parent Entry know that one of its children is no longer dirty.


  function reportCleanChild(parent, child) {
    // Must have called rememberChild(child) before calling
    // reportCleanChild(parent, child).
    assert$1(parent.childValues.has(child));
    assert$1(!mightBeDirty(child));
    var childValue = parent.childValues.get(child);

    if (childValue.length === 0) {
      parent.childValues.set(child, valueCopy(child.value));
    } else if (!valueIs(childValue, child.value)) {
      parent.setDirty();
    }

    removeDirtyChild(parent, child);

    if (mightBeDirty(parent)) {
      return;
    }

    reportClean(parent);
  }

  function removeDirtyChild(parent, child) {
    var dc = parent.dirtyChildren;

    if (dc) {
      dc.delete(child);

      if (dc.size === 0) {
        if (emptySetPool.length < POOL_TARGET_SIZE) {
          emptySetPool.push(dc);
        }

        parent.dirtyChildren = null;
      }
    }
  } // If the given entry has a reportOrphan method, and no remaining parents,
  // call entry.reportOrphan and return true iff it returns true. The
  // reportOrphan function should return true to indicate entry.dispose()
  // has been called, and the entry has been removed from any other caches
  // (see index.js for the only current example).


  function maybeReportOrphan(entry) {
    return entry.parents.size === 0 && typeof entry.reportOrphan === "function" && entry.reportOrphan() === true;
  } // Removes all children from this entry and returns an array of the
  // removed children.


  function forgetChildren(parent) {
    var children = reusableEmptyArray;

    if (parent.childValues.size > 0) {
      children = [];
      parent.childValues.forEach(function (_value, child) {
        forgetChild(parent, child);
        children.push(child);
      });
    } // After we forget all our children, this.dirtyChildren must be empty
    // and therefore must have been reset to null.


    assert$1(parent.dirtyChildren === null);
    return children;
  }

  function forgetChild(parent, child) {
    child.parents.delete(parent);
    parent.childValues.delete(child);
    removeDirtyChild(parent, child);
  }

  function maybeSubscribe(entry) {
    if (typeof entry.subscribe === "function") {
      try {
        maybeUnsubscribe(entry); // Prevent double subscriptions.

        entry.unsubscribe = entry.subscribe.apply(null, entry.args);
      } catch (e) {
        // If this Entry has a subscribe function and it threw an exception
        // (or an unsubscribe function it previously returned now throws),
        // return false to indicate that we were not able to subscribe (or
        // unsubscribe), and this Entry should remain dirty.
        entry.setDirty();
        return false;
      }
    } // Returning true indicates either that there was no entry.subscribe
    // function or that it succeeded.


    return true;
  }

  function maybeUnsubscribe(entry) {
    var unsubscribe = entry.unsubscribe;

    if (typeof unsubscribe === "function") {
      entry.unsubscribe = void 0;
      unsubscribe();
    }
  } // A trie data structure that holds object keys weakly, yet can also hold
  // non-object keys, unlike the native `WeakMap`.


  var KeyTrie =
  /** @class */
  function () {
    function KeyTrie(weakness) {
      this.weakness = weakness;
    }

    KeyTrie.prototype.lookup = function () {
      var array = [];

      for (var _i = 0; _i < arguments.length; _i++) {
        array[_i] = arguments[_i];
      }

      return this.lookupArray(array);
    };

    KeyTrie.prototype.lookupArray = function (array) {
      var node = this;
      array.forEach(function (key) {
        return node = node.getChildTrie(key);
      });
      return node.data || (node.data = Object.create(null));
    };

    KeyTrie.prototype.getChildTrie = function (key) {
      var map = this.weakness && isObjRef(key) ? this.weak || (this.weak = new WeakMap()) : this.strong || (this.strong = new Map());
      var child = map.get(key);
      if (!child) map.set(key, child = new KeyTrie(this.weakness));
      return child;
    };

    return KeyTrie;
  }();

  function isObjRef(value) {
    switch (typeof value) {
      case "object":
        if (value === null) break;
      // Fall through to return true...

      case "function":
        return true;
    }

    return false;
  } // The defaultMakeCacheKey function is remarkably powerful, because it gives
  // a unique object for any shallow-identical list of arguments. If you need
  // to implement a custom makeCacheKey function, you may find it helpful to
  // delegate the final work to defaultMakeCacheKey, which is why we export it
  // here. However, you may want to avoid defaultMakeCacheKey if your runtime
  // does not support WeakMap, or you have the ability to return a string key.
  // In those cases, just write your own custom makeCacheKey functions.


  var keyTrie = new KeyTrie(typeof WeakMap === "function");

  function defaultMakeCacheKey() {
    var args = [];

    for (var _i = 0; _i < arguments.length; _i++) {
      args[_i] = arguments[_i];
    }

    return keyTrie.lookupArray(args);
  }

  var caches = new Set();

  function wrap(originalFunction, options) {
    if (options === void 0) {
      options = Object.create(null);
    }

    var cache = new Cache(options.max || Math.pow(2, 16), function (entry) {
      return entry.dispose();
    });
    var disposable = !!options.disposable;
    var makeCacheKey = options.makeCacheKey || defaultMakeCacheKey;

    function optimistic() {
      if (disposable && !parentEntrySlot.hasValue()) {
        // If there's no current parent computation, and this wrapped
        // function is disposable (meaning we don't care about entry.value,
        // just dependency tracking), then we can short-cut everything else
        // in this function, because entry.recompute() is going to recycle
        // the entry object without recomputing anything, anyway.
        return void 0;
      }

      var key = makeCacheKey.apply(null, arguments);

      if (key === void 0) {
        return originalFunction.apply(null, arguments);
      }

      var args = Array.prototype.slice.call(arguments);
      var entry = cache.get(key);

      if (entry) {
        entry.args = args;
      } else {
        entry = new Entry(originalFunction, args);
        cache.set(key, entry);
        entry.subscribe = options.subscribe;

        if (disposable) {
          entry.reportOrphan = function () {
            return cache.delete(key);
          };
        }
      }

      var value = entry.recompute(); // Move this entry to the front of the least-recently used queue,
      // since we just finished computing its value.

      cache.set(key, entry);
      caches.add(cache); // Clean up any excess entries in the cache, but only if there is no
      // active parent entry, meaning we're not in the middle of a larger
      // computation that might be flummoxed by the cleaning.

      if (!parentEntrySlot.hasValue()) {
        caches.forEach(function (cache) {
          return cache.clean();
        });
        caches.clear();
      } // If options.disposable is truthy, the caller of wrap is telling us
      // they don't care about the result of entry.recompute(), so we should
      // avoid returning the value, so it won't be accidentally used.


      return disposable ? void 0 : value;
    }

    optimistic.dirty = function () {
      var key = makeCacheKey.apply(null, arguments);
      var child = key !== void 0 && cache.get(key);

      if (child) {
        child.setDirty();
      }
    };

    return optimistic;
  }

  var haveWarned = false;

  function shouldWarn() {
    var answer = !haveWarned;

    if (!isTest()) {
      haveWarned = true;
    }

    return answer;
  }

  var HeuristicFragmentMatcher = function () {
    function HeuristicFragmentMatcher() {}

    HeuristicFragmentMatcher.prototype.ensureReady = function () {
      return Promise.resolve();
    };

    HeuristicFragmentMatcher.prototype.canBypassInit = function () {
      return true;
    };

    HeuristicFragmentMatcher.prototype.match = function (idValue, typeCondition, context) {
      var obj = context.store.get(idValue.id);
      var isRootQuery = idValue.id === 'ROOT_QUERY';

      if (!obj) {
        return isRootQuery;
      }

      var _a = obj.__typename,
          __typename = _a === void 0 ? isRootQuery && 'Query' : _a;

      if (!__typename) {
        if (shouldWarn()) {
           invariant$2.warn("You're using fragments in your queries, but either don't have the addTypename:\n  true option set in Apollo Client, or you are trying to write a fragment to the store without the __typename.\n   Please turn on the addTypename option and include __typename when writing fragments so that Apollo Client\n   can accurately match fragments.");
           invariant$2.warn('Could not find __typename on Fragment ', typeCondition, obj);
           invariant$2.warn("DEPRECATION WARNING: using fragments without __typename is unsupported behavior " + "and will be removed in future versions of Apollo client. You should fix this and set addTypename to true now.");
        }

        return 'heuristic';
      }

      if (__typename === typeCondition) {
        return true;
      }

      if (shouldWarn()) {
         invariant$2.error('You are using the simple (heuristic) fragment matcher, but your ' + 'queries contain union or interface types. Apollo Client will not be ' + 'able to accurately map fragments. To make this error go away, use ' + 'the `IntrospectionFragmentMatcher` as described in the docs: ' + 'https://www.apollographql.com/docs/react/advanced/fragments.html#fragment-matcher');
      }

      return 'heuristic';
    };

    return HeuristicFragmentMatcher;
  }();

  var hasOwn = Object.prototype.hasOwnProperty;

  var DepTrackingCache = function () {
    function DepTrackingCache(data) {
      var _this = this;

      if (data === void 0) {
        data = Object.create(null);
      }

      this.data = data;
      this.depend = wrap(function (dataId) {
        return _this.data[dataId];
      }, {
        disposable: true,
        makeCacheKey: function (dataId) {
          return dataId;
        }
      });
    }

    DepTrackingCache.prototype.toObject = function () {
      return this.data;
    };

    DepTrackingCache.prototype.get = function (dataId) {
      this.depend(dataId);
      return this.data[dataId];
    };

    DepTrackingCache.prototype.set = function (dataId, value) {
      var oldValue = this.data[dataId];

      if (value !== oldValue) {
        this.data[dataId] = value;
        this.depend.dirty(dataId);
      }
    };

    DepTrackingCache.prototype.delete = function (dataId) {
      if (hasOwn.call(this.data, dataId)) {
        delete this.data[dataId];
        this.depend.dirty(dataId);
      }
    };

    DepTrackingCache.prototype.clear = function () {
      this.replace(null);
    };

    DepTrackingCache.prototype.replace = function (newData) {
      var _this = this;

      if (newData) {
        Object.keys(newData).forEach(function (dataId) {
          _this.set(dataId, newData[dataId]);
        });
        Object.keys(this.data).forEach(function (dataId) {
          if (!hasOwn.call(newData, dataId)) {
            _this.delete(dataId);
          }
        });
      } else {
        Object.keys(this.data).forEach(function (dataId) {
          _this.delete(dataId);
        });
      }
    };

    return DepTrackingCache;
  }();

  function defaultNormalizedCacheFactory(seed) {
    return new DepTrackingCache(seed);
  }

  var StoreReader = function () {
    function StoreReader(_a) {
      var _this = this;

      var _b = _a === void 0 ? {} : _a,
          _c = _b.cacheKeyRoot,
          cacheKeyRoot = _c === void 0 ? new KeyTrie(canUseWeakMap) : _c,
          _d = _b.freezeResults,
          freezeResults = _d === void 0 ? false : _d;

      var _e = this,
          executeStoreQuery = _e.executeStoreQuery,
          executeSelectionSet = _e.executeSelectionSet,
          executeSubSelectedArray = _e.executeSubSelectedArray;

      this.freezeResults = freezeResults;
      this.executeStoreQuery = wrap(function (options) {
        return executeStoreQuery.call(_this, options);
      }, {
        makeCacheKey: function (_a) {
          var query = _a.query,
              rootValue = _a.rootValue,
              contextValue = _a.contextValue,
              variableValues = _a.variableValues,
              fragmentMatcher = _a.fragmentMatcher;

          if (contextValue.store instanceof DepTrackingCache) {
            return cacheKeyRoot.lookup(contextValue.store, query, fragmentMatcher, JSON.stringify(variableValues), rootValue.id);
          }
        }
      });
      this.executeSelectionSet = wrap(function (options) {
        return executeSelectionSet.call(_this, options);
      }, {
        makeCacheKey: function (_a) {
          var selectionSet = _a.selectionSet,
              rootValue = _a.rootValue,
              execContext = _a.execContext;

          if (execContext.contextValue.store instanceof DepTrackingCache) {
            return cacheKeyRoot.lookup(execContext.contextValue.store, selectionSet, execContext.fragmentMatcher, JSON.stringify(execContext.variableValues), rootValue.id);
          }
        }
      });
      this.executeSubSelectedArray = wrap(function (options) {
        return executeSubSelectedArray.call(_this, options);
      }, {
        makeCacheKey: function (_a) {
          var field = _a.field,
              array = _a.array,
              execContext = _a.execContext;

          if (execContext.contextValue.store instanceof DepTrackingCache) {
            return cacheKeyRoot.lookup(execContext.contextValue.store, field, array, JSON.stringify(execContext.variableValues));
          }
        }
      });
    }

    StoreReader.prototype.readQueryFromStore = function (options) {
      return this.diffQueryAgainstStore(__assign(__assign({}, options), {
        returnPartialData: false
      })).result;
    };

    StoreReader.prototype.diffQueryAgainstStore = function (_a) {
      var store = _a.store,
          query = _a.query,
          variables = _a.variables,
          previousResult = _a.previousResult,
          _b = _a.returnPartialData,
          returnPartialData = _b === void 0 ? true : _b,
          _c = _a.rootId,
          rootId = _c === void 0 ? 'ROOT_QUERY' : _c,
          fragmentMatcherFunction = _a.fragmentMatcherFunction,
          config = _a.config;
      var queryDefinition = getQueryDefinition(query);
      variables = assign$2({}, getDefaultValues(queryDefinition), variables);
      var context = {
        store: store,
        dataIdFromObject: config && config.dataIdFromObject,
        cacheRedirects: config && config.cacheRedirects || {}
      };
      var execResult = this.executeStoreQuery({
        query: query,
        rootValue: {
          type: 'id',
          id: rootId,
          generated: true,
          typename: 'Query'
        },
        contextValue: context,
        variableValues: variables,
        fragmentMatcher: fragmentMatcherFunction
      });
      var hasMissingFields = execResult.missing && execResult.missing.length > 0;

      if (hasMissingFields && !returnPartialData) {
        execResult.missing.forEach(function (info) {
          if (info.tolerable) return;
          throw  new InvariantError("Can't find field " + info.fieldName + " on object " + JSON.stringify(info.object, null, 2) + ".");
        });
      }

      if (previousResult) {
        if (equal(previousResult, execResult.result)) {
          execResult.result = previousResult;
        }
      }

      return {
        result: execResult.result,
        complete: !hasMissingFields
      };
    };

    StoreReader.prototype.executeStoreQuery = function (_a) {
      var query = _a.query,
          rootValue = _a.rootValue,
          contextValue = _a.contextValue,
          variableValues = _a.variableValues,
          _b = _a.fragmentMatcher,
          fragmentMatcher = _b === void 0 ? defaultFragmentMatcher : _b;
      var mainDefinition = getMainDefinition(query);
      var fragments = getFragmentDefinitions(query);
      var fragmentMap = createFragmentMap(fragments);
      var execContext = {
        query: query,
        fragmentMap: fragmentMap,
        contextValue: contextValue,
        variableValues: variableValues,
        fragmentMatcher: fragmentMatcher
      };
      return this.executeSelectionSet({
        selectionSet: mainDefinition.selectionSet,
        rootValue: rootValue,
        execContext: execContext
      });
    };

    StoreReader.prototype.executeSelectionSet = function (_a) {
      var _this = this;

      var selectionSet = _a.selectionSet,
          rootValue = _a.rootValue,
          execContext = _a.execContext;
      var fragmentMap = execContext.fragmentMap,
          contextValue = execContext.contextValue,
          variables = execContext.variableValues;
      var finalResult = {
        result: null
      };
      var objectsToMerge = [];
      var object = contextValue.store.get(rootValue.id);
      var typename = object && object.__typename || rootValue.id === 'ROOT_QUERY' && 'Query' || void 0;

      function handleMissing(result) {
        var _a;

        if (result.missing) {
          finalResult.missing = finalResult.missing || [];

          (_a = finalResult.missing).push.apply(_a, result.missing);
        }

        return result.result;
      }

      selectionSet.selections.forEach(function (selection) {
        var _a;

        if (!shouldInclude(selection, variables)) {
          return;
        }

        if (isField(selection)) {
          var fieldResult = handleMissing(_this.executeField(object, typename, selection, execContext));

          if (typeof fieldResult !== 'undefined') {
            objectsToMerge.push((_a = {}, _a[resultKeyNameFromField(selection)] = fieldResult, _a));
          }
        } else {
          var fragment = void 0;

          if (isInlineFragment(selection)) {
            fragment = selection;
          } else {
            fragment = fragmentMap[selection.name.value];

            if (!fragment) {
              throw  new InvariantError("No fragment named " + selection.name.value);
            }
          }

          var typeCondition = fragment.typeCondition && fragment.typeCondition.name.value;
          var match = !typeCondition || execContext.fragmentMatcher(rootValue, typeCondition, contextValue);

          if (match) {
            var fragmentExecResult = _this.executeSelectionSet({
              selectionSet: fragment.selectionSet,
              rootValue: rootValue,
              execContext: execContext
            });

            if (match === 'heuristic' && fragmentExecResult.missing) {
              fragmentExecResult = __assign(__assign({}, fragmentExecResult), {
                missing: fragmentExecResult.missing.map(function (info) {
                  return __assign(__assign({}, info), {
                    tolerable: true
                  });
                })
              });
            }

            objectsToMerge.push(handleMissing(fragmentExecResult));
          }
        }
      });
      finalResult.result = mergeDeepArray(objectsToMerge);

      if (this.freezeResults && "development" !== 'production') {
        Object.freeze(finalResult.result);
      }

      return finalResult;
    };

    StoreReader.prototype.executeField = function (object, typename, field, execContext) {
      var variables = execContext.variableValues,
          contextValue = execContext.contextValue;
      var fieldName = field.name.value;
      var args = argumentsObjectFromField(field, variables);
      var info = {
        resultKey: resultKeyNameFromField(field),
        directives: getDirectiveInfoFromField(field, variables)
      };
      var readStoreResult = readStoreResolver(object, typename, fieldName, args, contextValue, info);

      if (Array.isArray(readStoreResult.result)) {
        return this.combineExecResults(readStoreResult, this.executeSubSelectedArray({
          field: field,
          array: readStoreResult.result,
          execContext: execContext
        }));
      }

      if (!field.selectionSet) {
        assertSelectionSetForIdValue(field, readStoreResult.result);

        if (this.freezeResults && "development" !== 'production') {
          maybeDeepFreeze(readStoreResult);
        }

        return readStoreResult;
      }

      if (readStoreResult.result == null) {
        return readStoreResult;
      }

      return this.combineExecResults(readStoreResult, this.executeSelectionSet({
        selectionSet: field.selectionSet,
        rootValue: readStoreResult.result,
        execContext: execContext
      }));
    };

    StoreReader.prototype.combineExecResults = function () {
      var execResults = [];

      for (var _i = 0; _i < arguments.length; _i++) {
        execResults[_i] = arguments[_i];
      }

      var missing;
      execResults.forEach(function (execResult) {
        if (execResult.missing) {
          missing = missing || [];
          missing.push.apply(missing, execResult.missing);
        }
      });
      return {
        result: execResults.pop().result,
        missing: missing
      };
    };

    StoreReader.prototype.executeSubSelectedArray = function (_a) {
      var _this = this;

      var field = _a.field,
          array = _a.array,
          execContext = _a.execContext;
      var missing;

      function handleMissing(childResult) {
        if (childResult.missing) {
          missing = missing || [];
          missing.push.apply(missing, childResult.missing);
        }

        return childResult.result;
      }

      array = array.map(function (item) {
        if (item === null) {
          return null;
        }

        if (Array.isArray(item)) {
          return handleMissing(_this.executeSubSelectedArray({
            field: field,
            array: item,
            execContext: execContext
          }));
        }

        if (field.selectionSet) {
          return handleMissing(_this.executeSelectionSet({
            selectionSet: field.selectionSet,
            rootValue: item,
            execContext: execContext
          }));
        }

        assertSelectionSetForIdValue(field, item);
        return item;
      });

      if (this.freezeResults && "development" !== 'production') {
        Object.freeze(array);
      }

      return {
        result: array,
        missing: missing
      };
    };

    return StoreReader;
  }();

  function assertSelectionSetForIdValue(field, value) {
    if (!field.selectionSet && isIdValue(value)) {
      throw  new InvariantError("Missing selection set for object of type " + value.typename + " returned for query field " + field.name.value);
    }
  }

  function defaultFragmentMatcher() {
    return true;
  }

  function readStoreResolver(object, typename, fieldName, args, context, _a) {
    var resultKey = _a.resultKey,
        directives = _a.directives;
    var storeKeyName = fieldName;

    if (args || directives) {
      storeKeyName = getStoreKeyName(storeKeyName, args, directives);
    }

    var fieldValue = void 0;

    if (object) {
      fieldValue = object[storeKeyName];

      if (typeof fieldValue === 'undefined' && context.cacheRedirects && typeof typename === 'string') {
        var type = context.cacheRedirects[typename];

        if (type) {
          var resolver = type[fieldName];

          if (resolver) {
            fieldValue = resolver(object, args, {
              getCacheKey: function (storeObj) {
                var id = context.dataIdFromObject(storeObj);
                return id && toIdValue({
                  id: id,
                  typename: storeObj.__typename
                });
              }
            });
          }
        }
      }
    }

    if (typeof fieldValue === 'undefined') {
      return {
        result: fieldValue,
        missing: [{
          object: object,
          fieldName: storeKeyName,
          tolerable: false
        }]
      };
    }

    if (isJsonValue(fieldValue)) {
      fieldValue = fieldValue.json;
    }

    return {
      result: fieldValue
    };
  }

  var ObjectCache = function () {
    function ObjectCache(data) {
      if (data === void 0) {
        data = Object.create(null);
      }

      this.data = data;
    }

    ObjectCache.prototype.toObject = function () {
      return this.data;
    };

    ObjectCache.prototype.get = function (dataId) {
      return this.data[dataId];
    };

    ObjectCache.prototype.set = function (dataId, value) {
      this.data[dataId] = value;
    };

    ObjectCache.prototype.delete = function (dataId) {
      this.data[dataId] = void 0;
    };

    ObjectCache.prototype.clear = function () {
      this.data = Object.create(null);
    };

    ObjectCache.prototype.replace = function (newData) {
      this.data = newData || Object.create(null);
    };

    return ObjectCache;
  }();

  var WriteError = function (_super) {
    __extends(WriteError, _super);

    function WriteError() {
      var _this = _super !== null && _super.apply(this, arguments) || this;

      _this.type = 'WriteError';
      return _this;
    }

    return WriteError;
  }(Error);

  function enhanceErrorWithDocument(error, document) {
    var enhancedError = new WriteError("Error writing result to store for query:\n " + JSON.stringify(document));
    enhancedError.message += '\n' + error.message;
    enhancedError.stack = error.stack;
    return enhancedError;
  }

  var StoreWriter = function () {
    function StoreWriter() {}

    StoreWriter.prototype.writeQueryToStore = function (_a) {
      var query = _a.query,
          result = _a.result,
          _b = _a.store,
          store = _b === void 0 ? defaultNormalizedCacheFactory() : _b,
          variables = _a.variables,
          dataIdFromObject = _a.dataIdFromObject,
          fragmentMatcherFunction = _a.fragmentMatcherFunction;
      return this.writeResultToStore({
        dataId: 'ROOT_QUERY',
        result: result,
        document: query,
        store: store,
        variables: variables,
        dataIdFromObject: dataIdFromObject,
        fragmentMatcherFunction: fragmentMatcherFunction
      });
    };

    StoreWriter.prototype.writeResultToStore = function (_a) {
      var dataId = _a.dataId,
          result = _a.result,
          document = _a.document,
          _b = _a.store,
          store = _b === void 0 ? defaultNormalizedCacheFactory() : _b,
          variables = _a.variables,
          dataIdFromObject = _a.dataIdFromObject,
          fragmentMatcherFunction = _a.fragmentMatcherFunction;
      var operationDefinition = getOperationDefinition(document);

      try {
        return this.writeSelectionSetToStore({
          result: result,
          dataId: dataId,
          selectionSet: operationDefinition.selectionSet,
          context: {
            store: store,
            processedData: {},
            variables: assign$2({}, getDefaultValues(operationDefinition), variables),
            dataIdFromObject: dataIdFromObject,
            fragmentMap: createFragmentMap(getFragmentDefinitions(document)),
            fragmentMatcherFunction: fragmentMatcherFunction
          }
        });
      } catch (e) {
        throw enhanceErrorWithDocument(e, document);
      }
    };

    StoreWriter.prototype.writeSelectionSetToStore = function (_a) {
      var _this = this;

      var result = _a.result,
          dataId = _a.dataId,
          selectionSet = _a.selectionSet,
          context = _a.context;
      var variables = context.variables,
          store = context.store,
          fragmentMap = context.fragmentMap;
      selectionSet.selections.forEach(function (selection) {
        var _a;

        if (!shouldInclude(selection, variables)) {
          return;
        }

        if (isField(selection)) {
          var resultFieldKey = resultKeyNameFromField(selection);
          var value = result[resultFieldKey];

          if (typeof value !== 'undefined') {
            _this.writeFieldToStore({
              dataId: dataId,
              value: value,
              field: selection,
              context: context
            });
          } else {
            var isDefered = false;
            var isClient = false;

            if (selection.directives && selection.directives.length) {
              isDefered = selection.directives.some(function (directive) {
                return directive.name && directive.name.value === 'defer';
              });
              isClient = selection.directives.some(function (directive) {
                return directive.name && directive.name.value === 'client';
              });
            }

            if (!isDefered && !isClient && context.fragmentMatcherFunction) {
               invariant$2.warn("Missing field " + resultFieldKey + " in " + JSON.stringify(result, null, 2).substring(0, 100));
            }
          }
        } else {
          var fragment = void 0;

          if (isInlineFragment(selection)) {
            fragment = selection;
          } else {
            fragment = (fragmentMap || {})[selection.name.value];
             invariant$2(fragment, "No fragment named " + selection.name.value + ".");
          }

          var matches = true;

          if (context.fragmentMatcherFunction && fragment.typeCondition) {
            var id = dataId || 'self';
            var idValue = toIdValue({
              id: id,
              typename: undefined
            });
            var fakeContext = {
              store: new ObjectCache((_a = {}, _a[id] = result, _a)),
              cacheRedirects: {}
            };
            var match = context.fragmentMatcherFunction(idValue, fragment.typeCondition.name.value, fakeContext);

            if (!isProduction() && match === 'heuristic') {
               invariant$2.error('WARNING: heuristic fragment matching going on!');
            }

            matches = !!match;
          }

          if (matches) {
            _this.writeSelectionSetToStore({
              result: result,
              selectionSet: fragment.selectionSet,
              dataId: dataId,
              context: context
            });
          }
        }
      });
      return store;
    };

    StoreWriter.prototype.writeFieldToStore = function (_a) {
      var _b;

      var field = _a.field,
          value = _a.value,
          dataId = _a.dataId,
          context = _a.context;
      var variables = context.variables,
          dataIdFromObject = context.dataIdFromObject,
          store = context.store;
      var storeValue;
      var storeObject;
      var storeFieldName = storeKeyNameFromField(field, variables);

      if (!field.selectionSet || value === null) {
        storeValue = value != null && typeof value === 'object' ? {
          type: 'json',
          json: value
        } : value;
      } else if (Array.isArray(value)) {
        var generatedId = dataId + "." + storeFieldName;
        storeValue = this.processArrayValue(value, generatedId, field.selectionSet, context);
      } else {
        var valueDataId = dataId + "." + storeFieldName;
        var generated = true;

        if (!isGeneratedId(valueDataId)) {
          valueDataId = '$' + valueDataId;
        }

        if (dataIdFromObject) {
          var semanticId = dataIdFromObject(value);
           invariant$2(!semanticId || !isGeneratedId(semanticId), 'IDs returned by dataIdFromObject cannot begin with the "$" character.');

          if (semanticId || typeof semanticId === 'number' && semanticId === 0) {
            valueDataId = semanticId;
            generated = false;
          }
        }

        if (!isDataProcessed(valueDataId, field, context.processedData)) {
          this.writeSelectionSetToStore({
            dataId: valueDataId,
            result: value,
            selectionSet: field.selectionSet,
            context: context
          });
        }

        var typename = value.__typename;
        storeValue = toIdValue({
          id: valueDataId,
          typename: typename
        }, generated);
        storeObject = store.get(dataId);
        var escapedId = storeObject && storeObject[storeFieldName];

        if (escapedId !== storeValue && isIdValue(escapedId)) {
          var hadTypename = escapedId.typename !== undefined;
          var hasTypename = typename !== undefined;
          var typenameChanged = hadTypename && hasTypename && escapedId.typename !== typename;
           invariant$2(!generated || escapedId.generated || typenameChanged, "Store error: the application attempted to write an object with no provided id but the store already contains an id of " + escapedId.id + " for this object. The selectionSet that was trying to be written is:\n" + JSON.stringify(field));
           invariant$2(!hadTypename || hasTypename, "Store error: the application attempted to write an object with no provided typename but the store already contains an object with typename of " + escapedId.typename + " for the object of id " + escapedId.id + ". The selectionSet that was trying to be written is:\n" + JSON.stringify(field));

          if (escapedId.generated) {
            if (typenameChanged) {
              if (!generated) {
                store.delete(escapedId.id);
              }
            } else {
              mergeWithGenerated(escapedId.id, storeValue.id, store);
            }
          }
        }
      }

      storeObject = store.get(dataId);

      if (!storeObject || !equal(storeValue, storeObject[storeFieldName])) {
        store.set(dataId, __assign(__assign({}, storeObject), (_b = {}, _b[storeFieldName] = storeValue, _b)));
      }
    };

    StoreWriter.prototype.processArrayValue = function (value, generatedId, selectionSet, context) {
      var _this = this;

      return value.map(function (item, index) {
        if (item === null) {
          return null;
        }

        var itemDataId = generatedId + "." + index;

        if (Array.isArray(item)) {
          return _this.processArrayValue(item, itemDataId, selectionSet, context);
        }

        var generated = true;

        if (context.dataIdFromObject) {
          var semanticId = context.dataIdFromObject(item);

          if (semanticId) {
            itemDataId = semanticId;
            generated = false;
          }
        }

        if (!isDataProcessed(itemDataId, selectionSet, context.processedData)) {
          _this.writeSelectionSetToStore({
            dataId: itemDataId,
            result: item,
            selectionSet: selectionSet,
            context: context
          });
        }

        return toIdValue({
          id: itemDataId,
          typename: item.__typename
        }, generated);
      });
    };

    return StoreWriter;
  }();

  function isGeneratedId(id) {
    return id[0] === '$';
  }

  function mergeWithGenerated(generatedKey, realKey, cache) {
    if (generatedKey === realKey) {
      return false;
    }

    var generated = cache.get(generatedKey);
    var real = cache.get(realKey);
    var madeChanges = false;
    Object.keys(generated).forEach(function (key) {
      var value = generated[key];
      var realValue = real[key];

      if (isIdValue(value) && isGeneratedId(value.id) && isIdValue(realValue) && !equal(value, realValue) && mergeWithGenerated(value.id, realValue.id, cache)) {
        madeChanges = true;
      }
    });
    cache.delete(generatedKey);

    var newRealValue = __assign(__assign({}, generated), real);

    if (equal(newRealValue, real)) {
      return madeChanges;
    }

    cache.set(realKey, newRealValue);
    return true;
  }

  function isDataProcessed(dataId, field, processedData) {
    if (!processedData) {
      return false;
    }

    if (processedData[dataId]) {
      if (processedData[dataId].indexOf(field) >= 0) {
        return true;
      } else {
        processedData[dataId].push(field);
      }
    } else {
      processedData[dataId] = [field];
    }

    return false;
  }

  var defaultConfig = {
    fragmentMatcher: new HeuristicFragmentMatcher(),
    dataIdFromObject: defaultDataIdFromObject,
    addTypename: true,
    resultCaching: true,
    freezeResults: false
  };

  function defaultDataIdFromObject(result) {
    if (result.__typename) {
      if (result.id !== undefined) {
        return result.__typename + ":" + result.id;
      }

      if (result._id !== undefined) {
        return result.__typename + ":" + result._id;
      }
    }

    return null;
  }

  var hasOwn$1 = Object.prototype.hasOwnProperty;

  var OptimisticCacheLayer = function (_super) {
    __extends(OptimisticCacheLayer, _super);

    function OptimisticCacheLayer(optimisticId, parent, transaction) {
      var _this = _super.call(this, Object.create(null)) || this;

      _this.optimisticId = optimisticId;
      _this.parent = parent;
      _this.transaction = transaction;
      return _this;
    }

    OptimisticCacheLayer.prototype.toObject = function () {
      return __assign(__assign({}, this.parent.toObject()), this.data);
    };

    OptimisticCacheLayer.prototype.get = function (dataId) {
      return hasOwn$1.call(this.data, dataId) ? this.data[dataId] : this.parent.get(dataId);
    };

    return OptimisticCacheLayer;
  }(ObjectCache);

  var InMemoryCache = function (_super) {
    __extends(InMemoryCache, _super);

    function InMemoryCache(config) {
      if (config === void 0) {
        config = {};
      }

      var _this = _super.call(this) || this;

      _this.watches = new Set();
      _this.typenameDocumentCache = new Map();
      _this.cacheKeyRoot = new KeyTrie(canUseWeakMap);
      _this.silenceBroadcast = false;
      _this.config = __assign(__assign({}, defaultConfig), config);

      if (_this.config.customResolvers) {
         invariant$2.warn('customResolvers have been renamed to cacheRedirects. Please update your config as we will be deprecating customResolvers in the next major version.');
        _this.config.cacheRedirects = _this.config.customResolvers;
      }

      if (_this.config.cacheResolvers) {
         invariant$2.warn('cacheResolvers have been renamed to cacheRedirects. Please update your config as we will be deprecating cacheResolvers in the next major version.');
        _this.config.cacheRedirects = _this.config.cacheResolvers;
      }

      _this.addTypename = !!_this.config.addTypename;
      _this.data = _this.config.resultCaching ? new DepTrackingCache() : new ObjectCache();
      _this.optimisticData = _this.data;
      _this.storeWriter = new StoreWriter();
      _this.storeReader = new StoreReader({
        cacheKeyRoot: _this.cacheKeyRoot,
        freezeResults: config.freezeResults
      });
      var cache = _this;
      var maybeBroadcastWatch = cache.maybeBroadcastWatch;
      _this.maybeBroadcastWatch = wrap(function (c) {
        return maybeBroadcastWatch.call(_this, c);
      }, {
        makeCacheKey: function (c) {
          if (c.optimistic) {
            return;
          }

          if (c.previousResult) {
            return;
          }

          if (cache.data instanceof DepTrackingCache) {
            return cache.cacheKeyRoot.lookup(c.query, JSON.stringify(c.variables));
          }
        }
      });
      return _this;
    }

    InMemoryCache.prototype.restore = function (data) {
      if (data) this.data.replace(data);
      return this;
    };

    InMemoryCache.prototype.extract = function (optimistic) {
      if (optimistic === void 0) {
        optimistic = false;
      }

      return (optimistic ? this.optimisticData : this.data).toObject();
    };

    InMemoryCache.prototype.read = function (options) {
      if (typeof options.rootId === 'string' && typeof this.data.get(options.rootId) === 'undefined') {
        return null;
      }

      var fragmentMatcher = this.config.fragmentMatcher;
      var fragmentMatcherFunction = fragmentMatcher && fragmentMatcher.match;
      return this.storeReader.readQueryFromStore({
        store: options.optimistic ? this.optimisticData : this.data,
        query: this.transformDocument(options.query),
        variables: options.variables,
        rootId: options.rootId,
        fragmentMatcherFunction: fragmentMatcherFunction,
        previousResult: options.previousResult,
        config: this.config
      }) || null;
    };

    InMemoryCache.prototype.write = function (write) {
      var fragmentMatcher = this.config.fragmentMatcher;
      var fragmentMatcherFunction = fragmentMatcher && fragmentMatcher.match;
      this.storeWriter.writeResultToStore({
        dataId: write.dataId,
        result: write.result,
        variables: write.variables,
        document: this.transformDocument(write.query),
        store: this.data,
        dataIdFromObject: this.config.dataIdFromObject,
        fragmentMatcherFunction: fragmentMatcherFunction
      });
      this.broadcastWatches();
    };

    InMemoryCache.prototype.diff = function (query) {
      var fragmentMatcher = this.config.fragmentMatcher;
      var fragmentMatcherFunction = fragmentMatcher && fragmentMatcher.match;
      return this.storeReader.diffQueryAgainstStore({
        store: query.optimistic ? this.optimisticData : this.data,
        query: this.transformDocument(query.query),
        variables: query.variables,
        returnPartialData: query.returnPartialData,
        previousResult: query.previousResult,
        fragmentMatcherFunction: fragmentMatcherFunction,
        config: this.config
      });
    };

    InMemoryCache.prototype.watch = function (watch) {
      var _this = this;

      this.watches.add(watch);
      return function () {
        _this.watches.delete(watch);
      };
    };

    InMemoryCache.prototype.evict = function (query) {
      throw  new InvariantError("eviction is not implemented on InMemory Cache");
    };

    InMemoryCache.prototype.reset = function () {
      this.data.clear();
      this.broadcastWatches();
      return Promise.resolve();
    };

    InMemoryCache.prototype.removeOptimistic = function (idToRemove) {
      var toReapply = [];
      var removedCount = 0;
      var layer = this.optimisticData;

      while (layer instanceof OptimisticCacheLayer) {
        if (layer.optimisticId === idToRemove) {
          ++removedCount;
        } else {
          toReapply.push(layer);
        }

        layer = layer.parent;
      }

      if (removedCount > 0) {
        this.optimisticData = layer;

        while (toReapply.length > 0) {
          var layer_1 = toReapply.pop();
          this.performTransaction(layer_1.transaction, layer_1.optimisticId);
        }

        this.broadcastWatches();
      }
    };

    InMemoryCache.prototype.performTransaction = function (transaction, optimisticId) {
      var _a = this,
          data = _a.data,
          silenceBroadcast = _a.silenceBroadcast;

      this.silenceBroadcast = true;

      if (typeof optimisticId === 'string') {
        this.data = this.optimisticData = new OptimisticCacheLayer(optimisticId, this.optimisticData, transaction);
      }

      try {
        transaction(this);
      } finally {
        this.silenceBroadcast = silenceBroadcast;
        this.data = data;
      }

      this.broadcastWatches();
    };

    InMemoryCache.prototype.recordOptimisticTransaction = function (transaction, id) {
      return this.performTransaction(transaction, id);
    };

    InMemoryCache.prototype.transformDocument = function (document) {
      if (this.addTypename) {
        var result = this.typenameDocumentCache.get(document);

        if (!result) {
          result = addTypenameToDocument(document);
          this.typenameDocumentCache.set(document, result);
          this.typenameDocumentCache.set(result, result);
        }

        return result;
      }

      return document;
    };

    InMemoryCache.prototype.broadcastWatches = function () {
      var _this = this;

      if (!this.silenceBroadcast) {
        this.watches.forEach(function (c) {
          return _this.maybeBroadcastWatch(c);
        });
      }
    };

    InMemoryCache.prototype.maybeBroadcastWatch = function (c) {
      c.callback(this.diff({
        query: c.query,
        variables: c.variables,
        previousResult: c.previousResult && c.previousResult(),
        optimistic: c.optimistic
      }));
    };

    return InMemoryCache;
  }(ApolloCache);

  /**
   * Produces the value of a block string from its parsed raw value, similar to
   * CoffeeScript's block string, Python's docstring trim or Ruby's strip_heredoc.
   *
   * This implements the GraphQL spec's BlockStringValue() static algorithm.
   *
   * @internal
   */
  function dedentBlockStringValue(rawString) {
    // Expand a block string's raw value into independent lines.
    var lines = rawString.split(/\r\n|[\n\r]/g); // Remove common indentation from all lines but first.

    var commonIndent = getBlockStringIndentation(lines);

    if (commonIndent !== 0) {
      for (var i = 1; i < lines.length; i++) {
        lines[i] = lines[i].slice(commonIndent);
      }
    } // Remove leading and trailing blank lines.


    while (lines.length > 0 && isBlank(lines[0])) {
      lines.shift();
    }

    while (lines.length > 0 && isBlank(lines[lines.length - 1])) {
      lines.pop();
    } // Return a string of the lines joined with U+000A.


    return lines.join('\n');
  }
  /**
   * @internal
   */

  function getBlockStringIndentation(lines) {
    var commonIndent = null;

    for (var i = 1; i < lines.length; i++) {
      var line = lines[i];
      var indent = leadingWhitespace(line);

      if (indent === line.length) {
        continue; // skip empty lines
      }

      if (commonIndent === null || indent < commonIndent) {
        commonIndent = indent;

        if (commonIndent === 0) {
          break;
        }
      }
    }

    return commonIndent === null ? 0 : commonIndent;
  }

  function leadingWhitespace(str) {
    var i = 0;

    while (i < str.length && (str[i] === ' ' || str[i] === '\t')) {
      i++;
    }

    return i;
  }

  function isBlank(str) {
    return leadingWhitespace(str) === str.length;
  }
  /**
   * Print a block string in the indented block form by adding a leading and
   * trailing blank line. However, if a block string starts with whitespace and is
   * a single-line, adding a leading blank line would strip that whitespace.
   *
   * @internal
   */


  function printBlockString(value) {
    var indentation = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    var preferMultipleLines = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    var isSingleLine = value.indexOf('\n') === -1;
    var hasLeadingSpace = value[0] === ' ' || value[0] === '\t';
    var hasTrailingQuote = value[value.length - 1] === '"';
    var hasTrailingSlash = value[value.length - 1] === '\\';
    var printAsMultipleLines = !isSingleLine || hasTrailingQuote || hasTrailingSlash || preferMultipleLines;
    var result = ''; // Format a multi-line block quote to account for leading space.

    if (printAsMultipleLines && !(isSingleLine && hasLeadingSpace)) {
      result += '\n' + indentation;
    }

    result += indentation ? value.replace(/\n/g, '\n' + indentation) : value;

    if (printAsMultipleLines) {
      result += '\n';
    }

    return '"""' + result.replace(/"""/g, '\\"""') + '"""';
  }

  /**
   * Converts an AST into a string, using one set of reasonable
   * formatting rules.
   */

  function print(ast) {
    return visit(ast, {
      leave: printDocASTReducer
    });
  } // TODO: provide better type coverage in future

  var printDocASTReducer = {
    Name: function Name(node) {
      return node.value;
    },
    Variable: function Variable(node) {
      return '$' + node.name;
    },
    // Document
    Document: function Document(node) {
      return join(node.definitions, '\n\n') + '\n';
    },
    OperationDefinition: function OperationDefinition(node) {
      var op = node.operation;
      var name = node.name;
      var varDefs = wrap$1('(', join(node.variableDefinitions, ', '), ')');
      var directives = join(node.directives, ' ');
      var selectionSet = node.selectionSet; // Anonymous queries with no directives or variable definitions can use
      // the query short form.

      return !name && !directives && !varDefs && op === 'query' ? selectionSet : join([op, join([name, varDefs]), directives, selectionSet], ' ');
    },
    VariableDefinition: function VariableDefinition(_ref) {
      var variable = _ref.variable,
          type = _ref.type,
          defaultValue = _ref.defaultValue,
          directives = _ref.directives;
      return variable + ': ' + type + wrap$1(' = ', defaultValue) + wrap$1(' ', join(directives, ' '));
    },
    SelectionSet: function SelectionSet(_ref2) {
      var selections = _ref2.selections;
      return block(selections);
    },
    Field: function Field(_ref3) {
      var alias = _ref3.alias,
          name = _ref3.name,
          args = _ref3.arguments,
          directives = _ref3.directives,
          selectionSet = _ref3.selectionSet;
      return join([wrap$1('', alias, ': ') + name + wrap$1('(', join(args, ', '), ')'), join(directives, ' '), selectionSet], ' ');
    },
    Argument: function Argument(_ref4) {
      var name = _ref4.name,
          value = _ref4.value;
      return name + ': ' + value;
    },
    // Fragments
    FragmentSpread: function FragmentSpread(_ref5) {
      var name = _ref5.name,
          directives = _ref5.directives;
      return '...' + name + wrap$1(' ', join(directives, ' '));
    },
    InlineFragment: function InlineFragment(_ref6) {
      var typeCondition = _ref6.typeCondition,
          directives = _ref6.directives,
          selectionSet = _ref6.selectionSet;
      return join(['...', wrap$1('on ', typeCondition), join(directives, ' '), selectionSet], ' ');
    },
    FragmentDefinition: function FragmentDefinition(_ref7) {
      var name = _ref7.name,
          typeCondition = _ref7.typeCondition,
          variableDefinitions = _ref7.variableDefinitions,
          directives = _ref7.directives,
          selectionSet = _ref7.selectionSet;
      return (// Note: fragment variable definitions are experimental and may be changed
        // or removed in the future.
        "fragment ".concat(name).concat(wrap$1('(', join(variableDefinitions, ', '), ')'), " ") + "on ".concat(typeCondition, " ").concat(wrap$1('', join(directives, ' '), ' ')) + selectionSet
      );
    },
    // Value
    IntValue: function IntValue(_ref8) {
      var value = _ref8.value;
      return value;
    },
    FloatValue: function FloatValue(_ref9) {
      var value = _ref9.value;
      return value;
    },
    StringValue: function StringValue(_ref10, key) {
      var value = _ref10.value,
          isBlockString = _ref10.block;
      return isBlockString ? printBlockString(value, key === 'description' ? '' : '  ') : JSON.stringify(value);
    },
    BooleanValue: function BooleanValue(_ref11) {
      var value = _ref11.value;
      return value ? 'true' : 'false';
    },
    NullValue: function NullValue() {
      return 'null';
    },
    EnumValue: function EnumValue(_ref12) {
      var value = _ref12.value;
      return value;
    },
    ListValue: function ListValue(_ref13) {
      var values = _ref13.values;
      return '[' + join(values, ', ') + ']';
    },
    ObjectValue: function ObjectValue(_ref14) {
      var fields = _ref14.fields;
      return '{' + join(fields, ', ') + '}';
    },
    ObjectField: function ObjectField(_ref15) {
      var name = _ref15.name,
          value = _ref15.value;
      return name + ': ' + value;
    },
    // Directive
    Directive: function Directive(_ref16) {
      var name = _ref16.name,
          args = _ref16.arguments;
      return '@' + name + wrap$1('(', join(args, ', '), ')');
    },
    // Type
    NamedType: function NamedType(_ref17) {
      var name = _ref17.name;
      return name;
    },
    ListType: function ListType(_ref18) {
      var type = _ref18.type;
      return '[' + type + ']';
    },
    NonNullType: function NonNullType(_ref19) {
      var type = _ref19.type;
      return type + '!';
    },
    // Type System Definitions
    SchemaDefinition: addDescription(function (_ref20) {
      var directives = _ref20.directives,
          operationTypes = _ref20.operationTypes;
      return join(['schema', join(directives, ' '), block(operationTypes)], ' ');
    }),
    OperationTypeDefinition: function OperationTypeDefinition(_ref21) {
      var operation = _ref21.operation,
          type = _ref21.type;
      return operation + ': ' + type;
    },
    ScalarTypeDefinition: addDescription(function (_ref22) {
      var name = _ref22.name,
          directives = _ref22.directives;
      return join(['scalar', name, join(directives, ' ')], ' ');
    }),
    ObjectTypeDefinition: addDescription(function (_ref23) {
      var name = _ref23.name,
          interfaces = _ref23.interfaces,
          directives = _ref23.directives,
          fields = _ref23.fields;
      return join(['type', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    }),
    FieldDefinition: addDescription(function (_ref24) {
      var name = _ref24.name,
          args = _ref24.arguments,
          type = _ref24.type,
          directives = _ref24.directives;
      return name + (hasMultilineItems(args) ? wrap$1('(\n', indent(join(args, '\n')), '\n)') : wrap$1('(', join(args, ', '), ')')) + ': ' + type + wrap$1(' ', join(directives, ' '));
    }),
    InputValueDefinition: addDescription(function (_ref25) {
      var name = _ref25.name,
          type = _ref25.type,
          defaultValue = _ref25.defaultValue,
          directives = _ref25.directives;
      return join([name + ': ' + type, wrap$1('= ', defaultValue), join(directives, ' ')], ' ');
    }),
    InterfaceTypeDefinition: addDescription(function (_ref26) {
      var name = _ref26.name,
          interfaces = _ref26.interfaces,
          directives = _ref26.directives,
          fields = _ref26.fields;
      return join(['interface', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    }),
    UnionTypeDefinition: addDescription(function (_ref27) {
      var name = _ref27.name,
          directives = _ref27.directives,
          types = _ref27.types;
      return join(['union', name, join(directives, ' '), types && types.length !== 0 ? '= ' + join(types, ' | ') : ''], ' ');
    }),
    EnumTypeDefinition: addDescription(function (_ref28) {
      var name = _ref28.name,
          directives = _ref28.directives,
          values = _ref28.values;
      return join(['enum', name, join(directives, ' '), block(values)], ' ');
    }),
    EnumValueDefinition: addDescription(function (_ref29) {
      var name = _ref29.name,
          directives = _ref29.directives;
      return join([name, join(directives, ' ')], ' ');
    }),
    InputObjectTypeDefinition: addDescription(function (_ref30) {
      var name = _ref30.name,
          directives = _ref30.directives,
          fields = _ref30.fields;
      return join(['input', name, join(directives, ' '), block(fields)], ' ');
    }),
    DirectiveDefinition: addDescription(function (_ref31) {
      var name = _ref31.name,
          args = _ref31.arguments,
          repeatable = _ref31.repeatable,
          locations = _ref31.locations;
      return 'directive @' + name + (hasMultilineItems(args) ? wrap$1('(\n', indent(join(args, '\n')), '\n)') : wrap$1('(', join(args, ', '), ')')) + (repeatable ? ' repeatable' : '') + ' on ' + join(locations, ' | ');
    }),
    SchemaExtension: function SchemaExtension(_ref32) {
      var directives = _ref32.directives,
          operationTypes = _ref32.operationTypes;
      return join(['extend schema', join(directives, ' '), block(operationTypes)], ' ');
    },
    ScalarTypeExtension: function ScalarTypeExtension(_ref33) {
      var name = _ref33.name,
          directives = _ref33.directives;
      return join(['extend scalar', name, join(directives, ' ')], ' ');
    },
    ObjectTypeExtension: function ObjectTypeExtension(_ref34) {
      var name = _ref34.name,
          interfaces = _ref34.interfaces,
          directives = _ref34.directives,
          fields = _ref34.fields;
      return join(['extend type', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    },
    InterfaceTypeExtension: function InterfaceTypeExtension(_ref35) {
      var name = _ref35.name,
          interfaces = _ref35.interfaces,
          directives = _ref35.directives,
          fields = _ref35.fields;
      return join(['extend interface', name, wrap$1('implements ', join(interfaces, ' & ')), join(directives, ' '), block(fields)], ' ');
    },
    UnionTypeExtension: function UnionTypeExtension(_ref36) {
      var name = _ref36.name,
          directives = _ref36.directives,
          types = _ref36.types;
      return join(['extend union', name, join(directives, ' '), types && types.length !== 0 ? '= ' + join(types, ' | ') : ''], ' ');
    },
    EnumTypeExtension: function EnumTypeExtension(_ref37) {
      var name = _ref37.name,
          directives = _ref37.directives,
          values = _ref37.values;
      return join(['extend enum', name, join(directives, ' '), block(values)], ' ');
    },
    InputObjectTypeExtension: function InputObjectTypeExtension(_ref38) {
      var name = _ref38.name,
          directives = _ref38.directives,
          fields = _ref38.fields;
      return join(['extend input', name, join(directives, ' '), block(fields)], ' ');
    }
  };

  function addDescription(cb) {
    return function (node) {
      return join([node.description, cb(node)], '\n');
    };
  }
  /**
   * Given maybeArray, print an empty string if it is null or empty, otherwise
   * print all items together separated by separator if provided
   */


  function join(maybeArray) {
    var _maybeArray$filter$jo;

    var separator = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    return (_maybeArray$filter$jo = maybeArray === null || maybeArray === void 0 ? void 0 : maybeArray.filter(function (x) {
      return x;
    }).join(separator)) !== null && _maybeArray$filter$jo !== void 0 ? _maybeArray$filter$jo : '';
  }
  /**
   * Given array, print each item on its own line, wrapped in an
   * indented "{ }" block.
   */


  function block(array) {
    return array && array.length !== 0 ? '{\n' + indent(join(array, '\n')) + '\n}' : '';
  }
  /**
   * If maybeString is not null or empty, then wrap with start and end, otherwise
   * print an empty string.
   */


  function wrap$1(start, maybeString) {
    var end = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
    return maybeString ? start + maybeString + end : '';
  }

  function indent(maybeString) {
    return maybeString && '  ' + maybeString.replace(/\n/g, '\n  ');
  }

  function isMultiline(string) {
    return string.indexOf('\n') !== -1;
  }

  function hasMultilineItems(maybeArray) {
    return maybeArray && maybeArray.some(isMultiline);
  }

  var defaultHttpOptions = {
    includeQuery: true,
    includeExtensions: false
  };
  var defaultHeaders = {
    accept: '*/*',
    'content-type': 'application/json'
  };
  var defaultOptions = {
    method: 'POST'
  };
  var fallbackHttpConfig = {
    http: defaultHttpOptions,
    headers: defaultHeaders,
    options: defaultOptions
  };

  var throwServerError = function (response, result, message) {
    var error = new Error(message);
    error.name = 'ServerError';
    error.response = response;
    error.statusCode = response.status;
    error.result = result;
    throw error;
  };

  var parseAndCheckHttpResponse = function (operations) {
    return function (response) {
      return response.text().then(function (bodyText) {
        try {
          return JSON.parse(bodyText);
        } catch (err) {
          var parseError = err;
          parseError.name = 'ServerParseError';
          parseError.response = response;
          parseError.statusCode = response.status;
          parseError.bodyText = bodyText;
          return Promise.reject(parseError);
        }
      }).then(function (result) {
        if (response.status >= 300) {
          throwServerError(response, result, "Response not successful: Received status code " + response.status);
        }

        if (!Array.isArray(result) && !result.hasOwnProperty('data') && !result.hasOwnProperty('errors')) {
          throwServerError(response, result, "Server response was missing for query '" + (Array.isArray(operations) ? operations.map(function (op) {
            return op.operationName;
          }) : operations.operationName) + "'.");
        }

        return result;
      });
    };
  };

  var checkFetcher = function (fetcher) {
    if (!fetcher && typeof fetch === 'undefined') {
      var library = 'unfetch';
      if (typeof window === 'undefined') library = 'node-fetch';
      throw  new InvariantError("\nfetch is not found globally and no fetcher passed, to fix pass a fetch for\nyour environment like https://www.npmjs.com/package/" + library + ".\n\nFor example:\nimport fetch from '" + library + "';\nimport { createHttpLink } from 'apollo-link-http';\n\nconst link = createHttpLink({ uri: '/graphql', fetch: fetch });");
    }
  };

  var createSignalIfSupported = function () {
    if (typeof AbortController === 'undefined') return {
      controller: false,
      signal: false
    };
    var controller = new AbortController();
    var signal = controller.signal;
    return {
      controller: controller,
      signal: signal
    };
  };

  var selectHttpOptionsAndBody = function (operation, fallbackConfig) {
    var configs = [];

    for (var _i = 2; _i < arguments.length; _i++) {
      configs[_i - 2] = arguments[_i];
    }

    var options = __assign({}, fallbackConfig.options, {
      headers: fallbackConfig.headers,
      credentials: fallbackConfig.credentials
    });

    var http = fallbackConfig.http;
    configs.forEach(function (config) {
      options = __assign({}, options, config.options, {
        headers: __assign({}, options.headers, config.headers)
      });
      if (config.credentials) options.credentials = config.credentials;
      http = __assign({}, http, config.http);
    });
    var operationName = operation.operationName,
        extensions = operation.extensions,
        variables = operation.variables,
        query = operation.query;
    var body = {
      operationName: operationName,
      variables: variables
    };
    if (http.includeExtensions) body.extensions = extensions;
    if (http.includeQuery) body.query = print(query);
    return {
      options: options,
      body: body
    };
  };

  var serializeFetchParameter = function (p, label) {
    var serialized;

    try {
      serialized = JSON.stringify(p);
    } catch (e) {
      var parseError =  new InvariantError("Network request failed. " + label + " is not serializable: " + e.message);
      parseError.parseError = e;
      throw parseError;
    }

    return serialized;
  };

  var selectURI = function (operation, fallbackURI) {
    var context = operation.getContext();
    var contextURI = context.uri;

    if (contextURI) {
      return contextURI;
    } else if (typeof fallbackURI === 'function') {
      return fallbackURI(operation);
    } else {
      return fallbackURI || '/graphql';
    }
  };

  var createHttpLink = function (linkOptions) {
    if (linkOptions === void 0) {
      linkOptions = {};
    }

    var _a = linkOptions.uri,
        uri = _a === void 0 ? '/graphql' : _a,
        fetcher = linkOptions.fetch,
        includeExtensions = linkOptions.includeExtensions,
        useGETForQueries = linkOptions.useGETForQueries,
        requestOptions = __rest(linkOptions, ["uri", "fetch", "includeExtensions", "useGETForQueries"]);

    checkFetcher(fetcher);

    if (!fetcher) {
      fetcher = fetch;
    }

    var linkConfig = {
      http: {
        includeExtensions: includeExtensions
      },
      options: requestOptions.fetchOptions,
      credentials: requestOptions.credentials,
      headers: requestOptions.headers
    };
    return new ApolloLink(function (operation) {
      var chosenURI = selectURI(operation, uri);
      var context = operation.getContext();
      var clientAwarenessHeaders = {};

      if (context.clientAwareness) {
        var _a = context.clientAwareness,
            name_1 = _a.name,
            version = _a.version;

        if (name_1) {
          clientAwarenessHeaders['apollographql-client-name'] = name_1;
        }

        if (version) {
          clientAwarenessHeaders['apollographql-client-version'] = version;
        }
      }

      var contextHeaders = __assign({}, clientAwarenessHeaders, context.headers);

      var contextConfig = {
        http: context.http,
        options: context.fetchOptions,
        credentials: context.credentials,
        headers: contextHeaders
      };

      var _b = selectHttpOptionsAndBody(operation, fallbackHttpConfig, linkConfig, contextConfig),
          options = _b.options,
          body = _b.body;

      var controller;

      if (!options.signal) {
        var _c = createSignalIfSupported(),
            _controller = _c.controller,
            signal = _c.signal;

        controller = _controller;
        if (controller) options.signal = signal;
      }

      var definitionIsMutation = function (d) {
        return d.kind === 'OperationDefinition' && d.operation === 'mutation';
      };

      if (useGETForQueries && !operation.query.definitions.some(definitionIsMutation)) {
        options.method = 'GET';
      }

      if (options.method === 'GET') {
        var _d = rewriteURIForGET(chosenURI, body),
            newURI = _d.newURI,
            parseError = _d.parseError;

        if (parseError) {
          return fromError(parseError);
        }

        chosenURI = newURI;
      } else {
        try {
          options.body = serializeFetchParameter(body, 'Payload');
        } catch (parseError) {
          return fromError(parseError);
        }
      }

      return new Observable$1(function (observer) {
        fetcher(chosenURI, options).then(function (response) {
          operation.setContext({
            response: response
          });
          return response;
        }).then(parseAndCheckHttpResponse(operation)).then(function (result) {
          observer.next(result);
          observer.complete();
          return result;
        }).catch(function (err) {
          if (err.name === 'AbortError') return;

          if (err.result && err.result.errors && err.result.data) {
            observer.next(err.result);
          }

          observer.error(err);
        });
        return function () {
          if (controller) controller.abort();
        };
      });
    });
  };

  function rewriteURIForGET(chosenURI, body) {
    var queryParams = [];

    var addQueryParam = function (key, value) {
      queryParams.push(key + "=" + encodeURIComponent(value));
    };

    if ('query' in body) {
      addQueryParam('query', body.query);
    }

    if (body.operationName) {
      addQueryParam('operationName', body.operationName);
    }

    if (body.variables) {
      var serializedVariables = void 0;

      try {
        serializedVariables = serializeFetchParameter(body.variables, 'Variables map');
      } catch (parseError) {
        return {
          parseError: parseError
        };
      }

      addQueryParam('variables', serializedVariables);
    }

    if (body.extensions) {
      var serializedExtensions = void 0;

      try {
        serializedExtensions = serializeFetchParameter(body.extensions, 'Extensions map');
      } catch (parseError) {
        return {
          parseError: parseError
        };
      }

      addQueryParam('extensions', serializedExtensions);
    }

    var fragment = '',
        preFragment = chosenURI;
    var fragmentStart = chosenURI.indexOf('#');

    if (fragmentStart !== -1) {
      fragment = chosenURI.substr(fragmentStart);
      preFragment = chosenURI.substr(0, fragmentStart);
    }

    var queryParamsPrefix = preFragment.indexOf('?') === -1 ? '?' : '&';
    var newURI = preFragment + queryParamsPrefix + queryParams.join('&') + fragment;
    return {
      newURI: newURI
    };
  }

  var HttpLink = function (_super) {
    __extends(HttpLink, _super);

    function HttpLink(opts) {
      return _super.call(this, createHttpLink(opts).request) || this;
    }

    return HttpLink;
  }(ApolloLink);

  function devAssert(condition, message) {
    var booleanCondition = Boolean(condition); // istanbul ignore else (See transformation done in './resources/inlineInvariant.js')

    if (!booleanCondition) {
      throw new Error(message);
    }
  }

  function _typeof$1(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof$1 = function _typeof(obj) { return typeof obj; }; } else { _typeof$1 = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof$1(obj); }

  /**
   * Return true if `value` is object-like. A value is object-like if it's not
   * `null` and has a `typeof` result of "object".
   */
  function isObjectLike(value) {
    return _typeof$1(value) == 'object' && value !== null;
  }

  // In ES2015 (or a polyfilled) environment, this will be Symbol.iterator

  var SYMBOL_TO_STRING_TAG = // $FlowFixMe Flow doesn't define `Symbol.toStringTag` yet
  typeof Symbol === 'function' ? Symbol.toStringTag : '@@toStringTag';

  /**
   * Represents a location in a Source.
   */

  /**
   * Takes a Source and a UTF-8 character offset, and returns the corresponding
   * line and column as a SourceLocation.
   */
  function getLocation(source, position) {
    var lineRegexp = /\r\n|[\n\r]/g;
    var line = 1;
    var column = position + 1;
    var match;

    while ((match = lineRegexp.exec(source.body)) && match.index < position) {
      line += 1;
      column = position + 1 - (match.index + match[0].length);
    }

    return {
      line: line,
      column: column
    };
  }

  /**
   * Render a helpful description of the location in the GraphQL Source document.
   */

  function printLocation(location) {
    return printSourceLocation(location.source, getLocation(location.source, location.start));
  }
  /**
   * Render a helpful description of the location in the GraphQL Source document.
   */

  function printSourceLocation(source, sourceLocation) {
    var firstLineColumnOffset = source.locationOffset.column - 1;
    var body = whitespace(firstLineColumnOffset) + source.body;
    var lineIndex = sourceLocation.line - 1;
    var lineOffset = source.locationOffset.line - 1;
    var lineNum = sourceLocation.line + lineOffset;
    var columnOffset = sourceLocation.line === 1 ? firstLineColumnOffset : 0;
    var columnNum = sourceLocation.column + columnOffset;
    var locationStr = "".concat(source.name, ":").concat(lineNum, ":").concat(columnNum, "\n");
    var lines = body.split(/\r\n|[\n\r]/g);
    var locationLine = lines[lineIndex]; // Special case for minified documents

    if (locationLine.length > 120) {
      var subLineIndex = Math.floor(columnNum / 80);
      var subLineColumnNum = columnNum % 80;
      var subLines = [];

      for (var i = 0; i < locationLine.length; i += 80) {
        subLines.push(locationLine.slice(i, i + 80));
      }

      return locationStr + printPrefixedLines([["".concat(lineNum), subLines[0]]].concat(subLines.slice(1, subLineIndex + 1).map(function (subLine) {
        return ['', subLine];
      }), [[' ', whitespace(subLineColumnNum - 1) + '^'], ['', subLines[subLineIndex + 1]]]));
    }

    return locationStr + printPrefixedLines([// Lines specified like this: ["prefix", "string"],
    ["".concat(lineNum - 1), lines[lineIndex - 1]], ["".concat(lineNum), locationLine], ['', whitespace(columnNum - 1) + '^'], ["".concat(lineNum + 1), lines[lineIndex + 1]]]);
  }

  function printPrefixedLines(lines) {
    var existingLines = lines.filter(function (_ref) {
      var _ = _ref[0],
          line = _ref[1];
      return line !== undefined;
    });
    var padLen = Math.max.apply(Math, existingLines.map(function (_ref2) {
      var prefix = _ref2[0];
      return prefix.length;
    }));
    return existingLines.map(function (_ref3) {
      var prefix = _ref3[0],
          line = _ref3[1];
      return leftPad(padLen, prefix) + (line ? ' | ' + line : ' |');
    }).join('\n');
  }

  function whitespace(len) {
    return Array(len + 1).join(' ');
  }

  function leftPad(len, str) {
    return whitespace(len - str.length) + str;
  }

  function _typeof$2(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof$2 = function _typeof(obj) { return typeof obj; }; } else { _typeof$2 = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof$2(obj); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof$2(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _wrapNativeSuper(Class) { var _cache = typeof Map === "function" ? new Map() : undefined; _wrapNativeSuper = function _wrapNativeSuper(Class) { if (Class === null || !_isNativeFunction(Class)) return Class; if (typeof Class !== "function") { throw new TypeError("Super expression must either be null or a function"); } if (typeof _cache !== "undefined") { if (_cache.has(Class)) return _cache.get(Class); _cache.set(Class, Wrapper); } function Wrapper() { return _construct(Class, arguments, _getPrototypeOf(this).constructor); } Wrapper.prototype = Object.create(Class.prototype, { constructor: { value: Wrapper, enumerable: false, writable: true, configurable: true } }); return _setPrototypeOf(Wrapper, Class); }; return _wrapNativeSuper(Class); }

  function _construct(Parent, args, Class) { if (_isNativeReflectConstruct()) { _construct = Reflect.construct; } else { _construct = function _construct(Parent, args, Class) { var a = [null]; a.push.apply(a, args); var Constructor = Function.bind.apply(Parent, a); var instance = new Constructor(); if (Class) _setPrototypeOf(instance, Class.prototype); return instance; }; } return _construct.apply(null, arguments); }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

  function _isNativeFunction(fn) { return Function.toString.call(fn).indexOf("[native code]") !== -1; }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }
  /**
   * A GraphQLError describes an Error found during the parse, validate, or
   * execute phases of performing a GraphQL operation. In addition to a message
   * and stack trace, it also includes information about the locations in a
   * GraphQL document and/or execution result that correspond to the Error.
   */

  var GraphQLError = /*#__PURE__*/function (_Error) {
    _inherits(GraphQLError, _Error);

    var _super = _createSuper(GraphQLError);

    /**
     * A message describing the Error for debugging purposes.
     *
     * Enumerable, and appears in the result of JSON.stringify().
     *
     * Note: should be treated as readonly, despite invariant usage.
     */

    /**
     * An array of { line, column } locations within the source GraphQL document
     * which correspond to this error.
     *
     * Errors during validation often contain multiple locations, for example to
     * point out two things with the same name. Errors during execution include a
     * single location, the field which produced the error.
     *
     * Enumerable, and appears in the result of JSON.stringify().
     */

    /**
     * An array describing the JSON-path into the execution response which
     * corresponds to this error. Only included for errors during execution.
     *
     * Enumerable, and appears in the result of JSON.stringify().
     */

    /**
     * An array of GraphQL AST Nodes corresponding to this error.
     */

    /**
     * The source GraphQL document for the first location of this error.
     *
     * Note that if this Error represents more than one node, the source may not
     * represent nodes after the first node.
     */

    /**
     * An array of character offsets within the source GraphQL document
     * which correspond to this error.
     */

    /**
     * The original error thrown from a field resolver during execution.
     */

    /**
     * Extension fields to add to the formatted error.
     */
    function GraphQLError(message, nodes, source, positions, path, originalError, extensions) {
      var _locations2, _source2, _positions2, _extensions2;

      var _this;

      _classCallCheck(this, GraphQLError);

      _this = _super.call(this, message); // Compute list of blame nodes.

      var _nodes = Array.isArray(nodes) ? nodes.length !== 0 ? nodes : undefined : nodes ? [nodes] : undefined; // Compute locations in the source for the given nodes/positions.


      var _source = source;

      if (!_source && _nodes) {
        var _nodes$0$loc;

        _source = (_nodes$0$loc = _nodes[0].loc) === null || _nodes$0$loc === void 0 ? void 0 : _nodes$0$loc.source;
      }

      var _positions = positions;

      if (!_positions && _nodes) {
        _positions = _nodes.reduce(function (list, node) {
          if (node.loc) {
            list.push(node.loc.start);
          }

          return list;
        }, []);
      }

      if (_positions && _positions.length === 0) {
        _positions = undefined;
      }

      var _locations;

      if (positions && source) {
        _locations = positions.map(function (pos) {
          return getLocation(source, pos);
        });
      } else if (_nodes) {
        _locations = _nodes.reduce(function (list, node) {
          if (node.loc) {
            list.push(getLocation(node.loc.source, node.loc.start));
          }

          return list;
        }, []);
      }

      var _extensions = extensions;

      if (_extensions == null && originalError != null) {
        var originalExtensions = originalError.extensions;

        if (isObjectLike(originalExtensions)) {
          _extensions = originalExtensions;
        }
      }

      Object.defineProperties(_assertThisInitialized(_this), {
        name: {
          value: 'GraphQLError'
        },
        message: {
          value: message,
          // By being enumerable, JSON.stringify will include `message` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: true,
          writable: true
        },
        locations: {
          // Coercing falsy values to undefined ensures they will not be included
          // in JSON.stringify() when not provided.
          value: (_locations2 = _locations) !== null && _locations2 !== void 0 ? _locations2 : undefined,
          // By being enumerable, JSON.stringify will include `locations` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: _locations != null
        },
        path: {
          // Coercing falsy values to undefined ensures they will not be included
          // in JSON.stringify() when not provided.
          value: path !== null && path !== void 0 ? path : undefined,
          // By being enumerable, JSON.stringify will include `path` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: path != null
        },
        nodes: {
          value: _nodes !== null && _nodes !== void 0 ? _nodes : undefined
        },
        source: {
          value: (_source2 = _source) !== null && _source2 !== void 0 ? _source2 : undefined
        },
        positions: {
          value: (_positions2 = _positions) !== null && _positions2 !== void 0 ? _positions2 : undefined
        },
        originalError: {
          value: originalError
        },
        extensions: {
          // Coercing falsy values to undefined ensures they will not be included
          // in JSON.stringify() when not provided.
          value: (_extensions2 = _extensions) !== null && _extensions2 !== void 0 ? _extensions2 : undefined,
          // By being enumerable, JSON.stringify will include `path` in the
          // resulting output. This ensures that the simplest possible GraphQL
          // service adheres to the spec.
          enumerable: _extensions != null
        }
      }); // Include (non-enumerable) stack trace.

      if (originalError === null || originalError === void 0 ? void 0 : originalError.stack) {
        Object.defineProperty(_assertThisInitialized(_this), 'stack', {
          value: originalError.stack,
          writable: true,
          configurable: true
        });
        return _possibleConstructorReturn(_this);
      } // istanbul ignore next (See: 'https://github.com/graphql/graphql-js/issues/2317')


      if (Error.captureStackTrace) {
        Error.captureStackTrace(_assertThisInitialized(_this), GraphQLError);
      } else {
        Object.defineProperty(_assertThisInitialized(_this), 'stack', {
          value: Error().stack,
          writable: true,
          configurable: true
        });
      }

      return _this;
    }

    _createClass(GraphQLError, [{
      key: "toString",
      value: function toString() {
        return printError(this);
      } // FIXME: workaround to not break chai comparisons, should be remove in v16
      // $FlowFixMe Flow doesn't support computed properties yet

    }, {
      key: SYMBOL_TO_STRING_TAG,
      get: function get() {
        return 'Object';
      }
    }]);

    return GraphQLError;
  }( /*#__PURE__*/_wrapNativeSuper(Error));
  /**
   * Prints a GraphQLError to a string, representing useful location information
   * about the error's position in the source.
   */

  function printError(error) {
    var output = error.message;

    if (error.nodes) {
      for (var _i2 = 0, _error$nodes2 = error.nodes; _i2 < _error$nodes2.length; _i2++) {
        var node = _error$nodes2[_i2];

        if (node.loc) {
          output += '\n\n' + printLocation(node.loc);
        }
      }
    } else if (error.source && error.locations) {
      for (var _i4 = 0, _error$locations2 = error.locations; _i4 < _error$locations2.length; _i4++) {
        var location = _error$locations2[_i4];
        output += '\n\n' + printSourceLocation(error.source, location);
      }
    }

    return output;
  }

  /**
   * Produces a GraphQLError representing a syntax error, containing useful
   * descriptive information about the syntax error's position in the source.
   */

  function syntaxError(source, position, description) {
    return new GraphQLError("Syntax Error: ".concat(description), undefined, source, [position]);
  }

  /**
   * The set of allowed kind values for AST nodes.
   */
  var Kind = Object.freeze({
    // Name
    NAME: 'Name',
    // Document
    DOCUMENT: 'Document',
    OPERATION_DEFINITION: 'OperationDefinition',
    VARIABLE_DEFINITION: 'VariableDefinition',
    SELECTION_SET: 'SelectionSet',
    FIELD: 'Field',
    ARGUMENT: 'Argument',
    // Fragments
    FRAGMENT_SPREAD: 'FragmentSpread',
    INLINE_FRAGMENT: 'InlineFragment',
    FRAGMENT_DEFINITION: 'FragmentDefinition',
    // Values
    VARIABLE: 'Variable',
    INT: 'IntValue',
    FLOAT: 'FloatValue',
    STRING: 'StringValue',
    BOOLEAN: 'BooleanValue',
    NULL: 'NullValue',
    ENUM: 'EnumValue',
    LIST: 'ListValue',
    OBJECT: 'ObjectValue',
    OBJECT_FIELD: 'ObjectField',
    // Directives
    DIRECTIVE: 'Directive',
    // Types
    NAMED_TYPE: 'NamedType',
    LIST_TYPE: 'ListType',
    NON_NULL_TYPE: 'NonNullType',
    // Type System Definitions
    SCHEMA_DEFINITION: 'SchemaDefinition',
    OPERATION_TYPE_DEFINITION: 'OperationTypeDefinition',
    // Type Definitions
    SCALAR_TYPE_DEFINITION: 'ScalarTypeDefinition',
    OBJECT_TYPE_DEFINITION: 'ObjectTypeDefinition',
    FIELD_DEFINITION: 'FieldDefinition',
    INPUT_VALUE_DEFINITION: 'InputValueDefinition',
    INTERFACE_TYPE_DEFINITION: 'InterfaceTypeDefinition',
    UNION_TYPE_DEFINITION: 'UnionTypeDefinition',
    ENUM_TYPE_DEFINITION: 'EnumTypeDefinition',
    ENUM_VALUE_DEFINITION: 'EnumValueDefinition',
    INPUT_OBJECT_TYPE_DEFINITION: 'InputObjectTypeDefinition',
    // Directive Definitions
    DIRECTIVE_DEFINITION: 'DirectiveDefinition',
    // Type System Extensions
    SCHEMA_EXTENSION: 'SchemaExtension',
    // Type Extensions
    SCALAR_TYPE_EXTENSION: 'ScalarTypeExtension',
    OBJECT_TYPE_EXTENSION: 'ObjectTypeExtension',
    INTERFACE_TYPE_EXTENSION: 'InterfaceTypeExtension',
    UNION_TYPE_EXTENSION: 'UnionTypeExtension',
    ENUM_TYPE_EXTENSION: 'EnumTypeExtension',
    INPUT_OBJECT_TYPE_EXTENSION: 'InputObjectTypeExtension'
  });
  /**
   * The enum type representing the possible kind values of AST nodes.
   */

  function _defineProperties$1(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass$1(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties$1(Constructor.prototype, protoProps); if (staticProps) _defineProperties$1(Constructor, staticProps); return Constructor; }

  /**
   * A representation of source input to GraphQL.
   * `name` and `locationOffset` are optional. They are useful for clients who
   * store GraphQL documents in source files; for example, if the GraphQL input
   * starts at line 40 in a file named Foo.graphql, it might be useful for name to
   * be "Foo.graphql" and location to be `{ line: 40, column: 0 }`.
   * line and column in locationOffset are 1-indexed
   */
  var Source = /*#__PURE__*/function () {
    function Source(body) {
      var name = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'GraphQL request';
      var locationOffset = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
        line: 1,
        column: 1
      };
      this.body = body;
      this.name = name;
      this.locationOffset = locationOffset;
      this.locationOffset.line > 0 || devAssert(0, 'line in locationOffset is 1-indexed and must be positive.');
      this.locationOffset.column > 0 || devAssert(0, 'column in locationOffset is 1-indexed and must be positive.');
    } // $FlowFixMe Flow doesn't support computed properties yet


    _createClass$1(Source, [{
      key: SYMBOL_TO_STRING_TAG,
      get: function get() {
        return 'Source';
      }
    }]);

    return Source;
  }();

  /**
   * The set of allowed directive location values.
   */
  var DirectiveLocation = Object.freeze({
    // Request Definitions
    QUERY: 'QUERY',
    MUTATION: 'MUTATION',
    SUBSCRIPTION: 'SUBSCRIPTION',
    FIELD: 'FIELD',
    FRAGMENT_DEFINITION: 'FRAGMENT_DEFINITION',
    FRAGMENT_SPREAD: 'FRAGMENT_SPREAD',
    INLINE_FRAGMENT: 'INLINE_FRAGMENT',
    VARIABLE_DEFINITION: 'VARIABLE_DEFINITION',
    // Type System Definitions
    SCHEMA: 'SCHEMA',
    SCALAR: 'SCALAR',
    OBJECT: 'OBJECT',
    FIELD_DEFINITION: 'FIELD_DEFINITION',
    ARGUMENT_DEFINITION: 'ARGUMENT_DEFINITION',
    INTERFACE: 'INTERFACE',
    UNION: 'UNION',
    ENUM: 'ENUM',
    ENUM_VALUE: 'ENUM_VALUE',
    INPUT_OBJECT: 'INPUT_OBJECT',
    INPUT_FIELD_DEFINITION: 'INPUT_FIELD_DEFINITION'
  });
  /**
   * The enum type representing the directive location values.
   */

  /**
   * An exported enum describing the different kinds of tokens that the
   * lexer emits.
   */
  var TokenKind = Object.freeze({
    SOF: '<SOF>',
    EOF: '<EOF>',
    BANG: '!',
    DOLLAR: '$',
    AMP: '&',
    PAREN_L: '(',
    PAREN_R: ')',
    SPREAD: '...',
    COLON: ':',
    EQUALS: '=',
    AT: '@',
    BRACKET_L: '[',
    BRACKET_R: ']',
    BRACE_L: '{',
    PIPE: '|',
    BRACE_R: '}',
    NAME: 'Name',
    INT: 'Int',
    FLOAT: 'Float',
    STRING: 'String',
    BLOCK_STRING: 'BlockString',
    COMMENT: 'Comment'
  });
  /**
   * The enum type representing the token kinds values.
   */

  /**
   * Given a Source object, creates a Lexer for that source.
   * A Lexer is a stateful stream generator in that every time
   * it is advanced, it returns the next token in the Source. Assuming the
   * source lexes, the final Token emitted by the lexer will be of kind
   * EOF, after which the lexer will repeatedly return the same EOF token
   * whenever called.
   */

  var Lexer = /*#__PURE__*/function () {
    /**
     * The previously focused non-ignored token.
     */

    /**
     * The currently focused non-ignored token.
     */

    /**
     * The (1-indexed) line containing the current token.
     */

    /**
     * The character offset at which the current line begins.
     */
    function Lexer(source) {
      var startOfFileToken = new Token(TokenKind.SOF, 0, 0, 0, 0, null);
      this.source = source;
      this.lastToken = startOfFileToken;
      this.token = startOfFileToken;
      this.line = 1;
      this.lineStart = 0;
    }
    /**
     * Advances the token stream to the next non-ignored token.
     */


    var _proto = Lexer.prototype;

    _proto.advance = function advance() {
      this.lastToken = this.token;
      var token = this.token = this.lookahead();
      return token;
    }
    /**
     * Looks ahead and returns the next non-ignored token, but does not change
     * the state of Lexer.
     */
    ;

    _proto.lookahead = function lookahead() {
      var token = this.token;

      if (token.kind !== TokenKind.EOF) {
        do {
          var _token$next;

          // Note: next is only mutable during parsing, so we cast to allow this.
          token = (_token$next = token.next) !== null && _token$next !== void 0 ? _token$next : token.next = readToken(this, token);
        } while (token.kind === TokenKind.COMMENT);
      }

      return token;
    };

    return Lexer;
  }();
  /**
   * @internal
   */

  function isPunctuatorTokenKind(kind) {
    return kind === TokenKind.BANG || kind === TokenKind.DOLLAR || kind === TokenKind.AMP || kind === TokenKind.PAREN_L || kind === TokenKind.PAREN_R || kind === TokenKind.SPREAD || kind === TokenKind.COLON || kind === TokenKind.EQUALS || kind === TokenKind.AT || kind === TokenKind.BRACKET_L || kind === TokenKind.BRACKET_R || kind === TokenKind.BRACE_L || kind === TokenKind.PIPE || kind === TokenKind.BRACE_R;
  }

  function printCharCode(code) {
    return (// NaN/undefined represents access beyond the end of the file.
      isNaN(code) ? TokenKind.EOF : // Trust JSON for ASCII.
      code < 0x007f ? JSON.stringify(String.fromCharCode(code)) : // Otherwise print the escaped form.
      "\"\\u".concat(('00' + code.toString(16).toUpperCase()).slice(-4), "\"")
    );
  }
  /**
   * Gets the next token from the source starting at the given position.
   *
   * This skips over whitespace until it finds the next lexable token, then lexes
   * punctuators immediately or calls the appropriate helper function for more
   * complicated tokens.
   */


  function readToken(lexer, prev) {
    var source = lexer.source;
    var body = source.body;
    var bodyLength = body.length;
    var pos = positionAfterWhitespace(body, prev.end, lexer);
    var line = lexer.line;
    var col = 1 + pos - lexer.lineStart;

    if (pos >= bodyLength) {
      return new Token(TokenKind.EOF, bodyLength, bodyLength, line, col, prev);
    }

    var code = body.charCodeAt(pos); // SourceCharacter

    switch (code) {
      // !
      case 33:
        return new Token(TokenKind.BANG, pos, pos + 1, line, col, prev);
      // #

      case 35:
        return readComment(source, pos, line, col, prev);
      // $

      case 36:
        return new Token(TokenKind.DOLLAR, pos, pos + 1, line, col, prev);
      // &

      case 38:
        return new Token(TokenKind.AMP, pos, pos + 1, line, col, prev);
      // (

      case 40:
        return new Token(TokenKind.PAREN_L, pos, pos + 1, line, col, prev);
      // )

      case 41:
        return new Token(TokenKind.PAREN_R, pos, pos + 1, line, col, prev);
      // .

      case 46:
        if (body.charCodeAt(pos + 1) === 46 && body.charCodeAt(pos + 2) === 46) {
          return new Token(TokenKind.SPREAD, pos, pos + 3, line, col, prev);
        }

        break;
      // :

      case 58:
        return new Token(TokenKind.COLON, pos, pos + 1, line, col, prev);
      // =

      case 61:
        return new Token(TokenKind.EQUALS, pos, pos + 1, line, col, prev);
      // @

      case 64:
        return new Token(TokenKind.AT, pos, pos + 1, line, col, prev);
      // [

      case 91:
        return new Token(TokenKind.BRACKET_L, pos, pos + 1, line, col, prev);
      // ]

      case 93:
        return new Token(TokenKind.BRACKET_R, pos, pos + 1, line, col, prev);
      // {

      case 123:
        return new Token(TokenKind.BRACE_L, pos, pos + 1, line, col, prev);
      // |

      case 124:
        return new Token(TokenKind.PIPE, pos, pos + 1, line, col, prev);
      // }

      case 125:
        return new Token(TokenKind.BRACE_R, pos, pos + 1, line, col, prev);
      // A-Z _ a-z

      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 78:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 86:
      case 87:
      case 88:
      case 89:
      case 90:
      case 95:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 102:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 110:
      case 111:
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 118:
      case 119:
      case 120:
      case 121:
      case 122:
        return readName(source, pos, line, col, prev);
      // - 0-9

      case 45:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
        return readNumber(source, pos, code, line, col, prev);
      // "

      case 34:
        if (body.charCodeAt(pos + 1) === 34 && body.charCodeAt(pos + 2) === 34) {
          return readBlockString(source, pos, line, col, prev, lexer);
        }

        return readString(source, pos, line, col, prev);
    }

    throw syntaxError(source, pos, unexpectedCharacterMessage(code));
  }
  /**
   * Report a message that an unexpected character was encountered.
   */


  function unexpectedCharacterMessage(code) {
    if (code < 0x0020 && code !== 0x0009 && code !== 0x000a && code !== 0x000d) {
      return "Cannot contain the invalid character ".concat(printCharCode(code), ".");
    }

    if (code === 39) {
      // '
      return 'Unexpected single quote character (\'), did you mean to use a double quote (")?';
    }

    return "Cannot parse the unexpected character ".concat(printCharCode(code), ".");
  }
  /**
   * Reads from body starting at startPosition until it finds a non-whitespace
   * character, then returns the position of that character for lexing.
   */


  function positionAfterWhitespace(body, startPosition, lexer) {
    var bodyLength = body.length;
    var position = startPosition;

    while (position < bodyLength) {
      var code = body.charCodeAt(position); // tab | space | comma | BOM

      if (code === 9 || code === 32 || code === 44 || code === 0xfeff) {
        ++position;
      } else if (code === 10) {
        // new line
        ++position;
        ++lexer.line;
        lexer.lineStart = position;
      } else if (code === 13) {
        // carriage return
        if (body.charCodeAt(position + 1) === 10) {
          position += 2;
        } else {
          ++position;
        }

        ++lexer.line;
        lexer.lineStart = position;
      } else {
        break;
      }
    }

    return position;
  }
  /**
   * Reads a comment token from the source file.
   *
   * #[\u0009\u0020-\uFFFF]*
   */


  function readComment(source, start, line, col, prev) {
    var body = source.body;
    var code;
    var position = start;

    do {
      code = body.charCodeAt(++position);
    } while (!isNaN(code) && ( // SourceCharacter but not LineTerminator
    code > 0x001f || code === 0x0009));

    return new Token(TokenKind.COMMENT, start, position, line, col, prev, body.slice(start + 1, position));
  }
  /**
   * Reads a number token from the source file, either a float
   * or an int depending on whether a decimal point appears.
   *
   * Int:   -?(0|[1-9][0-9]*)
   * Float: -?(0|[1-9][0-9]*)(\.[0-9]+)?((E|e)(+|-)?[0-9]+)?
   */


  function readNumber(source, start, firstCode, line, col, prev) {
    var body = source.body;
    var code = firstCode;
    var position = start;
    var isFloat = false;

    if (code === 45) {
      // -
      code = body.charCodeAt(++position);
    }

    if (code === 48) {
      // 0
      code = body.charCodeAt(++position);

      if (code >= 48 && code <= 57) {
        throw syntaxError(source, position, "Invalid number, unexpected digit after 0: ".concat(printCharCode(code), "."));
      }
    } else {
      position = readDigits(source, position, code);
      code = body.charCodeAt(position);
    }

    if (code === 46) {
      // .
      isFloat = true;
      code = body.charCodeAt(++position);
      position = readDigits(source, position, code);
      code = body.charCodeAt(position);
    }

    if (code === 69 || code === 101) {
      // E e
      isFloat = true;
      code = body.charCodeAt(++position);

      if (code === 43 || code === 45) {
        // + -
        code = body.charCodeAt(++position);
      }

      position = readDigits(source, position, code);
      code = body.charCodeAt(position);
    } // Numbers cannot be followed by . or NameStart


    if (code === 46 || isNameStart(code)) {
      throw syntaxError(source, position, "Invalid number, expected digit but got: ".concat(printCharCode(code), "."));
    }

    return new Token(isFloat ? TokenKind.FLOAT : TokenKind.INT, start, position, line, col, prev, body.slice(start, position));
  }
  /**
   * Returns the new position in the source after reading digits.
   */


  function readDigits(source, start, firstCode) {
    var body = source.body;
    var position = start;
    var code = firstCode;

    if (code >= 48 && code <= 57) {
      // 0 - 9
      do {
        code = body.charCodeAt(++position);
      } while (code >= 48 && code <= 57); // 0 - 9


      return position;
    }

    throw syntaxError(source, position, "Invalid number, expected digit but got: ".concat(printCharCode(code), "."));
  }
  /**
   * Reads a string token from the source file.
   *
   * "([^"\\\u000A\u000D]|(\\(u[0-9a-fA-F]{4}|["\\/bfnrt])))*"
   */


  function readString(source, start, line, col, prev) {
    var body = source.body;
    var position = start + 1;
    var chunkStart = position;
    var code = 0;
    var value = '';

    while (position < body.length && !isNaN(code = body.charCodeAt(position)) && // not LineTerminator
    code !== 0x000a && code !== 0x000d) {
      // Closing Quote (")
      if (code === 34) {
        value += body.slice(chunkStart, position);
        return new Token(TokenKind.STRING, start, position + 1, line, col, prev, value);
      } // SourceCharacter


      if (code < 0x0020 && code !== 0x0009) {
        throw syntaxError(source, position, "Invalid character within String: ".concat(printCharCode(code), "."));
      }

      ++position;

      if (code === 92) {
        // \
        value += body.slice(chunkStart, position - 1);
        code = body.charCodeAt(position);

        switch (code) {
          case 34:
            value += '"';
            break;

          case 47:
            value += '/';
            break;

          case 92:
            value += '\\';
            break;

          case 98:
            value += '\b';
            break;

          case 102:
            value += '\f';
            break;

          case 110:
            value += '\n';
            break;

          case 114:
            value += '\r';
            break;

          case 116:
            value += '\t';
            break;

          case 117:
            {
              // uXXXX
              var charCode = uniCharCode(body.charCodeAt(position + 1), body.charCodeAt(position + 2), body.charCodeAt(position + 3), body.charCodeAt(position + 4));

              if (charCode < 0) {
                var invalidSequence = body.slice(position + 1, position + 5);
                throw syntaxError(source, position, "Invalid character escape sequence: \\u".concat(invalidSequence, "."));
              }

              value += String.fromCharCode(charCode);
              position += 4;
              break;
            }

          default:
            throw syntaxError(source, position, "Invalid character escape sequence: \\".concat(String.fromCharCode(code), "."));
        }

        ++position;
        chunkStart = position;
      }
    }

    throw syntaxError(source, position, 'Unterminated string.');
  }
  /**
   * Reads a block string token from the source file.
   *
   * """("?"?(\\"""|\\(?!=""")|[^"\\]))*"""
   */


  function readBlockString(source, start, line, col, prev, lexer) {
    var body = source.body;
    var position = start + 3;
    var chunkStart = position;
    var code = 0;
    var rawValue = '';

    while (position < body.length && !isNaN(code = body.charCodeAt(position))) {
      // Closing Triple-Quote (""")
      if (code === 34 && body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34) {
        rawValue += body.slice(chunkStart, position);
        return new Token(TokenKind.BLOCK_STRING, start, position + 3, line, col, prev, dedentBlockStringValue(rawValue));
      } // SourceCharacter


      if (code < 0x0020 && code !== 0x0009 && code !== 0x000a && code !== 0x000d) {
        throw syntaxError(source, position, "Invalid character within String: ".concat(printCharCode(code), "."));
      }

      if (code === 10) {
        // new line
        ++position;
        ++lexer.line;
        lexer.lineStart = position;
      } else if (code === 13) {
        // carriage return
        if (body.charCodeAt(position + 1) === 10) {
          position += 2;
        } else {
          ++position;
        }

        ++lexer.line;
        lexer.lineStart = position;
      } else if ( // Escape Triple-Quote (\""")
      code === 92 && body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34 && body.charCodeAt(position + 3) === 34) {
        rawValue += body.slice(chunkStart, position) + '"""';
        position += 4;
        chunkStart = position;
      } else {
        ++position;
      }
    }

    throw syntaxError(source, position, 'Unterminated string.');
  }
  /**
   * Converts four hexadecimal chars to the integer that the
   * string represents. For example, uniCharCode('0','0','0','f')
   * will return 15, and uniCharCode('0','0','f','f') returns 255.
   *
   * Returns a negative number on error, if a char was invalid.
   *
   * This is implemented by noting that char2hex() returns -1 on error,
   * which means the result of ORing the char2hex() will also be negative.
   */


  function uniCharCode(a, b, c, d) {
    return char2hex(a) << 12 | char2hex(b) << 8 | char2hex(c) << 4 | char2hex(d);
  }
  /**
   * Converts a hex character to its integer value.
   * '0' becomes 0, '9' becomes 9
   * 'A' becomes 10, 'F' becomes 15
   * 'a' becomes 10, 'f' becomes 15
   *
   * Returns -1 on error.
   */


  function char2hex(a) {
    return a >= 48 && a <= 57 ? a - 48 // 0-9
    : a >= 65 && a <= 70 ? a - 55 // A-F
    : a >= 97 && a <= 102 ? a - 87 // a-f
    : -1;
  }
  /**
   * Reads an alphanumeric + underscore name from the source.
   *
   * [_A-Za-z][_0-9A-Za-z]*
   */


  function readName(source, start, line, col, prev) {
    var body = source.body;
    var bodyLength = body.length;
    var position = start + 1;
    var code = 0;

    while (position !== bodyLength && !isNaN(code = body.charCodeAt(position)) && (code === 95 || // _
    code >= 48 && code <= 57 || // 0-9
    code >= 65 && code <= 90 || // A-Z
    code >= 97 && code <= 122) // a-z
    ) {
      ++position;
    }

    return new Token(TokenKind.NAME, start, position, line, col, prev, body.slice(start, position));
  } // _ A-Z a-z


  function isNameStart(code) {
    return code === 95 || code >= 65 && code <= 90 || code >= 97 && code <= 122;
  }

  /**
   * Configuration options to control parser behavior
   */

  /**
   * Given a GraphQL source, parses it into a Document.
   * Throws GraphQLError if a syntax error is encountered.
   */
  function parse(source, options) {
    var parser = new Parser(source, options);
    return parser.parseDocument();
  }
  /**
   * Given a string containing a GraphQL value (ex. `[42]`), parse the AST for
   * that value.
   * Throws GraphQLError if a syntax error is encountered.
   *
   * This is useful within tools that operate upon GraphQL Values directly and
   * in isolation of complete GraphQL documents.
   *
   * Consider providing the results to the utility function: valueFromAST().
   */

  function parseValue(source, options) {
    var parser = new Parser(source, options);
    parser.expectToken(TokenKind.SOF);
    var value = parser.parseValueLiteral(false);
    parser.expectToken(TokenKind.EOF);
    return value;
  }
  /**
   * Given a string containing a GraphQL Type (ex. `[Int!]`), parse the AST for
   * that type.
   * Throws GraphQLError if a syntax error is encountered.
   *
   * This is useful within tools that operate upon GraphQL Types directly and
   * in isolation of complete GraphQL documents.
   *
   * Consider providing the results to the utility function: typeFromAST().
   */

  function parseType(source, options) {
    var parser = new Parser(source, options);
    parser.expectToken(TokenKind.SOF);
    var type = parser.parseTypeReference();
    parser.expectToken(TokenKind.EOF);
    return type;
  }

  var Parser = /*#__PURE__*/function () {
    function Parser(source, options) {
      var sourceObj = typeof source === 'string' ? new Source(source) : source;
      sourceObj instanceof Source || devAssert(0, "Must provide Source. Received: ".concat(inspect(sourceObj), "."));
      this._lexer = new Lexer(sourceObj);
      this._options = options;
    }
    /**
     * Converts a name lex token into a name parse node.
     */


    var _proto = Parser.prototype;

    _proto.parseName = function parseName() {
      var token = this.expectToken(TokenKind.NAME);
      return {
        kind: Kind.NAME,
        value: token.value,
        loc: this.loc(token)
      };
    } // Implements the parsing rules in the Document section.

    /**
     * Document : Definition+
     */
    ;

    _proto.parseDocument = function parseDocument() {
      var start = this._lexer.token;
      return {
        kind: Kind.DOCUMENT,
        definitions: this.many(TokenKind.SOF, this.parseDefinition, TokenKind.EOF),
        loc: this.loc(start)
      };
    }
    /**
     * Definition :
     *   - ExecutableDefinition
     *   - TypeSystemDefinition
     *   - TypeSystemExtension
     *
     * ExecutableDefinition :
     *   - OperationDefinition
     *   - FragmentDefinition
     */
    ;

    _proto.parseDefinition = function parseDefinition() {
      if (this.peek(TokenKind.NAME)) {
        switch (this._lexer.token.value) {
          case 'query':
          case 'mutation':
          case 'subscription':
            return this.parseOperationDefinition();

          case 'fragment':
            return this.parseFragmentDefinition();

          case 'schema':
          case 'scalar':
          case 'type':
          case 'interface':
          case 'union':
          case 'enum':
          case 'input':
          case 'directive':
            return this.parseTypeSystemDefinition();

          case 'extend':
            return this.parseTypeSystemExtension();
        }
      } else if (this.peek(TokenKind.BRACE_L)) {
        return this.parseOperationDefinition();
      } else if (this.peekDescription()) {
        return this.parseTypeSystemDefinition();
      }

      throw this.unexpected();
    } // Implements the parsing rules in the Operations section.

    /**
     * OperationDefinition :
     *  - SelectionSet
     *  - OperationType Name? VariableDefinitions? Directives? SelectionSet
     */
    ;

    _proto.parseOperationDefinition = function parseOperationDefinition() {
      var start = this._lexer.token;

      if (this.peek(TokenKind.BRACE_L)) {
        return {
          kind: Kind.OPERATION_DEFINITION,
          operation: 'query',
          name: undefined,
          variableDefinitions: [],
          directives: [],
          selectionSet: this.parseSelectionSet(),
          loc: this.loc(start)
        };
      }

      var operation = this.parseOperationType();
      var name;

      if (this.peek(TokenKind.NAME)) {
        name = this.parseName();
      }

      return {
        kind: Kind.OPERATION_DEFINITION,
        operation: operation,
        name: name,
        variableDefinitions: this.parseVariableDefinitions(),
        directives: this.parseDirectives(false),
        selectionSet: this.parseSelectionSet(),
        loc: this.loc(start)
      };
    }
    /**
     * OperationType : one of query mutation subscription
     */
    ;

    _proto.parseOperationType = function parseOperationType() {
      var operationToken = this.expectToken(TokenKind.NAME);

      switch (operationToken.value) {
        case 'query':
          return 'query';

        case 'mutation':
          return 'mutation';

        case 'subscription':
          return 'subscription';
      }

      throw this.unexpected(operationToken);
    }
    /**
     * VariableDefinitions : ( VariableDefinition+ )
     */
    ;

    _proto.parseVariableDefinitions = function parseVariableDefinitions() {
      return this.optionalMany(TokenKind.PAREN_L, this.parseVariableDefinition, TokenKind.PAREN_R);
    }
    /**
     * VariableDefinition : Variable : Type DefaultValue? Directives[Const]?
     */
    ;

    _proto.parseVariableDefinition = function parseVariableDefinition() {
      var start = this._lexer.token;
      return {
        kind: Kind.VARIABLE_DEFINITION,
        variable: this.parseVariable(),
        type: (this.expectToken(TokenKind.COLON), this.parseTypeReference()),
        defaultValue: this.expectOptionalToken(TokenKind.EQUALS) ? this.parseValueLiteral(true) : undefined,
        directives: this.parseDirectives(true),
        loc: this.loc(start)
      };
    }
    /**
     * Variable : $ Name
     */
    ;

    _proto.parseVariable = function parseVariable() {
      var start = this._lexer.token;
      this.expectToken(TokenKind.DOLLAR);
      return {
        kind: Kind.VARIABLE,
        name: this.parseName(),
        loc: this.loc(start)
      };
    }
    /**
     * SelectionSet : { Selection+ }
     */
    ;

    _proto.parseSelectionSet = function parseSelectionSet() {
      var start = this._lexer.token;
      return {
        kind: Kind.SELECTION_SET,
        selections: this.many(TokenKind.BRACE_L, this.parseSelection, TokenKind.BRACE_R),
        loc: this.loc(start)
      };
    }
    /**
     * Selection :
     *   - Field
     *   - FragmentSpread
     *   - InlineFragment
     */
    ;

    _proto.parseSelection = function parseSelection() {
      return this.peek(TokenKind.SPREAD) ? this.parseFragment() : this.parseField();
    }
    /**
     * Field : Alias? Name Arguments? Directives? SelectionSet?
     *
     * Alias : Name :
     */
    ;

    _proto.parseField = function parseField() {
      var start = this._lexer.token;
      var nameOrAlias = this.parseName();
      var alias;
      var name;

      if (this.expectOptionalToken(TokenKind.COLON)) {
        alias = nameOrAlias;
        name = this.parseName();
      } else {
        name = nameOrAlias;
      }

      return {
        kind: Kind.FIELD,
        alias: alias,
        name: name,
        arguments: this.parseArguments(false),
        directives: this.parseDirectives(false),
        selectionSet: this.peek(TokenKind.BRACE_L) ? this.parseSelectionSet() : undefined,
        loc: this.loc(start)
      };
    }
    /**
     * Arguments[Const] : ( Argument[?Const]+ )
     */
    ;

    _proto.parseArguments = function parseArguments(isConst) {
      var item = isConst ? this.parseConstArgument : this.parseArgument;
      return this.optionalMany(TokenKind.PAREN_L, item, TokenKind.PAREN_R);
    }
    /**
     * Argument[Const] : Name : Value[?Const]
     */
    ;

    _proto.parseArgument = function parseArgument() {
      var start = this._lexer.token;
      var name = this.parseName();
      this.expectToken(TokenKind.COLON);
      return {
        kind: Kind.ARGUMENT,
        name: name,
        value: this.parseValueLiteral(false),
        loc: this.loc(start)
      };
    };

    _proto.parseConstArgument = function parseConstArgument() {
      var start = this._lexer.token;
      return {
        kind: Kind.ARGUMENT,
        name: this.parseName(),
        value: (this.expectToken(TokenKind.COLON), this.parseValueLiteral(true)),
        loc: this.loc(start)
      };
    } // Implements the parsing rules in the Fragments section.

    /**
     * Corresponds to both FragmentSpread and InlineFragment in the spec.
     *
     * FragmentSpread : ... FragmentName Directives?
     *
     * InlineFragment : ... TypeCondition? Directives? SelectionSet
     */
    ;

    _proto.parseFragment = function parseFragment() {
      var start = this._lexer.token;
      this.expectToken(TokenKind.SPREAD);
      var hasTypeCondition = this.expectOptionalKeyword('on');

      if (!hasTypeCondition && this.peek(TokenKind.NAME)) {
        return {
          kind: Kind.FRAGMENT_SPREAD,
          name: this.parseFragmentName(),
          directives: this.parseDirectives(false),
          loc: this.loc(start)
        };
      }

      return {
        kind: Kind.INLINE_FRAGMENT,
        typeCondition: hasTypeCondition ? this.parseNamedType() : undefined,
        directives: this.parseDirectives(false),
        selectionSet: this.parseSelectionSet(),
        loc: this.loc(start)
      };
    }
    /**
     * FragmentDefinition :
     *   - fragment FragmentName on TypeCondition Directives? SelectionSet
     *
     * TypeCondition : NamedType
     */
    ;

    _proto.parseFragmentDefinition = function parseFragmentDefinition() {
      var _this$_options;

      var start = this._lexer.token;
      this.expectKeyword('fragment'); // Experimental support for defining variables within fragments changes
      // the grammar of FragmentDefinition:
      //   - fragment FragmentName VariableDefinitions? on TypeCondition Directives? SelectionSet

      if (((_this$_options = this._options) === null || _this$_options === void 0 ? void 0 : _this$_options.experimentalFragmentVariables) === true) {
        return {
          kind: Kind.FRAGMENT_DEFINITION,
          name: this.parseFragmentName(),
          variableDefinitions: this.parseVariableDefinitions(),
          typeCondition: (this.expectKeyword('on'), this.parseNamedType()),
          directives: this.parseDirectives(false),
          selectionSet: this.parseSelectionSet(),
          loc: this.loc(start)
        };
      }

      return {
        kind: Kind.FRAGMENT_DEFINITION,
        name: this.parseFragmentName(),
        typeCondition: (this.expectKeyword('on'), this.parseNamedType()),
        directives: this.parseDirectives(false),
        selectionSet: this.parseSelectionSet(),
        loc: this.loc(start)
      };
    }
    /**
     * FragmentName : Name but not `on`
     */
    ;

    _proto.parseFragmentName = function parseFragmentName() {
      if (this._lexer.token.value === 'on') {
        throw this.unexpected();
      }

      return this.parseName();
    } // Implements the parsing rules in the Values section.

    /**
     * Value[Const] :
     *   - [~Const] Variable
     *   - IntValue
     *   - FloatValue
     *   - StringValue
     *   - BooleanValue
     *   - NullValue
     *   - EnumValue
     *   - ListValue[?Const]
     *   - ObjectValue[?Const]
     *
     * BooleanValue : one of `true` `false`
     *
     * NullValue : `null`
     *
     * EnumValue : Name but not `true`, `false` or `null`
     */
    ;

    _proto.parseValueLiteral = function parseValueLiteral(isConst) {
      var token = this._lexer.token;

      switch (token.kind) {
        case TokenKind.BRACKET_L:
          return this.parseList(isConst);

        case TokenKind.BRACE_L:
          return this.parseObject(isConst);

        case TokenKind.INT:
          this._lexer.advance();

          return {
            kind: Kind.INT,
            value: token.value,
            loc: this.loc(token)
          };

        case TokenKind.FLOAT:
          this._lexer.advance();

          return {
            kind: Kind.FLOAT,
            value: token.value,
            loc: this.loc(token)
          };

        case TokenKind.STRING:
        case TokenKind.BLOCK_STRING:
          return this.parseStringLiteral();

        case TokenKind.NAME:
          this._lexer.advance();

          switch (token.value) {
            case 'true':
              return {
                kind: Kind.BOOLEAN,
                value: true,
                loc: this.loc(token)
              };

            case 'false':
              return {
                kind: Kind.BOOLEAN,
                value: false,
                loc: this.loc(token)
              };

            case 'null':
              return {
                kind: Kind.NULL,
                loc: this.loc(token)
              };

            default:
              return {
                kind: Kind.ENUM,
                value: token.value,
                loc: this.loc(token)
              };
          }

        case TokenKind.DOLLAR:
          if (!isConst) {
            return this.parseVariable();
          }

          break;
      }

      throw this.unexpected();
    };

    _proto.parseStringLiteral = function parseStringLiteral() {
      var token = this._lexer.token;

      this._lexer.advance();

      return {
        kind: Kind.STRING,
        value: token.value,
        block: token.kind === TokenKind.BLOCK_STRING,
        loc: this.loc(token)
      };
    }
    /**
     * ListValue[Const] :
     *   - [ ]
     *   - [ Value[?Const]+ ]
     */
    ;

    _proto.parseList = function parseList(isConst) {
      var _this = this;

      var start = this._lexer.token;

      var item = function item() {
        return _this.parseValueLiteral(isConst);
      };

      return {
        kind: Kind.LIST,
        values: this.any(TokenKind.BRACKET_L, item, TokenKind.BRACKET_R),
        loc: this.loc(start)
      };
    }
    /**
     * ObjectValue[Const] :
     *   - { }
     *   - { ObjectField[?Const]+ }
     */
    ;

    _proto.parseObject = function parseObject(isConst) {
      var _this2 = this;

      var start = this._lexer.token;

      var item = function item() {
        return _this2.parseObjectField(isConst);
      };

      return {
        kind: Kind.OBJECT,
        fields: this.any(TokenKind.BRACE_L, item, TokenKind.BRACE_R),
        loc: this.loc(start)
      };
    }
    /**
     * ObjectField[Const] : Name : Value[?Const]
     */
    ;

    _proto.parseObjectField = function parseObjectField(isConst) {
      var start = this._lexer.token;
      var name = this.parseName();
      this.expectToken(TokenKind.COLON);
      return {
        kind: Kind.OBJECT_FIELD,
        name: name,
        value: this.parseValueLiteral(isConst),
        loc: this.loc(start)
      };
    } // Implements the parsing rules in the Directives section.

    /**
     * Directives[Const] : Directive[?Const]+
     */
    ;

    _proto.parseDirectives = function parseDirectives(isConst) {
      var directives = [];

      while (this.peek(TokenKind.AT)) {
        directives.push(this.parseDirective(isConst));
      }

      return directives;
    }
    /**
     * Directive[Const] : @ Name Arguments[?Const]?
     */
    ;

    _proto.parseDirective = function parseDirective(isConst) {
      var start = this._lexer.token;
      this.expectToken(TokenKind.AT);
      return {
        kind: Kind.DIRECTIVE,
        name: this.parseName(),
        arguments: this.parseArguments(isConst),
        loc: this.loc(start)
      };
    } // Implements the parsing rules in the Types section.

    /**
     * Type :
     *   - NamedType
     *   - ListType
     *   - NonNullType
     */
    ;

    _proto.parseTypeReference = function parseTypeReference() {
      var start = this._lexer.token;
      var type;

      if (this.expectOptionalToken(TokenKind.BRACKET_L)) {
        type = this.parseTypeReference();
        this.expectToken(TokenKind.BRACKET_R);
        type = {
          kind: Kind.LIST_TYPE,
          type: type,
          loc: this.loc(start)
        };
      } else {
        type = this.parseNamedType();
      }

      if (this.expectOptionalToken(TokenKind.BANG)) {
        return {
          kind: Kind.NON_NULL_TYPE,
          type: type,
          loc: this.loc(start)
        };
      }

      return type;
    }
    /**
     * NamedType : Name
     */
    ;

    _proto.parseNamedType = function parseNamedType() {
      var start = this._lexer.token;
      return {
        kind: Kind.NAMED_TYPE,
        name: this.parseName(),
        loc: this.loc(start)
      };
    } // Implements the parsing rules in the Type Definition section.

    /**
     * TypeSystemDefinition :
     *   - SchemaDefinition
     *   - TypeDefinition
     *   - DirectiveDefinition
     *
     * TypeDefinition :
     *   - ScalarTypeDefinition
     *   - ObjectTypeDefinition
     *   - InterfaceTypeDefinition
     *   - UnionTypeDefinition
     *   - EnumTypeDefinition
     *   - InputObjectTypeDefinition
     */
    ;

    _proto.parseTypeSystemDefinition = function parseTypeSystemDefinition() {
      // Many definitions begin with a description and require a lookahead.
      var keywordToken = this.peekDescription() ? this._lexer.lookahead() : this._lexer.token;

      if (keywordToken.kind === TokenKind.NAME) {
        switch (keywordToken.value) {
          case 'schema':
            return this.parseSchemaDefinition();

          case 'scalar':
            return this.parseScalarTypeDefinition();

          case 'type':
            return this.parseObjectTypeDefinition();

          case 'interface':
            return this.parseInterfaceTypeDefinition();

          case 'union':
            return this.parseUnionTypeDefinition();

          case 'enum':
            return this.parseEnumTypeDefinition();

          case 'input':
            return this.parseInputObjectTypeDefinition();

          case 'directive':
            return this.parseDirectiveDefinition();
        }
      }

      throw this.unexpected(keywordToken);
    };

    _proto.peekDescription = function peekDescription() {
      return this.peek(TokenKind.STRING) || this.peek(TokenKind.BLOCK_STRING);
    }
    /**
     * Description : StringValue
     */
    ;

    _proto.parseDescription = function parseDescription() {
      if (this.peekDescription()) {
        return this.parseStringLiteral();
      }
    }
    /**
     * SchemaDefinition : Description? schema Directives[Const]? { OperationTypeDefinition+ }
     */
    ;

    _proto.parseSchemaDefinition = function parseSchemaDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('schema');
      var directives = this.parseDirectives(true);
      var operationTypes = this.many(TokenKind.BRACE_L, this.parseOperationTypeDefinition, TokenKind.BRACE_R);
      return {
        kind: Kind.SCHEMA_DEFINITION,
        description: description,
        directives: directives,
        operationTypes: operationTypes,
        loc: this.loc(start)
      };
    }
    /**
     * OperationTypeDefinition : OperationType : NamedType
     */
    ;

    _proto.parseOperationTypeDefinition = function parseOperationTypeDefinition() {
      var start = this._lexer.token;
      var operation = this.parseOperationType();
      this.expectToken(TokenKind.COLON);
      var type = this.parseNamedType();
      return {
        kind: Kind.OPERATION_TYPE_DEFINITION,
        operation: operation,
        type: type,
        loc: this.loc(start)
      };
    }
    /**
     * ScalarTypeDefinition : Description? scalar Name Directives[Const]?
     */
    ;

    _proto.parseScalarTypeDefinition = function parseScalarTypeDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('scalar');
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      return {
        kind: Kind.SCALAR_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        loc: this.loc(start)
      };
    }
    /**
     * ObjectTypeDefinition :
     *   Description?
     *   type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition?
     */
    ;

    _proto.parseObjectTypeDefinition = function parseObjectTypeDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('type');
      var name = this.parseName();
      var interfaces = this.parseImplementsInterfaces();
      var directives = this.parseDirectives(true);
      var fields = this.parseFieldsDefinition();
      return {
        kind: Kind.OBJECT_TYPE_DEFINITION,
        description: description,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: this.loc(start)
      };
    }
    /**
     * ImplementsInterfaces :
     *   - implements `&`? NamedType
     *   - ImplementsInterfaces & NamedType
     */
    ;

    _proto.parseImplementsInterfaces = function parseImplementsInterfaces() {
      var types = [];

      if (this.expectOptionalKeyword('implements')) {
        // Optional leading ampersand
        this.expectOptionalToken(TokenKind.AMP);

        do {
          var _this$_options2;

          types.push(this.parseNamedType());
        } while (this.expectOptionalToken(TokenKind.AMP) || // Legacy support for the SDL?
        ((_this$_options2 = this._options) === null || _this$_options2 === void 0 ? void 0 : _this$_options2.allowLegacySDLImplementsInterfaces) === true && this.peek(TokenKind.NAME));
      }

      return types;
    }
    /**
     * FieldsDefinition : { FieldDefinition+ }
     */
    ;

    _proto.parseFieldsDefinition = function parseFieldsDefinition() {
      var _this$_options3;

      // Legacy support for the SDL?
      if (((_this$_options3 = this._options) === null || _this$_options3 === void 0 ? void 0 : _this$_options3.allowLegacySDLEmptyFields) === true && this.peek(TokenKind.BRACE_L) && this._lexer.lookahead().kind === TokenKind.BRACE_R) {
        this._lexer.advance();

        this._lexer.advance();

        return [];
      }

      return this.optionalMany(TokenKind.BRACE_L, this.parseFieldDefinition, TokenKind.BRACE_R);
    }
    /**
     * FieldDefinition :
     *   - Description? Name ArgumentsDefinition? : Type Directives[Const]?
     */
    ;

    _proto.parseFieldDefinition = function parseFieldDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      var name = this.parseName();
      var args = this.parseArgumentDefs();
      this.expectToken(TokenKind.COLON);
      var type = this.parseTypeReference();
      var directives = this.parseDirectives(true);
      return {
        kind: Kind.FIELD_DEFINITION,
        description: description,
        name: name,
        arguments: args,
        type: type,
        directives: directives,
        loc: this.loc(start)
      };
    }
    /**
     * ArgumentsDefinition : ( InputValueDefinition+ )
     */
    ;

    _proto.parseArgumentDefs = function parseArgumentDefs() {
      return this.optionalMany(TokenKind.PAREN_L, this.parseInputValueDef, TokenKind.PAREN_R);
    }
    /**
     * InputValueDefinition :
     *   - Description? Name : Type DefaultValue? Directives[Const]?
     */
    ;

    _proto.parseInputValueDef = function parseInputValueDef() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      var name = this.parseName();
      this.expectToken(TokenKind.COLON);
      var type = this.parseTypeReference();
      var defaultValue;

      if (this.expectOptionalToken(TokenKind.EQUALS)) {
        defaultValue = this.parseValueLiteral(true);
      }

      var directives = this.parseDirectives(true);
      return {
        kind: Kind.INPUT_VALUE_DEFINITION,
        description: description,
        name: name,
        type: type,
        defaultValue: defaultValue,
        directives: directives,
        loc: this.loc(start)
      };
    }
    /**
     * InterfaceTypeDefinition :
     *   - Description? interface Name Directives[Const]? FieldsDefinition?
     */
    ;

    _proto.parseInterfaceTypeDefinition = function parseInterfaceTypeDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('interface');
      var name = this.parseName();
      var interfaces = this.parseImplementsInterfaces();
      var directives = this.parseDirectives(true);
      var fields = this.parseFieldsDefinition();
      return {
        kind: Kind.INTERFACE_TYPE_DEFINITION,
        description: description,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: this.loc(start)
      };
    }
    /**
     * UnionTypeDefinition :
     *   - Description? union Name Directives[Const]? UnionMemberTypes?
     */
    ;

    _proto.parseUnionTypeDefinition = function parseUnionTypeDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('union');
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      var types = this.parseUnionMemberTypes();
      return {
        kind: Kind.UNION_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        types: types,
        loc: this.loc(start)
      };
    }
    /**
     * UnionMemberTypes :
     *   - = `|`? NamedType
     *   - UnionMemberTypes | NamedType
     */
    ;

    _proto.parseUnionMemberTypes = function parseUnionMemberTypes() {
      var types = [];

      if (this.expectOptionalToken(TokenKind.EQUALS)) {
        // Optional leading pipe
        this.expectOptionalToken(TokenKind.PIPE);

        do {
          types.push(this.parseNamedType());
        } while (this.expectOptionalToken(TokenKind.PIPE));
      }

      return types;
    }
    /**
     * EnumTypeDefinition :
     *   - Description? enum Name Directives[Const]? EnumValuesDefinition?
     */
    ;

    _proto.parseEnumTypeDefinition = function parseEnumTypeDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('enum');
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      var values = this.parseEnumValuesDefinition();
      return {
        kind: Kind.ENUM_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        values: values,
        loc: this.loc(start)
      };
    }
    /**
     * EnumValuesDefinition : { EnumValueDefinition+ }
     */
    ;

    _proto.parseEnumValuesDefinition = function parseEnumValuesDefinition() {
      return this.optionalMany(TokenKind.BRACE_L, this.parseEnumValueDefinition, TokenKind.BRACE_R);
    }
    /**
     * EnumValueDefinition : Description? EnumValue Directives[Const]?
     *
     * EnumValue : Name
     */
    ;

    _proto.parseEnumValueDefinition = function parseEnumValueDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      return {
        kind: Kind.ENUM_VALUE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        loc: this.loc(start)
      };
    }
    /**
     * InputObjectTypeDefinition :
     *   - Description? input Name Directives[Const]? InputFieldsDefinition?
     */
    ;

    _proto.parseInputObjectTypeDefinition = function parseInputObjectTypeDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('input');
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      var fields = this.parseInputFieldsDefinition();
      return {
        kind: Kind.INPUT_OBJECT_TYPE_DEFINITION,
        description: description,
        name: name,
        directives: directives,
        fields: fields,
        loc: this.loc(start)
      };
    }
    /**
     * InputFieldsDefinition : { InputValueDefinition+ }
     */
    ;

    _proto.parseInputFieldsDefinition = function parseInputFieldsDefinition() {
      return this.optionalMany(TokenKind.BRACE_L, this.parseInputValueDef, TokenKind.BRACE_R);
    }
    /**
     * TypeSystemExtension :
     *   - SchemaExtension
     *   - TypeExtension
     *
     * TypeExtension :
     *   - ScalarTypeExtension
     *   - ObjectTypeExtension
     *   - InterfaceTypeExtension
     *   - UnionTypeExtension
     *   - EnumTypeExtension
     *   - InputObjectTypeDefinition
     */
    ;

    _proto.parseTypeSystemExtension = function parseTypeSystemExtension() {
      var keywordToken = this._lexer.lookahead();

      if (keywordToken.kind === TokenKind.NAME) {
        switch (keywordToken.value) {
          case 'schema':
            return this.parseSchemaExtension();

          case 'scalar':
            return this.parseScalarTypeExtension();

          case 'type':
            return this.parseObjectTypeExtension();

          case 'interface':
            return this.parseInterfaceTypeExtension();

          case 'union':
            return this.parseUnionTypeExtension();

          case 'enum':
            return this.parseEnumTypeExtension();

          case 'input':
            return this.parseInputObjectTypeExtension();
        }
      }

      throw this.unexpected(keywordToken);
    }
    /**
     * SchemaExtension :
     *  - extend schema Directives[Const]? { OperationTypeDefinition+ }
     *  - extend schema Directives[Const]
     */
    ;

    _proto.parseSchemaExtension = function parseSchemaExtension() {
      var start = this._lexer.token;
      this.expectKeyword('extend');
      this.expectKeyword('schema');
      var directives = this.parseDirectives(true);
      var operationTypes = this.optionalMany(TokenKind.BRACE_L, this.parseOperationTypeDefinition, TokenKind.BRACE_R);

      if (directives.length === 0 && operationTypes.length === 0) {
        throw this.unexpected();
      }

      return {
        kind: Kind.SCHEMA_EXTENSION,
        directives: directives,
        operationTypes: operationTypes,
        loc: this.loc(start)
      };
    }
    /**
     * ScalarTypeExtension :
     *   - extend scalar Name Directives[Const]
     */
    ;

    _proto.parseScalarTypeExtension = function parseScalarTypeExtension() {
      var start = this._lexer.token;
      this.expectKeyword('extend');
      this.expectKeyword('scalar');
      var name = this.parseName();
      var directives = this.parseDirectives(true);

      if (directives.length === 0) {
        throw this.unexpected();
      }

      return {
        kind: Kind.SCALAR_TYPE_EXTENSION,
        name: name,
        directives: directives,
        loc: this.loc(start)
      };
    }
    /**
     * ObjectTypeExtension :
     *  - extend type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
     *  - extend type Name ImplementsInterfaces? Directives[Const]
     *  - extend type Name ImplementsInterfaces
     */
    ;

    _proto.parseObjectTypeExtension = function parseObjectTypeExtension() {
      var start = this._lexer.token;
      this.expectKeyword('extend');
      this.expectKeyword('type');
      var name = this.parseName();
      var interfaces = this.parseImplementsInterfaces();
      var directives = this.parseDirectives(true);
      var fields = this.parseFieldsDefinition();

      if (interfaces.length === 0 && directives.length === 0 && fields.length === 0) {
        throw this.unexpected();
      }

      return {
        kind: Kind.OBJECT_TYPE_EXTENSION,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: this.loc(start)
      };
    }
    /**
     * InterfaceTypeExtension :
     *  - extend interface Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
     *  - extend interface Name ImplementsInterfaces? Directives[Const]
     *  - extend interface Name ImplementsInterfaces
     */
    ;

    _proto.parseInterfaceTypeExtension = function parseInterfaceTypeExtension() {
      var start = this._lexer.token;
      this.expectKeyword('extend');
      this.expectKeyword('interface');
      var name = this.parseName();
      var interfaces = this.parseImplementsInterfaces();
      var directives = this.parseDirectives(true);
      var fields = this.parseFieldsDefinition();

      if (interfaces.length === 0 && directives.length === 0 && fields.length === 0) {
        throw this.unexpected();
      }

      return {
        kind: Kind.INTERFACE_TYPE_EXTENSION,
        name: name,
        interfaces: interfaces,
        directives: directives,
        fields: fields,
        loc: this.loc(start)
      };
    }
    /**
     * UnionTypeExtension :
     *   - extend union Name Directives[Const]? UnionMemberTypes
     *   - extend union Name Directives[Const]
     */
    ;

    _proto.parseUnionTypeExtension = function parseUnionTypeExtension() {
      var start = this._lexer.token;
      this.expectKeyword('extend');
      this.expectKeyword('union');
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      var types = this.parseUnionMemberTypes();

      if (directives.length === 0 && types.length === 0) {
        throw this.unexpected();
      }

      return {
        kind: Kind.UNION_TYPE_EXTENSION,
        name: name,
        directives: directives,
        types: types,
        loc: this.loc(start)
      };
    }
    /**
     * EnumTypeExtension :
     *   - extend enum Name Directives[Const]? EnumValuesDefinition
     *   - extend enum Name Directives[Const]
     */
    ;

    _proto.parseEnumTypeExtension = function parseEnumTypeExtension() {
      var start = this._lexer.token;
      this.expectKeyword('extend');
      this.expectKeyword('enum');
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      var values = this.parseEnumValuesDefinition();

      if (directives.length === 0 && values.length === 0) {
        throw this.unexpected();
      }

      return {
        kind: Kind.ENUM_TYPE_EXTENSION,
        name: name,
        directives: directives,
        values: values,
        loc: this.loc(start)
      };
    }
    /**
     * InputObjectTypeExtension :
     *   - extend input Name Directives[Const]? InputFieldsDefinition
     *   - extend input Name Directives[Const]
     */
    ;

    _proto.parseInputObjectTypeExtension = function parseInputObjectTypeExtension() {
      var start = this._lexer.token;
      this.expectKeyword('extend');
      this.expectKeyword('input');
      var name = this.parseName();
      var directives = this.parseDirectives(true);
      var fields = this.parseInputFieldsDefinition();

      if (directives.length === 0 && fields.length === 0) {
        throw this.unexpected();
      }

      return {
        kind: Kind.INPUT_OBJECT_TYPE_EXTENSION,
        name: name,
        directives: directives,
        fields: fields,
        loc: this.loc(start)
      };
    }
    /**
     * DirectiveDefinition :
     *   - Description? directive @ Name ArgumentsDefinition? `repeatable`? on DirectiveLocations
     */
    ;

    _proto.parseDirectiveDefinition = function parseDirectiveDefinition() {
      var start = this._lexer.token;
      var description = this.parseDescription();
      this.expectKeyword('directive');
      this.expectToken(TokenKind.AT);
      var name = this.parseName();
      var args = this.parseArgumentDefs();
      var repeatable = this.expectOptionalKeyword('repeatable');
      this.expectKeyword('on');
      var locations = this.parseDirectiveLocations();
      return {
        kind: Kind.DIRECTIVE_DEFINITION,
        description: description,
        name: name,
        arguments: args,
        repeatable: repeatable,
        locations: locations,
        loc: this.loc(start)
      };
    }
    /**
     * DirectiveLocations :
     *   - `|`? DirectiveLocation
     *   - DirectiveLocations | DirectiveLocation
     */
    ;

    _proto.parseDirectiveLocations = function parseDirectiveLocations() {
      // Optional leading pipe
      this.expectOptionalToken(TokenKind.PIPE);
      var locations = [];

      do {
        locations.push(this.parseDirectiveLocation());
      } while (this.expectOptionalToken(TokenKind.PIPE));

      return locations;
    }
    /*
     * DirectiveLocation :
     *   - ExecutableDirectiveLocation
     *   - TypeSystemDirectiveLocation
     *
     * ExecutableDirectiveLocation : one of
     *   `QUERY`
     *   `MUTATION`
     *   `SUBSCRIPTION`
     *   `FIELD`
     *   `FRAGMENT_DEFINITION`
     *   `FRAGMENT_SPREAD`
     *   `INLINE_FRAGMENT`
     *
     * TypeSystemDirectiveLocation : one of
     *   `SCHEMA`
     *   `SCALAR`
     *   `OBJECT`
     *   `FIELD_DEFINITION`
     *   `ARGUMENT_DEFINITION`
     *   `INTERFACE`
     *   `UNION`
     *   `ENUM`
     *   `ENUM_VALUE`
     *   `INPUT_OBJECT`
     *   `INPUT_FIELD_DEFINITION`
     */
    ;

    _proto.parseDirectiveLocation = function parseDirectiveLocation() {
      var start = this._lexer.token;
      var name = this.parseName();

      if (DirectiveLocation[name.value] !== undefined) {
        return name;
      }

      throw this.unexpected(start);
    } // Core parsing utility functions

    /**
     * Returns a location object, used to identify the place in
     * the source that created a given parsed object.
     */
    ;

    _proto.loc = function loc(startToken) {
      var _this$_options4;

      if (((_this$_options4 = this._options) === null || _this$_options4 === void 0 ? void 0 : _this$_options4.noLocation) !== true) {
        return new Location(startToken, this._lexer.lastToken, this._lexer.source);
      }
    }
    /**
     * Determines if the next token is of a given kind
     */
    ;

    _proto.peek = function peek(kind) {
      return this._lexer.token.kind === kind;
    }
    /**
     * If the next token is of the given kind, return that token after advancing
     * the lexer. Otherwise, do not change the parser state and throw an error.
     */
    ;

    _proto.expectToken = function expectToken(kind) {
      var token = this._lexer.token;

      if (token.kind === kind) {
        this._lexer.advance();

        return token;
      }

      throw syntaxError(this._lexer.source, token.start, "Expected ".concat(getTokenKindDesc(kind), ", found ").concat(getTokenDesc(token), "."));
    }
    /**
     * If the next token is of the given kind, return that token after advancing
     * the lexer. Otherwise, do not change the parser state and return undefined.
     */
    ;

    _proto.expectOptionalToken = function expectOptionalToken(kind) {
      var token = this._lexer.token;

      if (token.kind === kind) {
        this._lexer.advance();

        return token;
      }

      return undefined;
    }
    /**
     * If the next token is a given keyword, advance the lexer.
     * Otherwise, do not change the parser state and throw an error.
     */
    ;

    _proto.expectKeyword = function expectKeyword(value) {
      var token = this._lexer.token;

      if (token.kind === TokenKind.NAME && token.value === value) {
        this._lexer.advance();
      } else {
        throw syntaxError(this._lexer.source, token.start, "Expected \"".concat(value, "\", found ").concat(getTokenDesc(token), "."));
      }
    }
    /**
     * If the next token is a given keyword, return "true" after advancing
     * the lexer. Otherwise, do not change the parser state and return "false".
     */
    ;

    _proto.expectOptionalKeyword = function expectOptionalKeyword(value) {
      var token = this._lexer.token;

      if (token.kind === TokenKind.NAME && token.value === value) {
        this._lexer.advance();

        return true;
      }

      return false;
    }
    /**
     * Helper function for creating an error when an unexpected lexed token
     * is encountered.
     */
    ;

    _proto.unexpected = function unexpected(atToken) {
      var token = atToken !== null && atToken !== void 0 ? atToken : this._lexer.token;
      return syntaxError(this._lexer.source, token.start, "Unexpected ".concat(getTokenDesc(token), "."));
    }
    /**
     * Returns a possibly empty list of parse nodes, determined by
     * the parseFn. This list begins with a lex token of openKind
     * and ends with a lex token of closeKind. Advances the parser
     * to the next lex token after the closing token.
     */
    ;

    _proto.any = function any(openKind, parseFn, closeKind) {
      this.expectToken(openKind);
      var nodes = [];

      while (!this.expectOptionalToken(closeKind)) {
        nodes.push(parseFn.call(this));
      }

      return nodes;
    }
    /**
     * Returns a list of parse nodes, determined by the parseFn.
     * It can be empty only if open token is missing otherwise it will always
     * return non-empty list that begins with a lex token of openKind and ends
     * with a lex token of closeKind. Advances the parser to the next lex token
     * after the closing token.
     */
    ;

    _proto.optionalMany = function optionalMany(openKind, parseFn, closeKind) {
      if (this.expectOptionalToken(openKind)) {
        var nodes = [];

        do {
          nodes.push(parseFn.call(this));
        } while (!this.expectOptionalToken(closeKind));

        return nodes;
      }

      return [];
    }
    /**
     * Returns a non-empty list of parse nodes, determined by
     * the parseFn. This list begins with a lex token of openKind
     * and ends with a lex token of closeKind. Advances the parser
     * to the next lex token after the closing token.
     */
    ;

    _proto.many = function many(openKind, parseFn, closeKind) {
      this.expectToken(openKind);
      var nodes = [];

      do {
        nodes.push(parseFn.call(this));
      } while (!this.expectOptionalToken(closeKind));

      return nodes;
    };

    return Parser;
  }();
  /**
   * A helper function to describe a token as a string for debugging
   */


  function getTokenDesc(token) {
    var value = token.value;
    return getTokenKindDesc(token.kind) + (value != null ? " \"".concat(value, "\"") : '');
  }
  /**
   * A helper function to describe a token kind as a string for debugging
   */


  function getTokenKindDesc(kind) {
    return isPunctuatorTokenKind(kind) ? "\"".concat(kind, "\"") : kind;
  }

  var parser = /*#__PURE__*/Object.freeze({
    __proto__: null,
    parse: parse,
    parseValue: parseValue,
    parseType: parseType
  });

  var parser$1 = getCjsExportFromNamespace(parser);

  var parse$1 = parser$1.parse; // Strip insignificant whitespace
  // Note that this could do a lot more, such as reorder fields etc.

  function normalize(string) {
    return string.replace(/[\s,]+/g, ' ').trim();
  } // A map docString -> graphql document


  var docCache = {}; // A map fragmentName -> [normalized source]

  var fragmentSourceMap = {};

  function cacheKeyFromLoc(loc) {
    return normalize(loc.source.body.substring(loc.start, loc.end));
  } // For testing.


  function resetCaches() {
    docCache = {};
    fragmentSourceMap = {};
  } // Take a unstripped parsed document (query/mutation or even fragment), and
  // check all fragment definitions, checking for name->source uniqueness.
  // We also want to make sure only unique fragments exist in the document.


  var printFragmentWarnings = true;

  function processFragments(ast) {
    var astFragmentMap = {};
    var definitions = [];

    for (var i = 0; i < ast.definitions.length; i++) {
      var fragmentDefinition = ast.definitions[i];

      if (fragmentDefinition.kind === 'FragmentDefinition') {
        var fragmentName = fragmentDefinition.name.value;
        var sourceKey = cacheKeyFromLoc(fragmentDefinition.loc); // We know something about this fragment

        if (fragmentSourceMap.hasOwnProperty(fragmentName) && !fragmentSourceMap[fragmentName][sourceKey]) {
          // this is a problem because the app developer is trying to register another fragment with
          // the same name as one previously registered. So, we tell them about it.
          if (printFragmentWarnings) {
            console.warn("Warning: fragment with name " + fragmentName + " already exists.\n" + "graphql-tag enforces all fragment names across your application to be unique; read more about\n" + "this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names");
          }

          fragmentSourceMap[fragmentName][sourceKey] = true;
        } else if (!fragmentSourceMap.hasOwnProperty(fragmentName)) {
          fragmentSourceMap[fragmentName] = {};
          fragmentSourceMap[fragmentName][sourceKey] = true;
        }

        if (!astFragmentMap[sourceKey]) {
          astFragmentMap[sourceKey] = true;
          definitions.push(fragmentDefinition);
        }
      } else {
        definitions.push(fragmentDefinition);
      }
    }

    ast.definitions = definitions;
    return ast;
  }

  function disableFragmentWarnings() {
    printFragmentWarnings = false;
  }

  function stripLoc(doc, removeLocAtThisLevel) {
    var docType = Object.prototype.toString.call(doc);

    if (docType === '[object Array]') {
      return doc.map(function (d) {
        return stripLoc(d, removeLocAtThisLevel);
      });
    }

    if (docType !== '[object Object]') {
      throw new Error('Unexpected input.');
    } // We don't want to remove the root loc field so we can use it
    // for fragment substitution (see below)


    if (removeLocAtThisLevel && doc.loc) {
      delete doc.loc;
    } // https://github.com/apollographql/graphql-tag/issues/40


    if (doc.loc) {
      delete doc.loc.startToken;
      delete doc.loc.endToken;
    }

    var keys = Object.keys(doc);
    var key;
    var value;
    var valueType;

    for (key in keys) {
      if (keys.hasOwnProperty(key)) {
        value = doc[keys[key]];
        valueType = Object.prototype.toString.call(value);

        if (valueType === '[object Object]' || valueType === '[object Array]') {
          doc[keys[key]] = stripLoc(value, true);
        }
      }
    }

    return doc;
  }

  var experimentalFragmentVariables = false;

  function parseDocument(doc) {
    var cacheKey = normalize(doc);

    if (docCache[cacheKey]) {
      return docCache[cacheKey];
    }

    var parsed = parse$1(doc, {
      experimentalFragmentVariables: experimentalFragmentVariables
    });

    if (!parsed || parsed.kind !== 'Document') {
      throw new Error('Not a valid GraphQL document.');
    } // check that all "new" fragments inside the documents are consistent with
    // existing fragments of the same name


    parsed = processFragments(parsed);
    parsed = stripLoc(parsed, false);
    docCache[cacheKey] = parsed;
    return parsed;
  }

  function enableExperimentalFragmentVariables() {
    experimentalFragmentVariables = true;
  }

  function disableExperimentalFragmentVariables() {
    experimentalFragmentVariables = false;
  } // XXX This should eventually disallow arbitrary string interpolation, like Relay does


  function gql()
  /* arguments */
  {
    var args = Array.prototype.slice.call(arguments);
    var literals = args[0]; // We always get literals[0] and then matching post literals for each arg given

    var result = typeof literals === "string" ? literals : literals[0];

    for (var i = 1; i < args.length; i++) {
      if (args[i] && args[i].kind && args[i].kind === 'Document') {
        result += args[i].loc.source.body;
      } else {
        result += args[i];
      }

      result += literals[i];
    }

    return parseDocument(result);
  } // Support typescript, which isn't as nice as Babel about default exports


  gql.default = gql;
  gql.resetCaches = resetCaches;
  gql.disableFragmentWarnings = disableFragmentWarnings;
  gql.enableExperimentalFragmentVariables = enableExperimentalFragmentVariables;
  gql.disableExperimentalFragmentVariables = disableExperimentalFragmentVariables;
  var src = gql;

  const APOLLO_KEY = "__lwcapolloc_client__";
  function getClient() {
    return window[APOLLO_KEY];
  }
  function setClient(client) {
    return window[APOLLO_KEY] = client;
  }

  function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

  function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }
  class useQuery {
    constructor(dataCallback) {
      this.connected = false;
      this.dataCallback = dataCallback;
      this.pendingResult = {
        client: undefined,
        loading: false,
        data: undefined,
        error: undefined,
        initialized: false,
        fetch: this.fetch.bind(this)
      };
    }

    update(config) {
      const {
        client,
        lazy
      } = config,
            props = _objectWithoutProperties(config, ["client", "lazy"]);

      this.apolloOptions = props;
      this.pendingResult.client = client || getClient();

      if (!lazy) {
        this.fetch();
      } else {
        this.sendUpdate();
      }
    }

    connect() {
      this.connected = true;
      this.sendUpdate();
    }

    disconnect() {
      this.connected = false;

      if (this.subscription) {
        this.subscription.unsubscribe();
      }
    }

    sendUpdate() {
      if (this.connected) {
        // Make a copy to make the notification effective and prevent changes (ex: client instance)
        const o = Object.assign({}, this.pendingResult);
        this.dataCallback(o);
      }
    }

    fetch(options) {
      const mergedOptions = _objectSpread({}, this.apolloOptions, options);

      this.pendingResult.loading = true;
      this.sendUpdate();

      try {
        if (this.subscription) {
          this.subscription.unsubscribe();
        }

        this.observableQuery = this.pendingResult.client.watchQuery(mergedOptions);
        this.subscription = this.observableQuery.subscribe(({
          data,
          loading,
          errors
        }) => {
          Object.assign(this.pendingResult, {
            loading,
            data,
            error: errors,
            initialized: true
          });
          this.sendUpdate();
        });
      } catch (error) {
        Object.assign(this.pendingResult, {
          loading: false,
          data: undefined,
          error,
          initialized: true
        });
        this.sendUpdate();
      }
    }

  }

  function stylesheet(hostSelector, shadowSelector, nativeShadow) {
    return ".greet" + shadowSelector + " {font-size: xx-large;}\n.fade-fast" + shadowSelector + " {opacity: 0;animation: fade-in 1s;}\n.fade-slow" + shadowSelector + " {opacity: 0;animation: fade-in 5s;}\n.fade-medium" + shadowSelector + " {opacity: 0;animation: fade-in 2s;}\n@keyframes fade-in {0% {opacity: 0;}\n35% {opacity: 1;}\n65% {opacity: 1;}\n100% {opacity: 0;}\n}.hide" + shadowSelector + " {opacity: 0;}\n.div1" + shadowSelector + "{margin:10px;font-size:1.25em;}\n.table" + shadowSelector + "{border-collapse:collapse;border: 2px solid black;}\n.td" + shadowSelector + "{border: 2px solid black;width:100px;height:100px;text-align:center;}\n";
  }
  var _implicitStylesheets = [stylesheet];

  function tmpl($api, $cmp, $slotset, $ctx) {
    const {
      t: api_text,
      h: api_element,
      d: api_dynamic
    } = $api;
    return [api_element("div", {
      key: 2
    }, [!$cmp.isBundle ? api_element("h1", {
      key: 0
    }, [api_text("Data below: ")]) : null, !$cmp.isBundle ? $cmp.results.loading ? api_text("Loading....") : null : null, !$cmp.isBundle ? $cmp.results.error ? api_text("Man, there is an error ") : null : null, !$cmp.isBundle ? $cmp.results.error ? api_dynamic($cmp.results.error) : null : null, !$cmp.isBundle ? $cmp.results.data ? api_element("div", {
      key: 1
    }, [api_dynamic($cmp.drawTable)]) : null : null])];
  }

  var _tmpl$1 = registerTemplate(tmpl);
  tmpl.stylesheets = [];

  if (_implicitStylesheets) {
    tmpl.stylesheets.push.apply(tmpl.stylesheets, _implicitStylesheets);
  }
  tmpl.stylesheetTokens = {
    hostAttribute: "my-greeting_greeting-host",
    shadowAttribute: "my-greeting_greeting"
  };

  const QUERY = src`
query($pidList: [String]) {
    multipleProducts(pidList: $pidList){
        id
        name
        master{
                    masterId
                    orderable
                    price
                }
                price
                prices{
                    sale
                    list
                }
                currency
                longDescription
                shortDescription
                variants{
                productId
                orderable
                price
                variationValues{
                    color
                    size
                }
                }
                type{
                bundle
                item
                master
                option
                set
                }
                productPromotions{
                calloutMsg
                promotionalPrice
                promotionId
                }
                pageDescription
                pageTitle
                recommendations{
                recommendedItemId
                recommendedItemLink
                }
    }
    }
`;
  var QUERY$1 = registerComponent(QUERY, {
    tmpl: _tmpl
  });

  function _objectSpread$1(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty$1(target, key, source[key]); }); } return target; }

  function _defineProperty$1(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  class Greeting extends BaseLightningElement {
    constructor(...args) {
      super(...args);
      this.isBundle = false;
      this.attributes = ["name", "price", "shortDescription", "variants"];
      this.variables = {
        pidList: ''
      };
      this.results = void 0;
    }

    set pid(val) {
      var temp = this.strToArr(val);
      console.log("inside set pid, pidList:", temp);
      this.variables = _objectSpread$1({}, this.variables, {
        pidList: temp
      });
    }

    get pid() {
      return this.variables.pidList;
    }

    strToArr(val) {
      console.log("inside strToArr function");
      var pidStr = val;
      console.log("inside strToArr pid: ", pidStr);
      let pidSlice = pidStr.slice(1, pidStr.length - 1);
      let pidList = pidSlice.split(",");

      for (var i = 0; i < pidList.length; i++) {
        pidList[i] = pidList[i].trim();
        var tempStr = pidList[i].toString();

        if (tempStr.includes("bundle")) {
          this.isBundle = true;
        }
      }

      console.log("inside strToArr pidList: ", pidList[1]);
      return pidList; //this.pidList( this.pidList);
    }

    async connectedCallback() {
      if (this.isBundle == false) {
        this.results.fetch({
          variables: _objectSpread$1({}, this.variables)
        });
      }
    }

    get firstResult() {
      // console.log("value of pidList", this.pid());
      if (this.isBundle == false) {
        console.log("inside firstResult: ", this.results);
        return this.results.loading ? "" : this.results.data.multipleProducts;
      }
    }

    productArr() {
      var multiProd = this.results.data.multipleProducts;

      for (var i = 0; i < multiProd.length; i++) {}
    }

    get drawTable() {
      var multiProd = this.results.data.multipleProducts;
      var totalRows = this.attributes.length;
      var cellsInRow = multiProd.length;
      var div1 = document.getElementById("div1");
      console.log("div1", div1);
      var tbl = document.createElement("table");
      tbl.style = "width: 100%;border-collapse:collapse;border: 2px solid black;"; //tbl.setAttribute("class", "democlass");

      console.log("tbl", tbl);

      for (var r = 0; r < totalRows; r++) {
        var row = document.createElement("tr");
        row.style = "border: 1px solid black;";
        var cell = document.createElement("td");
        var cellText = document.createTextNode(this.attributes[r]);
        cell.style = "border: 1px solid black;width:100px;height:50px;text-align:center;";
        cell.appendChild(cellText);
        row.appendChild(cell);

        for (var c = 1; c <= cellsInRow; c++) {
          var v = c - 1;
          var map = new Map();
          let obj = multiProd[v];
          Object.keys(obj).forEach(key => {
            map.set(key, obj[key]);
          });
          console.log("inside drawtable");
          var cell = document.createElement("td");
          cell.style = "border: 1px solid black;width:100px;height:50px;text-align:center;";
          var name = this.attributes[r];
          console.log("val of name: ", name);
          console.log("val of map.get(string): ", map.get(name));
          var cellText = document.createTextNode(map.get(name));
          cell.appendChild(cellText);
          row.appendChild(cell);
        }

        tbl.appendChild(row); // add the row to the end of the table body
      }

      div1.appendChild(tbl); // appends <table> into <div1>
    }

  }

  registerDecorators(Greeting, {
    publicProps: {
      pid: {
        config: 3
      }
    },
    wire: {
      results: {
        adapter: useQuery,
        params: {
          variables: "variables"
        },
        static: {
          query: QUERY$1,
          lazy: false
        },
        config: function ($cmp) {
          return {
            query: QUERY$1,
            lazy: false,
            variables: $cmp.variables
          };
        }
      }
    },
    fields: ["isBundle", "attributes", "variables"]
  });

  var Greeting$1 = registerComponent(Greeting, {
    tmpl: _tmpl$1
  });

  /* eslint-disable no-constant-condition */
  const httpLink = new HttpLink({
    uri: 'https://safe-brushlands-35946.herokuapp.com//'
  });
  const authLink = new ApolloLink((operation, forward) => {
    // Call the next link in the middleware chain.
    return forward(operation);
  });
  const defaultOptions$1 = {
    watchQuery: {
      fetchPolicy: 'no-cache',
      errorPolicy: 'all'
    },
    query: {
      fetchPolicy: 'no-cache',
      errorPolicy: 'all'
    }
  };
  setClient(new ApolloClient({
    link: authLink.concat(httpLink),
    // Chain it with the HttpLink
    cache: new InMemoryCache(),
    defaultOptions: defaultOptions$1
  })); // Components to export
  // This function can be removed if the components are not going to be used as custom elements

  if ( typeof customElements !== 'undefined') {
    customElements.define('my-greeting', deprecatedBuildCustomElementConstructor(Greeting$1));
  } // Register a function to create the components dynamically
  // This function can be removed if the components are not going to be created that way


  {
    const delegate = window.createLwcComponent;

    window.createLwcComponent = function createLwcComponent(name) {
      if (name === "my-greeting") {
        return createElement("my-greeting", {
          is: Greeting$1
        });
      }

      return delegate ? delegate(name) : null;
    };
  }

}());
//# sourceMappingURL=lwc-components.js.map
