class GreetingAppPage {
}
module.exports = new GreetingAppPage();
